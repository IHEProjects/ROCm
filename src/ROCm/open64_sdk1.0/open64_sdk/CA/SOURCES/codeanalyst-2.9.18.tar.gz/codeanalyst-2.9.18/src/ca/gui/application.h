//$Id: application.h,v 1.11 2006/05/15 22:09:22 jyeh Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef APPLICATION_H
#define APPLICATION_H

#include <vector>
#include <string>
#include <map>

#include "cawfile.h"
#include "projectwindow.h"
#include "progressmgr.h"
#include "tbsStruct.h"
#include "sessionnav.h"
#include "ImportWizard.h"
#include "oprofile_interface.h"
#include "translatedlg.h"
#include "catranslate.h"
#include "opdata_handler.h"
#include "catranslate_display.h"
#include "newProjectDlg.h"
#include "ProfileCollection.h"
#include "eventsfile.h"
#include "ImportController.h"
#include "OprofileDaemonDockView.h"
#include "OprofileDriverDockView.h"

/// Headers from Oprofile
//#include "op_config.h"

using namespace std;


////////////////////////////////////
// Menu ID's under the Sampling Menu
//
enum {
	SM_START = 0,
	SM_PAUSE,
	SM_STOP,
	SM_ABORT,
	SM_OPTIONS,
	MAX_MENU_NUM
};

///////////////////////////////////
// Menu ID's under the Tools Menu
enum {
	TM_SETTINGS = 0,
	TM_CAOPTIONS,
	TM_EDITPROFILES,
	TM_EDITVIEWS,
	TM_DIFFANALYST,
	TM_DAEMON_MONITOR,
	TM_DRIVER_MONITOR,
	TM_LAST
};

///////////////////////////////////
// Position of the Tool Bar menu item
#define FILE_TB_ID	0
#define SAMP_TB_ID	1
#define TRACE_TB_ID	2

#define MAX_TOOLBARS	4

///////////////////////////////////
// Sampling States
//
enum SAMPLING_STATE
{
	SS_IDLE,
	SS_DELAY,
	SS_START_PROFILE,
	SS_START_APP,
	SS_PAUSED,
	SS_RESUMED,
	SS_FINISHED
};


//////////////////////////////////////////////////////////////////////////
// MruEntry
//
//////////////////////////////////////////////////////////////////////////
typedef struct _MruEntry
{
	QString filePath;
	int	index;
} MruEntry, *PMruEntry;

typedef QValueList<MruEntry> MruList;


//////////////////////////////////////////////////////////////////////////
// PID_MAP_T
//
//////////////////////////////////////////////////////////////////////////
typedef QMap<unsigned int, unsigned int>  PID_MAP_T;


const QString OP_DEFAULT_SAMPLE_DIR =  OP_SAMPLES_DIR;
const QString OP_DEFAULT_DIR = OP_BASE_DIR;
const QString DLG_ALLOC_ERROR_MSG = "Could not allocate memory for the dialog box";



//////////////////////////////////////////////////////////////////////////
class ApplicationWindow: public QMainWindow
{
	Q_OBJECT
public:
	ApplicationWindow();
	~ApplicationWindow();

public:
	QString getCurrentFilePath();
	bool setSamplingState( SAMPLING_STATE State );

protected:
	void customEvent( QCustomEvent *pCustEvent );
	void closeEvent( QCloseEvent *pCloseEvent );
	void saveMRUToReg();

private slots:
	void targetExit();
	void onFileNew();
	void onAboutToQuit();

	void onFileOpen();
	void onFileSave();
	void onFileClose(bool *isOk=NULL);

	void onHelpAbout();
	void onHelpContents();
	void onHelpSysInfo();

	void windowsMenuAboutToShow();
	void windowsMenuActivated( int id );
	QWidget* findWindow( QString caption );
	void onCascade();
	void onToggleChartDensity ();

	void initProjectWindow();

	void onSamplingStart();
	void onSamplingPause();
	void onSamplingStop ();

	void OnProfileChange (const QString &profile);

	void onMruItemSelected(int id);


	void onSessionDeletedOnly (TRIGGER trigger, QString SessionName);
	void onSessionDeleted (TRIGGER trigger, QString SessionName);
	void onSessionDblClicked (TRIGGER trigger, QString SessionName);
	void onSessionRenamed (TRIGGER trigger, QString oldName);
	void onTbsSessionProperties( QString SessionName );
	void onEbsSessionProperties( QString SessionName );
	void OnCopySessionToCurrent (TRIGGER trigger, QString SessionName);

	int OnSessionSettings();
	int onToolsATuneOptions();
	void OnProfileManage ();
	void OnViewManage ();
	void OnOpenDiffAnalyst(DiffSessionInfo *sess = NULL);
	void OnOpenKcachegrind(QString sessionDirName);

	void onWindowActivated( QWidget *pWnd );
	void onDataViewChanged( QString exportString, QListView *pList );
	void onModuleProcessingClosed();
	void onExportData();
	void onImportData();
	void onOprofileDaemonDockViewNoShow();
	void onOprofileDriverDockViewNoShow();
	void onOprofileDaemonDockViewToggle();
	void onOprofileDriverDockViewToggle();
	void onInitOprofileDaemonDockView();
	void onInitOprofileDriverDockView();

	void closeAllWindows();


signals:
	void densityVisibilityChanged ();
	void shownChanged(QString viewName);

private:
	void setDefaultSize(QWidget* pWnd);
	bool startProfiling();

	void setGUIButtonsStart();
	int launchProgressManager();	
	bool runEbs ();
	bool runTbs ();
	void LoadFile( QString FileName );
	void resizeAllWindows( QSize NewSize );
	void parseMruString( const char *mrulist );
	void insertMruItems();
	void updateMruFile( QString NewFilePath );
	void removeMruFile( QString filePath );
	bool mruFileContains( QString FilePath );
	void updateMruItemIndex( QString file, int index);
	void registerHotKeys();
	bool sampling();
	bool isCorrectDriverForGH();
	float translateMSToTicks(float ms);

	void handleCADriverInterfaceError(unsigned int errorCode);
	bool ProcessTIPRD (QString ca_result_filename );
	void enumerateDir(QString & dirName, PID_MAP_T & map);
	int isCss32Bit();

	BOOL startDaemon(bool mlinux,
		QString vmlinux_dir, 
		int buffer_size,
		int watershed_size,
		int cpu_buf_size);

	//TODO: place this in the factory class
	bool createOprofileTranslateObjects();
	void deleteOprofileTranslateObjects();

private:
	int		m_ExportDataId;
	int		m_ImportDataId;
	int		m_SaveId;
	int		m_CloseId;
	int             m_toggleDensityId;
	ProjectWindow	*m_pProjWnd;
	QListView	*m_pTree;
	CawFile		*m_pCawFile;
	int		m_SamplingState;
	int		m_FileSepId;
	bool		m_bDocumentOpen;
	bool		m_bHotKeysLoaded;
	bool		m_bFirstDialog;
	bool		m_bLegacyTimer;
	int		m_nDocNum;
	QLabel		*m_pStatusMsg;
	ProgressMgr	*m_pProgress;
	SESSION_OPTIONS *m_pSession;
	TranslateDlg    *m_pTranslateProgressDlg;
	QProgressBar	*m_pStatusProgress;
	QSplitter	*m_pSplitter;
	QVBox		*m_pVBox;
	QWidgetList	m_Windows;
	QListView	*m_pExportList;
	MruList		m_MruList;
	unsigned int	m_tick_per_sec;
	oprofile_interface m_opIf;
	unsigned long 	m_this_cpuFamily;
	unsigned long 	m_this_cpuModel;

	CEventsFile 	m_eventFile;
	uid_t 		m_euid;

	QComboBox 	*m_pProfileBox;
	ProfileCollection m_profiles;

	PID_MAP_T 	m_RecordedPidMap;
	PID_MAP_T 	m_PidMap;

	unsigned int 	m_novmlinux;
	QString 	m_vmlinux;
	unsigned int 	m_sample_buf_size;
	unsigned int 	m_cpu_buf_size;

	SAMPLING_STATE 	m_prevState;

	CATranslate 	*m_pTranslate;
	ca_translate_display *m_pCaTransDisplay;



	/* Which group of the events of EBP_OPTIONS->pEvents is 
	* being profiled by the GUI, only valid when the state of
	* GUI is SS_RUNNING.
	*/
	int m_totalEventGroup;
	QWorkspace	*m_pWs;
	QToolBar	*m_pFileTools;
	QToolBar	*pSamplingToolBar;
	QToolBar	*pNavToolBar;
	QToolBar 	*m_pToolsToolBar;
	QPopupMenu	*m_pWindowsMenu;
	QPopupMenu	*m_pSamplingMenu;
	QPopupMenu	*m_pToolsMenu;
	QPopupMenu	*m_pFileMenu;
	QPopupMenu	*m_pHelpMenu;
	QToolButton 	* m_SamplingToolId[MAX_MENU_NUM];
	QToolButton 	* m_ToolsToolId[TM_LAST];
	QToolButton 	* m_SaveButt;
	int		m_SamplingMenuId[MAX_MENU_NUM];
	int		m_ToolsMenuId[TM_LAST];
	QStringList	m_processFilter;
	ImportController m_importController;
	OprofileDaemonDockView	*m_pOprofileDaemonDockView;
	OprofileDriverDockView	*m_pOprofileDriverDockView;
};

#endif
