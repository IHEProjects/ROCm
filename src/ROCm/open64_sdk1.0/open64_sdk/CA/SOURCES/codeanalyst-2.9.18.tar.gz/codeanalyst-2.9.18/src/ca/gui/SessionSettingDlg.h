//$Id: SessionSettingDlg.h 16863 2009-07-22 18:07:49Z ssuthiku $
//  This is the interface for the SessionSettingDlg class, which derives from
//	ISessionOptions and has different functionality for express vs normal mode

/**
*   (c) 2006 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/

#ifndef SESSION_OPTIONS_DLG_H
#define SESSION_OPTIONS_DLG_H

#include <qstring.h>
#include <qpopupmenu.h>
#include "iSessionSettingDlg.h"
#include "iruncontrol.h"
#include "cawfile.h"
#include "atuneoptions.h"
#include "ProfileCollection.h"
#include "CpuAffinityDlg.h"
#include "eventsfile.h"

const QString CAJVMPIA = " -XrunCAJVMPIA";
const QString CAJVMTIA_LIB_PATH = CA_LIB_DIR;
const QString CAJVMTIA = " -agentpath:" + CAJVMTIA_LIB_PATH + "/libCAJVMTIA";

class SessionSettingDlg : public iSessionSettingDlg
{ 
	Q_OBJECT

public:

	enum SessionTab {
		TAB_GENERAL=0,
		TAB_ADVANCE,
		TAB_NOTE,
		TAB_LOG	
	};

	SessionSettingDlg (CawFile *pCawFile, 
		CEventsFile * pEventsFile,
		QWidget* parent = 0, 
		const char* name = 0, 
		bool modal = true, 
		WFlags fl = WStyle_Customize | 
				WStyle_DialogBorder | 
				WStyle_Title | 
				WDestructiveClose);

	virtual ~SessionSettingDlg();

	void initFromCawFile(ProfileCollection * pProfiles);
	void initPropertyView(QString sessionName, TRIGGER trigger);
	QStringList getProcessFilter();
	bool isApplyProcessFilter();

private:
	bool saveToCawFile();
	virtual void fillProfiles (ProfileCollection * pProfiles);
	bool validateCurrentSetting();
	void verifyJavaAgent (QString bitness);
	QString verifyJavaBitness (QString javaFile);
	bool isFile32Bit (const char* fileName);
	void updateWithCurrentSetting(bool isProperty = false);
	void saveSettingFromGui(RUN_SETTING * pRunSetting);
	QString getEventName(unsigned int value);
	bool validateOprofileBufferSetting();
	bool validateProcessFilter();
	bool validateCss();
	void setupProfileViewer(TBP_OPTIONS opt);
	void setupProfileViewer(EBP_OPTIONS opt);
	void importOprofileLog(QString sessionName);

private slots:
	void onSave ();
	void onOk();

	//-----------------
	// Setting Explorer
	void onSettingAdd (QString name = QString(), RUN_SETTING * pRunSetting = NULL);
	void onSettingRemove (QString name = QString());
	void onSettingChange(QListBoxItem * item); 
	void onSettingRename() ;
	void onSettingDuplicate() ;
	void onSettingRightClicked ( QListBoxItem * item, const QPoint &pt);

	//-----------------
	// General Tab
	void onLaunchChange (const QString & string);
	void onBrowseLaunch ();
	void onBrowseWorkDir ();
	void onCheckDuration ();
	void onToggleStopOnExit(bool b);
	
	void onProfileEdit ();
	void onProfileChange (const QString &profile);

	// Affinity
	void onCpuAffinity();
	void onToggleAffinityEnable(bool t);

	// Filter
	void onToggleApplyFilter(bool t);
	void onSetAdvanceFilter();

	//-----------------
	// Advance Tab

	// CSS
	void onToggleCssEnable(bool t);
	void onToggleCssUseTgid(bool t);

	// Vmlinux
	void onToggleVmlinuxEnable(bool t);
	void onVmlinuxBrowse();

	// OProfile buffer
	void onResetBufferSize();
	
	//-----------------
	// Note Tab
	void onClearSessionNote();

	//-----------------
	// Info Tab

signals:
	void enableLaunchItems (bool enable);

protected:
	bool 			m_lastDurationChecked;
	QString 		m_lastDuration;
	QStringList 		m_filterList;
	CawFile *		m_pCawFile;
	ProfileCollection * 	m_pProfiles;
	CpuAffinityDlg *	m_pAffinityDlg;
	RUN_SETTING * 		m_pCurrentSetting;
	CEventsFile *		m_pEventsFile;
	QPopupMenu * 		m_pSettingMenu;
	bool			m_noChange;
	bool			m_isAccept;
};
#endif
