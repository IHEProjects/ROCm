//$Id: opdata_handler.cpp $
// Interface for processing profile data.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <stdlib.h>
#include <vector>
#include <string>
#include <list>
#include <iomanip>
#include <qmessagebox.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// CodeAnalyst headers
#include "opdata_handler.h"
#include "proctree.h"
#include "tbswriter.h"
#include "dataagg.h"

#ifdef HAVE_LIBELF_GELF_H
#include <libelf/gelf.h>
#else
#include <gelf.h>
#endif

using namespace std;


opdata_handler::opdata_handler()
{
	m_ca_display = NULL;
	m_missed = 0;
}

opdata_handler::~opdata_handler()
{
	reset_data();
}

void opdata_handler::reset_data()
{
	m_mod_detail.clear();
	m_mod_summary.clear();
	m_task_summary.clear();
}

void opdata_handler::init(EventMaskEncodeMap evt_map)
{
	m_event_encode_map = evt_map;
}


void opdata_handler::getSortedModset(sorted_mod_set &modset)
{
	typedef map<string, mod_total> M;
	M::iterator it, it_end;
	M m;

	mod_summary_list::iterator m_it = m_mod_summary.begin();
	mod_summary_list::iterator m_it_end = m_mod_summary.end();
	for (; m_it != m_it_end; m_it++) {
		it = m.find(m_it->name);
		if (it != m.end()) {
			it->second.total += m_it->total;
		} else  {
			mod_total t;
			t.total = m_it->total;
			t.modtype = m_it->modtype;
			m.insert(M::value_type(m_it->name, t));
		}
	}

	it = m.begin();
	it_end = m.end();
	mod_total mt;
	for (; it != it_end; it++) {
		mt.modname = it->first;
		mt.modtype = it->second.modtype;
		mt.total = it->second.total;
		modset.insert(mt);
	}

	m.clear();
}


SampleDetail* opdata_handler::getDetailMap(string modname) 
{
	SampleDetail *pRet = NULL;

	MOD_DETAIL_MAP::iterator it = m_mod_detail.find(modname);
	if (it != m_mod_detail.end()) {
		pRet = &(it->second);
	} else {
		SampleDetail d;
		m_mod_detail.insert(MOD_DETAIL_MAP::value_type(modname, d));
		it = m_mod_detail.find(modname);
		if (it != m_mod_detail.end())
			pRet = &(it->second);
	}

	return pRet;
}


void opdata_handler::addTaskData(string taskname, 
		unsigned int taskid, unsigned int bit, SampleDataMap taskdata)
{
	TASK_TYPE tdata;
	tdata.taskid = taskid; 

	tdata.bitness = bit;
	tdata.total= 0;
	tdata.sampMap = taskdata;
	SampleDataMap::iterator it = tdata.sampMap.begin();
	SampleDataMap::iterator it_end = tdata.sampMap.end();
	for(; it != it_end; it++) {
		tdata.total += it->second;
	}	
	m_task_summary.insert(task_summary_map::value_type(
				taskname, tdata));
}


bool opdata_handler::write_ebp_output(
			string outputfile, unsigned int ncpu, 
			unsigned long cpuFamily, unsigned long cpuModel)
{
	bool bRet = false;

	CTbsWriter writer;
	unsigned total = 0;
	task_summary_map::iterator t_it;
	task_summary_map::iterator t_it_end;
	mod_summary_list::iterator m_it;
	mod_summary_list::iterator m_it_end;
	
	sorted_mod_set modset;

	t_it = m_task_summary.begin();	
	t_it_end = m_task_summary.end();	
	for (; t_it != t_it_end; t_it++) {
		total += t_it->second.total;
	}
	
	if (!writer.open_file_to_write(outputfile))
		return bRet;

	// write [Env] section;	
	if (!writer.writeEnvHeader(ncpu, m_mod_detail.size(),
				m_event_encode_map.size(), total, 
				m_event_encode_map, cpuFamily, cpuModel, 0)) {

		return bRet;
	}

	// write [PROCESSDATA] section
	writer.writeProcSectionProlog();
	t_it = m_task_summary.begin();	
	t_it_end = m_task_summary.end();	
	for (; t_it != t_it_end; t_it++) {
		writer.writeProcLineData(t_it->first, t_it->second.taskid,
			t_it->second.sampMap, 
			(t_it->second.bitness == ev32bit ? true : false));

	}	
	writer.writeProcSectionEpilog();

	// write [MODDATA] section
	writer.writeModSummaryProlog();
	m_it = m_mod_summary.begin();
	m_it_end = m_mod_summary.end();
	for (; m_it != m_it_end; m_it++) {
		writer.writeModSummaryLine(
			m_it->name, m_it->taskid, m_it->sampMap, 
			(m_it->bitness == ev32bit ? true : false));
	}	
	writer.writeModSummaryEpilog();

	getSortedModset(modset);

	/* For each module */	
	sorted_mod_set::iterator s_it     = modset.begin();
	sorted_mod_set::iterator s_it_end = modset.end();
	for(; s_it != s_it_end; s_it++) {

		MOD_DETAIL_MAP::iterator md_it = m_mod_detail.find(s_it->modname);
		if (md_it != m_mod_detail.end()) {
		
			writer.writeModDetailProlog(
				s_it->modname, s_it->modtype, s_it->total,
				md_it->second.size(), 0, 0);

			// start to write lines under module detail
			int cur_jitId = -1;
			SampleDetail::iterator sd_it     = md_it->second.begin();	
			SampleDetail::iterator sd_it_end = md_it->second.end();	
			for(; sd_it != sd_it_end; sd_it++) {

				if (s_it->modtype == JAVAMODULE) {
					if (cur_jitId != -1
					&&  cur_jitId != sd_it->first.jitId) {
						writer.writeJitEpilog();	
						cur_jitId = -1;
					}

					if ( cur_jitId == -1) {
						cur_jitId = sd_it->first.jitId;
						jitDetail jDetail = m_jitDetailVec.at(cur_jitId);
						QString jncFile = jDetail.jncFile;
						jncFile = jncFile.section("/", -3, -1);

						writer.writeJitProlog(  
								jDetail.jitSym,  // jitSym
								jncFile,         // jitSrc
								jDetail.jitAddr, // jitAddr
								0,       // TODO: jitSize
								0);     // TODO: itemCount
					}
				}

				writer.writeModDetailLine( sd_it->first.taskId, 
							0, 
							sd_it->first.rip,
							sd_it->second);
			}
			
			if (s_it->modtype == JAVAMODULE) {
				if (cur_jitId != -1) {
					writer.writeJitEpilog();	
					cur_jitId = -1;
				}
			}

		} else {
			// write an dummy header for Module detail
			writer.writeModDetailProlog(s_it->modname, 0, s_it->total, 0, 0, 0);
		}
		writer.writeModDetailEpilog();
	}

	writer.close();

	bRet = true;
	return bRet;
}


bool opdata_handler::copyJoFile(QString dirPath)
{
	mod_summary_list::iterator m_it = m_mod_summary.begin();
	mod_summary_list::iterator m_it_end = m_mod_summary.end();
	for(; m_it != m_it_end; m_it++)
	{
		QString modName(m_it->name);
		if(modName.endsWith(".jo"))
		{
			QFile joFile;
			joFile.setName(modName);
			while(!joFile.exists())
			{
				QString msg = "Could not find " + modName + ".\nBrowse for File?";

				// the image does not exist on the hard disk
				if (QMessageBox::information (NULL, "Error", msg,
					QMessageBox::Yes, QMessageBox::No) != 
					QMessageBox::Yes) 
				{
					return false;
				}else {
					modName = QFileDialog::getOpenFileName ();
					if (modName.isEmpty ())
						return false;
					else
						joFile.setName(modName);
				}
			}

			QString cmd_cp("cp -f \"" + modName + "\" \"" + dirPath + "\"");
			if(system(cmd_cp.ascii()) == -1)
				return false;
		}
	}
	return true;
}


unsigned int opdata_handler::getTaskBitness(string taskname)
{
	unsigned int ret = evUnknown;
	int fd;
	int elfClass;
	Elf * e = NULL;

	if(elf_version(EV_CURRENT) == EV_NONE)
		return ret;
	
	if(( fd = open (taskname.c_str(), O_RDONLY, 0)) >= 0)
	{
		if(( e = elf_begin(fd, ELF_C_READ, NULL)) != NULL )
		{
			elfClass = gelf_getclass(e);

			if(elfClass == ELFCLASS32){
				ret = ev32bit;	
			} else if(elfClass == ELFCLASS64) {
				ret = ev64bit;
			}
	
			elf_end(e);
		}
		close(fd);
	}

	if (ret == evUnknown) {
		QString cmd_uname("uname -m | grep x86_64 > /dev/null");
		if(system(cmd_uname.ascii()) != 0)
			ret = ev32bit;
		else
			ret = ev64bit;
	}
	
	return ret;
}


