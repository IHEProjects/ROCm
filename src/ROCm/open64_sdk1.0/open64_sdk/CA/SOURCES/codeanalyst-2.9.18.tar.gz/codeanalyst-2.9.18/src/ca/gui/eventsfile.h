//$Id: eventsfile.h,v 1.2 2005/02/14 16:52:40 jyeh Exp $
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _EVENTS_FILE
#define _EVENTS_FILE

#include <qfile.h>
#include <qxml.h>
#include <list>

#include "PerfEvent.h"
#include "typedefs.h"

using namespace std;

struct UnitMask {
	QString name;               // human readable name
	unsigned int value;         // unit mask value
};

typedef list < UnitMask > UnitMaskList;

struct CpuEvent {
	QString 	name;		// human readable name for event
	QString 	abbrev;		// Abbreviated name
	QString 	source;		// source unit for event
	QString 	op_name;	// OProfile event name
	unsigned int 	value;		// event value
	
	UnitMaskList 	m_UnitMaskList;	// list of valid unit masks for the vent
	int 		m_minValidModel;// The minimum model number for which the event is valid.

	CpuEvent(){
		value 		= 0;
		m_minValidModel = 0;
	};
};

typedef list < CpuEvent > EventList;

/*===================================================================
* Events File Class
* ~~~~~~~~~~~~~~~~~
* Provides functions for interfacing with the xml based .cef 
* (CPU Events File)
*/
class CEventsFile:public QXmlDefaultHandler {
public:
	CEventsFile ();
	virtual ~ CEventsFile ();

	// client interface
	bool open (const char *events_file_path);
	void close ();
	void printEvents ();

	bool isEventExist( QString eventName );
	bool findEventByName (QString eventName, CpuEvent & event);
	bool findEventByValue (unsigned int value, CpuEvent & event);
	bool findEventByOpStr  (QString str, CpuEvent & event);
	bool findEventByOpName (QString eventName, CpuEvent & event);
	bool findIbsEvent(EventList &evList);

	EventList::const_iterator FirstEvent ();
	EventList::const_iterator FirstPmcEvent();
	EventList::const_iterator FirstIbsFetchEvent();
	EventList::const_iterator FirstIbsOpEvent();
	EventList::const_iterator EndOfEvents ();
	UnitMaskList::const_iterator FirstUnitMask (const CpuEvent & event);
	UnitMaskList::const_iterator EndOfUnitMasks (const CpuEvent & event);

	bool characters (const QString & ch);
protected:
	/* overrides from QXmlDefaultHandler */
	virtual bool startDocument ();
	virtual bool startElement (const QString & namespaceURI,
			const QString & localName, 
			const QString & qName,
			const QXmlAttributes & atts);

	virtual bool endElement (const QString & namespaceURI,
			const QString & localName, 
			const QString & qName);

	EventList 	m_EventList;
	QString 	m_CurrentSourceUnit;
};

#endif // #ifndef _EVENTS_FILE
