/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef _TI_MAPPER_H
#define _TI_MAPPER_H

#include <stdlib.h>
#include <stdio.h>
#include <map>
#include <set>
#include <string>

#include "libprofile_ctrl.h"
#include "op_types.h"

using namespace std;


struct ModuleKey
{
    unsigned int processId;    
    unsigned long moduleLoadAddr;
    u64 moduleLoadTime;

    // constructor
    ModuleKey(unsigned int pid, u64 loadAddr, unsigned long loadTime)
        : processId(pid)
        , moduleLoadAddr(loadAddr)
        , moduleLoadTime(loadTime)
    {};

    // this defines the comparison for ModuleKey
    bool operator < (const ModuleKey & other) const
    {
        return (this->processId < other.processId) ? true
            :  (this->processId > other.processId) ? false
            :  (this->moduleLoadAddr < other.moduleLoadAddr) ? true
			:	(this->moduleLoadAddr > other.moduleLoadAddr) ? false
			:	(this->moduleLoadTime < other.moduleLoadTime);
    };

    // assignment operator over loading.
	ModuleKey& operator=(const ModuleKey& other) 
	{
		this->processId = other.processId;
		this->moduleLoadAddr = other.moduleLoadAddr;
		this->moduleLoadTime = other.moduleLoadTime;
		return *this;
	};
};

struct ModuleValue
{
    u64	moduleBaseAddr;		// module image base address; 
    unsigned long moduleSize;
    u64 moduleUnloadTime;
    string moduleName;
    bool bNameConverted;
    bool bJitModule;

    // default constructor
	ModuleValue()
		: moduleBaseAddr (0), 
		  moduleSize (0),
		  moduleUnloadTime (0),
		  bNameConverted (false),
		  bJitModule(false)
	{
	};

    // constructor
	ModuleValue(u64 ctor_mBaseAddr, unsigned long ctor_mSize, u64 ctor_mUnloadTime, char* ctor_mName)
		: moduleBaseAddr (ctor_mBaseAddr), 
		  moduleSize (ctor_mSize),
		  moduleUnloadTime (ctor_mUnloadTime),
		  bJitModule(false)
	{
		moduleName = ctor_mName;
	};
};

typedef map<ModuleKey, ModuleValue> ModuleMap;

#endif
