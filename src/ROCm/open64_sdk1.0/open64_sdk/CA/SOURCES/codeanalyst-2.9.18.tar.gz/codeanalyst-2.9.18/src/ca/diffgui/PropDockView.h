
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _PROPDOCKVIEW_H_
#define _PROPDOCKVIEW_H_

#include <qdockwindow.h>
#include <qlayout.h>
#include <qlistview.h>
#include <qsplitter.h>
#include <qhbox.h>
#include <qmainwindow.h>
#include <qcheckbox.h>
#include <qtoolbutton.h>
#include <qpushbutton.h>
#include <qcombobox.h>
#include "diffStruct.h"
#include "DiffSession.h"
#include "bbanalysis.h"

#include "BBDataListItem.h"

class PropDockView : public QDockWindow
{

	Q_OBJECT;
public:
	PropDockView(QWidget * parent, const char * name = 0, WFlags f = 0);
	~PropDockView();
	bool init();

signals:
	void propDockViewNoShow();

public slots:
	virtual void undock()
	{
		QDockWindow::undock();
	};
	virtual bool close(bool alsoDelete);	
	virtual void onPropDockViewShowChanged(bool b);	
	virtual void onChangeSession(DiffSession *s);
private:
	
	void addColumns();
	void fillProperty();
	void setProperty();

	DiffSession	*m_pDiffSession;
	QBoxLayout	*m_pBLayout;
	QListView	*m_pView;
	QMainWindow	*m_pMainWindow;
	SampleDataMap	*m_pTotalSampleDataMap[MAX_NUM_DIFF];
	BBDataListItem	*m_pCurHighlightedBB[MAX_NUM_DIFF];

};

#endif //_DASMDOCKVIEW_H_


