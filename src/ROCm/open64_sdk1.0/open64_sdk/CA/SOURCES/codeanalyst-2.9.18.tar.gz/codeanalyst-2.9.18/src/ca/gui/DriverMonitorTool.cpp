#include "stdafx.h"
#include "DriverMonitorTool.h"

DriverMonitorSnapshot::DriverMonitorSnapshot()
{
	m_devOprofile = QString("/dev/oprofile/");
	m_devOprofileStat = m_devOprofile + "stats/";
}


DriverMonitorSnapshot::~DriverMonitorSnapshot()
{
}


QString DriverMonitorSnapshot::helpReadFile(QString path)
{
	QString value = "N/A";
	QFile file(path);
	
	if (!file.open(IO_ReadOnly)
	||  (file.readLine(value, 1024) <= 0)) {
		//value = QString("Cannot access ") + path;
		value = QString("N/A");
	}
	file.close();

	return value;
}


QStringList DriverMonitorSnapshot::getSnapGeneral()
{
	QStringList tmp;

	tmp = m_generalData;
	
	return tmp;
}


bool DriverMonitorSnapshot::takeSnapGeneral()
{
	QStringList * pStrList = &m_generalData;
	// Clear old value
	pStrList->clear();

	// Update w/ new value
	pStrList->push_back(QString("Driver Enabled"));
	pStrList->push_back(helpReadFile(m_devOprofile + "enable"));
	pStrList->push_back(QString("CPU type"));
	pStrList->push_back(helpReadFile(m_devOprofile + "cpu_type"));
	pStrList->push_back(QString("Buffer Size"));
	pStrList->push_back(helpReadFile(m_devOprofile + "buffer_size"));
	pStrList->push_back(QString("Buffer Watershed Size"));
	pStrList->push_back(helpReadFile(m_devOprofile + "buffer_watershed"));
	pStrList->push_back(QString("CPU Buffer Size"));
	pStrList->push_back(helpReadFile(m_devOprofile + "cpu_buffer_size"));
	pStrList->push_back(QString("Backtrace Depth"));
	pStrList->push_back(helpReadFile(m_devOprofile + "backtrace_depth"));
	pStrList->push_back(QString("CSS Depth"));
	pStrList->push_back(helpReadFile(m_devOprofile + "ca_css_depth"));
	pStrList->push_back(QString("CSS Interval"));
	pStrList->push_back(helpReadFile(m_devOprofile + "ca_css_interval"));
	pStrList->push_back(QString("CSS Tgid"));
	pStrList->push_back(helpReadFile(m_devOprofile + "ca_css_tgid"));
	pStrList->push_back(QString("CSS Bitness"));
	pStrList->push_back(helpReadFile(m_devOprofile + "ca_css_bitness"));
	pStrList->push_back(QString("Multiplexing Interval"));
	pStrList->push_back(helpReadFile(m_devOprofile + "time_slice"));
	return true;
}


QStringList DriverMonitorSnapshot::getSnapStats()
{
	QStringList tmp;

	tmp = m_statsData;
	
	return tmp;
}


bool DriverMonitorSnapshot::takeSnapStats()
{
	QStringList * pStrList = &m_statsData;

	// Clear old value
	pStrList->clear();

	// Update w/ new value
	pStrList->push_back(QString("Event Lost Due to Overflow"));
	pStrList->push_back(helpReadFile(m_devOprofileStat + "event_lost_overflow"));
	pStrList->push_back(QString("Backtrace Lost Due to No Mapping"));
	pStrList->push_back(helpReadFile(m_devOprofileStat + "bt_lost_no_mapping"));
	pStrList->push_back(QString("Sampe Lost Due to No Mapping"));
	pStrList->push_back(helpReadFile(m_devOprofileStat + "sample_lost_no_mapping"));
	pStrList->push_back(QString("Sample Lost Due to No MM"));
	pStrList->push_back(helpReadFile(m_devOprofileStat + "sample_lost_no_mm"));
	pStrList->push_back(QString("Multiplex Counter"));
	pStrList->push_back(helpReadFile(m_devOprofileStat + "multiplex_counter"));
	return true;
}


void DriverMonitorSnapshot::signalSnapshotReady(QObject *obj)
{
	QApplication::postEvent (obj, new QCustomEvent ( 
		(QEvent::Type) EVENT_UPDATE_OPROFILEDRV_MONITOR));	
}


QStringList DriverMonitorSnapshot::getSnapCpu()
{
	QStringList tmp;

	tmp = m_cpuData;
	
	return tmp;
}


bool DriverMonitorSnapshot::takeSnapCpu()
{
	QStringList * pStrList = &m_cpuData;

	// Clear old value
	pStrList->clear();

	QDir * dir = new QDir(m_devOprofileStat);
	
	// Update w/ new value for each cpu
	QStringList cpuList = dir->entryList("cpu*");
	QStringList::iterator it = cpuList.begin();
	QStringList::iterator it_end = cpuList.end();

	for (; it != it_end; it++) {
		QString tmp = m_devOprofileStat + (*it);
		pStrList->push_back(QString(*it));
		pStrList->push_back(helpReadFile(tmp + "/sample_received"));
		pStrList->push_back(helpReadFile(tmp + "/sample_lost_overflow"));
		pStrList->push_back(helpReadFile(tmp + "/sample_invalid_eip"));
		pStrList->push_back(helpReadFile(tmp + "/backtrace_aborted"));
	}

	if (dir)
		delete dir;

	return true;
}


QStringList DriverMonitorSnapshot::getSnapIbs()
{
	QStringList tmp;

	tmp = m_ibsData;
	
	return tmp;
}


bool DriverMonitorSnapshot::takeSnapIbs()
{
	QStringList * pStrList = &m_ibsData;

	// Clear old value
	pStrList->clear();

	QString fetchStr = m_devOprofile + "/ibs_fetch";
	QString opStr = m_devOprofile + "/ibs_op";
	
	// Update w/ new value for each cpu
	pStrList->push_back(QString("IBS Fetch"));
	pStrList->push_back(helpReadFile(fetchStr + "/enable"));
	pStrList->push_back(helpReadFile(fetchStr + "/max_count"));
	pStrList->push_back(QString("Randomize Enable :")+ helpReadFile(fetchStr+ "/rand_enable"));

	pStrList->push_back(QString("IBS Op"));
	pStrList->push_back(helpReadFile(opStr + "/enable"));
	pStrList->push_back(helpReadFile(opStr + "/max_count"));
	pStrList->push_back(QString("Dispatched Op :")+ helpReadFile(opStr+ "/dispatched_ops"));

	return true;
}


QStringList DriverMonitorSnapshot::getSnapPmc()
{
	QStringList tmp;

	tmp = m_pmcData;
	
	return tmp;
}


bool DriverMonitorSnapshot::takeSnapPmc()
{
	QStringList * pStrList = &m_pmcData;
	// Clear old value
	pStrList->clear();

	QDir * dir = new QDir(m_devOprofile);
	
	// Update w/ new value for each cpu
	QStringList counterList = dir->entryList("[0-9]*");
	int count = counterList.count();

	for (int i=0 ; i < count; i++) {
		QString tmp = m_devOprofile + QString::number(i,10);
		pStrList->push_back(QString::number(i,10));
		pStrList->push_back(helpReadFile(tmp + "/enabled"));

		QString str = helpReadFile(tmp + "/event");
		unsigned int val = str.toUInt(0, 10);
		str = QString("0x") + QString::number(val,16);	
		pStrList->push_back(str);
		
		str = helpReadFile(tmp + "/unit_mask");
		val = str.toUInt(0, 10);
		str = QString("0x") + QString::number(val,16);	
		pStrList->push_back(str);

		pStrList->push_back(helpReadFile(tmp + "/count"));
	}
	
	if (dir)
		delete dir;

	return true;
}


bool DriverMonitorSnapshot::takeSnapshot()
{
	takeSnapGeneral();
	takeSnapStats();
	takeSnapCpu();
	takeSnapIbs();
	takeSnapPmc();

	return true;
}


///////////////////////////////////////////////////////////////////////////////
DriverMonitorTool::DriverMonitorTool(QWidget * parent) :
QTabWidget(parent)
{
	m_pGeneralTab	= NULL;
	m_pStatsTab	= NULL;
	m_pIbsTab	= NULL;
	m_pPmcTab	= NULL;
}


DriverMonitorTool::~DriverMonitorTool()
{

}


bool DriverMonitorTool::init()
{
	bool ret = false;

	// First time
	DriverMonitorSnapshot snap;
	snap.takeSnapshot();

	ret = ( initGeneralTab(&snap)
		&& initStatsTab(&snap)
		&& initCpuTab(&snap)	
		&& initIbsTab(&snap)	
		&& initPmcTab(&snap));

	return true;	
}


bool DriverMonitorTool::initGeneralTab(DriverMonitorSnapshot * snap)
{
	m_pGeneralTab = new QListView(this);
	if (!m_pGeneralTab) return false;

	// Set column	
	m_pGeneralTab->addColumn(QString("Monitor"), 200);
	m_pGeneralTab->addColumn(QString("Value"));
	m_pGeneralTab->setColumnAlignment(1,Qt::AlignRight);
	
	initCommon(m_pGeneralTab);
	
	this->addTab(m_pGeneralTab, QString("Driver Info"));
	
	// Insert QListViewItems
	QStringList list = snap->getSnapGeneral();

	QStringList::iterator it     = list.begin();
	QStringList::iterator it_end = list.end();
	QListViewItem * item = NULL;
	for (; it != it_end; it++) {
		item = new QListViewItem(m_pGeneralTab, item, *(it), *(++it));
	}
	return true;
}


bool DriverMonitorTool::initStatsTab(DriverMonitorSnapshot * snap)
{
	m_pStatsTab = new QListView(this);
	if (!m_pStatsTab) return false;
	
	// Set column	
	m_pStatsTab->addColumn(QString("Monitor"), 200);
	m_pStatsTab->addColumn(QString("Value"));
	m_pStatsTab->setColumnAlignment(1,Qt::AlignRight);
	
	initCommon(m_pStatsTab);

	this->addTab(m_pStatsTab, QString("Driver Stats"));
	
	// Insert QListViewItems
	QStringList list = snap->getSnapStats();

	QStringList::iterator it     = list.begin();
	QStringList::iterator it_end = list.end();
	QListViewItem * item = NULL;
	for (; it != it_end; it++) {
		item = new QListViewItem(m_pStatsTab, item, *(it), *(++it));
	}
	return true;
}


bool DriverMonitorTool::initCpuTab(DriverMonitorSnapshot * snap)
{
	m_pCpuTab = new QListView(this);
	if (!m_pCpuTab) return false;

	// Set column	
	m_pCpuTab->addColumn(QString("CPU"));
	m_pCpuTab->addColumn(QString("Sample Received"));
	m_pCpuTab->addColumn(QString("Sample Lost Due to Overflow"));
	m_pCpuTab->addColumn(QString("Sample Invalid IP"));
	m_pCpuTab->addColumn(QString("Backtrace Aborted"));
	m_pCpuTab->setColumnAlignment(0,Qt::AlignHCenter);
	m_pCpuTab->setColumnAlignment(1,Qt::AlignRight);
	m_pCpuTab->setColumnAlignment(2,Qt::AlignRight);
	m_pCpuTab->setColumnAlignment(3,Qt::AlignRight);
	m_pCpuTab->setColumnAlignment(4,Qt::AlignRight);

	initCommon(m_pCpuTab);

	this->addTab(m_pCpuTab, QString("CPU Stats"));
	
	// Insert QListViewItems
	QStringList list = snap->getSnapCpu();

	QStringList::iterator it     = list.begin();
	QStringList::iterator it_end = list.end();
	QListViewItem * item = NULL;
	for (; it != it_end; it++) {
		item = new QListViewItem(m_pCpuTab, item, *(it), *(++it), *(++it), *(++it), *(++it));
	}
	return true;
}


bool DriverMonitorTool::initIbsTab(DriverMonitorSnapshot * snap)
{
	m_pIbsTab = new QListView(this);
	if (!m_pIbsTab) return false;

	// Set column	
	m_pIbsTab->addColumn(QString("IBS Type"));
	m_pIbsTab->addColumn(QString("Enable"));
	m_pIbsTab->addColumn(QString("Count"));
	m_pIbsTab->addColumn(QString("Options"));
	m_pIbsTab->setColumnAlignment(0,Qt::AlignHCenter);
	m_pIbsTab->setColumnAlignment(1,Qt::AlignRight);
	m_pIbsTab->setColumnAlignment(2,Qt::AlignRight);
	m_pIbsTab->setColumnAlignment(3,Qt::AlignRight);
	
	initCommon(m_pIbsTab);

	this->addTab(m_pIbsTab, QString("IBS Config"));

	// Insert QListViewItems
	QStringList list = snap->getSnapIbs();

	QStringList::iterator it     = list.begin();
	QStringList::iterator it_end = list.end();
	QListViewItem * item = NULL;
	for (; it != it_end; it++) {
		item = new QListViewItem(m_pIbsTab, item, *(it), *(++it), *(++it), *(++it));
	}
	return true;
}


bool DriverMonitorTool::initPmcTab(DriverMonitorSnapshot * snap)
{
	m_pPmcTab = new QListView(this);
	if (!m_pPmcTab) return false;

	// Set column	
	m_pPmcTab->addColumn(QString("Counter"));
	m_pPmcTab->addColumn(QString("Enable"));
	m_pPmcTab->addColumn(QString("Event"));
	m_pPmcTab->addColumn(QString("Unitmask"));
	m_pPmcTab->addColumn(QString("Count"));
	m_pPmcTab->setColumnAlignment(0,Qt::AlignHCenter);
	m_pPmcTab->setColumnAlignment(1,Qt::AlignRight);
	m_pPmcTab->setColumnAlignment(2,Qt::AlignRight);
	m_pPmcTab->setColumnAlignment(3,Qt::AlignRight);
	m_pPmcTab->setColumnAlignment(4,Qt::AlignRight);
	
	initCommon(m_pPmcTab);

	this->addTab(m_pPmcTab,"PMC Config");

	// Insert QListViewItems
	QStringList list = snap->getSnapPmc();

	QStringList::iterator it     = list.begin();
	QStringList::iterator it_end = list.end();
	QListViewItem * item = NULL;
	for (; it != it_end; it++) {
		item = new QListViewItem(m_pPmcTab, item, *(it), *(++it), *(++it), *(++it), *(++it));
	}
	
	return true;
}

void DriverMonitorTool::initCommon(QListView * pList)
{
	// Set property
	pList->setSorting(-1);
	pList->setAllColumnsShowFocus(true);
	pList->setSelectionMode(QListView::NoSelection);
}
