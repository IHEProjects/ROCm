//$Id: ebpdef.h,v 1.2 2005/02/14 16:52:40 jyeh Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _EBPDEF_H
#define _EBPDEF_H


#define EC_USR	(1<<16)
#define EC_OS	(1<<17)


/////////////////////////////////////////////////////////////////////////////
// ------------------------- AMD K8 -----------------------------------------
//

#define INVALID_ESR_VALUE	0x500000

// Macros
#define AMD_EVENT_SEL_REG( UnitMask, EventMask, CounterMask, Os, Usr ) \
	(CounterMask << 24) | (UnitMask << 8) | (EventMask) \
	/*Os*/		| (Os << 17)	| \
	/*User*/	| (Usr << 16) | \
	/*Enable*/	| (1 << 22)	| \
	/*APIC*/	| (1 << 20)


#endif // #ifndef _EBPDEF_H
