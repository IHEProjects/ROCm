#ifndef __NEWDIFFSESSIONDLG_H__
#define __NEWDIFFSESSIONDLG_H__

#include "iNewDiffSessionDlg.h"
#include "tbsreader.h"
#include "cawfile.h"

#define MAX_NUM_DIFF 2

typedef struct _DiffSessionInfo
{
	enum{
		UNKNOWN_SESS = -1,
		TBP_SESS,
		EBP_SESS,
		IBS_SESS
	};
	QString sessionFile;
	QString task;
	QString module;
	int 	type;
	_DiffSessionInfo()
	{
		type = -1;
	}
} DiffSessionInfo;

class NewDiffSessionDlg : public iNewDiffSessionDlg
{
	Q_OBJECT
public:
	NewDiffSessionDlg( 
			QString cawPath,
			QWidget* parent = 0, 
			const char* name = 0, 
			bool modal = FALSE, 
			WFlags fl = 0 );

	~NewDiffSessionDlg();
	bool init(DiffSessionInfo* sess = NULL);
	QStringList getDiffSession();

public slots:
	virtual void onAdd();
	virtual void onReset();
	virtual void onEdit();
	virtual void onRemove();

private:
	bool initSessionComboBox(DiffSessionInfo *sess = NULL);
	TbsReader* 	m_pTbsReader;	
	CawFile*	m_pCawFile;
	QString 	m_cawPath;

	    
private slots:
	void onSessionFileChanged();
	bool populateTask();
	bool populateModule();
	void onModuleChanged();

};
#endif // __NEWDIFFSESSIONDLG_H__
