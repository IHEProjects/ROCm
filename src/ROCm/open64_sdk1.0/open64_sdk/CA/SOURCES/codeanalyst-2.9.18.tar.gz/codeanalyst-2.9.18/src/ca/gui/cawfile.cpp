//$Id: cawfile.cpp,v 1.3 2005/02/14 16:52:29 jyeh Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "stdafx.h"
#include <assert.h>
#include <errno.h>

#include "helperAPI.h"
#include "cawfile.h"
#include "auxil.h"
#include "helperAPI.h"
#include "EventMaskEncoding.h"

CawFile::CawFile(QString fileName)
{
	if (!fileName.isEmpty()) {
		m_szFilePath = fileName;
		m_szFileName = fileName.section ('/', -1);
		m_szFileDir  = fileName.section ('/', 0, -2, 
					QString::SectionIncludeTrailingSep);
	}
}


CawFile::~CawFile()
{
}

/* static */ 
bool CawFile::create (const QString fileName)
{
	bool ret = false;

	QString tempFileName = fileName;

	//Replaces \ with / in directories
	tempFileName.replace ('\\', '/');

	//recursively create directories, if needed
	int sections = tempFileName.contains ("/");
	for (int sects = 1; sects < sections; sects ++) {
		QDir    dir;
		dir.setPath( tempFileName.section ("/", 0, sects) );
		if( !dir.exists() ) {
			dir.mkdir (dir.path());
		}
	}

	//create default project
	CawFile * pTemp = new CawFile (fileName);
	if(!pTemp) 
		return ret;

	ret = pTemp->saveCawFile();
	delete pTemp;
	return ret;	
}//CawFile::create


bool CawFile::create ()
{
	bool ret = false;

	QString tempFileName = m_szFilePath;

	//Replaces \ with / in directories
	tempFileName.replace ('\\', '/');

	//recursively create directories, if needed
	int sections = tempFileName.contains ("/");
	for (int sects = 1; sects < sections; sects ++) {
		QDir    dir;
		dir.setPath( tempFileName.section ("/", 0, sects) );
		if( !dir.exists() ) {
			dir.mkdir (dir.path());
		}
	}

	//create default project
	ret = this->saveCawFile();
	return ret;	
}//CawFile::create


// reads the General options located in the .caw file
// The General section has the [GENERAL] Key before it
//
void CawFile::readGeneralSection( QTextStream * pStream )
{
	QString line;
	line = pStream->readLine();

	while (!line.startsWith ("[End]")) {
		if (pStream->atEnd ())
			break;
	
		if ( line.contains ("=") == 0 ) {
			line = pStream->readLine();
			continue;
		}
	
		QString parm  = line.section ('=', 0, 0 );
		QString val = line.section ('=', 1 );

		if (parm ==("LaunchHistory")) {
			m_launchHistory += val;
		} else if (parm ==("WorkDirHistory")) {
			m_workDirHistory += val;
		} else if (parm ==("LastRunSetting")) {
			m_lastRunSettingName = val;
		}  
		line = pStream->readLine();
		/*
 		 * Prior to version 8, [GENERAL] section 
 		 * does not have [End] tag. So we break
 		 * on blank line
 		 */
		if (m_cawVersion < 8 && line.isEmpty())
			break;
	}
}


//checks whether the file is a valid file
int CawFile::getVersion (QString first_line)
{
	if (first_line.startsWith ("FileVersion")) 
	{
		m_cawVersion = first_line.section ('=', 1, 1).toInt();
		return m_cawVersion;
	}
	return -1;
}

bool CawFile::openCawFile()
{
	bool ret = false;
	QString line;
	QTextStream *pStream = NULL;
	
	QFile *pFile = new QFile(m_szFilePath);
	if (!pFile)
		return ret;

	// Check existance
	if (!pFile->exists())
		return ret;

	// Opens an existing file
	if(!pFile->open( IO_ReadWrite ))
		goto out;

	pStream = new QTextStream ( pFile );
	if(!pStream)
		goto out;

	/*
	 * Check Version
	 */
	if (!pStream->atEnd()) {
		line = pStream->readLine();

		// TODO: Suravee: Need to implement file conversion
		if (getVersion(line) != PROJECT_INT_FILE_VERSION
		&&  QMessageBox::Yes != 
			QMessageBox::question (NULL, "CodeAnalyst",
			QString("This is an older version (")
			+ QString::number(m_cawVersion)
			+ ") of CodeAnalyst project (.CAW) file.\n"
			+ "Some information (i.e. session property) might not be accurate.\n"
			+ "Do you want to continue?",
			QMessageBox::Yes, QMessageBox::No))
		{
			goto out;
		}
	}
	
	/* 
	 * Read each section
	 */
	while( !pStream->atEnd() ) {
		line = pStream->readLine();

		if( line.find("[GENERAL]") != -1 ) {
			readGeneralSection( pStream );
		} else if( line.find("[RUN_SETTING]") != -1 ) {
			readSettingSection( pStream );
		} else if( line.find("[TBP]") != -1 ) {
			readTbpSection( pStream );
		} else if( line.find("[EBP]") != -1 ) {
			readEventSection( pStream );
		} else if( line.find("[IBS]") != -1 ) {
			// Now we handling IBS as EBP session
			readEventSection( pStream );
		}
		

	}

	ret = true;
out:
	if (pStream)
		delete pStream;

	if (pFile) {
		if (pFile->isOpen())
			pFile->close();
		delete pFile;
	}
	return ret;
	
} // CawFile::openCawFile()


void CawFile::helpWriteRunSetting (QTextStream *pStream, RUN_SETTING *pRun)
{
	*pStream << "SessionName=" << pRun->sessionName << endl;
	*pStream << "SessionNote=" << pRun->sessionNote << endl;
	*pStream << "DcConfig=" << pRun->dcConfig<< endl;
	*pStream << "Launch=" << pRun->launch << endl;
	*pStream << "WorkDir=" << pRun->workDir << endl;
	*pStream << "StopOnApp=" << pRun->stopOnAppExit << endl;
	*pStream << "BreakAfter=" << pRun->termAppOnDur << endl;
	*pStream << "Duration=" << pRun->duration << endl;
	*pStream << "StartPaused=" << pRun->startPaused << endl;
	*pStream << "StartDelay=" << pRun->startDelay << endl;
	*pStream << "Affinity=0x" << QString::number(pRun->affinity,16)<< endl;
	*pStream << "AffinityEnable=" << pRun->affinityEnable << endl;
	*pStream << "FilterEnable=" << pRun->filterEnable << endl;
	*pStream << "FilterList=" << pRun->filterList << endl;
	*pStream << "CssEnable=" << pRun->cssEnable << endl;
	*pStream << "CssDepth=" << pRun->cssDepth << endl;
	*pStream << "CssInterval=" << pRun->cssInterval<< endl;
	*pStream << "CssUseTgid=" << pRun->cssUseTgid<< endl;
	*pStream << "CssTgid=" << pRun->cssTgid<< endl;
	*pStream << "EnableVmlinux=" << pRun->vmlinuxEnable << endl;
	*pStream << "Vmlinux=" << pRun->vmlinux << endl;
	*pStream << "OpWaterShed=" << pRun->opWaterShed << endl;
	*pStream << "OpBuffer=" << pRun->opBuffer << endl;
	*pStream << "OpCpuBuffer=" << pRun->opCpuBuffer << endl;
	*pStream << "ShowTerminal=" << pRun->showTerminalEnable<< endl;
}


//This avoids copy/pasting this code in multiple sections,
//	returns true if this function consumed the line
bool CawFile::helpReadRunSetting (QString parm, QString value, RUN_SETTING *pRun)
{
	bool handled = true;

	if (NULL == pRun)
		return false;

	if( parm == "SessionName" ) {
		pRun->sessionName = value;
	} else if( parm == "SessionNote" ) {
		pRun->sessionNote = value;
	} else if( parm == "DcConfig" ) {
		pRun->dcConfig = value;
	} else if( parm == "Launch" ) {
		pRun->launch = value;
	} else if( parm == "WorkDir" ) {
		pRun->workDir = value;
	} else if( parm == "StopOnApp" ) {
		pRun->stopOnAppExit = value.toInt();
	} else if( parm == "BreakAfter" ) {
		pRun->termAppOnDur = value.toInt();
	} else if( parm == "Duration" ) {
		pRun->duration = value.toInt();
	} else if (parm == "StartPaused" ) {
		pRun->startPaused = value.toInt();
	} else if (parm == "StartDelay" ) {
		pRun->startDelay = value.toInt();
	} else if (parm == "Affinity" ) {
		pRun->affinity = value.toInt(0,0);
	} else if (parm == "AffinityEnable" ) {
		pRun->affinityEnable = value.toInt();
	} else if (parm == "EnableFilter" ) {
		pRun->filterEnable = value.toInt();
	} else if (parm == "FilterList" ) {
		pRun->filterList = value;
	} else if (parm == "CssEnable" ) {
		pRun->cssEnable = value.toInt();
	} else if (parm == "CssDepth" ) {
		pRun->cssDepth = value.toInt();
	} else if (parm == "CssInterval" ) {
		pRun->cssInterval = value.toInt();
	} else if (parm == "CssUseTgid" ) {
		pRun->cssUseTgid = value.toInt();
	} else if (parm == "CssTgid" ) {
		pRun->cssTgid = value.toInt();
	} else if (parm == "EnableVmlinux" ) {
		pRun->vmlinuxEnable = value.toInt();
	} else if (parm == "Vmlinux" ) {
		pRun->vmlinux = value;
	} else if (parm == "OpWaterShed" ) {
		pRun->opWaterShed = value.toInt();
	} else if (parm == "OpBuffer" ) {
		pRun->opBuffer = value.toInt();
	} else if (parm == "OpCpuBuffer" ) {
		pRun->opCpuBuffer = value.toInt();
	} else if (parm == "ShowTerminal" ) {
		pRun->showTerminalEnable= value.toInt();
	} else if (parm == "Info" ) {
		pRun->info= value;
	} else {
		handled = false;
	}
	return handled;
}//CawFile::helpReadRunSetting


// saveCawFile all the options in the options structure to the file
bool CawFile::saveCawFile()
{
	bool ret = false;
	QTextStream * pStream = NULL;	
	QFile * pFile = new QFile(m_szFilePath);
	if (!pFile)
		return ret;

	if(!pFile->open(IO_ReadWrite | IO_Truncate | IO_Translate) ) {
		QMessageBox::information (0, "CodeAnalyst Error", 
			QString("Failed to create or save CodeAnalyst Project file\n")
			+ "at location:\n\n\t"
			+ pFile->name()
			+ "\n\nPlease check the permission.");
		goto out;
	}

	pStream = new QTextStream ( pFile );
	if (!pStream)
		goto out;

	*pStream << "FileVersion=" << PROJECT_FILE_VERSION << endl;

	// General Setting 
	*pStream << "[GENERAL]"   << endl;
	if (m_launchHistory.size() != 0)
		*pStream << "LaunchHistory=" << m_launchHistory.join ("\nLaunchHistory=") << endl;
	if (m_workDirHistory.size() != 0)
		*pStream << "WorkDirHistory=" << m_workDirHistory.join ("\nWorkDirHistory=") << endl;
	*pStream << "LastRunSetting=" << m_lastRunSettingName << endl;
	*pStream << "[End]"   << endl;
	*pStream << endl;

	// List of TBP Sessions
	writeSettingSection (pStream);
	*pStream << endl;

	// List of TBP Sessions
	writeTbpSection (pStream);
	*pStream << endl;

	// List of EBP Sessions
	writeEventSection (pStream);
	*pStream << endl;

	ret = true;
out:
	if (pStream)
		delete pStream;

	if (pFile) {
		if (pFile->isOpen())
			pFile->close();
		delete pFile;
	}
	return ret;
} //CawFile::saveCawFile()


//If there already exists "SessionName" for the trigger, this will try
//	"SessionName 1", "SessionName 2", etc.
QString CawFile::getNextSessionName (TRIGGER trigger, QString orgName)
{
	QString result, tmpName;
	int additional = 1;
	char tmp[10] = "";


	if (!orgName.isEmpty())
		tmpName = orgName;
	else
		tmpName = ((SettingMap::iterator)
			(m_settingMap.find(m_lastRunSettingName))).data()->sessionName;
	result = tmpName;

	//since ibs sessions also use .ebp extensions, we can't have overlap or the 
	//session gets overwritten
	QString ext;
	switch (trigger)
	{
	case TIMER_TRIGGER:
		ext = TBS_FILE_EXT;
		break;
	case EVENT_TRIGGER:
		ext = EBS_FILE_EXT;
		break;
	default:
		break;
	};
	QString existTest = m_szFileDir + result + ext + DIR_FILE_EXT;

	while ((m_sessions[trigger].contains (result)) || QFile::exists (existTest))
	{
		sprintf(tmp,"%02d",additional++);
		result = tmpName + " " + QString(tmp);
		existTest = m_szFileDir + result + ext + DIR_FILE_EXT;
	}
	return result;
}


bool CawFile::IsSessionNameTaken (TRIGGER trigger, QString SessionName)
{
	if (trigger >= NO_TRIGGER) {
		return true;
	}
	else {
		return m_sessions[trigger].contains (SessionName);
	}
}


//This adds an existing profile to the project - note that the CawFile will
//	take care of deleting the allocated memory
void CawFile::addSession (SESSION_OPTIONS *const pSession)
{
	if (NULL == pSession)
		return;
	m_sessions[pSession->Trigger].insert (pSession->sessionName, pSession);
}


void CawFile::deleteSession (TRIGGER trigger, QString sessionName)
{
	SESSION_OPTIONS *pSession = m_sessions[trigger][sessionName];
	QString filename = pSession->sessionFile;
	m_sessions[trigger].remove (sessionName);

	QString dirName = m_szFileDir + filename + DIR_FILE_EXT;
	QDir dir (dirName);
	if (dir.exists()) {
		QDir dir = QDir (dirName);
		folderRemove(dir);
	}

	saveCawFile();
}//CawFile::DeleteSession


/* get only SESSION_OPTIONS */
bool CawFile::getSessionCfg (TRIGGER trigger, QString name, SESSION_OPTIONS *pSession)
{
	if (NULL == pSession)
		return false;

	if (m_sessions[trigger].contains (name)) {
		*pSession = * (m_sessions[trigger] [name]);
		return true;
	} else {
		return false;
	}
}


/* get XXX_OPTIONS specific info*/
bool CawFile::getSessionDetails (QString name, SESSION_OPTIONS *pSession)
{
	if (NULL == pSession)
		return false;

	TRIGGER trigger = pSession->Trigger;
	if (m_sessions[trigger].contains (name)) {
		switch (trigger) {
			case TIMER_TRIGGER:
			{
				TBP_OPTIONS *pTbp = static_cast<TBP_OPTIONS *>(pSession);
				TBP_OPTIONS *pOther = 
					static_cast<TBP_OPTIONS *>(m_sessions[trigger] [name]);
				*pTbp = *pOther;
				break;
			}
			case EVENT_TRIGGER:
			default:
			{
				EBP_OPTIONS *pEbp = static_cast<EBP_OPTIONS *>(pSession);
				EBP_OPTIONS *pOther = 
					static_cast<EBP_OPTIONS *>(m_sessions[trigger] [name]);
				*pEbp = *pOther;
				break;
			}
		}
		return true;
	}
	else {
		return false;
	}
}


//This will alter the session name and file name in the internal lists, in
//  addition to renaming all applicable files (session data, ti, prd, dir)
void CawFile::renameSession (TRIGGER trigger, QString oldname, QString newname)
{
	QString newFile;
	QString oldFile;
	QString ext;

	newFile = m_szFileDir + newname;
	oldFile = m_szFileDir + oldname;
	SESSION_OPTIONS *pSession = m_sessions[trigger][oldname];
	m_sessions[trigger].remove (oldname);
	switch (trigger) {
		default: //should never happen
		case TIMER_TRIGGER:
			ext = TBS_FILE_EXT;
			break;
		case EVENT_TRIGGER:
			ext = EBS_FILE_EXT;
			break;
	}
	newFile += ext;
	oldFile += ext;
	pSession->sessionFile = newname + ext;
	pSession->sessionName = newname;
	m_sessions[trigger].insert (newname, pSession);

	//rename the files
	QDir dir;
	//first rename the directory
	newFile += DIR_FILE_EXT;
	oldFile += DIR_FILE_EXT;
	dir.rename (oldFile, newFile);
	//now all files in dir
	oldFile = newFile + "/" + oldname + ext;
	newFile += "/" + newname + ext;
	dir.rename (oldFile, newFile);
	dir.rename ((oldFile + PRD_FILE_EXT), (newFile + PRD_FILE_EXT));
	dir.rename ((oldFile + TI_FILE_EXT), (newFile + TI_FILE_EXT));
}//CawFile::RenameSession


//Since the indexes of the maps are names, we just get the list of indexes
QStringList CawFile::getSessionList (TRIGGER trigger)
{
	QStringList sessionList;
	SessionMap::Iterator it = m_sessions[trigger].begin();
	for( ; it != m_sessions[trigger].end(); ++it ) {
		sessionList += it.key();
	}
	return sessionList;
}

void CawFile::writeSettingSection (QTextStream *pStream )
{
	*pStream << "[RUN_SETTING]\n" << endl;

	SettingMap::iterator it = m_settingMap.begin();
	SettingMap::iterator it_end = m_settingMap.end();
	for (; it != it_end; it++) {
		helpWriteRunSetting(pStream, it.data());
		*pStream << endl;
	}
	*pStream << "\n[End]" << endl;
}

void CawFile::readSettingSection (QTextStream *pStream )
{
	QString line, parm, val;
	RUN_SETTING * pRun = NULL;

	line = pStream->readLine();

	while (!line.startsWith ("[End]")) {
		if (pStream->atEnd ())
			break;
	
		if ( line.contains ("=") == 0 ) {
			line = pStream->readLine();
			continue;
		}
	
		parm  = line.section ('=', 0, 0 );
		val = line.section ('=', 1 );

		if (parm == "SessionName") {
			if (pRun) {
				m_settingMap.insert (pRun->sessionName, pRun);
			}
				
			pRun = new RUN_SETTING();
		} 
		helpReadRunSetting (parm, val, pRun);

		line = pStream->readLine();
	}

	// Insert last setting
	if (pRun) {
		m_settingMap.insert (pRun->sessionName, pRun);
		pRun = NULL;
	}
}

void CawFile::writeTbpSection (QTextStream *pStream )
{
	*pStream << "[TBP]" << endl;
	// Individual TBP Session options
	RUN_SETTING *pRun;
	SessionMap::iterator it = m_sessions[TIMER_TRIGGER].begin();
	for( ; it != m_sessions[TIMER_TRIGGER].end(); ++it ) {
		TBP_OPTIONS *pTbsSession = static_cast <TBP_OPTIONS *>(it.data());
		pRun = static_cast<RUN_SETTING *> (pTbsSession);

		//each session separated by this blank line
		*pStream << endl;
		helpWriteRunSetting(pStream, pRun);
		*pStream << "ProfileFile=" << pTbsSession->sessionFile << endl;
		*pStream << "Cpus=" << pTbsSession->Cpus << endl;
		*pStream << "Interval=" << pTbsSession->msInterval << endl;
	}
	*pStream << endl << "[End]" << endl;
}


//Reads all the timer-based profile sessions
void CawFile::readTbpSection( QTextStream *pStream )
{
	QString line = pStream->readLine();

	//This is allocated on the first blank line
	TBP_OPTIONS *pTbp = NULL;

	while (!line.startsWith ("[End]")) {
		if (pStream->atEnd ()) {
			break;
		}

		QString parm = line.section ('=', 0, 0);
		QString value = line.section ('=', 1);
		if (helpReadRunSetting (parm, value, static_cast<RUN_SETTING *>(pTbp))) { 
			// This case is intentionally empty, the handling is done in
			// helpReadRunSetting, we need this to set up the other elses
		} else if (parm.startsWith ("ProfileFile")) {
			pTbp->sessionFile = value;
		} else if (parm.startsWith ("Cpus")) {
			pTbp->Cpus = value.toInt();
		} else if (parm.startsWith ("Interval")) {
			pTbp->msInterval = value.toFloat();
		} else if (parm.startsWith ("Name")) {  // Prior to V8
			pTbp->sessionName = value;
		} else if (line.isEmpty()) {
			//write info to map
			if (NULL != pTbp) {
				m_sessions[TIMER_TRIGGER].insert (pTbp->sessionName,
					static_cast<SESSION_OPTIONS *>(pTbp));
			}

			// create next, these will be deleted when the object closes
			pTbp = new TBP_OPTIONS;
			RETURN_IF_NULL (pTbp, NULL);
		}
		line = pStream->readLine();
	}
	if (NULL != pTbp) {
		if (!pTbp->sessionFile.isEmpty()) {
			//write info to map
			m_sessions[TIMER_TRIGGER].insert (pTbp->sessionName,
				static_cast<SESSION_OPTIONS *>(pTbp));
		} else
			delete pTbp;
	}
}//CawFile::ReadTbpSection


void CawFile::writeEventSection (QTextStream *pStream )
{
	*pStream << "[EBP]" << endl;

	// Individual Ebp Session options
	RUN_SETTING *pRun;
	SessionMap::iterator it = m_sessions[EVENT_TRIGGER].begin();
	for( ; it != m_sessions[EVENT_TRIGGER].end(); ++it ) {
		EBP_OPTIONS *pEventSession = static_cast <EBP_OPTIONS *>(it.data());
		pRun = static_cast<RUN_SETTING *> (pEventSession);

		//each session separated by this blank line
		*pStream << endl;
		helpWriteRunSetting(pStream, pRun);
		*pStream << "ProfileFile=" << pEventSession->sessionFile << endl;
		*pStream << "Cpus=" << pEventSession->Cpus << endl;
		*pStream << "MultiplexInterval=" << QString::number(pEventSession->msMpxInterval) << endl;
		//write event cfg

		PerfEventList::iterator it = pEventSession->getEventContainer()->getPerfEventListBegin();
		PerfEventList::iterator it_end = pEventSession->getEventContainer()->getPerfEventListEnd();
		for (; it != it_end; it++) {
				//PerfEvent = type, opName,ev_select,unitmask,flags,eventCount
				*pStream << "PerfEvent=";
				*pStream << (*it).type << ",";
				*pStream << (*it).opName << ",";
				*pStream << (*it).select << ",";
				*pStream << (*it).umask << ",";
				*pStream << (*it).flags << ",";
				*pStream << (*it).count << endl;
		}
	}
	*pStream << endl << "[End]" << endl;
}//CawFile::writeEventSection


void CawFile::readEventSection( QTextStream *pStream )
{
	QString line = pStream->readLine();
	EBP_OPTIONS *pEventOpts = NULL;

	while (!line.startsWith ("[End]")) {
		QString parm = line.section ('=', 0, 0);
		QString value = line.section ('=', 1);
		//note that the first line should be blank, so pEventOpts will be valid
		if (helpReadRunSetting(parm, value, static_cast<RUN_SETTING *>(pEventOpts))) {
			// This case is intentionally empty, the handling is done in
			// helpReadRunSetting, we need this to set up the other elses
		} else if (parm.startsWith ("ProfileFile")) {
			pEventOpts->sessionFile = value;
		} else if (parm.startsWith ("Cpus")) {
			pEventOpts->Cpus = value.toInt();
		} else if (parm.startsWith ("MultiplexInterval")) {
			pEventOpts->msMpxInterval = value.toULongLong();
		} else if (parm.startsWith ("PerfEvent")) {
			//The section depends on the order it was written
			//PerfEvent = type, opName,ev_select,unitmask,flags,eventCount
			PerfEvent pe;
			pe.type   = value.section (",", 0, 0).toUInt ();
			pe.opName = value.section (",", 1, 1);
			pe.select = value.section (",", 2, 2).toUInt ();
			pe.umask  = value.section (",", 3, 3).toUInt ();
			pe.flags  = value.section (",", 4, 4).toUInt ();
			pe.count  = value.section (",", 5, 5).toULong();
			pEventOpts->getEventContainer()->add(pe);
		} else if (parm.startsWith ("Name")) {  // Prior to V8
			pEventOpts->sessionName = value;
		} else if (parm.startsWith ("OneEvent")) {  // Prior to V8
			//The section depends on the order it was written
			//OneEvent = group,index,ev select,unitmask,eventOs,eventUsr,eventCount,Edge
			PerfEvent pe;
			pe.type   = 0;
			pe.opName = "";
			pe.select = value.section (",", 2, 2).toUInt ();
			pe.umask  = value.section (",", 3, 3).toUInt ();
			pe.count  = value.section (",", 6, 6).toULong();
			pe.setOs(value.section (",", 4, 4).toUInt () == 1);
			pe.setUsr(value.section (",", 5, 5).toUInt () == 1);
			pe.setEdge(value.section (",", 7, 7).toUInt () == 1);
			pEventOpts->getEventContainer()->add(pe);
		} else if (line.isEmpty()) {
			//write info to map
			if (NULL != pEventOpts) {
				m_sessions[EVENT_TRIGGER].insert (pEventOpts->sessionName,
					static_cast<SESSION_OPTIONS *>(pEventOpts));
			}

			// create next, these will be deleted when the object closes
			pEventOpts = new EBP_OPTIONS;
			RETURN_IF_NULL (pEventOpts, NULL);
		}
		line = pStream->readLine();
	}
	if (NULL != pEventOpts) {
		if (!pEventOpts->sessionFile.isEmpty()) {
			//write info to map
			m_sessions[EVENT_TRIGGER].insert (pEventOpts->sessionName,
				static_cast<SESSION_OPTIONS *>(pEventOpts));
		}
		else {
			delete pEventOpts;
		}
	}
}//CawFile::readEventSection


RUN_SETTING * CawFile::getRunSetting (QString name)
{
	SettingMap::iterator it = m_settingMap.find (name);
	if (it != m_settingMap.end())
		return  it.data();
	else
		return NULL;
}


QStringList CawFile::getSettingList ()
{
	QStringList list;

	SettingMap::iterator it = m_settingMap.begin();
	SettingMap::iterator it_end = m_settingMap.end();
	for (; it != it_end; it++) 
		list.push_back(it.key());
	return list;
}


QStringList CawFile::getLaunchHistory ()
{
	return m_launchHistory;
}


QStringList CawFile::getWorkDirHistory ()
{
	return m_workDirHistory;
}


QString CawFile::getLastProfile ()
{
	QString ret;

	SettingMap::iterator it = m_settingMap.find(m_lastRunSettingName);
	if (it != m_settingMap.end())
		ret = it.data()->dcConfig;

	if (ret.isEmpty())
		ret = CURRENT_TIME;
	return ret;
}


//update last profile
void CawFile::setLastProfile (QString profileName)
{
	SettingMap::iterator it = m_settingMap.find(m_lastRunSettingName);
	if (it != m_settingMap.end())
		it.data()->dcConfig = profileName;
}


bool CawFile::addRunSetting(QString name, RUN_SETTING * pRunSetting)
{
	if (!pRunSetting || name.isEmpty())
		return false;

	if (m_settingMap.find(name) != m_settingMap.end())
		return false;

	m_settingMap.insert(name, pRunSetting);

	return true;
}


void CawFile::addLaunchHistory(QString launch)
{
	if (launch.isEmpty())
		return;

	if (m_launchHistory.find(launch) == m_launchHistory.end())
		m_launchHistory.push_front(launch);
}


void CawFile::addWorkDirHistory(QString workDir)
{
	if (workDir.isEmpty())
		return;

	if (m_workDirHistory.find(workDir) == m_workDirHistory.end())
		m_workDirHistory.push_front(workDir);
}


bool CawFile::deleteRunSetting(QString name)
{
	if (name.isEmpty())
		return false;

	SettingMap::iterator it = m_settingMap.find(name);
	if (it == m_settingMap.end())
		return false;

	m_settingMap.remove(it);

	return true;
}

bool CawFile::setLastRunSetting ( QString name )
{
	if (name.isEmpty())
		return false;

	SettingMap::iterator it = m_settingMap.find(name);
	if (it == m_settingMap.end())
		return false;
	
	m_lastRunSettingName = name;
	return true;
}

RUN_SETTING * CawFile::getLastRunSetting()
{
	if (m_lastRunSettingName.isEmpty())
		return NULL;

	SettingMap::iterator it = m_settingMap.find(m_lastRunSettingName);
	if (it == m_settingMap.end())
		return NULL;
	
	return (RUN_SETTING*) it.data();
}
