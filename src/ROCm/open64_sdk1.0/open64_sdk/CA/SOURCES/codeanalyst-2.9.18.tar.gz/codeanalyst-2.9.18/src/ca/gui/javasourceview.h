//$Id: javasourceview.h,v 1.5 2005/02/14 16:52:40 jyeh Exp $
// interface for the CJavaSourceView class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#if !defined(JAVAFSOURCEVIEW_H__04B75858_01F8_43c4_8B9A_0A3522AF346D__INCLUDED_)
#define JAVAFSOURCEVIEW_H__04B75858_01F8_43c4_8B9A_0A3522AF346D__INCLUDED_

#include "stdafx.h"
#include "sourceview.h"
#include "jncfile.h"
#include "symbolengine.h"
#include "codeDensity.h"

#define JAVASRCFILEMAP	"javasrcfile.map"

typedef QMap<QString, QString> JavaSrcFileMap;
typedef QMap<VADDR, QCString> JavaOffsetDsmMap;


class CJavaSourceView : public DataTab 
{	
	Q_OBJECT
public:
	CJavaSourceView (ViewShownData *pViewShown, VADDR Address, SampleMap SampMap, 
		QWidget* parent, QString jncDir, const char* name, 
		ProfileAttribute profInfo, JitBlockMap jitBlockMap, 
		int wflags );

	~CJavaSourceView();

	bool	Initialize();
	void	Tag( QString caption );
	void	DisplayJavaSource();

protected:
	void showEvent (QShowEvent * e);

private:
	void    PrintSrcInfo();
	void	DisplayNativeCode();
	void	ReadSourceFileMap();
	void	WriteSourceFileMap();
	void	AddJncNativeCode(JIT_BLOCK_INFO jitBlock, 
		SrcFunctionMap *pfunMap, 
		SrcChartSampMap *psampMap);
	void addDataToList ();
	QListViewItem * GetSourceLineItem(int lineNum);
	void ReorderInstNumbers(QListViewItem *plistviewItem);
	void SwapFrist2Items(QListViewItem *plistviewItem);
	QListViewItem* GetPrecedingChildItem (QListViewItem *plistviewItem,
		VADDR addr);
	bool ReadJNCDataSec(const char *);

public slots:
	void OnNewJavaHotspot( VADDR addr, QString caption );
	void OnSelectionChange();
	void OnRightClick( QListViewItem *pItem, const QPoint &pt, int i );
	void OnDensityVisibilty ();
	virtual void onViewChanged (ViewShownData* pShownData);

private slots:
	void OnListRedrawn (); 
	void OnHeaderClicked (int column);

private:
	ProfileAttribute m_profInfo;
	UINT32		m_moduleSamples;
	QPopupMenu		*m_pMenu;
	ChartListView	*m_pSourceList;
	SampleMap		m_SampleMap;
	QString		m_jncDir;

	DWORD		 m_nSourceLines;
	VADDR		 m_Address;

	QListViewItem	*m_pItemOfInterest;
	QProgressDialog	 m_progressDlg;
	QString			 m_Caption;
	// source file path to read source code from
	QString			 m_SourceFilePath;
	JavaSrcFileMap	 m_SrcFileMap;
	JitBlockMap		 m_jitBlockMap;
	unsigned int     m_dataSecOffset;
	VADDR m_jnc_load_addr;
	JavaSrcLineInfo * m_pSrcInfo;
	unsigned int     m_srcEntryCnt;
	SrcDensityView * m_densityChart;
};


#endif
