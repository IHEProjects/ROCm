#ifndef _DATALISTITEM_H_
#define _DATALISTITEM_H_

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qlistview.h>
#include <qcolor.h>
#include "stdafx.h"

using namespace std;


//base item for the listview in a data tab - allows dynamic columns
//	An example IndexVector would hold 0, 1, 6, 5.  This would mean to the line
//	item should show dataList[0] in column 1, datalist[1] in column 2, 
//	dataList[6] in column 3, and datalist[5] in column 4
class DataListItem : public QListViewItem
{
public:
	DataListItem( ViewShownData *pViewShown, int indexOffset, 
		QListView * pParent);
	DataListItem( ViewShownData *pViewShown, int indexOffset, 
		QListView * pParent, QListViewItem * pAfter);
	DataListItem( ViewShownData *pViewShown, int indexOffset, 
		QListViewItem * pItem);
	DataListItem( ViewShownData *pViewShown, int indexOffset, 
		QListViewItem * pItem, QListViewItem * pAfter);

	~DataListItem();

	void setItemColor(QColor color) { m_textColor = color;};
	void setBackgroundColor (QColor color) {m_backColor = color;};
	void setPrecision (int precision);
	void setTotal(SampleDataMap *pTotal) {m_pTotalData = pTotal;};
	virtual void drawData (SampleDataMap *pSampMap, UINT64 sessionTotal, 
					bool bAssign = false );
	virtual void drawPercent (SamplePercentMap *pPercentMap); 

	QString getTipString() {  return m_tip;	};
	void getItemSamples(SampleDataMap &data);
	SampleDataMap* getItemSamples() {return m_pSampMap;};

	// The following functino should be removed.
	QStringList m_dataList;
	//this would be better as a slot.
	void appendData (float data, int precision = 2);
	void updateShown ();
	void setChecked (int column);
	//show check boxes if necessary
	virtual void paintCell( QPainter * p, const QColorGroup & cg, int column, 
		int width, int align );
private:
	ViewShownData *m_pViewShown;
	int m_indexOffset;
	int m_precision;

	QString m_tip;
	int m_checkColumn;
	QColor m_textColor;
	QColor m_backColor;
	SampleDataMap *m_pSampMap;
	SampleDataMap *m_pTotalData;
};



#endif ///_DATALISTITEM_H_
