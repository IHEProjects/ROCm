//$Id: EventCfg.h 17066 2009-08-28 22:38:27Z ssuthiku $
//  This is our derivative of the iEventCfg.ui

/**
*   (c) 2006 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/

#ifndef EVENT_CFG_H
#define  EVENT_CFG_H

#include <qstring.h>
#include <qcheckbox.h>
#include <qlistbox.h>
#include "iEventCfgDlg.h"
#include "ProfileCollection.h"
#include "eventsfile.h"
#include "cawfile.h"


const unsigned int UNIT_MASK_COUNT = 8;

class UnitCheckBox : public QCheckBox
{
	Q_OBJECT
private:
	int m_index;
public:
	UnitCheckBox (QWidget *parent, int index);
	~UnitCheckBox ();
signals:
	void checked (int index);
private slots:
	void onChecked ();
};


///////////////////////////////////////////////////////////////////////////////
class EventWithProps : public QListViewItem
{
public:
	EventWithProps (QListView *pParent) 
		: QListViewItem (pParent)
	{
	};

	EventWithProps (QListView *pParent, EventWithProps *pAfter)
		: QListViewItem(pParent, pAfter)
	{
	}; 

	QString		opName;
};


///////////////////////////////////////////////////////////////////////////////
class EventCfgDlg : public iEventCfgDlg
{ 
	Q_OBJECT
public:
	enum AvailableTab {
		PAGE_PMC = 0,
		PAGE_FETCH,
		PAGE_OP,
		PAGE_IMPORT
	};

	enum TableColumns {
		ColSel= 0,
		ColSrc,
		ColCount,	
		ColAvailName = 2,	
		ColUmask,	
		ColUsr,	
		ColOs,	
//		ColEdge,
		ColSelName,	
		MaxCol
	};


	EventCfgDlg ( QWidget* parent = 0, const char* name = 0, bool modal = true,
		WFlags fl = WStyle_Customize | WStyle_NormalBorder | WStyle_Title );
	
	virtual ~EventCfgDlg ();

	void setProfile ( ProfileCollection *pProfiles,
				QString profileName, 
				CEventsFile * pEventsFile = NULL);
	bool wasModified () { return m_modified;};

private:
	EventWithProps * addAvailableEvent(QListView *lv, CpuEvent ev);
	EventWithProps * addSelectedEvent( QString name,
					QString opName,
					QString src,
					QString evSel, 
					QString count, 
					unsigned int umask,
					QString usr,
					QString os,
					QString edge);
	bool detectCpuAndGetEventsFile ();
	int getCpuInfo(const char* path,
			QString &vendorId,
			QString &name,
			QString &family,
			QString &model,
			QString &stepping,
			QString &flags);
	void buildUmaskBoxes (QGroupBox * pBox, UnitCheckBox ** pUmasks);
	unsigned int getCurrentUmask(UnitCheckBox ** pBox);
	unsigned int getDefaultUmask(QString opName);
	void setCurrentUmask(UnitCheckBox ** pBox, unsigned int umask);
	void setupInfoTab();
	void clearUmasks( UnitCheckBox ** pBox);
	void syncAllIbsFetchEvents(unsigned long count, unsigned int umask);
	void syncAllIbsOpEvents(unsigned long count, unsigned int umask); 
	bool hasDuplicateEvent(EventWithProps * pEvent, QString umask);
	QString helpGetCheckBoxValue(QCheckBox * pBox);
	unsigned int getDefaultCountForEvent(QString opName);
	unsigned int getMinCountForEvent(QString opName);
	bool checkEventsMinCount(QString opName, unsigned long count);
	bool checkEventsMaxCount(unsigned long count);
	bool checkIbsMaxCount(unsigned long count);
	bool checkMaxPmcEvent();
	bool verifySelectedEvent(EventWithProps * pEvent, 
					unsigned long count,
					unsigned int umask);
	bool verifyPmcEvents(EventWithProps * pEvent, 
					unsigned long count, 
					unsigned int umask);
	bool verifyIbsFetchEvents(EventWithProps * pEvent, 
					unsigned long count, 
					unsigned int umask);
	bool verifyIbsOpEvents(EventWithProps * pEvent, 
					unsigned long count, 
					unsigned int umask);

public slots:
	virtual void onApplyEventSetting();
	virtual void onRemove();
	virtual void onSave();
	virtual void onSaveAs();
	virtual bool onSave(QString saveName);
	virtual void onOk();
	
	virtual void onAddPmcEvent();
	virtual void onAddFetchEvent();
	virtual void onAddOpEvent();
	virtual void onAddImportEvent();

	virtual void onManageDcConfigs();
	virtual void onDcConfigNameChanged(const QString & str);
	virtual void onImportDcConfigChanged(const QString & configName);
	virtual void onAvailableTabChanged(QWidget *w);

	void onSelectedSelectionChanged(QListViewItem * pEvent); 
	void onPmcCountChanged();

private:
	bool		m_modified;
	bool		m_isViewProperty;
	QString		m_eventsFilePath;
	UnitCheckBox 	* m_pUmask[UNIT_MASK_COUNT];
	CEventsFile	* m_pCaEventsFile;
	ProfileCollection * m_pProfiles;
	unsigned int	m_pmcEventCount;
	unsigned long 	m_gFetchCount;
	unsigned int 	m_gFetchUmask;
	unsigned long 	m_gOpCount;
	unsigned int 	m_gOpUmask;

	QString 	m_cpuName;
	QString 	m_cpuFamily;
	QString 	m_cpuModel;
	QString 	m_cpuStepping;
	QString 	m_cpuVendorId;
	QString 	m_cpuFlags;
	bool		m_closeEventsFile;
	QString 	m_description;
};
#endif
