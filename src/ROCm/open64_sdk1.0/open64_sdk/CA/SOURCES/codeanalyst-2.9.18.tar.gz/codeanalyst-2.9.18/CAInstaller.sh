#!/bin/bash

# FILE        : CAInstaller.sh
# DESCRIPTION : CodeAnalyst Installation Wizard script
# AUTHOR      : Suravee Suthikulpanit (suravee.suthikulpanit@amd.com)
#

# General parameters
CAINSTALLER_VER=1.1
CAINSTALLER_DATE="3/2008"
CA_CONFIG_FILE="/root/AMD/CodeAnalyst/ca.config"
NUMCPU=`cat /proc/cpuinfo | grep "processor" |wc -l`
NUM_MAKE=0
MAX_NUM_MAKE=4 
BITNESS="`uname -m`"
RECONFIG=1
PROMPT_USER=0
QUIET_BUILD=0
MAKEFLAGS=""
OP_BIN_DIR=""

restoreDefault()
{
	#ca.config parameters
	PREFIX_DIR="/opt/CodeAnalyst/"
	OP_SRC_DIR=""
	CONFIGUREFLAGS=""
	INSTALL_KM=0
	JVMTI_32=0
	JVMTI_64=0
	JDK_64=""
	JDK_32=""
}

showUsage()
{
	echo "USAGE: CAInstaller.sh [-h|--help] [-f|--file]"
        echo "       Options :"
        echo "       -h|--help         Print this message"
        echo "       -v|--version      Print version of CodeAnalyst Installer"
        echo "       -f|--file=<file>  Specify the CodeAnalyst configuration file"
        echo "       -p|--prompt       Prompt User between each installation step"
        echo "       -q|--quiet        Quiet Installation mode"
        echo "       -n|--numproc=<n>  Specify number of processes used by make (Default: Upto $MAX_NUM_MAKE)"
        echo "       -u|--uninstall    Uninstall CodeAnalyst based on the installer configuration."
        echo ""
}

showVersion()
{
        echo ""
	echo "CAInstaller.sh : version $CAINSTALLER_VER (Date $CAINSTALLER_DATE)"
        echo ""
	exit 0;
}

readConfig()
{
	echo ".... Import CodeAnalyst installer configuration file"
	echo ".... CodeAnalyst found an existing configuration file ($CA_CONFIG_FILE)."
	source $CA_CONFIG_FILE
	echo ""
}

saveConfig()
{
	mkdir -p /root/AMD/CodeAnalyst
	echo ".... Saving configuration in \"$CA_CONFIG_FILE\" file."
	echo "# This is the configuration file for CodeAnalyst Linux Installation Wizard." > $CA_CONFIG_FILE
	echo "#" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# --prefix option to CodeAnalyst / JVMTI \"configure\" script." >> $CA_CONFIG_FILE
	echo "PREFIX_DIR=\"$PREFIX_DIR\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# This is the location of external OProfile source." >> $CA_CONFIG_FILE
	echo "OP_SRC_DIR=\"$OP_SRC_DIR\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Command-line option to CodeAnalyst \"configure\" script." >> $CA_CONFIG_FILE
	echo "CONFIGUREFLAGS=\"$CONFIGUREFLAGS\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Install CodeAnalyst Kernel Module (0/1)" >> $CA_CONFIG_FILE
	echo "INSTALL_KM=\"$INSTALL_KM\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Install 32-bit libCAJVMTIA.so (0/1)" >> $CA_CONFIG_FILE
	echo "JVMTI_32=\"$JVMTI_32\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Install 64-bit libCAJVMTIA.so (0/1)" >> $CA_CONFIG_FILE
	echo "JVMTI_64=\"$JVMTI_64\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Absolute path of where 64-bit Java is installed" >> $CA_CONFIG_FILE
	echo "JDK_64=\"$JDK_64\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Absolute path of where 32-bit Java is installed" >> $CA_CONFIG_FILE
	echo "JDK_32=\"$JDK_32\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE

	echo "# Add non-root users to amdca group" >> $CA_CONFIG_FILE
	echo "NONROOTUSER=\"$NONROOTUSER\"" >> $CA_CONFIG_FILE
	echo "" >> $CA_CONFIG_FILE
}

doOptions()
{
        while [ "$#" -ne 0 ]
        do
                arg=`printf %s $1 | awk -F= '{print $1}'`
                val=`printf %s $1 | awk -F= '{print $2}'`
                shift
                if test -z "$val"; then
                        local possibleval=$1
                        printf %s $1 "$possibleval" | grep ^- >/dev/null 2>&1
                        if test "$?" != "0"; then
                                val=$possibleval
                                if [ "$#" -ge 1 ]; then
                                        shift
                                fi
                        fi
                fi

                case "$arg" in
                        -h|--help)
                                showUsage
                                exit 0                          
                                ;;
			-f|--file)
				CA_CONFIG_FILE="$val"			
				echo ".... Using configuration file : $CA_CONFIG_FILE"	
                                ;;
			-v|--version)
				showVersion
                                ;;
			-p|--prompt)
				PROMPT_USER=1
                                ;;
			-q|--quiet)
				QUIET_BUILD=1
                                ;;
			-n|--numproc)
				NUM_MAKE=$val
				echo ".... Using $NUM_MAKE processes for Building."
                                ;;
			-u|--uninstall)
				UNINSTALL=1
                                ;;
                        *)
                                echo "ERROR: Invalid options $arg"
                                show_usage
                                exit 1
                                ;;
                esac
        done
}

parseInput()
{
	read input
	if test $input ; then 
		case "$input" in
			y|Y|yes|Yes|YES)
				echo 1
				;;
			n|N|no|No|NO)
				echo 0
				;;
		esac
	else
		echo 1
	fi
	return
}

doSetup()
{
	if [ $NUM_MAKE = 0 ]; then
		# Get thee suitable number of process for make
		# Currently, default at 4
		if [ $NUMCPU -gt $MAX_NUM_MAKE ]; then 
			MAKEFLAGS="$MAKEFLAGS -j$MAX_NUM_MAKE"
		else 
			MAKEFLAGS="$MAKEFLAGS -j$NUMCPU"
		fi
	else
		MAKEFLAGS="$MAKEFLAGS -j$NUM_MAKE"
	fi

	if [ "$QUIET_BUILD" = 1 ] ; then
		MAKEFLAGS="$MAKEFLAGS -s"
	fi
}

nextStep()
{
	if [ "$PROMPT_USER" = "1" ] ; then
		echo ""
		echo "**********************************************************************"
		echo "* CAInstaller.sh : Next step is : \"$1\""
		echo "* Continue? ([Y]es/[N]o, Default Yes)"
		tmp=`parseInput`
		if [ "$tmp" = "0" ]; then
			echo "* CAInstaller.sh : Installation is aborted by user."
			echo "*                  CodeAnalyst installation is incomplete."
			echo "*"
			echo "**********************************************************************"
			exit 0;	
		fi
	fi	
	clear
	showStep $@
}

showStep()
{
	echo "**********************************************************************"
	echo "*"
	echo "* STEP: $@" 
	echo "*"
	echo "**********************************************************************"

}

nextConfig()
{
	echo "-----------------------------------------------------------"
}

doConfig()
{
	showStep "Configuring CodeAnalyst Installation"
	echo "*"
	echo "* CodeAnalyst will be built and installed based on the following"
	echo "* information :"
	echo ""

	nextConfig
	echo "- Please specify location where you want to install CodeAnalyst."
	echo "  (Default: /opt/CodeAnalyst/ )"
	read tmp
	if test $tmp ; then
		PREFIX_DIR=$tmp
	fi
	
	nextConfig
	echo "- Please specify additional options for CodeAnalyst \"configure\" script."
	echo "  Except the \"--prefix\" option which should be specified above."
	echo "  (Type \"help\" for list of options.)"
	read CONFIGUREFLAGS
	while test "$CONFIGUREFLAGS" = "help" 
	do
		./configure --help | more
		echo ""
		echo "- Please specify additional options for CodeAnalyst \"configure\" script."
		echo "  Except the \"--prefix\" option which should be specified above."
		echo "  (Type \"help\" for list of options.)"
		read CONFIGUREFLAGS
	done

	nextConfig
	echo "  By default, CodeAnalyst build an install a modified version of OProfile-0.9.6"
	echo "  To use this version, just leave the input blank and hit enter."
	echo ""
	echo "  To specify other version of OProfile, PLEASE ENTER THE FULLPATH TO"
	echo "  THE OPROFILE SOURCE TREE WHICH IS ALREADY BUILT AND INSTALLED."
	echo ""
	echo "  (Default: )"
	read tmp
	if test $tmp ; then
		OP_SRC_DIR=$tmp
	fi
	
	# If not using our oprofile, do not configure JVMTI
	if test "$OP_SRC_DIR" = "" ; then

		nextConfig
		echo "- Do you want to install CodeAnalyst Java Profiling Agent?" 
		echo "  ([Y]es/[N]o, Default: Yes)"
		INSTALL_JVMTI=`parseInput`

		if test "$INSTALL_JVMTI" = 1 ; then
			if [ $BITNESS = "x86_64" ]; then
				JVMTI_BITNESS="";
				echo "- Please specify bitness of Java runtime?"
				echo " (32/64/[B]oth)"
				read JVMTI_BITNESS
				if [ -z $JVMTI_BITNESS ] ; then
					JVMTI_BITNESS="Both"
				fi
			
				case "$JVMTI_BITNESS" in
				b|B|both|BOTH|Both)
					JVMTI_32=1
					JVMTI_64=1
					;;
				32)
					JVMTI_32=1
					;;
				64)
					JVMTI_64=1
					;;
				esac
			else
				JVMTI_32=1
				JVMTI_64=0
				JDK_64=""
				JDK_32=""
			fi # BITNESS
		else
			JVMTI_32=0
			JVMTI_64=0
			JDK_64=""
			JDK_32=""
		fi # INSTALL_JVMTI

		if [ "$JVMTI_32" = "1" ]; then
			while [ -z "$JDK_32" ];
			do
				echo "- Please specify the absolute path of where 32-bit Java is installed?"
				read JDK_32;
			done
		fi

		if [ "$JVMTI_64" = "1" ]; then
			while [ -z "$JDK_64" ];
			do
				echo "- Please specify the absolute path of where 64-bit Java is installed?"
				read JDK_64;
			done
		fi
	fi

	nextConfig
	echo "- Do you want to install CodeAnalyst Kernel Module?"
	echo "  This is necessary if one of the following applies:"
	echo ""
	echo "  * Running on Barcelona (family 0x10) and beyond"
	echo "  * Want Java profiling capability on Red Hat Enterprise Linux 4 "
	echo ""
	echo "  ([Y]es/[N]o, Default: Yes)"
	INSTALL_KM=`parseInput`

	nextConfig
	echo "- Please specify non-root users to be added to the \"amdca\" group :"
	echo "  NOTE:"
	echo "  * Please provide list of users with comma separated."
	echo "  * Omit space"
	read NONROOTUSER 
	
	echo ""	
}

printYesOrNo()
{
	if [ "$1" = "1" ]; then
		echo "Yes"
	else
		echo "No"
	fi
}

showSummary()
{
	showStep "CodeAnalyst Installation Summary"
	echo ""
	echo " - CodeAnalyst installation location                 : $PREFIX_DIR"
	echo " - Additional flags to configure                     : $CONFIGUREFLAGS"
	echo " - External OProfile source directory                : $OP_SRC_DIR"
	echo " - Install 32-bit CodeAnalyst JVMTI Agent , JDK path : `printYesOrNo $JVMTI_32` , $JDK_32" 
	echo " - Install 64-bit CodeAnalyst JVMTI Agent , JDK path : `printYesOrNo $JVMTI_64` , $JDK_64" 
	echo " - Install CodeAnalyst Kernel Module                 : `printYesOrNo $INSTALL_KM`" 
	echo " - Non-root users                                    : $NONROOTUSER "
	echo ""
	echo " Accept this configuration?"
	echo " ([Y]es and continue / [N]o and exit / [R]econfig / [S]ave and exit, Default: Reconfig)"
	read input
	
	case "$input" in
		y|Y|yes|Yes|YES)
			saveConfig
			RECONFIG=0
			;;
		n|N|no|No|NO)
			exit 0
			;;
		r|R|reconfig|Reconfig|RECONFIG)
			RECONFIG=1
			clear
			;;
		s|S|save|Save|SAVE)
			saveConfig
			exit 0
			;;
		*)
			RECONFIG=1
			;;
	esac
}

checkErrorOut()
{
	if test "$?" != "0" ; then 
		errorOut; 
	fi;
}

errorOut()
{
	echo "**********************************************************"
	echo "* CAInstaller.sh : ERROR! Please check configuration and "
	echo "*                  re-run the \"CAInstaller.sh\"."
	echo "*"
	echo "**********************************************************"
	exit 1;
}

doFinish()
{
        echo "*************************************************************************"
	echo "* CAInstaller.sh :"
	echo "*"
        echo "* CodeAnalyst Linux has finished installation, please do the followings:"
        echo "*"
        echo "* 1) Ensure that \"$PREFIX_DIR/bin\" \"$PREFIX_DIR/sbin\" are in the PATH environment variable."
        echo "*"
	echo "* 2) Ensure that \"$PREFIX_DIR/man\" or \"$PREFIX_DIR/share/man\""
	echo "*    is in the MANPATH environment variable."
        echo "*"
        echo "* 3) [Optional] "
        echo "*    To allow non-root users to run CodeAnalyst, please do one of the following: "
        echo "*        - Run \"$PREFIX_DIR/sbin/ca_user_manager\" "
        echo "*    OR"
        echo "*        - Manually add users by:"
        echo "*            1. Add the following line to /etc/sudoers "
        echo "*               using command \"visudo\""
        echo "*"
        echo "*                   %amdca ALL= NOPASSWD: /opt/CodeAnalyst/bin/oprofiled"
        echo "*"
        echo "*            2. Add each user to group \"amdca\" in file \"/etc/group\""
        echo "*"
        echo "*************************************************************************"
	exit 0;
}

uninstallCA()
{
	echo ".... Uninstall existing CodeAnalyst"
	make clean uninstall 1> /dev/null
	make -C src/oprofile/libopagent clean uninstall 1> /dev/null
	echo ""
}

uninstallCAKM()
{
	echo ".... Uninstall existing Kernel Module"
	src/cakm/mod_uninstall.sh
	/usr/bin/pkill oprofiled
	echo ""
}

uninstallJVMTI()
{
	echo ".... Uninstall existing JVMTI"
	make -C src/ca_agent/jvmti clean uninstall 1> /dev/null
	echo ""
}

unloadCAKM()
{
	echo ".... Unload OProfile Kernel Module"
	if [ -f /dev/oprofile/cpu_type ]; then
		/bin/umount /dev/oprofile
	fi
	/sbin/lsmod | grep oprofile
	if [ "$?" = "0" ]; then
		/sbin/rmmod oprofile
	fi
	echo ""
}

loadCAKM()
{
	echo ".... Load OProfile Kernel Module"
	grep oprofilefs /proc/filesystems > /dev/null
	if test "$?" -ne 0; then
		modprobe oprofile
		if test "$?" != "0"; then
			# couldn't load the module
			return 1
		fi
		grep oprofile /proc/modules > /dev/null
		if test "$?" != "0"; then
                        # didn't find module
                        return 1
                fi
                grep oprofilefs /proc/filesystems >/dev/null
                if test "$?" -ne 0; then
                        # filesystem still not around
                        return 1
                fi
	fi
	mkdir /dev/oprofile > /dev/null 2>&1
	grep oprofilefs /etc/mtab >/dev/null
        if test "$?" -ne 0; then
                mount -t oprofilefs nodev /dev/oprofile >/dev/null
        fi
}
#-------------------------------------------------------------------------------
# CONFIGURATION 


# Parsing command-line option
doOptions $@

# Check if running as root
if [ "`whoami`" != "root" ]; then
	echo "**************************************************************"
	echo "* CAInstaller.sh : ERROR! Please run this script as \"root\"".
	echo "*"
	echo "**************************************************************"
	exit 1;
fi

# Initialization
doSetup
restoreDefault

# Try to read configuration file
if test -f $CA_CONFIG_FILE; then
	readConfig
	clear
	showSummary
fi

# Run autogen.sh : Need to do before do config
showStep "Preparing configure script."
./autogen.sh
checkErrorOut
clear

# Reconfig if needed
while test "$RECONFIG" = "1"; 
do
	restoreDefault
	doConfig	
	clear
	showSummary
done


#-------------------------------------------------------------------------------
# BUILD AND INSTALL
clear

# Configure CodeAnalyst
CONFIGURE_ARG="--prefix=$PREFIX_DIR $CONFIGUREFLAGS"

if test ! -z $OP_SRC_DIR ; then
	CONFIGURE_ARG="$CONFIGURE_ARG --with-oprofile-source=$OP_SRC_DIR --disable-shared"

	# We try to extract the OP_BINDIR macro from the config.h file
        OP_INSTALL_DIR=`fgrep OP_BINDIR $OP_SRC_DIR/config.h 2> /dev/null | \
                awk '{ sub( /#define OP_BINDIR / , "" ); \
			gsub( /"/ , "" ); \
			gsub( /\/bin/ , "" ); \
			print }'`
else
	OP_INSTALL_DIR=$PREFIX_DIR
fi

echo "DEBUG: OP_INSTALL_DIR = $OP_INSTALL_DIR"

nextStep "./configure $CONFIGURE_ARG"
./configure $CONFIGURE_ARG
checkErrorOut

# Clean and Uninstall the existing CodeAnalyst
nextStep "Uninstalling CodeAnalyst"
uninstallCA
uninstallJVMTI
unloadCAKM
uninstallCAKM
if [ "$UNINSTALL" = "1" ]; then
	echo "**********************************************************"
	echo "* CAInstaller.sh : Uninstallation is completed."
	echo "*"
	echo "**********************************************************"
	exit 0;
fi # UNINSTALL

nextStep "Install CodeAnalyst GUI"
make $MAKEFLAGS install
checkErrorOut

# Install CA Kernel Module
if test "$INSTALL_KM" = "1"; then
	nextStep "Install CodeAnalyst Kernel Module"
	unloadCAKM
#	uninstallCAKM
	./src/cakm/mod_install.sh -r -n
	checkErrorOut
	loadCAKM
fi


# Uninstalling existing JVMTI
if [ "$JVMTI_64" = "1" -o  "$JVMTI_32" = "1" ]; then
	nextStep "Uninstalling existing Java Profiling Agent"
	rm -rf $PREFIX_DIR/bin/libCAJVMTIA*
	rm -rf $PREFIX_DIR/lib/libCAJVMTIA*
	rm -rf $PREFIX_DIR/lib64/libCAJVMTIA*
fi 

# If not using our oprofile, do not build JVMTI
if test "$OP_SRC_DIR" = ""; then

	# Install 64-bit JVMTI
	if test "$JVMTI_64" = "1"; then

		nextStep "Install 64-bit JVMTI Agent"
		pushd src/ca_agent/
		./autogen.sh
		checkErrorOut
		./configure --prefix=$PREFIX_DIR --with-java=$JDK_64
		checkErrorOut

		make clean 
		make install
		checkErrorOut

		popd
	fi

	# Install 32-bit JVMTI
	if test "$JVMTI_32" = "1"; then

		# Need to check if this is a cross-compilation
		if [ $BITNESS = "x86_64" ]; then
			CROSS_COMPILE=1                
		fi

		nextStep "Install 32-bit JVMTI Agent"
		pushd src/ca_agent/
		./autogen.sh
		checkErrorOut
		./configure --prefix=$PREFIX_DIR --with-java=$JDK_32 CFLAGS=-m32 CXXFLAGS=-m32
		checkErrorOut

		make clean 
		make install
		checkErrorOut
		popd
	fi
fi

# Call group.pl
if test "$NONROOTUSER" ; then 
	
	#Sanity check for space (" ")
	echo "$NONROOTUSER" | grep " " > /dev/null
	if test "$?" = "0" ; then 
		echo ".... ERROR: Invalid non-root user string \"$NONROOTUSER\""
		echo "....        Please omit space. You can add non-root" 
		echo "....        users after the installation completes"
		echo "....        using \"$PREFIX_DIR/sbin/ca_user_manger\" script."
	else	
		echo ".... Add users: $NONROOTUSER"
		$PREFIX_DIR/sbin/ca_user_manager -a $NONROOTUSER
		if test "$?" != "0" ; then 
			echo ".... ERROR: Failed to add user \"$NONROOTUSER\" to amdca group."
			echo "....        Please check the input and add non-root user after" 
			echo "....        the installation completes using "
			echo "....        \"$PREFIX_DIR/sbin/ca_user_manager\"."
		fi
	fi;
fi

doFinish
