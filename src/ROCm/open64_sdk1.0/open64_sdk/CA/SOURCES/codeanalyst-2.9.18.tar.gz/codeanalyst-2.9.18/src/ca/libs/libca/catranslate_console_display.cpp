#include "catranslate_console_display.h"

using namespace std;

ca_translate_console_display::ca_translate_console_display()
{
}

ca_translate_console_display::~ca_translate_console_display()
{
}

void ca_translate_console_display::init()
{
}

void ca_translate_console_display::update_display(const char * text)
{
   cout << text << endl;
}

void ca_translate_console_display::update_display_error(const char * text)
{
   cout << "Error: " << text << endl;
}
