//$Id: catranslate.cpp,v 1.3 2006/08/23 16:46:45 ssuthiku Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <sys/utsname.h>
#include <bfd.h>
#include <iostream>
#include <iomanip>
#include <assert.h>
#include <qapplication.h>
#include <qtextedit.h>
#include <qprogressdialog.h>
#include <qurloperator.h>
#include <qnetwork.h>
#include <qstringlist.h>

#include <stdlib.h>

#include "elf.h"
#include "catranslate.h"
#include "stdafx.h"
#include "atuneoptions.h"

#ifndef DISABLE_OPROFILE_LIB
#include "opsampledata_handler.h"
#endif
#include "opxmldata_handler.h"

using namespace std;

const QString KERNEL_MOD_DIR = "/lib/modules/";

CATranslate::CATranslate()
{
    //m_pAnonProcessing = NULL;
    m_pStatusDisplay = NULL;
}

void CATranslate::init(QString & op_data_dir, unsigned int ncpu, 
			QString & caSession, EventMaskEncodeMap & events_map,
			ca_translate_display *display )
{
	m_op_events_map = events_map;
    
	m_op_data_dir = op_data_dir;

	m_ncpu = ncpu;
	
	m_casession = caSession;
	m_pStatusDisplay = display;

}


CATranslate::~CATranslate ()
{
    m_pStatusDisplay = NULL;
}

//helper function to copy the jnc files to session/jit/pid/ dir
void copy_jnc_files(jitDetailVec jitVec, QString sessiondir)
{
	QString jitdir;
	QDir t_dir;
	if (jitVec.size()) {
		jitdir = sessiondir + "/jit";
		t_dir.mkdir (jitdir);
	}

	QString pre_java_id;

	jitDetailVec::iterator f_it  = jitVec.begin();
	jitDetailVec::iterator f_end = jitVec.end();
	for (;f_it != f_end; f_it++) {
		QString src = f_it->jncFile.c_str();
		if (!src.startsWith("/var/lib/oprofile/jit/"))
			continue;

		QString java_id = src.section("/", 5, 5);
		if (pre_java_id != java_id) {
			// this is new java task;
			t_dir.mkdir(jitdir + "/" + java_id);
			pre_java_id = java_id;
		}

		QString dest = sessiondir + "/" + src.section("/", -3, -1);
	
		QFile oldfile (src);
		if (oldfile.open(IO_ReadOnly)) {
			QFile newfile (dest);
			if (newfile.open(IO_WriteOnly)) {
				const QByteArray tmpbuffer = oldfile.readAll();
				newfile.writeBlock(tmpbuffer);
				newfile.close();
			}
			oldfile.close();	
		}
	}
}

bool CATranslate::translate_op_to_ca( unsigned long family, unsigned long model,
				QStringList taskFilter, QString resultName,
				bool useXML)
{
	int ret = false;
	
#ifdef DISABLE_OPROFILE_LIB
	// If DISABLE_OPROFILE_LIB, force to use XML
	useXML = true;
#endif
	if(!useXML)
	{
#ifndef DISABLE_OPROFILE_LIB
		// Use OPROFILE LIB
		opsampledata_handler opDataHandler;

		// Opdata_handler initialization:
		opDataHandler.init(m_op_data_dir.data(), m_op_events_map);
		if (m_pStatusDisplay) {
			opDataHandler.set_display(m_pStatusDisplay);
			m_pStatusDisplay->translationInProgress(true);
		}

		// convert TaskFilter into string list;	
		if ((ret = opDataHandler.read_op_module_data(taskFilter))) {

			// write output ebp file
			opDataHandler.write_ebp_output(resultName.data(), m_ncpu, 
							family, model);

			// Copy jnc files
			jitDetailVec jitVec;	
			opDataHandler.getJitDetailVec(jitVec);
			copy_jnc_files(jitVec, m_casession);
			jitVec.clear();
		
			// Copy jo files
			opDataHandler.copyJoFile(resultName.section("/",0,-2));
		}
#endif //DISABLE_OPROFILE_LIB
	}else{
		// Use Oprofile XML
		opxmldata_handler opDataHandler;

		// Opdata_handler initialization:
		opDataHandler.init(m_op_events_map);
		if (m_pStatusDisplay) {
			opDataHandler.set_display(m_pStatusDisplay);
			m_pStatusDisplay->translationInProgress(true);
		}

		// Generate XML 
		QString xmlPath= m_casession+"/opreport.xml";
		ret = opDataHandler.generateXML(xmlPath.ascii(), taskFilter, m_op_data_dir);

		// Read XML file
		if(ret) {
			ret = opDataHandler.readXML(xmlPath.ascii());	
		}

		if(ret) {
			// Process XML file
			opDataHandler.processXMLData();	

			// write output ebp file
			opDataHandler.write_ebp_output(resultName.data(), 
						m_ncpu, family, model);

			// Copy jo files
			opDataHandler.copyJoFile(resultName.section("/",0,-2));
		}
	}

	if (m_pStatusDisplay)
		m_pStatusDisplay->translationInProgress(false);

    return ret;
}


