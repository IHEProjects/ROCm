/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qstring.h>
#include <qtextview.h>
#include <stdlib.h>

#include "AboutDlg.h"

AboutDlg::AboutDlg( QWidget* parent, const char* name, bool modal,
                                   WFlags fl) : IAboutDlg( parent, name, modal, fl )

{
//        pSplashMap->setPixmap (QPixmap (CA_DATA_DIR "/CASplash.png"));
        txtVersion->setText ("Version " VERSION );

        ldd_process = new QProcess (QString ("ldd"), this);
        if (NULL != ldd_process)
        {
                connect (ldd_process, SIGNAL (readyReadStdout()),
                        this, SLOT (readStdout()));

                connect (ldd_process, SIGNAL (processExited()),
                        this, SLOT (displayBuffer()));

                ldd_process->addArgument (CA_BIN_DIR "/DiffAnalyst");
                ldd_process->start ();
        } else {
                QMessageBox::critical (this, "Memory error", "Could not allocate"
                        " memory");
                m_view_dlls->setText ( "library information unavailable"  );
        }

        buttonOk->setFocus();

}

AboutDlg::~AboutDlg()
{
        // If the qprocess that launched ldd is still in memory, remove it
        if (NULL != ldd_process) {
                delete ldd_process;
                ldd_process = NULL;
        }
        return;
}

//This is signaled when the ldd process exited, so no more input will be
// coming
void AboutDlg::displayBuffer()
{
        for (QStringList::Iterator it = buffer.begin(); it != buffer.end();
                it++) {
                        m_view_dlls->append ( *it );
        }
}


//This is signaled when there is input from the ldd process to be read into
// the buffer
void AboutDlg::readStdout()
{
        QString tmp;

        while (QString::null != (tmp = ldd_process->readLineStdout())) {
                buffer += tmp.section ('(',0,0).stripWhiteSpace();
        }
}

