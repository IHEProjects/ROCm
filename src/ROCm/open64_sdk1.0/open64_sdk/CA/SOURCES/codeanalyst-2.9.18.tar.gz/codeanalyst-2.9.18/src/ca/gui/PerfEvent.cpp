#include "PerfEvent.h"
#include "helperAPI.h"

void PerfEvent::dump()
{
	fprintf(stdout, "PerfEvent: %d, %s, %s, 0x%x, %lu, 0x%x, 0x%x\n",
			type, opName.ascii(), name.ascii(),
			select, count, umask, flags);
}

QString PerfEvent::getEventMaskEncodeMapKey()
{
	QString ret;
	ret += QString("event:") + opName;
	ret += QString(" count:") + QString::number(count,10);
	ret += QString(" unit-mask:") + QString::number(umask,10);
	return ret;
}


unsigned int PerfEvent::getEventType(QString cpuType, unsigned int value)
{
	if (isSupportedAmdCpuType(cpuType)) {
		if (isIbsFetchEvent(value))
			return PerfEvent::IbsFetch;
		else if (isIbsOpEvent(value))
			return PerfEvent::IbsOp;
		else
			return PerfEvent::Pmc;
	} else {
		return PerfEvent::OProfile;
	}
}


bool PerfEvent::isPmcEvent(unsigned int value)
{
	if (value < IBS_FETCH_EVENT_BEGIN)
		return true;
	else
		return false;	
}


bool PerfEvent::isIbsFetchEvent(unsigned int value)
{
	if (value >= IBS_FETCH_EVENT_BEGIN
	&&  value <  IBS_OP_EVENT_BEGIN)
		return true;
	else
		return false;	
}


bool PerfEvent::isIbsOpEvent(unsigned int value)
{
	if (value >= IBS_OP_EVENT_BEGIN
	&&  value <=  IBS_OP_EVENT_END)
		return true;
	else
		return false;	
}

