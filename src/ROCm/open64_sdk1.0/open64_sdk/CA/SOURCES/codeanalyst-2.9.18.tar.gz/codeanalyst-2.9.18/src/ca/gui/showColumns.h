/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

//@doc
//@module showColumns.h | The definition for the ColumnType struct.  This is
//  in a seperate header to simplify using the columns.

//by Frank Swehosky
//Last touched: 7/14/03

#ifndef _SHOW_COLUMNS_H
#define	_SHOW_COLUMNS_H

#include <qlistview.h>
#include "atuneoptions.h"

struct ColumnType 
{
	QString qsName;
	bool    bShown;
	int     iIndex;
	int     iWidth;
};

//============================================================================
//CNoteListItem

//@class This is a listview item for each item that has notes
//@base public | QListViewItem

//============================================================================
class CNoteListItem : public QListViewItem
{
	//@access public members
public:
	//@cmember Constructor
	CNoteListItem( QListView * pParent);

	//@cmember Constructor with sorting information
	CNoteListItem( QListView * pParent, QListViewItem * pAfter);

	//@cmember Constructor with sorting information
	CNoteListItem( QListViewItem * pItem);

	//@cmember Constructor with sorting information
	CNoteListItem( QListViewItem * pItem, QListViewItem * pAfter);

	//@cmember The tip for the notes, with long data
	virtual QString LongNoteTip() = 0;

};

#endif //_SHOW_COLUMNS_H
