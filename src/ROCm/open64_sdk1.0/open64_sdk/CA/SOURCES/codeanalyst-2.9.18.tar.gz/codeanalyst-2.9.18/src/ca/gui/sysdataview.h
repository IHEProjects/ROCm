//$Id: sysdataview.h,v 1.2 2005/02/14 16:52:40 jyeh Exp $
// interface for SystemDataView class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


//Revision history
//$Log: sysdataview.h,v $
//Revision 1.2  2005/02/14 16:52:40  jyeh
//Updated header.
//
//Revision 1.1.1.1  2004/10/05 17:03:23  jyeh
//initial import into CVS
//
//Revision 1.4.2.1  2004/08/13 20:16:31  jyeh
//Added Java Source line info.
//
//Revision 1.4  2003/12/15 23:39:39  franksw
//Code Review for TbsFile
//
//Revision 1.3  2003/12/12 23:04:00  franksw
//Code Review
//
//Revision 1.2  2003/11/13 20:39:06  franksw
//code cleanup
//

#ifndef _SYSDATAVIEW_H
#define	_SYSDATAVIEW_H

#include "stdafx.h"
#include "tbsreader.h"
#include "sessionnav.h"

enum SYSTEM_COLUMNS {
	SYS_MOD_NAME = 0,
	SYS_TASK_NAME,
	SYS_64_BIT,
	SYS_OFFSET_INDEX,
	SYS_INVALID
};

enum SYSTEM_POPUPS {
	SYS_POP_COPY = 0,
	SYS_POP_DATA,
	SYS_POP_GRAPH,
	SYS_POP_PRO,
	SYS_POP_SHOWN
};


////////////////////////////////////////////////////////////////////////////
// Structure to hold list view data
//
enum SysDataViewEnum {
	MF_MOD_NAME = 0,
	MF_TOTAL,
	MF_PERC,
	MF_CPU0,
	POPUP_SEP = 0,
	POPUP_DATA,
	POPUP_GRAPH
};


//////////////////////////////////////////////////////////////////////////////

// TODO: We should separated this class into another file.
// It is also used by TaskTab.cpp 
class SystemItem : public DataListItem {
public:
	unsigned int m_taskId;
	SystemItem ( ViewShownData *pViewShown, int indexOffset, 
		QListView * pParent);
protected:
	QString key( int column, bool ascending ) const;
};

//////////////////////////////////////////////////////////////////////////////

class SystemDataTab : public DataTab 
{
	Q_OBJECT
public:
	SystemDataTab (TbsReader* tbp_file, ViewShownData *pViewShown, 
		QWidget * parent, const char *name, int wflags);
	~SystemDataTab ();

	QListView *getListView ();
	bool display (QString caption);

private:
	bool readAndDisplayModuleData ();
	int m_module_popup_id[SYS_POP_SHOWN + 1];
	QPopupMenu *m_menu;
	TbsReader *m_tbp_file;
	SystemItem  *m_item_right_clicked;

public slots: 
	void onDblClicked (QListViewItem * item);
	void onRightClick (QListViewItem * item, const QPoint & pt, int col);
	void onViewSystemGraph ();
	void onViewSystemTask ();
	void onViewModuleGraph ();
	void onViewModuleData ();
	virtual void onViewChanged (ViewShownData* pShownData);

signals: 
	void moduleDblClicked (QString module_name, TAB_TYPE type, 
					unsigned int taskId = SHOW_ALL_TASKS);
	void moduleRightClicked (QString module_name, TAB_TYPE type, 
					unsigned int taskId = SHOW_ALL_TASKS);
	void viewGraph ();
	void viewTasks ();
};

#endif // _SYSDATAVIEW_H
