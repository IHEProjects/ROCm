#include "PerfEventContainer.h"
#include "stdafx.h"

PerfEventContainer::PerfEventContainer()
{

}


PerfEventContainer::~PerfEventContainer()
{

}

bool PerfEventContainer::operator==(const PerfEventContainer & opt) const
{
	if (m_perfEventList.size() != opt.m_perfEventList.size())
		return false;

	PerfEventList::const_iterator it 	= opt.m_perfEventList.begin();	
	PerfEventList::const_iterator it_end 	= opt.m_perfEventList.end();	
	for (; it != it_end ; it++) {
		PerfEventList::const_iterator cur = m_perfEventList.find(
					(PerfEventList::const_iterator) m_perfEventList.begin(),
					(*it)); 
		if (cur == m_perfEventList.end())
			return false;

		if (*cur == *it
		&&  (*cur).count == (*it).count    // Also compare count value in this case
		&&  (*cur).flags == (*it).flags)   // Also compare flags value in this case
			continue;
		else
			return false;
	}
	return true;
}

bool PerfEventContainer::add(const PerfEvent & event)
{
	PerfEventList::iterator it = m_perfEventList.find(
				(PerfEventList::iterator) m_perfEventList.begin(), 
				event);

	// Do not allow duplicate event
	if (it != m_perfEventList.end())
		return false;

	m_perfEventList.push_back(event);
	qHeapSort(m_perfEventList);

	return true;	
}


bool PerfEventContainer::remove(const PerfEvent & event)
{
	PerfEventList::iterator it = m_perfEventList.find(m_perfEventList.begin(), event);
	if (it == m_perfEventList.end())
		return false;

	m_perfEventList.remove(it);

	return true;	

}


unsigned int PerfEventContainer::count()
{
	return m_perfEventList.size();
}


unsigned int PerfEventContainer::countPmc()
{
	int count = 0;
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type != PerfEvent::IbsFetch
		&&  (*it).type != PerfEvent::IbsOp) {
			count++;
		}
	}
	return count;
}


unsigned int PerfEventContainer::countIbsFetch()
{
	return m_perfEventList.size();
	int count = 0;
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsFetch) {
			count++;
		}
	}
	return count;
}


unsigned int PerfEventContainer::countIbsOp()
{
	int count = 0;
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsOp) {
			count++;
		}
	}
	return count;
}


void PerfEventContainer::dumpPerfEvents()
{
	fprintf(stdout, "Total %d PerfEvents:\n", (int)m_perfEventList.count());
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		(*it).dump();
	}
}


void PerfEventContainer::setIbsFetchCountUmask(unsigned long count, unsigned int umask)
{
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsFetch) {
			(*it).count = count;
			(*it).umask = umask;
		}
	}

	return;
}


bool PerfEventContainer::getIbsFetchCountUmask(unsigned long & count, unsigned int & umask)
{
	unsigned long tmpCount = 0;
	unsigned int  tmpUmask = 0;

	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsFetch) {
			if (tmpCount == 0 && tmpUmask == 0) {
				tmpCount = (*it).count;
				tmpUmask = (*it).umask;
			} else if (tmpCount != (*it).count 
				|| tmpUmask != (*it).umask) {
				return false;
			}
		}
	}
	count = tmpCount;
	umask = tmpUmask;
	
	return true;
}


void PerfEventContainer::setIbsOpCountUmask(unsigned long count, unsigned int umask)
{
	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsOp) {
			(*it).count = count;
			(*it).umask = umask;
		}
	}

	return;
}


bool PerfEventContainer::getIbsOpCountUmask(unsigned long & count, unsigned int & umask)
{
	unsigned long tmpCount = 0;
	unsigned int  tmpUmask = 0;

	PerfEventList::iterator it = m_perfEventList.begin();	
	PerfEventList::iterator it_end = m_perfEventList.end();	
	for (; it != it_end; it++) {
		if ((*it).type == PerfEvent::IbsOp) {
			if (tmpCount == 0 && tmpUmask == 0) {
				tmpCount = (*it).count;
				tmpUmask = (*it).umask;
			} else if (tmpCount != (*it).count 
				|| tmpUmask != (*it).umask) {
				return false;
			}
		}
	}
	count = tmpCount;
	umask = tmpUmask;

	return true;
}


void PerfEventContainer::enumerateAllEvents(EventMaskEncodeMap & event_map)
{
	EventMaskEncodeMap::iterator ev_it, ev_end;
		
	PerfEventList::iterator it     = getPerfEventListBegin();
	PerfEventList::iterator it_end = getPerfEventListEnd();
	for (; it != it_end; it++) {
		// This string will be passed to Oprofile	
		string  key = (*it).getEventMaskEncodeMapKey().ascii();
	
		EventEncodeType eet;
		eet.sortedIndex = 0; 
		eet.weight = 1;
		eet.eventCount = (*it).count; 
		eet.eventMask = EncodeEventMask((*it).select, (*it).umask);
		event_map.insert(EventMaskEncodeMap::value_type(key, eet));
	}

	// change the index order of events;
	ev_it = event_map.begin();
	ev_end = event_map.end();
	for(int i = 0; ev_it != ev_end; ev_it++, i++) {
		ev_it->second.sortedIndex = i;
	}
}


bool PerfEventContainer::hasIbs()
{
	unsigned long tmpCount = 0;
	unsigned int  tmpUmask = 0;

	if (getIbsFetchCountUmask(tmpCount, tmpUmask) && tmpCount > 0)
		return true;

	if (getIbsOpCountUmask(tmpCount, tmpUmask) && tmpCount > 0)
		return true;

	return false;
}

bool PerfEventContainer::validateEvents(QString & errorStr)
{
	bool ret = false;
	errorStr = "";

	if (!validateOpName(errorStr)) goto out;

	if (hasIbs())
		if (!validateIbs(errorStr)) goto out;

	ret = true;
out:
	return ret;
}


bool PerfEventContainer::getCounterAllocation(AllocMap * alloc)
{

//TODO: Suravee: Add this check somewhere
#if 0
	groups = static_cast <EBP_OPTIONS *>(m_pSession)->countEventGroups;
	if(groups > MAX_EVENTGROUP_MULTIPLEXING)
	{
		QMessageBox::critical(this,"CodeAnalyst Error",
			QString("ERROR:\n")
			+ "Invalid event configuration. CodeAnalyst only supports up to " 
			+ QString::number(MAX_EVENTGROUP_MULTIPLEXING) + "event groups.\n"
			+ "Please reconfigure.\n");	
		rt = false;	
	}
#endif

	return true;
}

bool PerfEventContainer::validateOpName(QString & errorStr)
{
	bool ret = false;
	errorStr = "";



	// TODO: Implement this

	if (0) {
		errorStr = QString("ERROR:\n")	
		+ "Could not validate Oprofile event name\n"; 
		goto out;
	}
	
	ret = true;

out:
	return ret;
}


bool PerfEventContainer::validateIbs(QString & errorStr)
{
	bool ret = false;
	unsigned long count = 0;
	unsigned int umask = 0;
	errorStr = "";

	if (!getIbsFetchCountUmask(count, umask)) {
		errorStr = QString("Invalid Ibs Fetch Count/Umask.\n")
				+ "All Fetch events must have the same count/umask.";
		goto out;
	}
		
	if (!getIbsOpCountUmask(count, umask)) {
		errorStr = QString("Invalid Ibs Op Count/Umask.\n")
				+ "All Ibs Op events must have the same count/umask.";
		goto out;
	}
	
	ret = true;
out:
	return ret;
}

int PerfEventContainer::populateOpNames(CEventsFile * pEventFile)
{
	CpuEvent ev;
	
	if (!pEventFile)
		return -1;

	PerfEventList::iterator it     = getPerfEventListBegin();
	PerfEventList::iterator it_end = getPerfEventListEnd();
	for (; it != it_end; it++) {
		pEventFile->findEventByValue((*it).select, ev);
		(*it).opName = ev.op_name;

		// TODO: Suravee; Reimplement this
		if ((*it).type == PerfEvent::Invalid) {
			if ((*it).select < 0xf000)
				(*it).type   = PerfEvent::Pmc;
			else if ((*it).select >= 0xf000 
			      && (*it).select < 0xf100 )
				(*it).type   = PerfEvent::IbsFetch;
			else if ((*it).select >= 0xf100 
			      && (*it).select < 0xf200 )
				(*it).type   = PerfEvent::IbsOp;
		}
	}

	return 0;
}

void PerfEventContainer::dumpAllEvents()
{
	PerfEventList::iterator it     = getPerfEventListBegin();
	PerfEventList::iterator it_end = getPerfEventListEnd();
	for (; it != it_end; it++) {
		(*it).dump();
	}
	
}
