//$Id: ProfileCollection.cpp 17547 2010-01-19 21:46:37Z ssuthiku $
//This file defines the ProfileCollection implementation

/*
// CodeAnalyst for Open Source
// Copyright 2006-2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include "helperAPI.h"
#include "ProfileCollection.h"
#include "atuneoptions.h"

ProfileCollection::ProfileCollection ()
{
}

ProfileCollection::~ProfileCollection ()
{
	m_configs.clear();
}

void ProfileCollection::readAvailableProfiles()
{
	QString path;
	CATuneOptions ao;

	QDir dir;
	QFileInfo *fi;

	char VendorId[15];
	unsigned long family;
	unsigned long model;
	unsigned long stepping;

	/*********************************************************
	* Read DCConfig files from common DCConfig directory
	*/
	path = CA_DATA_DIR;
	path += "/Configs/DCConfig/";
	dir.setPath (path);

	//This will be NULL if the directory doesn't exist
	if (dir.exists())
	{
		const QFileInfoList *f_list = dir.entryInfoList ("*.xml");
		QFileInfoListIterator f_it( *f_list );

		for (; ((fi = f_it.current()) != 0 ); ++f_it) 
		{
			CDCConfig  * pTemp = new CDCConfig ();
			RETURN_IF_NULL (pTemp, NULL);

			QString filePath = path + "/" + fi->fileName();

			//If it's not an events configuration...
			if (!pTemp->ReadConfigFile ((wchar_t *)filePath.ucs2()))
			{
				delete pTemp;
				continue;
			}

			QString profileName;
			pTemp->GetConfigName(profileName);
			if (m_configs.contains (profileName))
			{
				delete pTemp;
				continue;
			}

			m_configs[profileName].pConfigure = pTemp;
			m_configs[profileName].path = filePath;
			m_configs[profileName].modifiable = false;
		}
	}

	/*********************************************************
	* Read DCConfig files from platform specific directory
	*/
	CpuId( VendorId, &family, &model, &stepping);
	
	path = QString(CA_DATA_DIR) + "/Configs/DCConfig/";
	if ( 0 == strncmp (VendorId, "AuthenticAMD", 12) )
		path += helpGetFamilyDir(family);

	dir.setPath (path);

	//This will be NULL if the directory doesn't exist
	if (dir.exists())
	{
		const QFileInfoList *f_list = dir.entryInfoList ("*.xml");
		QFileInfoListIterator f_it( *f_list );

		for (; ((fi = f_it.current()) != 0 ); ++f_it) 
		{
			CDCConfig  * pTemp = new CDCConfig ();
			RETURN_IF_NULL (pTemp, NULL);

			QString filePath = path + "/" + fi->fileName();

			//If it's not an events configuration...
			if (!pTemp->ReadConfigFile ((wchar_t *)filePath.ucs2()))
			{
				delete pTemp;
				continue;
			}

			QString profileName;
			pTemp->GetConfigName(profileName);
			if (m_configs.contains (profileName))
			{
				delete pTemp;
				continue;
			}

			m_configs[profileName].pConfigure = pTemp;
			m_configs[profileName].path = filePath;
			m_configs[profileName].modifiable = false;
		}
	}

	/*********************************************************
	* Read DCConfig files from user hone/.CodeAnalyst/configs 
	*/
	path = QDir::home ().path();
	path += "/.CodeAnalyst/Configs/DCConfig/";
	path.replace ('\\', '/');

	dir.setPath (path);

	if (!dir.exists())
	{
		//recursively create directories
		int sections = path.contains ("/");
		for (int sects = 1; sects <= sections; sects ++)
		{
			QDir tempDir;
			tempDir.setPath( path.section ("/", 0, sects) );
			if( !tempDir.exists() )
			{
				tempDir.mkdir (tempDir.path());
			}
		}
	}
	
	CDCConfig  * pCurrent = NULL;
	QString tempText = "";
	
	//create current time: CURRENT_TIME
	QFileInfo tempFile = QFileInfo(path + "/Current Time.xml");
	if(!tempFile.exists())
	{
		pCurrent = new CDCConfig ();
		RETURN_IF_NULL (pCurrent, NULL);
		pCurrent->SetConfigType (DCConfigTBP);
		pCurrent->SetConfigName (CURRENT_TIME);

		tempText = "The current timer-based profile";
		pCurrent->SetToolTip (tempText) ;
		tempText = "A default timer-based profile for you to customize";
		pCurrent->SetDescription (tempText) ;
		pCurrent->SetCpuType (getCurrentCpuType()) ;
		pCurrent->SetTimerInterval (1) ;
		m_configs[CURRENT_TIME].pConfigure = pCurrent;
		m_configs[CURRENT_TIME].path = path + "/Current Time.xml";
		m_configs[CURRENT_TIME].modifiable = true;

		pCurrent->WriteConfigFile ((wchar_t*)m_configs[CURRENT_TIME].path.ucs2());
	}

	//create current event: CURRENT_EVENT
	tempFile = QFileInfo(path + "/Current Events.xml");
	if(!tempFile.exists())
	{
		pCurrent = new CDCConfig ();
		RETURN_IF_NULL (pCurrent, NULL);
		pCurrent->SetConfigType (DCConfigEBP);
		pCurrent->SetConfigName (CURRENT_EVENT);

		tempText = "The current event-based profile";
		pCurrent->SetToolTip (tempText) ;
		tempText = "A default event-based profile for you to customize";
		pCurrent->SetDescription (tempText) ;
		pCurrent->SetCpuType (getCurrentCpuType()) ;

		PmcEvent pmcEvents;
		pmcEvents.select 	= 0x76;
		pmcEvents.count  	= 1000000;
		pCurrent->AddEventInfo (pmcEvents); 

		m_configs[CURRENT_EVENT].pConfigure = pCurrent;
		m_configs[CURRENT_EVENT].path = path + "/Current Events.xml";
		m_configs[CURRENT_EVENT].modifiable = true;

		pCurrent->WriteConfigFile ((wchar_t*)m_configs[CURRENT_EVENT].path.ucs2());
	}

	//create current event: CURRENT_IBS
	if(isCpuIbsOk ())
	{
		tempFile = QFileInfo(path + "/Current Ibs.xml");
		if(!tempFile.exists())
		{
			pCurrent = new CDCConfig ();
			RETURN_IF_NULL (pCurrent, NULL);
			pCurrent->SetConfigType (DCConfigEBP);
			pCurrent->SetConfigName (CURRENT_IBS);

			tempText = "The current instruction-based profile";
			pCurrent->SetToolTip (tempText) ;
			tempText = "A default instruction-based profile for you to customize";
			pCurrent->SetDescription (tempText) ;
			pCurrent->SetCpuType (getCurrentCpuType()) ;

			IbsFetchEvent fetch;
			fetch.select 	= 0xf000;
			fetch.count  	= 1000000;
			fetch.setOs(false);
			fetch.setUsr(false);
			pCurrent->AddEventInfo (fetch); 
			
			IbsOpEvent op;
			op.select 	= 0xf100;
			op.count  	= 1000000;

			// Check if CPU support IBS Op Dispatch-op
			unsigned long ibsFeatureFlag = 0;
			getCpuIdIbs(&ibsFeatureFlag);
			if (isCpuIbsOpDispatchOpOk(ibsFeatureFlag))
				op.umask |= IbsOpEvent::DispatchCount;
			else
				op.umask &= ~IbsOpEvent::DispatchCount;
			
			op.setOs(false);
			op.setUsr(false);
			pCurrent->AddEventInfo (op); 
			
			m_configs[CURRENT_IBS].pConfigure = pCurrent;
			m_configs[CURRENT_IBS].path = path + "/Current Ibs.xml";
			m_configs[CURRENT_IBS].modifiable = true;

			pCurrent->WriteConfigFile
				((wchar_t*)m_configs[CURRENT_IBS].path.ucs2());
		}
	}

	const QFileInfoList *f_list = dir.entryInfoList ("*.xml");
	QFileInfoListIterator u_it( *f_list );

	for (; ((fi = u_it.current()) != 0 ); ++u_it)
	{
		CDCConfig  * pTemp = new CDCConfig ();
		RETURN_IF_NULL (pTemp, NULL);


		QString filePath = path + "/" + fi->fileName();

		if (!pTemp->ReadConfigFile ((wchar_t *)filePath.ucs2()))
		{
			delete pTemp;
			continue;
		}

		//don't display profiles if not able to use them
		DCConfigType type = pTemp->GetConfigType ();
		if ((DCConfigEBP == type) 
		&&  !isCpuAMD()
		&&  !isCpuIbsOk())
		{
			delete pTemp;
			continue;
		}

		QString profileName;
		pTemp->GetConfigName(profileName);
		if (m_configs.contains (profileName)) 
		{
			delete pTemp;
			continue;
		}

		m_configs[profileName].pConfigure = pTemp;
		m_configs[profileName].path = filePath;
		m_configs[profileName].modifiable = true;
	}

	verifyAMDPlatform ();
} //ProfileCollection::readAvailableProfiles


QStringList ProfileCollection::getListOfProfiles ()
{
	QStringList configList;
	ConfigMap::Iterator it = m_configs.begin();
	for( ; it != m_configs.end(); ++it )
	{
		configList += it.key();
	}
	return configList;	
}

QStringList ProfileCollection::getListOfEbpProfiles ()
{
    QStringList configList;
    ConfigMap::Iterator it = m_configs.begin();
    for( ; it != m_configs.end(); ++it )
    {
	if(it.data().pConfigure->GetConfigType() == DCConfigEBP)
		configList += it.key();
    }
    return configList;	
}

bool ProfileCollection::getProfileTexts (QString name, 
					QString *pToolTip, 
					 QString *pDescrip)
{
	if (!m_configs.contains (name))
		return false;

	if (NULL != pToolTip)
	{
		m_configs[name].pConfigure->GetToolTip (*pToolTip);
	}
	if (NULL != pDescrip)
	{
		m_configs[name].pConfigure->GetDescription (*pDescrip);
	}
	return true;
}


TRIGGER ProfileCollection::getProfileType (QString name)
{
	if (m_configs.contains (name))
	{
		switch (m_configs[name].pConfigure->GetConfigType())
		{
		case DCConfigTBP:
			return TIMER_TRIGGER;
		case DCConfigEBP:
			return EVENT_TRIGGER;
		default:
			break;
		}
	}
	return NO_TRIGGER;
}


//Note that the correct type needs to be passed in...
bool ProfileCollection::getProfileConfig (QString name, 
					  SESSION_OPTIONS * pConfig)
{
	if (!m_configs.contains (name))
		return false;
	if (NULL == pConfig)
		return false;

	switch (pConfig->Trigger)
	{
	case TIMER_TRIGGER:
		{
			TBP_OPTIONS *pTbp = static_cast<TBP_OPTIONS *>(pConfig);
			pTbp->msInterval = m_configs[name].pConfigure->GetTimerInterval();
			break;
		}
	case EVENT_TRIGGER:
		{
			EBP_OPTIONS *pEvent = static_cast<EBP_OPTIONS *>(pConfig);
			m_configs[name].pConfigure->GetEventInfo (pEvent->getEventContainer());
			pEvent->msMpxInterval = m_configs[name].pConfigure->GetMultiplexPeriod();
			break;
		}
	default:
		QMessageBox::critical (NULL, "CodeAnalyst Error", 
			"Unavailable information was requested for an invalid type");
		return false;
	}

	return true;
} //ProfileCollection::getProfileConfig


bool ProfileCollection::setProfileConfig (QString name, 
					SESSION_OPTIONS * pConfig,
					QString tip, 
					QString desc)
{
	if (NULL == pConfig)
		return false;
	if (!m_configs.contains (name))
	{
		CDCConfig  * pCurrent = new CDCConfig ();
		RETURN_FALSE_IF_NULL (pCurrent, NULL);

		pCurrent->SetConfigName (name);
		QString tempText = "A custom profile";
		pCurrent->SetToolTip (tempText) ;
		tempText = "A custom profile";
		pCurrent->SetDescription (tempText) ;	

		m_configs[name].pConfigure = pCurrent;
		m_configs[name].modifiable = true;

		QString path = QDir::home ().path();
		path += "/.CodeAnalyst/Configs/DCConfig/";
		path.replace ('\\', '/');

		path += name + ".xml";
		m_configs[name].path = path;
	}
	else if (!m_configs[name].modifiable)
	{
		QMessageBox::warning (NULL, "CodeAnalyst warning",
			"The named configuration could not be overwritten, please change the name.");
		return false;
	}

	//update profile settings
	switch (pConfig->Trigger)
	{
	case TIMER_TRIGGER:
		{
			TBP_OPTIONS *pTbp = static_cast<TBP_OPTIONS *>(pConfig);
			m_configs[name].pConfigure->SetConfigType (DCConfigTBP);
			m_configs[name].pConfigure->SetTimerInterval (pTbp->msInterval);
			break;
		}
	case EVENT_TRIGGER:
		{
			EBP_OPTIONS *pEvent = static_cast<EBP_OPTIONS *>(pConfig);
			m_configs[name].pConfigure->SetConfigType (DCConfigEBP);
			m_configs[name].pConfigure->SetEventInfo (
							pEvent->getEventContainer(), 
							pEvent->msMpxInterval);
			break;
		}
	default:
		QMessageBox::critical (NULL, "CodeAnalyst Error", 
			"Unavailable information was set for an invalid type");
		return false ;
	}

	// Save tooltip and description
	m_configs[name].pConfigure->SetToolTip(tip);
	m_configs[name].pConfigure->SetDescription(desc);

	m_lastModified = name;
	//write session
	m_configs[name].pConfigure->WriteConfigFile ((wchar_t *)m_configs[name].path.ucs2());
	return true;
} //ProfileCollection::setProfileConfig


//Bascially copies file to specified file
bool ProfileCollection::exportProfile (QString name, QString fileName)
{
	if (!m_configs.contains (name))
		return false;

	m_configs[name].pConfigure->WriteConfigFile ((wchar_t *)fileName.ucs2());
	return true;
}


//Bascially reads settings and copies file to user's directory
int ProfileCollection::importProfile (QString fileName)
{
	//Read in profile to get name
	CDCConfig *pTemp = new CDCConfig();
	RETURN_FALSE_IF_NULL (pTemp, NULL);
	if (!pTemp->ReadConfigFile ((wchar_t *)fileName.ucs2()))
	{
		delete pTemp;
		return PROFILE_FILE_NOT_FOUND;
	}

	QString importName;
	pTemp->GetConfigName (importName);

	//If it's already available, stop
	if (m_configs.contains (importName))
	{
		delete pTemp;
		return PROFILE_DUPLICATE_NAME;
	}

	m_configs[importName].pConfigure = pTemp;

	//set path to user home/.CodeAnalyst\configs
	QString path = QDir::home ().path();
	path += "/.CodeAnalyst/Configs/DCConfig/";
	fileName.replace ('\\', '/');
	path += fileName.section ('/', -1);

	//copy file to user's directory
	m_configs[importName].path = path;
	m_configs[importName].modifiable = true;
	m_configs[importName].pConfigure->WriteConfigFile ((wchar_t *)path.ucs2());
	return PROFILE_IMPORT_OKAY;
} //ProfileCollection::importProfile


bool ProfileCollection::removeProfile (QString name)
{
	if (!m_configs.contains (name))
	{
		return false;
	}
	//if file in install directory, return false
	if (!m_configs[name].modifiable)
	{
		return false;
	}

	//If file is unremovable, return false
	if ((name == CURRENT_TIME) 
	|| (name == CURRENT_EVENT)
	|| (name == CURRENT_IBS))
	{
		return false;
	}

	//delete file
	QFile::remove (m_configs[name].path);

	m_configs.remove  (name);
	return true;
}


bool ProfileCollection::profileExists (QString name)
{
	return m_configs.contains (name);
}


QString ProfileCollection::getLastModified ()
{
	return m_lastModified;
}


void ProfileCollection::setLastModified (QString name)
{
	m_lastModified = name;
}


void ProfileCollection::clearLastModified ()
{
	m_lastModified = QString::null;
}


//This will strip all event-based profiles out of the available list.
void ProfileCollection::verifyAMDPlatform ()
{
	if (!isCpuAMD ())
	{
		ConfigMap::Iterator it = m_configs.begin();
		for( ; it != m_configs.end(); ++it )
		{
			QString remEvent = it.key();
			TRIGGER type = getProfileType (remEvent);
			QString typeString;
			if (type == EVENT_TRIGGER)
				typeString = "Event";
			else
				typeString = "Not removed";

			if (EVENT_TRIGGER == type)
				m_configs.remove  (remEvent);
		}
	}
}

QString ProfileCollection::getFileName (QString name)
{
	QString retFile;
	if (m_configs.contains (name))
	{
		retFile = m_configs[name].path;
	}
	return retFile;
}
