//$Id: opxmldata_handler.cpp $
// Interface for processing profile data using Oprofile XML output.

/*
// CodeAnalyst for Open Source
// Copyright 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

// CodeAnalyst headers
#include <qstringlist.h>
#include <qprocess.h>
#include <sstream>


#include "opxmldata_handler.h"
#include "dataagg.h"
#include "config.h"
#include "EventMaskEncoding.h"

using namespace std;


opxmldata_handler::opxmldata_handler()
: opdata_handler()
{
	m_isXMLReady = false;
}


opxmldata_handler::~opxmldata_handler()
{
	m_eventVec.clear();
	m_classMap.clear();
	m_binaryList.clear();
	m_symbolVec.clear();
	m_symbolDetailsVec.clear();
		
	reset_data();
}


void
opxmldata_handler::init()
{
	m_xmlHandler.init(&m_eventVec,
			&m_classMap,
			&m_binaryList,
			&m_symbolVec,
			&m_symbolDetailsVec);
}


void
opxmldata_handler::init(EventMaskEncodeMap evt_map)
{
	init();

	m_event_encode_map = evt_map;
}


int
opxmldata_handler::getEvents(OP_EVENT_PROPERTY_MAP &ebp_events_name_map)
{
	int ret = 0;

	if(!m_isXMLReady)
		return -1;

	CLASS_MAP::iterator it     = m_classMap.begin();
	CLASS_MAP::iterator it_end = m_classMap.end();
	for(; it != it_end ; it++)
	{
		std::stringstream ssout;
		ssout << "event:" << it->second.event->eventname << 
			" count:" << it->second.event->setupcount <<
			" unit-mask:" << it->second.mask ;
		string key = ssout.str();

		OP_EVENT_PROPERTY_MAP::iterator eit = ebp_events_name_map.find(key);
		if(eit == ebp_events_name_map.end())
		{
			op_event_property op;
			op.count     = it->second.event->setupcount;
			op.unitmask  = it->second.mask;
			op.os        = true;	// Fake
			op.usr       = true;	// Fake
			op.op_name   = it->second.event->eventname;

			ebp_events_name_map.insert(
				OP_EVENT_PROPERTY_MAP::value_type(key,op));
			ret++;
		}	
	}
	return ret;
}


int opxmldata_handler::exec_command (QStringList & args)
{

        QProcess m_proc;
        m_proc.setArguments (args);

        int rt = 0;

        if(!m_proc.start ()) {
                rt = -1;
        }

        while (rt == 0 && m_proc.isRunning ()) {
        }

        // Check for normal Exit
        if (!m_proc.normalExit ()) {
                rt = -1;
        }

        // Check for exit status
        if (m_proc.exitStatus() != 0) {
                rt = -1;
        }

        return rt;
}


bool
opxmldata_handler::generateXML(const char *xmlPath,
			QStringList taskFilter,
			QString opDataDir)
{

	bool ret = false;

        QStringList cmd_opreport;
	QString opreportBin = QString(OP_BINDIR) + "/opreport";
        cmd_opreport.append(opreportBin);
        cmd_opreport.append("-wdlX");
        cmd_opreport.append("--session-dir");

	// To get rid off the "....../samples/current/"
	QString tmp = opDataDir.section("/",0,-4);
        cmd_opreport.append(tmp);

        cmd_opreport.append("-o");
        cmd_opreport.append(xmlPath);
        cmd_opreport += taskFilter;

	if (m_ca_display) {
		m_ca_display->update_display(
			"\n============================\n");
		string t_str = "Generating opreport XML:\n    " 
			+ string(cmd_opreport.join(" ").ascii());
		m_ca_display->update_display((t_str.c_str()));
	}

        if (exec_command(cmd_opreport) == 0) 
        {
		ret = true;
        }

	return ret; 
}


bool
opxmldata_handler::readXML(const char *xmlPath)
{
	bool ret = false;

	if (m_ca_display) {
		m_ca_display->update_display(
			"\n============================\n");
		string t_str = "Parsing XML: \n    " + string(xmlPath);
		m_ca_display->update_display((t_str.c_str()));
	}
	ret = m_xmlHandler.open(xmlPath);

	if(ret)
		m_isXMLReady = true;
		
	return ret;
}


void
opxmldata_handler::setEventEncodeMap(EventMaskEncodeMap evt_map)
{
	m_event_encode_map = evt_map;

	m_mod_summary.clear();
}


bool
opxmldata_handler::getSampleKeyEvent(EventMaskType& ev, 
				op_event* opEv,
				unsigned int mask)
{
	if(!opEv)
		return false;

	std::stringstream ssout;
	ssout << "event:" << opEv->eventname << 
		" count:" << opEv->setupcount <<
		" unit-mask:" << mask ;
	string str = ssout.str();

	EventMaskEncodeMap::iterator it = m_event_encode_map.find(str);
	if (it == m_event_encode_map.end()) {
		return false;
	}
	ev = it->second.sortedIndex;
	return true;
}


bool
opxmldata_handler::attributeSamples(MODULE_SUMMARY_TYPE & mod_data,
				SYMBOL_LIST		* pSymbolList,
				SampleDataMap 		& taskSampMap)
{
	SYMBOL_LIST::iterator sit;
	SYMBOL_LIST::iterator send;
	Detail_Key d_key;
	SampleDetail *pDetailMap = getDetailMap(mod_data.name);


	// Sanity check
	if(!pSymbolList) {
//		fprintf(stderr,"Warning: opxmldata_handler::attributeSamples: pSymbolList is empty.\n");
		return false;
	}

	sit  = pSymbolList->begin();
	send = pSymbolList->end();
	// For each symbol
	for(; sit != send ; sit++)
	{
		unsigned int idref = (*sit).idref;
//		fprintf(stderr,"		SYM: idref = %u, lo = %u, hi = %u\n",
//			(*sit).idref, (*sit).lo, (*sit).hi); 
			
		d_key.taskId = mod_data.taskid;
		unsigned long symbolStartAddr = m_symbolVec[idref].startingaddr;	

		// For each sample	
		for( unsigned int i = (*sit).lo ; i <= (*sit).hi ; i++)
		{
			SampleDataMap oneAddr;
			if(m_symbolDetailsVec.size() == 0) {
				return false;
			}
				
			op_detaildata *pdata = &(m_symbolDetailsVec[idref].detaildataVec[i]);
//			fprintf(stderr,
//			"			SAMPLE: %u: vmaoffset = %lx, class = %s, count = %u\n",
//				i, pdata->vmaoffset, pdata->evclass.c_str(),
//				pdata->evcount);

			if( symbolStartAddr > pdata->vmaoffset )
				d_key.rip = symbolStartAddr + pdata->vmaoffset;	
			else
				d_key.rip = pdata->vmaoffset;	
				
			SampleKey sampKey;
			CLASS_MAP::iterator cit  = m_classMap.find(pdata->evclass);
			CLASS_MAP::iterator cend = m_classMap.end();
			if(cit != cend)
			{
				sampKey.cpu   = (*cit).second.cpu;
				if(!getSampleKeyEvent(sampKey.event, 
							cit->second.event,
							cit->second.mask))
					continue;
				
				oneAddr.insert(SampleDataMap::value_type(sampKey,
								pdata->evcount));
			}

			SampleDetail::iterator sd_it = pDetailMap->find(d_key);
			if (sd_it != pDetailMap->end()) {
				AggregateSamples(sd_it->second, oneAddr); 
			} else {
				SampleDataMap sampMap;
				
				AggregateSamples(sampMap, oneAddr); 
				
				pDetailMap->insert(SampleDetail::value_type(d_key, sampMap));
			}
			AggregateSamples(mod_data.sampMap, oneAddr);
			AggregateSamples(taskSampMap   , oneAddr);

		} // For each sample
	} // For each symbol
	m_mod_summary.push_back(mod_data);

	return true;
}


bool
opxmldata_handler::processXMLData()
{
	bool ret = false;

	if(!m_isXMLReady)
		return ret;

	if(m_event_encode_map.size() == 0)
		return ret;

	string cur_taskname;
	unsigned int cur_taskid = 0;
	string cur_modname; 
	SampleDataMap		taskSampMap;
	MODULE_SUMMARY_TYPE 	mod_data;
	unsigned int bitness = 0;

	BINARY_LIST::iterator bit  = m_binaryList.begin();
	BINARY_LIST::iterator bend = m_binaryList.end();
	SYMBOL_LIST::iterator sit;
	SYMBOL_LIST::iterator send;

	/*
	 * FOR EACH BINARY
	 */	
	for(; bit != bend ; bit++)
	{
//		fprintf(stderr,"TASKNAME: %s\n",(*bit).name.c_str());

		// clear previous task sample data
		taskSampMap.clear();
		cur_taskid++;
		cur_taskname = (*bit).name.c_str();
		bitness = getTaskBitness(cur_taskname);

		// update GUI for data processing
		if (m_ca_display) {
			m_ca_display->update_display(
				"\n============================\n");
			string t_str = "Processing Task: " + cur_taskname;
			m_ca_display->update_display((t_str.c_str()));
		}

		
		/*
 		 * Initialize Binary Module
 		 */
		mod_data.taskid		= cur_taskid;
		mod_data.total		= 0;
		mod_data.bitness	= bitness;
		mod_data.name 		= (*bit).name.c_str();
		mod_data.sampMap.clear();

		if(!attributeSamples(mod_data, &((*bit).symbolList), taskSampMap)) {
//			string t_str = "Warning: XML contains no symbol detail for " 
//				+ mod_data.name;
//			m_ca_display->update_display_error((t_str.c_str()));
//			continue;
			return false;
		}
		/**************************************************************
		 * FOR EACH MODULE
		 */	
		// Check dependency Module
		MODULE_LIST::iterator mit  = (*bit).modList.begin();
		MODULE_LIST::iterator mend = (*bit).modList.end();
		// For each module
		for(; mit != mend ; mit++)
		{
//			fprintf(stderr,"	MODNAME: %s\n",(*mit).name.c_str());
			// update GUI for data processing
			if (m_ca_display) {
				string t_str = "    Processing Module: " + (*mit).name;
				m_ca_display->update_display((t_str.c_str()));
			}


			/*
			 * Initialize Binary Module
			 */
			mod_data.taskid		= cur_taskid;
			mod_data.total		= 0;
			mod_data.bitness	= bitness;
			mod_data.name 		= (*mit).name.c_str();
			mod_data.sampMap.clear();

			if(!attributeSamples(mod_data, &((*mit).symbolList), taskSampMap)) {
//				string t_str = "    Warning: XML contains no symbol detail for " 
//					+ mod_data.name;
//				m_ca_display->update_display_error((t_str.c_str()));
//				continue;
				return false;
			}
		
		}// For each module 

		addTaskData(cur_taskname, cur_taskid, bitness, taskSampMap);

	} // For each binary

	//dumpresult();
	
	if (m_ca_display)
		m_ca_display->display_oprofile_log();

	ret = true;
	return ret;
}

void opxmldata_handler::dumpDataMap(SampleDataMap &data)
{
	SampleDataMap::iterator it = data.begin();
	SampleDataMap::iterator it_end = data.end();
	for(; it != it_end; it++) {
		printf("[%d %llu] %u, ", 	it->first.cpu, 
			(unsigned long long) it->first.event, it->second);
	}
	printf("\n");
}


void opxmldata_handler::dumpresult()
{
	//dump process info
	printf("Task section\n");
	task_summary_map::iterator t_it = m_task_summary.begin();	
	task_summary_map::iterator t_it_end = m_task_summary.end();	
	for (; t_it != t_it_end; t_it++) {
		printf("%d, %s, %llu\n", t_it->second.taskid, 
				t_it->first.c_str(), t_it->second.total);
	}


	printf("Module section\n");
	mod_summary_list::iterator m_it = m_mod_summary.begin();
	mod_summary_list::iterator m_it_end = m_mod_summary.end();
	for (; m_it != m_it_end; m_it++) {
		printf("tid = %d, type=%d, total=%llu, %s\n",
			m_it->taskid, m_it->modtype, m_it->total, m_it->name.c_str());
	}


	printf("Module Detail\n");
	MOD_DETAIL_MAP::iterator md_it = m_mod_detail.begin();
	MOD_DETAIL_MAP::iterator md_it_end = m_mod_detail.end();
	for(; md_it != md_it_end; md_it++) {
		printf("modname = %s\n", md_it->first.c_str());
		SampleDetail::iterator sd_it = md_it->second.begin();
		SampleDetail::iterator sd_end = md_it->second.end();
		for (; sd_it != sd_end; sd_it++) {
			printf("addr = %llx, tid=%u", 
					sd_it->first.rip, sd_it->first.taskId);
			
			dumpDataMap(sd_it->second);
		}
	}
}
