//$Id: TimerCfg.cpp 16863 2009-07-22 18:07:49Z ssuthiku $
/**
*   (c) 2003-2006 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/

#include "TimerCfg.h"
#include "iruncontrol.h"
#include <qtextedit.h>

TimerCfgDlg::TimerCfgDlg ( QWidget* parent, const char* name, bool modal, 
						  WFlags fl) : ITimerCfg (parent, name, modal, fl)
{
	m_pProfiles = NULL;
	connect (m_pProfileName, SIGNAL (textChanged ( const QString &)), 
		SLOT (onModified ()));
	connect (m_pInterval, SIGNAL (textChanged ( const QString &)), 
		SLOT (onModified ()));
}

TimerCfgDlg::~TimerCfgDlg ()
{
}


void TimerCfgDlg::onModified ()
{
	m_modified = true;
}

void TimerCfgDlg::setProperties (TBP_OPTIONS *pSession)
{
	setCaption ("Review timer configuration");
	//add run control
	IRunControl * pRunControl = new IRunControl (this);
	RETURN_IF_NULL (pRunControl, this);
	setExtension (pRunControl);
	setOrientation (Vertical);
	showExtension (true);

	//set readonly
	m_pProfileName->setReadOnly (true);
	m_pInterval->setReadOnly (true);
	m_pLaunch->setReadOnly (true);
	m_pWorkDir->setReadOnly (true);
	pRunControl->m_pDuration->setReadOnly (true);
	pRunControl->m_pStartDelay->setReadOnly (true);
	pRunControl->m_pStartPaused->setEnabled (false);
	pRunControl->m_pAffinityValue->setReadOnly(true);	
	pRunControl->m_pClearSessionNoteBtn->setEnabled(false);
	pRunControl->m_pApplyFilter->setEnabled(false);

	//hide 
	pRunControl->m_pAffinityBtn->hide();
	buttonCancel->hide();

	//Add setting info
	m_pProfileName->setText (pSession->sessionName);
	m_pInterval->setText (QString::number (pSession->msInterval));

	//Run control info
	pRunControl->m_pSessionNote->setText (pSession->sessionNote);
	pRunControl->m_pSessionNote->setReadOnly (true);
	pRunControl->m_pDuration->setText ((pSession->duration <= 0)? "N/A": QString::number( pSession->duration));
	pRunControl->m_pProfileDuration->setChecked (0 == pSession->duration);
	pRunControl->m_pStartDelay->setText ((pSession->startDelay < 0)? "N/A": QString::number( pSession->startDelay));
	pRunControl->m_pStartPaused->setChecked (pSession->startPaused);
	pRunControl->m_pStopOnExit->setChecked (pSession->stopOnAppExit);
	pRunControl->m_pTerminateAfter->setChecked (pSession->termAppOnDur);
	QString afStr; 

	if(pSession->affinity == 0)
		afStr = QString("N/A");
	else
		afStr = QString("0x") + QString::number(pSession->affinity,16);

	pRunControl->m_pAffinityValue->setText(afStr);

	m_pLaunch->setText (pSession->launch);
	m_pWorkDir->setText (pSession->workDir);
	m_modified = false;
} //TimerCfgDlg::setProperties


void TimerCfgDlg::setProfile (ProfileCollection *pProfiles, QString name)
{
	m_tick_per_sec = getTick();
	m_profileName = name;
	m_pProfiles = pProfiles;
	TBP_OPTIONS tbpOptions;
	m_pProfiles->getProfileConfig (name, &tbpOptions);
	m_pProfileName->setText (m_profileName);
	m_pInterval->setText (QString::number (tbpOptions.msInterval));

	m_pLaunchBox->hide();
	m_modified = false;
}

void TimerCfgDlg::onOk ()
{
	if (m_pProfileName->text().isEmpty())
	{
		QMessageBox::question (this, "CodeAnalyst error",
			"Please specify profile name.");
		m_pProfileName->setFocus ();
		return;
	}

	if ((m_modified) && (NULL != m_pProfiles))
	{
		//If the name would overwrite an existing profile
		if ((m_profileName != m_pProfileName->text()) && 
			(NO_TRIGGER != m_pProfiles->getProfileType (m_pProfileName->text()))
			&& (QMessageBox::question (this, "CodeAnalyst warning",
			"There is already a profile with that name,"
			"\ndo you want to overwrite the profile?",
			QMessageBox::Yes, QMessageBox::No) == QMessageBox::No))
		{
			//Set the focus, so the user can change the name
			m_pProfileName->setFocus ();
			return;
		}
		
		// Counvert ms to count
		double ms = m_pInterval->text().toDouble(); 
		double count = (m_tick_per_sec / 1000) * ms;
		
		// Check if ms is less than 3000 (Oprofile lower limit)
		unsigned int min_count = 3000;
		double min_ms = min_count;
		min_ms = (double)(min_ms*1000) / m_tick_per_sec;
		
		// Count has type unsigned int, and max counter value is 0x7FFF FFFF
		unsigned int max_count = -1;
		max_count = max_count >> 1;
		double max_ms = max_count;
		max_ms = ((double)(max_ms*1000) / m_tick_per_sec);

		// Check for min.
		if(count < min_count)
		{
			QMessageBox::critical(this,"CodeAnalyst Error",
				QString("Timer interval is too small.\n")
				+ "Warning: Value too small can cause system to be unresponsive.\n"
				);
				m_pInterval->setFocus();
			return;
		}

		// Check for max.
		if(count > max_count)
		{
			QMessageBox::critical(this,"CodeAnalyst Error",
				QString("Timer interval is too big.\n")
				+ "Warning: Value too large will not generate meaningful profile.\n");
				m_pInterval->setFocus();
			return;
		}
		//Save modified profile
		TBP_OPTIONS tbpOptions;
		tbpOptions.msInterval = m_pInterval->text().toFloat();
		if(!(m_pProfiles->setProfileConfig (m_pProfileName->text(), &tbpOptions)))
		{
			m_pProfileName->setFocus ();
			return;
		}
		
	}
	accept();
} //TimerCfgDlg::onOk

bool TimerCfgDlg::wasModified ()
{
	return m_modified;
}
