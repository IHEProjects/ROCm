//$Id: typedefs.h,v 1.2 2005/02/14 16:52:40 jyeh Exp $
// A file that contains all the simple type definitions, and some 
//  cross-compiler definitions.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


//Revision history
//$Log: typedefs.h,v $
//Revision 1.2  2005/02/14 16:52:40  jyeh
//Updated header.
//
//Revision 1.1.1.1  2004/10/05 17:03:23  jyeh
//initial import into CVS
//
//Revision 1.3  2003/12/12 23:04:00  franksw
//Code Review
//
//Revision 1.2  2003/11/14 20:17:24  franksw
//Removed windows specific defines
//

#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_

#define TRUE	1
#define FALSE	0

#define MAX_UINT64 0xffffffffffffffffLL
#define MAX_INT64  0x7fffffffffffffffLL
#define MIN_UINT64 0x0000000000000000LL
#define MIN_INT64  0x8000000000000000LL

#define FMT64 "ll"

#define sign64(num64) num64##ll
#define usign64(num64) num64##ull

#ifdef __cplusplus
typedef unsigned long long int	UINT64;
typedef long long int INT64;
#else
typedef unsigned long long int UINT64 ;
typedef long long int INT64;
#endif

#if !defined(HRESULT)
typedef unsigned int HRESULT ;
#endif

#if !defined(DWORD)
typedef unsigned int DWORD;
#endif


#if !defined(ULONG)
typedef unsigned int ULONG;
#endif

#if !defined(ULONG64)
typedef unsigned long long ULONG64;
#endif

#if !defined(LONG)
typedef long LONG;
#endif

#if !defined(_MAX_PATH)
#define _MAX_PATH   256 /* max. length of full pathname */
#define MAX_PATH   256  /* max. length of full pathname */
#define _MAX_EXT   256  /* max. length of extention */
#define _MAX_DIR    32  /* max. length of path component */
#define _MAX_FNAME  64  /* max. length of file name component */
#define _MAX_DRIVE  3   /* max. length of drive */
#endif

#if !defined(__int64)
typedef long long __int64;
#endif

#include <asm/types.h>

#if !defined(__u8)
typedef __u8  field8;     /* 8 bits, 1 byte   */
#endif

#if !defined(__u16)
typedef __u16 field16;    /* 16 bits, 2 bytes */
#endif

#if !defined(__u32)
typedef __u32 field32;    /* 32 bits, 4 bytes */
#endif

#if !defined(__u64)
typedef __u64 field64;    /* 64 bits, 8 bytes */
#endif

#if !defined(S_OK)
#define S_OK 0L
#define S_FALSE 1L
#define E_FAIL 0x80004005L
#define E_INVALIDARG 0x80070057L
#define E_OUTOFMEMORY 0x8007000EL
#endif

#define MAX_UINT32 0xffffffff
#define MAX_INT32  0x7fffffff
#define MAX_UINT16 0xffff
#define MAX_INT16  0x7fff
#define MAX_UINT8  0xff
#define MAX_INT8   0x7f

#define MIN_UINT32 0x00000000
#define MIN_INT32  0x80000000
#define MIN_UINT16 0x0000
#define MIN_INT16  0x8000
#define MIN_UINT8  0x00
#define MIN_INT8   0x80

typedef unsigned int			UINT32;
typedef	signed int				INT32;
typedef	unsigned short int		UINT16;
typedef short int				INT16;
typedef	unsigned char			UINT8;
typedef	signed char				INT8;
typedef	float					FLOAT32;
typedef double					FLOAT64;

typedef unsigned int *			PUINT32;
typedef	signed int *			PINT32;
typedef	unsigned short int *	PUINT16;
typedef short int *				PINT16;
typedef	unsigned char *			PUINT8;
typedef	signed char *			PINT8;
typedef	float *					PFLOAT32;
typedef double *				PFLOAT64;

typedef struct uint128
{
	UINT64 lsw;
	UINT64 msw;
#ifdef __cplusplus
	inline bool operator==(const uint128 &val) { return( (lsw == val.lsw) && (msw == val.msw) ); }
	inline bool operator!=(const uint128 &val) { return( (lsw != val.lsw) || (msw != val.msw) ); }
	inline uint128 &operator>>=(const int &count)
	{
		if( count < 64 )
		{
			UINT64 tmp;
			tmp = msw << (64 - count);
			msw >>= count;
			lsw >>= count;
			lsw |= tmp;
		}
		else if( count < 128 )
		{
			lsw = msw >> (count - 64);
			msw = 0;
		}
		else
			msw = lsw = 0;

		return( *this );
	}
	inline uint128 &operator<<=(const int &count)
	{
		if( count < 64 )
		{
			UINT64 tmp;
			tmp = lsw >> (64 - count);
			msw <<= count;
			msw |= tmp;
			lsw <<= count;
		}
		else if( count < 128 )
		{
			msw = lsw << (count - 64);
			lsw = 0;
		}
		else
			msw = lsw = 0;

		return( *this );
	}
#endif
} UINT128, INT128;

typedef struct FLOAT80
{
	UINT8 buffer[10];
} *PFLOAT80;

typedef enum {IOBYTE, IOWORD, IODWORD} IOSIZE;	// Data Size for IO Transfers.

#define uInt128	UINT128
#define Int128	INT128
#define uInt64	UINT64
#define Int64	INT64
#define uInt32	UINT32
#define Int32	INT32
#define uInt16	UINT16
#define Int16	INT16
#define uInt8	UINT8
#define Int8	INT8
#define Float32	FLOAT32
#define Float64	FLOAT64

#define byte uInt8
typedef int BOOL;								
#ifndef __cplusplus
#define public
#define private static
#endif

#if !defined(NULL) 
#define NULL 0
#endif

#if !defined(BYTE)
typedef UINT8 BYTE ;
#endif

#define E_NOTREADY          0x8000F001L
#define E_FILE_NOT_FOUND    0x2L
#define E_NOT_ELF           0x11L
#define E_BAD_FORMAT        0x11L
#define E_PARSE_ERROR       0x12L
#define E_NOT_FOUND         0x15L
#define E_NO_DWARF          0x16L

#if !defined(LONG)
typedef long LONG ;
#endif

#if !defined(UINT)
typedef unsigned int UINT;
#endif

#if !defined(_MAX_PATH)
#define _MAX_PATH 512
#endif

#if !defined(STRING)
#define STRING std::string
#endif

#if defined(_x86_64_)

typedef unsigned long VADDR;

#elif defined(i386)

typedef unsigned long VADDR;

#else

#error "Machine type required."

#endif


#endif //_TYPEDEFS_H_
