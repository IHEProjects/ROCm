/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef _JNCFILE_H
#define _JNCFILE_H

#include <elf.h>
#include <memory.h>
#include <stdlib.h>
#include <stdio.h>

#define MAXLENGTH 			1024

#define CAJNC_NUM_SECTION_NODATA	3	
#define CAJNC_NUM_SECTION_WITHDATA	4

struct JavaSrcLineInfo {
	unsigned int addrOffset;
	unsigned int lineNum;
};



class CJNCFile {
public:
	CJNCFile();
	~CJNCFile();

	void setJNCFileName(char *pFileName);
	void setJITFuncName(char *pClassName, char *pFuncName, 
    			char *pSourceFile = NULL);
	bool writeJITNativeCode(unsigned char *pJITNativeCode, unsigned int size, 
		JavaSrcLineInfo *pSrcInfo = NULL, unsigned int srcEntryCnt = 0);
	void setJITStartAddr(unsigned long addr) {m_jitLoadAddr = addr;};
	void close();
	
private:
	void initElfHeader64();
	void writeElf64(unsigned char *pJITNativeCode, unsigned int size);
	void initElfHeader32();
	void writeElf32(unsigned char *pJITNativeCode, unsigned int size);
	unsigned long getDataSecSize();
	void writeDataSection();

private: 
	Elf64_Ehdr	m_elfhdr64;
	Elf32_Ehdr	m_elfhdr32;
	char 		m_jncFileName[MAXLENGTH];
	char 		m_jncClassName[MAXLENGTH];
	char 		m_jncFuncName[MAXLENGTH];
	char        	m_javaSrcName[MAXLENGTH];
	unsigned long long	m_jitLoadAddr;
	JavaSrcLineInfo *m_pSrcInfo;
	unsigned int 	m_SrcEntryCnt;
	FILE		*m_pFileStream;
};	

#endif // #ifndef_JNCFILE_Hs
