#ifndef _PERFEVENT_H_
#define _PERFEVENT_H_

#include <qstring.h>

#define		IBS_FETCH_EVENT_BEGIN	0xf000
#define		IBS_OP_EVENT_BEGIN	0xf100
#define		IBS_OP_EVENT_END	0xf24C

class PerfEvent
{
public:
	enum PerfEventFlag {
		Usr  = 0x1,
		Os   = 0x2,
		Edge = 0x4,
		Host = 0x8,
		Guest= 0x10
	};

	enum PerfEventType {
		Invalid = 0,
		Pmc,
		IbsFetch,
		IbsOp,
		Nb,
		OProfile,
	};

	PerfEvent() {
		select = 0;
		count = 0;	
		umask = 0;
		flags = PerfEvent::Usr | PerfEvent::Os;	// Default value
		type  = 0;
		minCount = 0;
	};

	bool operator < (const PerfEvent & other) const {
		if (select < other.select)
			return true;
		else if (select == other.select 
		     &&  umask < other.umask)
			return true;
		else if (select == other.select 
		     &&  umask == other.umask 
		     &&  flags < other.flags)
			return true;
		else if (select == other.select 
		     &&  umask == other.umask 
		     &&  flags == other.flags
		     &&  count < other.count)
			return true;
		else
			return false;
	};

	bool operator == (const PerfEvent & other) const {
		if ((select == other.select)
		&&  (umask == other.umask))
			return true;
		else
			return false;
	};

	void setOs(bool b)    { (b)? flags |= PerfEvent::Os: flags &= ~PerfEvent::Os; };
	void setUsr(bool b)   { (b)? flags |= PerfEvent::Usr: flags &= ~PerfEvent::Usr; };
	void setEdge(bool b)  { (b)? flags |= PerfEvent::Edge: flags &= ~PerfEvent::Edge; };
	void setHost(bool b)  { (b)? flags |= PerfEvent::Host: flags &= ~PerfEvent::Host; };
	void setGuest(bool b) { (b)? flags |= PerfEvent::Guest: flags &= ~PerfEvent::Guest; };

	bool os() { return ((flags & PerfEvent::Os) > 0); };
	bool usr() { return ((flags & PerfEvent::Usr) > 0); };
	bool edge() { return ((flags & PerfEvent::Edge) > 0); };
	bool host() { return ((flags & PerfEvent::Host) > 0); };
	bool guest() { return ((flags & PerfEvent::Guest) > 0); };

	void dump();
	QString getEventMaskEncodeMapKey();

	static bool isPmcEvent(unsigned int value);
	static bool isIbsFetchEvent(unsigned int value);
	static bool isIbsOpEvent(unsigned int value);
	static unsigned getEventType(QString cpuType, unsigned int value);

	unsigned int	type;
	QString		opName;
	QString		name;
	unsigned int	select;
	unsigned long	count;
	unsigned int	umask;
	unsigned int	flags;
	unsigned int	minCount;
};

///////////////////////////////////////////////////////////////////////////////
class PmcEvent : public PerfEvent
{
public:
	PmcEvent() : PerfEvent() {
		type = PerfEvent::Pmc;
	};
};

///////////////////////////////////////////////////////////////////////////////
class IbsFetchEvent : public PerfEvent
{
public:
	IbsFetchEvent() : PerfEvent() {
		type = PerfEvent::IbsFetch;
	};
};

///////////////////////////////////////////////////////////////////////////////
class IbsOpEvent : public PerfEvent
{
public:
	enum IbsOpUmaskFlag {
		DispatchCount = 0x1,
	};

	IbsOpEvent() : PerfEvent() {
		type = PerfEvent::IbsOp;
		umask= IbsOpEvent::DispatchCount;
	};
};

///////////////////////////////////////////////////////////////////////////////
class NbEvent : public PerfEvent
{
public:
	NbEvent() : PerfEvent() {
		type = PerfEvent::Nb;
	};
};

///////////////////////////////////////////////////////////////////////////////
class OProfileEvent : public PerfEvent
{
public:
	QString	counterMask;

	OProfileEvent() : PerfEvent() {
		type = PerfEvent::OProfile;
	};
};

#endif /*_PERFEVENT_H_ */
