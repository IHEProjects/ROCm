
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _DIFFSTRUCT_H_
#define _DIFFSTRUCT_H_

#include <bfd.h>
#include <qstring.h>
#include <qvaluevector.h>
#include <qmap.h>

#include "stdafx.h"
#include "ViewCollection.h"
#include "DataListItem.h"

#define MAX_NUM_DIFF	2
#define DEFAULT_FLOAT_PRECISION   2

typedef struct _SESSION_DIFF_INFO
{
	QString sessionFile;
	QString task;	
	QString module;	

	ViewCollection *pViewCollection;
	QString currentViewName;

	EventConfig *pEvArray;
	unsigned int evCount;
	

	_SESSION_DIFF_INFO()
	{
		pViewCollection = NULL;
		pEvArray = NULL;
		evCount = 0;
	};

	~_SESSION_DIFF_INFO()
	{

		if(pViewCollection!= NULL)
		{
			delete pViewCollection;
			pViewCollection= NULL;
		}

		if(pEvArray != NULL)
		{
			delete [] pEvArray;
			pEvArray = NULL;
			evCount = 0;
		}
	};
} SESSION_DIFF_INFO;

typedef QValueVector<SESSION_DIFF_INFO> SESSION_DIFF_INFO_VEC;
typedef QValueVector<QString> MODULE_DIFF_INFO_VEC;

/////////////////////////////////////////////////////
class SYMBOL_VIEW_INFO;
typedef map <QString, SYMBOL_VIEW_INFO> SYMBOL_VIEW_INFO_MAP;

class SYMBOL_VIEW_INFO
{
public:
	SampleDataMap sampleDataMap[MAX_NUM_DIFF];
	SampleDataMap sampleDataMapTotal[MAX_NUM_DIFF];
	SamplePercentMap samplePercentMap[MAX_NUM_DIFF];
	bfd_vma startAddr[MAX_NUM_DIFF];
	bfd_vma stopAddr[MAX_NUM_DIFF];
	QString symName;
	SYMBOL_VIEW_INFO_MAP inlineInstance;
	SYMBOL_VIEW_INFO* pCallerFunc;
	bool isInlineInstance;

	SYMBOL_VIEW_INFO()
	{
		pCallerFunc = NULL;
		isInlineInstance = false;
		for(int i = 0 ; i < MAX_NUM_DIFF ; i++)
		{
			startAddr[i] = 0;
			stopAddr[i] = 0;
		}
	};	
};

/////////////////////////////////////////////////////

class DASM_VIEW_INFO
{
public:
	enum {
		BB_ROW = 0,
		DASM_ROW	
	};
	bfd_vma		addr;	
	QString 	name;
	QString		codeByte;
	unsigned int	loadCnt;
	unsigned int	storeCnt;
	QString		inlineName;
	DataListItem 	*dataListItem;
	SampleDataMap	aggSampleDataMap;
	SamplePercentMap *pSamplePercentMap;
	int		rowType;
	DASM_VIEW_INFO	*pParent;	

	DASM_VIEW_INFO(QString n = "",
			DataListItem *ptr = NULL,
			int r = -1)
	{
		addr		= 0;
		name 		= n;	
		dataListItem 	= ptr;
		rowType 	= r;
		aggSampleDataMap.clear();
		pSamplePercentMap = NULL;
		loadCnt		= 0;
		storeCnt	= 0;
		inlineName	= "";
		codeByte	= "";
		pParent		= NULL;
	};	

};

typedef map <bfd_vma, DASM_VIEW_INFO> DASM_VIEW_INFO_MAP;

/////////////////////////////////////////////////////

//given a cpu/event key, get the column index
class DiffCpuEventType {

public:
	int cpu;
	EventMaskType event;
	EventMaskType umask;	
	int diffIndex;

	DiffCpuEventType () 
	{cpu = 0; event = 0; umask = 0; diffIndex = 0;};

	DiffCpuEventType (int a, EventMaskType b, EventMaskType c = 0, int d = 0) 
	{cpu = a; event = b; umask = c; diffIndex = d;};

	DiffCpuEventType(CpuEventType t, int i = 0)
	{
		cpu   = t.cpu;	
		event = t.event;	
		umask = t.umask;	
		diffIndex = i;
	};

	void setKey ( SampleKey sample) 
	{
		cpu = sample.cpu;
		// Decoding 
		event = sample.event & 0x000000000000ffff;
		umask = sample.event >> 16;
	};

	void setDiffIndex(int d)
	{ diffIndex = d; };

	BOOL operator< (const DiffCpuEventType &temp2) const
	{
		if(diffIndex < temp2.diffIndex)
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (event < temp2.event))
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (event == temp2.event) 
			&& (umask < temp2.umask))
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (event == temp2.event) 
			&& (umask == temp2.umask)
			&& (cpu < temp2.cpu))
			return true;
		else
			return false;
	};

};
/////////////////////////////////////////////////////

enum 
{
	UNDEFINED_COL = -1,
	SYMBOL_COL = 0,
	ADDR_COL,
	DATA_COL,
	DELTA_COL,
	COMPLEX_COL,
	PERCENT_COL
};

enum
{
	DASM_ADDR_COL = 0,
	DASM_BB_COL,
	DASM_CODEBYTE_COL,
	DASM_INLINE_COL,
	DASM_LOAD_COL,
	DASM_STORE_COL,
	DASM_OFFSET_COL
};

class DiffViewColumnInfo
{
public:
	bool 	isShown;
	QString colName;	
	QString colTip;
	int	colIndex;
	int	colType;

	DiffViewColumnInfo()
	{
		isShown 	= true;
		colIndex 	= -1;
		colType 	= UNDEFINED_COL;	
	};
	
	DiffViewColumnInfo(bool s, 
			int i, 
			int t,
			QString n="", 
			QString T="")
	{
		isShown  = s;
		colIndex = i;
		colType  = t;	
		colName  = n;
		colTip	 = T;
	};
}; // DiffViewColumnInfo

class ComplexKey
{
public:
	int diffIndex;
	int LopIndex;
	int RopIndex;
	int opType;
	
	ComplexKey()
	{
		diffIndex = -1;
		LopIndex = -1;
		RopIndex = -1;
		opType   = -1;
	};

	ComplexKey(int i, int l, int r, int o)
	{
		diffIndex = i;	
		LopIndex = l;
		RopIndex = r;
		opType   = o;
	};

	BOOL operator< (const ComplexKey &temp2) const
	{

		if(diffIndex < temp2.diffIndex)
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (LopIndex < temp2.LopIndex))
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (LopIndex == temp2.LopIndex)
			&& (RopIndex < temp2.RopIndex))
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (LopIndex == temp2.LopIndex)
			&& (RopIndex == temp2.RopIndex)
			&& (opType < temp2.opType))
			return true;
		else
			return false;

	};
}; // ComplexKey

typedef QMap <DiffCpuEventType , DiffViewColumnInfo> DiffViewColumnInfoMap;
typedef QMap<ComplexKey,DiffViewColumnInfo> ComplexColumnInfoMap;

/////////////////////////////////////////////////////

struct DIFF_VIEW_OPTIONS
{
	bool separateCpus;
	bool showPercentage;
	bool showSideBySide;
	bool showDelta;
	bool showLeftRight;
	bool showCommonEvent;

	DIFF_VIEW_OPTIONS()
	{
		separateCpus 	= false;
		showPercentage	= false;
		showSideBySide	= false;
		showDelta	= false;
		showLeftRight	= true;		// Default View
		showCommonEvent	= false;
	};

	const DIFF_VIEW_OPTIONS& operator = (const DIFF_VIEW_OPTIONS &right)
        {
                if (this != &right) 
		{
			separateCpus	= right.separateCpus;
			showPercentage	= right.showPercentage;
			showSideBySide	= right.showSideBySide;
			showDelta	= right.showDelta;
			showLeftRight	= right.showLeftRight;
			showCommonEvent	= right.showCommonEvent;
                }

                return (*this);
        };

};

typedef QMap<int,QListViewItem*> MAX_ENTRY_MAP;

extern void aggregateSampleDataMap(SampleDataMap* left, SampleDataMap* right);




#endif //_DIFFSTRUCT_H_
