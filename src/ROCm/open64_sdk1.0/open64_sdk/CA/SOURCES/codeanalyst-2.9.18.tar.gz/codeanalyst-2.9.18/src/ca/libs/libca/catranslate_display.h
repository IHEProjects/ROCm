#ifndef _CATRANSLATE_DISPLAY_H_
#define _CATRANSLATE_DISPLAY_H_

#include <qwidget.h>
#include <qstring.h>

class ca_translate_display
{
public:
    virtual ~ca_translate_display(){};

    virtual void init() = 0;
    virtual void update_display(const char * text) = 0;
    virtual void update_display_error(const char * text) = 0;
    virtual void translationInProgress(bool b) {Q_UNUSED(b);};
    virtual void setDlgEventHandler(QWidget * evHandler) {Q_UNUSED(evHandler);};
    virtual void display_oprofile_log(){};
};

#endif
