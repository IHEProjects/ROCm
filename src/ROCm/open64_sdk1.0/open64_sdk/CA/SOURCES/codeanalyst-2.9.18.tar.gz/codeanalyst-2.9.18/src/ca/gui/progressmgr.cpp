//$Id: progressmgr.cpp,v 1.7 2006/05/15 22:09:22 jyeh Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

// ProgressMgr class implementation


#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sched.h>
#include <qmessagebox.h>

#include "stdafx.h"
#include "progressmgr.h"
#include "oprofile_interface.h"



ProgressMgr::ProgressMgr (unsigned int delay, unsigned int duration, 
						  QObject * app, QString program, QString work_dir,
						  bool stop_on_app, bool break_after)
						  : QThread ()
{
	m_delay    = delay;
	m_duration = duration;
	m_app      = app;
	m_sleep    = FALSE;
	m_term     = FALSE;

	m_program	= program;
	m_work_dir	= work_dir;
	m_stop_on_app	= stop_on_app;
	m_break_after   = break_after;
	m_exitStatus 	= 0;
}


ProgressMgr::~ProgressMgr()
{
	wait();
}


#if QT_3_0 == 1
void ProgressMgr::terminate()
{
	m_mutex.lock();
	m_term  = TRUE;
	m_mutex.unlock();
}
#endif


void ProgressMgr::goToSleep()
{
	m_mutex.lock();
	m_sleep = TRUE;
	m_mutex.unlock();
}


void  ProgressMgr::wakeUp()
{
	m_mutex.lock();
	m_sleep = FALSE;
	m_mutex.unlock();
}


void ProgressMgr::stopNow()
{
	//reset the progress bar
	QApplication::postEvent (m_app, new QCustomEvent ( 
		(QEvent::Type) EVENT_RESET_PROGRESS, NULL));

	m_mutex.lock();
	m_term  = TRUE;
	m_mutex.unlock();

	if (m_break_after && m_process_launched) {
		m_launched.tryTerminate();
		QTimer::singleShot(1000, &m_launched, SLOT(kill()));
		int i = 0;		
		while(m_launched.isRunning() && i < 3) {
			m_launched.tryTerminate();
			QTimer::singleShot(1000, &m_launched, SLOT(kill()));
			i++;
		}
	}
	wait ();
}


//Wait for the specified time before sending the delay finished event
// so the profiling will start
void ProgressMgr::doDelay ()
{
	bool done = false;

	QApplication::postEvent (m_app, new QCustomEvent ( 
		(QEvent::Type) EVENT_SET_STEPS, (void *) long (m_delay * 2)));

	for ( unsigned int i = 1; i <= m_delay * 2; ++i ) {
		bool temp_sleep;  
		do {
			if ( m_process_launched && m_stop_on_app ) {
				m_mutex.lock();
				if (!m_launched.isRunning()) { 
					m_mutex.unlock();
					done = true;
					break;
				}
				m_mutex.unlock();
			}
			//sleep for 500 mS
			msleep (500);

			m_mutex.lock();
			temp_sleep = m_sleep;

			bool temp_terminate = m_term;
			m_mutex.unlock();

			if ( temp_terminate) {
				QThread::exit ();
			}
		} while ( temp_sleep );

		if (done) break;

		m_mutex.lock();
		bool temp_terminate = m_term;
		m_mutex.unlock();
		if ( temp_terminate) 
			QThread::exit ();

		QApplication::postEvent (m_app, new QCustomEvent ( 
			(QEvent::Type) EVENT_SET_PROGRESS, (void *) long (i)));
	}
} //ProgressMgr::doDelay


int ProgressMgr::launch(AffinityMask_t afMask, bool setCssTgid, bool showTerminal)
{
	/*
	We lauch the app first before the delay, rather than after.  If the
	user is telling us to put in a delay, it is typically because the app
	is not doing anything interesting during the delay duration.
	*/
	if (! launchApplication(afMask, showTerminal)) {
		QApplication::postEvent (m_app, new QCustomEvent ( 
			(QEvent::Type) EVENT_LAUNCH_ERROR,
			(void *) new QString("Unable to launch the "
			"specified application.\nMake sure "
			"you have specified a valid app." )));
		return -1;
	}

	// ***************************************
	/*
	* Setting Affinity
	*/
	if ((m_tgid = m_launched.processIdentifier()) > 0) {
		cpu_set_t set;

		// Clear 
		CPU_ZERO(&set);

		// Set	
		helpSetAffinityMask(&set,afMask);

		if(sched_setaffinity(m_tgid,sizeof(cpu_set_t),&set)) {
			fprintf(stderr,
				"ERROR: Cannot set affinity mask %#x. Default to all available CPUs\n",
				afMask);
		}
	}
	// ***************************************
	/*
	 * configuring CSS
	 */
	oprofile_interface opIf;
	if (setCssTgid
	&&  (!opIf.set_param(QString("enable"), 0) 
		||  !opIf.set_param(QString("ca_css_tgid"), m_tgid) 
		||  !opIf.set_param(QString("enable"), 1))) {
		fprintf(stderr,
			"ERROR: Cannot set CSS tgid %d.\n",
			m_tgid);
	}

	start();
    return 0;
}

void ProgressMgr::storeStatusStdoutStderr()
{
	// Storing exit status, stderr, stdout
	m_exitStatus = m_launched.exitStatus();
	while(m_launched.canReadLineStdout())
	{
		m_stdout += m_launched.readLineStdout() + "\n";
	}
	while(m_launched.canReadLineStderr())
	{
		m_stderr += m_launched.readLineStderr() + "\n";
	}
}

void  ProgressMgr::run ()
{
	bool done = false;
	m_exitStatus	= 0;
	m_stdout 	= "";
	m_stderr 	= "";

	doDelay ();

	QApplication::postEvent (m_app, new QCustomEvent ( 
		(QEvent::Type) EVENT_RESET_PROGRESS, NULL));

	QApplication::postEvent (m_app, new QCustomEvent ( 
		(QEvent::Type) EVENT_DELAY_FINISH ));


	/// duration
	if (m_duration > 0) {
		QApplication::postEvent (m_app, new QCustomEvent ( 
			(QEvent::Type) EVENT_SET_STEPS, (void *) long (m_duration * 2)));

		for ( unsigned int j = 1; j <= m_duration * 2; ++j ) {
			bool temp_sleep;
			
			do {
				m_mutex.lock();
				if (!m_launched.isRunning()) { 
					if ( m_process_launched && m_stop_on_app ) {
						m_mutex.unlock();
						done = true;
						break;
					} else if(!m_exitStatus) { 
						// Store information in case,
						// user manually stop the profile.
						storeStatusStdoutStderr();
					}
				}
				m_mutex.unlock();

				//sleep for 500 mS
				msleep (500);

				m_mutex.lock();
				temp_sleep = m_sleep;
				bool temp_terminate = m_term;
				m_mutex.unlock();
				if ( temp_terminate) 
					QThread::exit ();

			} while ( temp_sleep );

			if (done) break;

			m_mutex.lock();
			bool temp_terminate = m_term;
			m_mutex.unlock();

			if ( temp_terminate) 
				QThread::exit ();

			QApplication::postEvent (m_app, new QCustomEvent ( 
				(QEvent::Type) EVENT_SET_PROGRESS, (void *) long (j)));
		}
	} else {
		//m_bProcessLaunched && m_stop_on_app are assumed here

		int i_counter = 0;
		const int DURATION_STEPS = 20;
		QApplication::postEvent (m_app, new QCustomEvent ( 
			(QEvent::Type) EVENT_SET_STEPS, (void *) long (DURATION_STEPS)));

		while (!done) {
			m_mutex.lock();
			if (!m_launched.isRunning()) { 
				m_mutex.unlock();
				done = true;
				break;
			}
			m_mutex.unlock();

			//sleep 500 mS
			msleep (500);

			m_mutex.lock();
			bool temp_terminate = m_term;
			m_mutex.unlock();

			if ( temp_terminate)
				QThread::exit ();

			QApplication::postEvent (m_app, new QCustomEvent ( 
				(QEvent::Type) EVENT_SET_PROGRESS, (void *) long (i_counter)));

			if (++i_counter > DURATION_STEPS) 
				i_counter = 0;
		}    
	}

	if ((m_break_after) && (!done)) {
		m_mutex.lock();
		if (m_launched.isRunning()) {
			m_launched.tryTerminate();
		}
		m_mutex.unlock();
	}

	// Storing exit status, stderr, stdout
	storeStatusStdoutStderr();

	// Let the Application know that the time has expired
	QApplication::postEvent (m_app, new QCustomEvent ( 
		(QEvent::Type) EVENT_DURATION_FINISH));

	return ;
} //ProgressMgr::run


void ProgressMgr::cleanup()
{
}


bool ProgressMgr::launchApplication(AffinityMask_t afMask, bool showTerminal)
{
	m_process_launched = false;

	if ( m_program.isEmpty() ) {
		return true;
	}

	// Setup
	m_launched.clearArguments();
	m_launched.setWorkingDirectory (m_work_dir);

#ifdef XTERM
	// Start application with xterm
	if (showTerminal)
	{
		m_launched.addArgument (XTERM);
		m_launched.addArgument ("-e");
		m_launched.addArgument (m_program);
	} 
	else 
#endif
	// Start applicatin directly
	{

		// Parse input	
		QString temp = m_program;

		while (!temp.isEmpty()) {
			QString argument;
			static const QRegExp whitespace ("\\s");
			int next_pos;

			if (temp.startsWith ("\"")) {
				//find closing "
				next_pos = temp.find ("\"", 1); 
				argument = temp.mid (1, (next_pos - 1));
				next_pos ++;
			} else {
				next_pos = temp.find (whitespace);
				argument = temp.mid (0, next_pos );
			}

			if (next_pos >= 0)
				temp = temp.mid (next_pos + 1).stripWhiteSpace();
			else
				temp = "";

			if (!argument.isEmpty())
				m_launched.addArgument (argument);
		}
	}


	if (!m_launched.start()) {
		return false;
	}

	m_process_launched = true;

	return true;
}

void ProgressMgr::helpSetAffinityMask(cpu_set_t *set, AffinityMask_t afMask)
{
	int index = 0;
	AffinityMask_t coreMask = 0x1;
	while(afMask != 0)
	{
		if((coreMask & afMask) == 1)	
		{
			CPU_SET(index,set);
		}
		index++;
		afMask = afMask >> 1;
	}
}


