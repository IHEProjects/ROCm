//$Id: tbsreader.h 17060 2009-08-25 15:41:38Z ssuthiku $
//  interface for the TbsReader class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _TBSREADER_H_
#define _TBSREADER_H_

#include "stdafx.h"
#include "tbsStruct.h"
#include "tbsFuncTor.h"

#include <map>
using namespace std;

#define TBPFILEVERSION_3	3
#define TBPFILEVERSION_6	6
#define TBPFILEVERSION_7	7
#define TBPFILEVERSION_8	8	

/* Version 9:
 * - Add JIT function level
 * - Java Profiling Not compatible with previous version 
 */
#define TBPFILEVERSION_9	9

// key is module name (or, PROCESSDATA, MODDATA), 
// data is offset of the file
typedef map<QString, unsigned int> FileOffsetMap;

class TbsReader
{
public:
	TbsReader();

	~TbsReader();

	bool OpenTbsFile(QString tbp_file_path);

	unsigned int getTbpFileVersion();

	unsigned int getNumCpus() {return m_env_vals.m_num_cpus;};

	unsigned int getNumEvents(){return m_env_vals.m_num_events;};

	unsigned int getNumSamples(){return m_env_vals.m_num_samples;};

	unsigned int getNumModules(){return m_env_vals.m_num_modules;};

	QValueList<unsigned long long> getEventList() {
		return m_env_vals.m_event_list;
	};

	unsigned int getEventIndex(unsigned int event_mask) {
		return m_env_vals.m_event_list.findIndex(event_mask);
	};

	QString getPath () {return m_tbp_file_path;};

	QString getDir (){
		QString dir =  m_tbp_file_path.section ("/", 0, -2, 
					QString::SectionIncludeTrailingSep);
		return dir;
	};

	QString getName () {
		QString name =  m_tbp_file_path.section ("/", -1 );
		return name;
	};

	QString getJncDir() {
		QString dir =  m_tbp_file_path.section ("/", 0, -2, 
					QString::SectionIncludeTrailingSep);
		dir += "jit/";
		return dir;
	};

	unsigned int getTbpVersion();

	unsigned long getCpuFamily(){return m_env_vals.m_cpufamily;};

	unsigned long getCpuModel(){return m_env_vals.m_cpumodel;};

	QString getTimestamp() {return m_env_vals.m_timestamp;};
	
	// parsing process section
	bool readProcInfo(QValueList<SYS_LV_ITEM> & list);

	// parse module data section
	bool readModInfo(QValueList<SYS_LV_ITEM> & list, 
					SampleDataMap *pTotal = NULL);

	// parse module data section and aggregate
	bool readAggregatedModInfo(QValueList<SYS_LV_ITEM> & list,
					SampleDataMap *pTotal = NULL);

	bool readInstSampleInfo(QString          & name, 
				TaskSampleMap    * pTaskSampMap, 
				JitBlockPtrVec   * pJitBlkPtrVec,
				ProfileAttribute * pAtt, 
				TFunctor         * dis_callback);

	bool getModAttributes (QString modName, ProfileAttribute *pAtt);

	QString getTbpDir() { return m_tbp_dir; };
private:
	bool readEnvSection();

	void processEnvLine(QString const & line);

	void tbp_processProcLine(QValueList<SYS_LV_ITEM> & list, QString & line);

	void tbp_processModLine(QValueList<SYS_LV_ITEM> & list, 
				QString & line,
				SampleDataMap *pTotal);

	bool readModAttributes (ProfileAttribute *pAtt);

	bool tbp_processInstSampleLine(QString & line, MOD_LV_ITEM &inst_item);

	bool open_filestream();

	void delete_filestream();

	unsigned int GetFileOffset(QString str);

	void markOffset(QString mark);

	bool GetOffset(QString mark, unsigned int *pOffset);

	bool readJitAttribute(QString & jitSym,
				QString & jitSrc,
				unsigned long & jitBase,
				unsigned int & jitSize,
				unsigned int & lineCount);

	bool processJitBlock(JIT_BLOCK_INFO ** pJitBlkInfo);
private:
	// tbp file name;
	QString  m_tbp_file_path;

	QString  m_tbp_dir;

	// file descriptor
	QFile * m_file;

	// stream
	QTextStream * m_stream;
	
	// file version
	unsigned int m_tbp_version;

	//
	EnvValues m_env_vals;

	FileOffsetMap m_offsetMap;
	
	unsigned int m_largestOffset;
};



#endif //ifndef _TBSREADER_H_
