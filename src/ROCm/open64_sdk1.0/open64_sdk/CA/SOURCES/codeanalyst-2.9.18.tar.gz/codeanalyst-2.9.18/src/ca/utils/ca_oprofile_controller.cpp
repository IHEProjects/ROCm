// CodeAnayst Profiling Controller

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <signal.h>
#include <popt.h>
#include <string.h>
#include <sys/wait.h>
#include <string>
#include <iostream>

#include "config.h"

#define LOCK_PATH "/var/lib/oprofile/lock"
#define SAMPLES_CURRENT_PATH "/var/lib/oprofile/samples/current/"

using namespace std;

static char* start= NULL;
static int sigterm = 0;
static int sigkill = 0;
static int rmlock  = 0;
static int reset   = 0;
static int load    = 0;
static int unload  = 0;
static char* devConfig = NULL;

enum {
	OPT_START = 1,
	OPT_TERM,
	OPT_KILL,
	OPT_RMLOCK,
	OPT_RESET,
	OPT_LOAD,
	OPT_UNLOAD,
	OPT_DEVCONFIG,
	OPT_VERSION,
	OPT_HELP
};

static struct poptOption options[] = {
{ "start"      , 's', POPT_ARG_STRING, &start, OPT_START , "", NULL },
{ "term"       , 't', POPT_ARG_NONE, &sigterm, OPT_TERM  , "", NULL },
{ "kill"       , 'k', POPT_ARG_NONE, &sigkill, OPT_KILL  , "", NULL },
{ "rmlock"     , 'r', POPT_ARG_NONE, &rmlock , OPT_RMLOCK, "", NULL }, 
{ "reset"      , 'e', POPT_ARG_NONE, &reset  , OPT_RESET , "", NULL },
{ "load-drv"   , 'l', POPT_ARG_NONE, &load   , OPT_LOAD  , "", NULL },
{ "unload-drv" , 'u', POPT_ARG_NONE, &unload , OPT_UNLOAD, "", NULL },
{ "dev-config" , 'd', POPT_ARG_STRING, &devConfig, OPT_DEVCONFIG , "", NULL },
{ "version"    , 'v', POPT_ARG_NONE, NULL, OPT_VERSION , "", NULL },
{ "help"       , 'h', POPT_ARG_NONE, NULL, OPT_HELP    , "", NULL },
{ NULL         , 0, 0, NULL, 0, NULL, NULL },
};

void show_version() 
{
        fprintf(stdout,"ca_oprofile_controller for %s\n",PACKAGE_STRING);
        fprintf(stdout,"  Built on : %s %s\n",__DATE__,__TIME__);
        fprintf(stdout,"  Contacts : %s \n",PACKAGE_BUGREPORT);
        fprintf(stdout,"  Configure detail :\n  %s\n",CA_CONFIG_ARG);
}


void show_usage() 
{
	printf( " Usage:\n"
		"       ca_oprofile_controller [-s|--start]| | [-t|--term] | [-k|-kill] |\n"
		"                              [-r|--rmlock] | [-e|--reset] | \n"
		"                              [-v|--version] | [-h|--help]\n"
		"\n"
		"    -s|--start=<option string>     Start Oprofile daemon with specified option string.\n"
		"    -t|--term      Send SIGTERM to Oprofile daemon.\n"
		"    -k|--kill      Send SIGKILL to Oprofile daemon.\n"
		"    -r|--rmlock    Remove Oprofile lock file (/var/lib/oprofile/samples/oprofiled.log).\n"
		"    -e|--reset     Delete Oprofile sample files in /var/lib/oprofile/samples/current.\n"
		"    -l|--load-drv  Load OProfile driver.\n"
		"    -u|--unload-drv    Unload OProfile driver.\n"
		"    -d|--dev_config=<file>:<value>\n"
		"                   Configure OProfile /dev/oprofile/<file> device file.\n"
		"    -v|--version   Show version number.\n"
		"    -h|--help      Show this message.\n"
		"\n"
		" Description :\n"
		"     CodeAnalyst uses this utility to control profiling session.\n"
		"\n"
		" NOTE :\n"
		"     - Please run as root\n");
}


int do_options(int argc, char const * argv[])
{
	poptContext optcon;
	int c = 0, ret = 0;

	optcon = poptGetContext(NULL, argc, argv, options, 0);

	if (argc < 2) {
		poptPrintUsage(optcon, stdout, 0);
		ret = -1;
		goto out;
	}

	while ( (c = poptGetNextOpt(optcon)) != -1  ) {
		switch (c) {
		case OPT_START:	
		case OPT_TERM:
		case OPT_KILL:
		case OPT_RMLOCK:
		case OPT_RESET:
		case OPT_LOAD:
		case OPT_UNLOAD:
		case OPT_DEVCONFIG:
			break;	
		case OPT_HELP:
			show_usage();
			exit(0);
			break;	
		case OPT_VERSION:
			show_version();
			exit(0);
			break;	
		default:
			fprintf(stderr,"Error: Invalid arguments.\n");	
			show_usage();
			exit(1);
			break;
		}
	}

	poptFreeContext(optcon);
out:
	return ret;
}

int mkdir_var_lib_oprofile_samples_current()
{
        return system("mkdir -p /var/lib/oprofile/samples/current");
}

int mkdir_var_lib_oprofile_jitdump()
{
	int ret = 0;
	// This is needed by Oprofile-0.9.4+ for Java profiling
        if(ret == 0 ) ret = system("mkdir -p /var/lib/oprofile/jitdump");
        if(ret == 0 ) ret = system("chgrp amdca /var/lib/oprofile/jitdump");
        if(ret == 0 ) ret = system("chmod g+w /var/lib/oprofile/jitdump");
	return ret;
}

int mkdir_var_lib_oprofile_jit()
{
	int ret = 0;
	// This is needed by CA Oprofile for Java profiling
        if(ret == 0 ) ret = system("mkdir -p /var/lib/oprofile/jit");
        if(ret == 0 ) ret = system("chgrp amdca /var/lib/oprofile/jit");
        if(ret == 0 ) ret = system("chmod g+w /var/lib/oprofile/jit");
	return ret;
}

int mkdir_var_lib_oprofile_Java()
{
	int ret = 0;
	// This is needed by CA Oprofile for Java profiling
        if(ret == 0 ) ret = system("mkdir -p /var/lib/oprofile/Java");
        if(ret == 0 ) ret = system("chgrp amdca /var/lib/oprofile/Java");
        if(ret == 0 ) ret = system("chmod g+w /var/lib/oprofile/Java");
	return ret;
}
int remove_var_lib_oprofile_samples_current_star()
{
        return system("rm -rf /var/lib/oprofile/samples/current/*");
}

int remove_var_lib_oprofile_samples_ca_oprofile_cg()
{
        return system("rm -rf /var/lib/oprofile/samples/ca_oprofile.cg");
}

int remove_var_lib_oprofile_jitdump_star()
{
        return system("rm -rf /var/lib/oprofile/jitdump/*");
}

int remove_var_lib_oprofile_jit_star()
{
        return system("rm -rf /var/lib/oprofile/jit/*");
}

int remove_var_lib_oprofile_Java_star()
{
        return system("rm -rf /var/lib/oprofile/Java/*");
}

int remove_var_lib_oprofile_samples_oprofiled_log()
{
        return system("rm -rf /var/lib/oprofile/samples/oprofiled.log");
}

int get_pid_from_lock_file()
{
	FILE * lock_file;
	struct stat st;
	char buf[64];
	int ret = -1;
	int size = 0;

	// Use /var/lib/oprofile/lock
	if (0 != stat(LOCK_PATH, &st))
	{
		return ret;	
	}
	if (!(lock_file = fopen(LOCK_PATH, "r"))) {
		return ret;	
	}

	if((size = fread(&buf, 1, sizeof(buf), lock_file)) == 0)
		goto out;
	else	
		buf[size+1] = 0;

	ret = atol(buf);
out:
	return ret;
}


int get_pid_from_pidof()
{
	pid_t pid;
	int pipe_fd[2];
	int status = 0;
	int readCnt = 0;
	char buf[10];
	char pidof[] = PIDOF;
	char oprofiled[] = "oprofiled";

	// Command
	char * const cmd_pidof[3] = { pidof, oprofiled, NULL };

	// Pipe
	if(pipe(pipe_fd) < 0)
		return -1;

	//Create Process
	if( (pid = fork()) < 0 ) {
		return -1;
	} else if ( pid == 0 ) { // child
		// Setup stdout
		close (pipe_fd[0]);
		dup2 (pipe_fd[1],1);
		close (pipe_fd[1]);
	
		// Execute
		execvp(cmd_pidof[0], cmd_pidof);
	
	} else { //parent
		// Setup stdin
		close (pipe_fd[1]);
		dup2 (pipe_fd[0],0);
		close (pipe_fd[0]);

		// Read from pipe
		readCnt = read(0, buf,10);
		waitpid (pid, &status, 0);
	}
	
	if(readCnt <= 0)
		return -1;
	
	return atoi(buf);
}

int remove_lock()
{
	int ret = -1;
	pid_t pid;

	if((pid = get_pid_from_pidof()) > 0) {
		fprintf(stderr,"pid = %d\n",pid);
		fprintf(stderr,
			"ca_oprofile_controller: Cannot remove lock file since oprofiled is still running.\n");
	} else {
		ret = 0;
		unlink(LOCK_PATH);	
	}
	return ret;
}

int send_signal(void )
{
	int ret = -1;
	pid_t pid;
 
	// Suravee commented out.
	// NOTE: This approach is a security risk 
	// since some might update /var/lib/oprofile/lock
	// to be any number
	//if((pid = get_pid_from_lock_file()) == -1)
	if((pid = get_pid_from_pidof()) <= 0) {
		fprintf(stderr,
			"ca_oprofile_controller: Could not locate oprofiled.\n");
		goto out;
	}

	if (sigterm != 0) {
		printf("ca_oprofile_controller: sending SIGTERM to pid %d\n", pid);
		if((ret = kill(pid, SIGTERM)) != 0)
			fprintf(stderr,
			"ca_oprofile_controller: Error sending SIGTERM to oprofiled.\n");
	} else if (sigkill != 0) {
		printf("ca_oprofile_controller: sending SIGKILL to pid %d\n", pid);
		if((ret = kill(pid, SIGKILL)) != 0)
			fprintf(stderr,
			"ca_oprofile_controller: Error sending SIGKILL to oprofiled.\n");
		else
			unlink(LOCK_PATH);
	}
out:
	return ret;
}

int run_oprofiled()
{
	int ret = 1;
	string str(start);
	string cmd(OP_BINDIR);

	// Start oprofiled
	cmd.append("/oprofiled");
	cmd.append(" ");
	cmd.append(str);

#if 0 // _DEBUG_
	fprintf(stdout,"cmd = %s\n",cmd.c_str());
#endif

	ret=system(cmd.c_str());
	return ret;
}

int device_config(const char * filePath, const char * val, int size)
{
	int ret = -1;
	FILE * file = NULL;
	string devFile = ("/dev/oprofile/");
	
	if (!filePath || !val || !size) 
		return ret;

	devFile += filePath;

	file = fopen(devFile.c_str(), "w" );
	if (!file) {
		perror(devFile.c_str());
		return ret;
	}

	ret = fwrite(val, 1, size, file); 
	
	fclose(file);

	return ret;
}


int device_config()
{
	// Parse input
	string str(devConfig);
	
	int found = str.find_first_of(":"); 

	if (!found)
		return -1;
	
	string path = str.substr(0, found);
	string val  = str.substr(found+1, string::npos);
	
	return device_config(path.c_str(), val.c_str(), val.size());
			
}


int main(int argc, char const * argv[]) 
{
	int ret = 1;

	// Check if root user
	if(0 == getuid())
		goto permissionOk;

	/* 
	 *NOTE:
	 * In sudo approach, we check if this is a root user.
	 * Only root can run this.
	 */ 
	fprintf(stderr,"ca_oprofile_controller: Error, must be root.\n");
	goto out;

permissionOk:

	// Parse options
	if (0 != (ret = do_options(argc, argv))) {
		fprintf(stderr,"ca_oprofile_controller: Error, parsing option.\n");
		goto out;
	}

	// Handle Start
	if(start) {
		if(0 != (ret = run_oprofiled())) 
			fprintf(stderr,"ca_oprofile_controller: Error, starting oprofiled.\n");
		goto out;
	}

	// Handle Reset
	if(reset) {
	        if( remove_var_lib_oprofile_samples_current_star()  == 0
		&&  remove_var_lib_oprofile_samples_ca_oprofile_cg() == 0
		&&  remove_var_lib_oprofile_samples_oprofiled_log() == 0 
		&&  remove_var_lib_oprofile_jitdump_star() == 0
		// TODO: [Suravee] Clean out this directory when no jitted process running
		//&&  remove_var_lib_oprofile_jit_star() == 0
		//&&  remove_var_lib_oprofile_Java_star() == 0
		&&  mkdir_var_lib_oprofile_samples_current() == 0
		&&  mkdir_var_lib_oprofile_jitdump() == 0
		&&  mkdir_var_lib_oprofile_jit() == 0
		&&  mkdir_var_lib_oprofile_Java() == 0) 
		{
			ret = 0;
		}
		goto out;
	}
	
	// Handle Remove lock
	if(rmlock) {
		ret = remove_lock();
		goto out;
	}

	// Handle driver load 
	if(load) {
		string cmd(OP_BINDIR);
		cmd += "/opcontrol --init 2> /dev/null > /dev/null";
		ret = system(cmd.c_str());
		goto out;
	}

	// Handle driver unload
	if(unload) {
		string cmd(OP_BINDIR);
		cmd += "/opcontrol --deinit 2> /dev/null > /dev/null";
		ret = system(cmd.c_str());
		goto out;
	}

	// Handle device file configuration
	if (devConfig) {
		if((ret = device_config()) <= 0) 
			fprintf(stderr,"ca_oprofile_controller: Error, Cannot configure /dev/oprofile.\n");
		else
			ret = 0;
		goto out;
	}

	// Sending SIGTERM or SIGKILL
	ret = send_signal();
out:
	return ret;
}
