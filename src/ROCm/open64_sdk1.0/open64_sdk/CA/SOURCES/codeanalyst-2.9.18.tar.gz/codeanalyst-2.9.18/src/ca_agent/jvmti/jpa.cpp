/*
 * CodeAnalyst for Open Source
 * Copyright 2002 . 2005 Advanced Micro Devices, Inc.
 * You may redistribute this program and/or modify this program under the terms
 * of the GNU General Public License as published by the Free Software 
 * Foundation; either version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA.
 */


#include <jvmti.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <asm/unistd.h>
#include <stdio.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <iostream>
#include <fstream>
#include <sstream>

#include "libCAagent.h"
#include "config.h"

using namespace std;

typedef struct {
    /* JVMTI Environment */
    jvmtiEnv      * jvmti;
    jvmtiCapabilities   * vmCapabilities;
	pid_t jvmPID;
} GlobalAgentData;

static string jvmCmd = "";

static GlobalAgentData * gdata = NULL;

/* This is taken from Sun's demo.  Check copyright 
 * Send message to stderr or whatever the error output location is and exit  
 */
static void
fatal_error(const char * format, ...)
{
    va_list ap;
	
    va_start(ap, format);
    (void)vfprintf(stderr, format, ap);
    (void)fflush(stderr);
    va_end(ap);
    exit(3);
}

/* Every JVMTI interface returns an error code, which should be checked
 *   to avoid any cascading errors down the line.
 *   The interface GetErrorName() returns the actual enumeration constant
 *   name, making the error messages much easier to understand.
 *   Again, this is taken from Sun's demo, check copy right.
 */
static void
check_jvmti_error(jvmtiEnv *jvmti, jvmtiError errnum, const char *str)
{
    if ( errnum != JVMTI_ERROR_NONE ) {
	char       *errnum_str = NULL;
	
	jvmti->GetErrorName(errnum, &errnum_str);
	
	fatal_error("ERROR: JVMTI: %d(%s): %s\n", errnum, 
		(errnum_str==NULL?"Unknown":errnum_str),
		(str==NULL?"":str));
	if (NULL != errnum_str)
	    jvmti->Deallocate ((unsigned char *)errnum_str);
    }
}

static void JNICALL
cbVMInit(jvmtiEnv *jvmti, JNIEnv *env, jthread thread)
{
}



static void getCmdline()
{
    char tmp[100] = {NULL};
    pid_t pid = gdata->jvmPID; 
    stringstream tstream;
    tstream << "/proc/" << pid << "/cmdline";
    string pidDir = tstream.rdbuf()->str(); 

    filebuf fb;
    if (NULL == fb.open(pidDir.c_str(), ios::in))
		cout << "filebuf failed to open" << endl;
	
    istream is(&fb);
    while (!is.eof()) {
        is >> jvmCmd;
#ifdef _DEBUG_
        cout << "getCmdline " << jvmCmd << endl;
#endif
    }

    int end = jvmCmd.find ("CAJVMTIA\0");
//      cerr << "DEBUG: jvmCmd = " << jvmCmd << endl;
    if (end > -1 ) {
		jvmCmd.erase (0, end);

		// Attempt to parse the string 
		// -agentpath:/usr/local/bin/libCAJVMTIA.so
		sprintf(tmp,"%s",jvmCmd.c_str());
		unsigned int tmpSize = strlen(tmp);
		if(jvmCmd.length() > tmpSize)
			jvmCmd.erase (0, tmpSize+1);
	}
    
    for (unsigned int i=0; i < jvmCmd.length(); i++)
      if (0 == jvmCmd[i])
	  jvmCmd[i] = ' ';

    char cmdFileName[FILENAME_MAX];
    sprintf (cmdFileName, "%s/%d", CA_JAVA_DIR, pid);
    FILE * cmdFile = fopen (cmdFileName, "w");
    if (NULL != cmdFile) 
    {
	fprintf (cmdFile, "%s", jvmCmd.c_str());
	fclose (cmdFile);
    }
}


/*
void createNewEntry(jmethodID method, jint code_size, const void* code_addr)
{		
}
*/

/*
static char stub_i386[] = {
	0x55,
	0x55							//push   %ebp
  //0xb8, 0, 0, 0, 0,               // mov $0,%eax
  //0xff, 0xe0                      // jmp *(%eax)
};
*/

void JNICALL
writeJITToELF(jvmtiEnv *jvmti_env,
            jmethodID method,
            jint code_size,
            const void* code_addr,
            jint map_length,
            const jvmtiAddrLocationMap* map,
            const void* compile_info)
{
	string str_name = "UnknownClass";

	/* Get the declaring class of the method */
	jclass declaringClass;
	jvmti_env->GetMethodDeclaringClass(method, &declaringClass);
	
	char * classSig = NULL;
	jvmti_env->GetClassSignature(declaringClass,
            &classSig, NULL);

	if (classSig) {
		str_name = classSig;
	}
	str_name += "::";

 	char * methodName = NULL;
	jvmti_env->GetMethodName(method, &methodName, NULL, NULL);
	if (methodName) {
		str_name += methodName;
	} else {
		str_name += "UnknownFunction";
	}

	ca_write_native_code(str_name.c_str(), code_addr, code_size);

	// need to de-allocate the methodName and classSig;
	if (NULL != classSig)
	    jvmti_env->Deallocate ((unsigned char *) classSig);

	if (NULL != methodName)
	    jvmti_env->Deallocate ((unsigned char *) methodName);
}


void JNICALL
cbCompiledMethodLoad(jvmtiEnv *jvmti_env,
		    jmethodID method,
		    jint code_size,
		    const void* code_addr,
		    jint map_length,
		    const jvmtiAddrLocationMap* map,
		    const void* compile_info)
{

#ifdef _DEBUG_
	char * classSig = NULL;
	jclass declaringClass;
	jvmti_env->GetMethodDeclaringClass(method, &declaringClass);
	jvmti_env->GetClassSignature(declaringClass, &classSig, NULL);
	
	char * name_ptr = NULL;
	jvmti_env->GetMethodName(method, &name_ptr, NULL, NULL);
	
	fprintf(stderr, "DEBUG:   LOAD: 0x%lx: %s:%s\n",
		(unsigned long) code_addr, classSig, name_ptr ); 
	jvmti_env->Deallocate ((unsigned char *) classSig);
	jvmti_env->Deallocate ((unsigned char *) name_ptr);
#endif

	writeJITToELF(jvmti_env, method, code_size, 
			code_addr, map_length, map, compile_info);

	/* Get the declaring class of the method */
	jclass declaring_class;
	jvmti_env->GetMethodDeclaringClass(method, &declaring_class);
			
	struct ca_jit_shm_entry new_entry;
	new_entry.start_address = (unsigned long)code_addr;
	new_entry.size          = (unsigned)code_size;
	ca_add_mapping(&new_entry);
}


void JNICALL cbCompiledMethodUnload (jvmtiEnv *jvmti_env, 
				jmethodID method,
				const void* code_addr)
{
#ifdef _DEBUG_
	char * classSig = NULL;
	jclass declaringClass;
	jvmti_env->GetMethodDeclaringClass(method, &declaringClass);
	jvmti_env->GetClassSignature(declaringClass, &classSig, NULL);
	
	char * name_ptr = NULL;
	jvmti_env->GetMethodName(method, &name_ptr, NULL, NULL);
	
	fprintf(stderr, "DEBUG: UNLOAD: 0x%lx: %s:%s\n",
		(unsigned long) code_addr, classSig, name_ptr ); 
	jvmti_env->Deallocate ((unsigned char *) classSig);
	jvmti_env->Deallocate ((unsigned char *) name_ptr);
#endif

	/* NOTE:
	 * For method unload, we add a new entry to the
	 * shared buffer with size = 0 to communicate that
	 * the function with this particular address is
	 * no longer available.
	 */

	struct ca_jit_shm_entry new_entry;
	new_entry.start_address = (unsigned long)code_addr;
	new_entry.size          = 0 ;
	ca_add_mapping(&new_entry);

} //cbCompiledMethodUnload

typedef void (JNICALL *jvmtiEventDynamicCodeGenerated)
    (jvmtiEnv *jvmti_env, 
     const char* name, 
     const void* address, 
     jint length);



void JNICALL cbDynamicCodeGenerated (jvmtiEnv *jvmti_env, const char* name,
				     const void* code_addr, jint code_size)
{
	ca_write_native_code(name, code_addr, code_size);

	struct ca_jit_shm_entry new_entry;
	new_entry.start_address =  (unsigned long)code_addr;
	new_entry.size = (unsigned)code_size;
	ca_add_mapping(&new_entry);
} //cbDynamicCodeGenerated


JNIEXPORT jint JNICALL 
Agent_OnLoad(JavaVM *vm, char *options, void *reserved)
{
    jint                res;
    jvmtiEnv           *jvmti = NULL;
    jvmtiEventCallbacks callbacks;
    jvmtiCapabilities   capabilities;
    jvmtiError          error;

    gdata = (GlobalAgentData*)malloc(sizeof(GlobalAgentData));
   
    if (NULL == gdata) 
        fatal_error("Error: Out of Memory");
	
    gdata->jvmPID = getpid();
	
    mkdir(CA_JIT_DIR, 0x01fd);
    mkdir(CA_JAVA_DIR, 0x01fd);
	 
    getCmdline();
    /*
    char name[256];
    sprintf(name, "%s/%d/%d.jcl", CA_JAVA_DIR, gdata->jvmPID, gdata->jvmPID);
    */

     /* Get the jvmti environment */
     res = vm->GetEnv((void **)&jvmti, JVMTI_VERSION_1);
     if (res != JNI_OK) {
	    /* This means that the VM was unable to obtain this version of the
	     *   JVMTI interface, this is a fatal error.
	     */
	    fprintf(stderr,
            "ERROR: Unable to access JVMTI Version 1 (0x%x),"
            " is your J2SE a 1.5 or newer version?"
            " JNIEnv's GetEnv() returned %d\n",
            JVMTI_VERSION_1, res);

        /* todo: JVMTI_ERROR_INTERNAL appropriate?? */
        return JVMTI_ERROR_INTERNAL;
    }

    /* Immediately after getting the jvmtiEnv* we need to ask for the
     *   capabilities this agent will need. In this case we want to
     *   get method entry and method exit events.
     */
    (void)memset(&capabilities,0, sizeof(capabilities));
	/// Enabling can_generate_method_entry_events  will preventing jvm from
	/// inlining.
    /// capabilities.can_generate_method_entry_events = 1;
    capabilities.can_generate_compiled_method_load_events = 1;
    capabilities.can_get_source_file_name = 1;
    capabilities.can_get_line_numbers = 1;
    error = jvmti->AddCapabilities(&capabilities);

    /* Save the capabilities of the current VM */
    jvmtiCapabilities * vmCapabilities = 
        (jvmtiCapabilities *)malloc(sizeof(jvmtiCapabilities));
    if (JVMTI_ERROR_NONE != jvmti->GetPotentialCapabilities(vmCapabilities)) {
        /* todo: JVMTI_ERROR_INTERNAL appropriate?? */
        fprintf(stderr, "ERROR: Failed to get capabilities");
        return JVMTI_ERROR_INTERNAL;
    }
    gdata->vmCapabilities = vmCapabilities;

    /* Find the JLocation format of the current machine */
    jvmtiJlocationFormat locationFormat;
    error = jvmti->GetJLocationFormat(&locationFormat);

    /* Next we need to provide the pointers to the callback functions to
     *   to this jvmtiEnv*
     */
    (void)memset(&callbacks,0, sizeof(callbacks));
    /* JVMTI_EVENT_COMPILED_METHOD_LOAD */
    callbacks.CompiledMethodLoad = &cbCompiledMethodLoad;

    /* JVMTI_EVENT_DYNAMIC_CODE_GENERATED */
    callbacks.DynamicCodeGenerated = &cbDynamicCodeGenerated;

    /* JVMTI_EVENT_COMPILED_METHOD_UNLOAD */
    callbacks.CompiledMethodUnload = &cbCompiledMethodUnload;

    /* Set event call back */
    error = jvmti->SetEventCallbacks( &callbacks, (jint)sizeof(callbacks));
    check_jvmti_error(jvmti, error, "Cannot set jvmti callbacks");
	
    /* Initialize events we are interested in */
    error = jvmti->SetEventNotificationMode(JVMTI_ENABLE, 
                JVMTI_EVENT_COMPILED_METHOD_LOAD, (jthread)NULL);
    check_jvmti_error(jvmti, error, "Cannot set event notification");			
    error = jvmti->SetEventNotificationMode(JVMTI_ENABLE, 
					    JVMTI_EVENT_CLASS_LOAD, (jthread)NULL);
    check_jvmti_error(jvmti, error, "Cannot set event notification");

    error = jvmti->SetEventNotificationMode(JVMTI_ENABLE, 
                JVMTI_EVENT_COMPILED_METHOD_UNLOAD, (jthread)NULL);
    check_jvmti_error(jvmti, error, "Cannot set event notification");

    error = jvmti->SetEventNotificationMode(JVMTI_ENABLE,
                JVMTI_EVENT_DYNAMIC_CODE_GENERATED, (jthread)NULL); 
    check_jvmti_error(jvmti, error, "Cannot set event notification");

    if (ca_open_agent(getpid()) < 0)
        fatal_error("Error: Failed to create shared memory"
			"in Java profile agent.\n");
				
    return error;
}


/* Agent_OnUnload: This is called immediately before the shared library is 
 *   unloaded. This is the last code executed.
 */
JNIEXPORT void JNICALL 
Agent_OnUnload(JavaVM *vm)
{

    if (NULL != gdata->vmCapabilities) {
        free(gdata->vmCapabilities);
        gdata->vmCapabilities = NULL;
    }

    if (NULL != gdata) {
        free(gdata);
        gdata = NULL;
    }
}
