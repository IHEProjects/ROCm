
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <err.h>
#include <unistd.h>
#include <fcntl.h>
#include <bfd.h>

#include "bbanalysis.h"
#include "disassembler.h"
#include "smafile.h"

typedef struct _DasmExtraInfo {
	unsigned int 	instr_start;
	INSTRTYPE 		instr_type;
	unsigned int 	instr_length;
	MEMORYTYPE		memory_access;
	unsigned int	destination; 	
} DasmExtraInfo;


//helper functions
bool 
disassemble_helper(CDisassembler *pdasm, unsigned char *buffer, 
				unsigned int start_offset, DasmExtraInfo *pDasmInfo)
{
	if (!pdasm || !buffer ||  !pDasmInfo)
		return false;

	unsigned char opcode[8];
	int numOpcode = 0;
	bool pc_relative = false;
	int displacement = 0;
	int numOperands = 0;

	char * pdisasmStr = NULL;
	// assume that disassmbler had been configurated.
	if (!(pdisasmStr = pdasm->Disassemble(buffer)))
		return false;

	pDasmInfo->instr_length = pdasm->GetLength();
	pDasmInfo->instr_start = start_offset;

	numOpcode = pdasm->GetNumOpcodeBytes();
	for (int i = 0; i < numOpcode; i++)
		opcode[i] = pdasm->GetOpcode(i);

	pDasmInfo->instr_type = INSTR_OTHER_TYPE;
	if (1 == numOpcode) {
		switch(opcode[0]) {
			case 0x70:	// JO rel8	jump short if overflow
			case 0x71:	// JNO rel8	jump short if not overflow
			case 0x72:	// JB rel8	jump short if carry (CRF = 1)
			case 0x73:	// JAE rel8	jump short if above or equal (CF=0)
			case 0x74:	// JE rel8	jumpshort if carry (CF-1)
			case 0x75:	// JNE rel8	jumpshort if NOT equal 
			case 0x76:	// JBE rel8	jump short if below (CF=1)
			case 0x77:	// JA rel8	jump short if above (CF=0 & ZF=0)
			case 0x78:	// JS rel8	jump short if sign (SF=1) 
			case 0x79:	// JNS rel8	jump short if not sign (SF=0)
			case 0x7A:	// JP rel8	jump short if parity
			case 0x7B:	// JPO rel8	jump short if not parity
			case 0x7C:	// JL rel8	jump short if less (SF <>OF) 
			case 0x7D:	// JGE rel8	jump short if greater or equal
			case 0x7E:	// JNG rel8	jump short if not greater
			case 0x7F:	// JG rel8	jump short if equal (ZF=1)
				// jump
				pDasmInfo->instr_type = BR_COND_JUMP;
				break;

			case 0x9A:	// call ptr16:32, call far, absolute, 
				pDasmInfo->instr_type = BR_ABS_CALL;
				break;

			case 0xE8:
				// call near, relative, displacement relative to next instr
				pDasmInfo->instr_type = BR_RELATIVE_CALL;
				break;

			case 0xE9:	// JMP rel16/32
			case 0xEB:	// JMP rel8
				pDasmInfo->instr_type = BR_RELATIVE_JUMP;
				break;

			case 0xEA:	// JMP ptr16:32
				pDasmInfo->instr_type = BR_ABS_JUMP;
				break;
			
			case 0xFF:
				{
					unsigned char modrm = pdasm->GetModrm();
					unsigned char reg_opcode = ((modrm >> 3) & 0x07);
					switch(reg_opcode) {
						case 0x02:
						case 0x03:
							pDasmInfo->instr_type = BR_ABS_INDIRECT_CALL;
							break;
						case 0x04:
						case 0x05:
							pDasmInfo->instr_type = BR_ABS_INDIRECT_JUMP;
							break;
						default:
							break;
					}
				}
				break;

			case 0xC2:
			case 0xC3:
			case 0xCA:
			case 0xCB:
				pDasmInfo->instr_type = BR_RET;
				break;

			default:
				break;

		}
	} else if  (2 == numOpcode) {
		switch (opcode[1]) {
			case 0x80:	// JO rel16/32
			case 0x81:
			case 0x82:
			case 0x83:
			case 0x84:
			case 0x85:
			case 0x86:
			case 0x87:
			case 0x88:
			case 0x89:
			case 0x8A:
			case 0x8B:
			case 0x8C:
			case 0x8D:
			case 0x8E:
			case 0x8F:
				// jump instruction
				pDasmInfo->instr_type = BR_COND_JUMP;
				break;

			case 0x05:
				// syscall
				pDasmInfo->instr_type = BR_SYSCALL;
				break;

			case 0x07:
				//sysret
				pDasmInfo->instr_type = BR_SYSRET;
				break;

			default:
				break;
		}
	}

	pDasmInfo->memory_access = MA_NA;	
	numOperands = pdasm->GetNumOperands();	
	// should be pc relative and must have displacement
	for (int i = 0; i < numOperands; i++) {
		int type = pdasm->GetOperandType(i);
		if ((n_Disassembler::OPERANDTYPE_RIPRELATIVE == type) ||
				(n_Disassembler::OPERANDTYPE_PCOFFSET == type))
			pc_relative = true;

		if (n_Disassembler::OPERANDTYPE_MEMORY == type) {
			if (0 == i)
				pDasmInfo->memory_access = (MEMORYTYPE) MA_WRITE;
			else if (1 == i)
				pDasmInfo->memory_access = (MEMORYTYPE) (
						pDasmInfo->memory_access + (MEMORYTYPE) MA_READ);
		}
	}

	displacement = pdasm->GetDisplacement();
	if (pc_relative && displacement) {
		pDasmInfo->destination = start_offset + pdasm->GetLength() 
						+ displacement;
	} else
		pDasmInfo->destination = 0; 

	return OK;
}


void 
updateBranchMaps( unsigned int block_start,
				DasmExtraInfo dasmInfo, 
				BLOCKMAP *pBBMap,
				BRANCHINSTRMAP *pBrMap) 
{
	BR_INSTR_INFO t_br;

	BASIC_BLOCK_KEY bb_key;

	BASIC_BLOCK_INFO bblock;
	
	// update temporary block map;
	bb_key.bb_start = block_start;

	bblock.bb_start_offset = block_start;
	bblock.bb_size = dasmInfo.instr_start + dasmInfo.instr_length 
				- bb_key.bb_start;
	bblock.bb_end_instr_length = dasmInfo.instr_length; 
	bblock.bb_end_instr_type = dasmInfo.instr_type;
	pBBMap->insert(	BLOCKMAP::value_type(bb_key, bblock));
			
	// update temporary jump map;
	if (pBrMap) {
		t_br.instr_offset = dasmInfo.instr_start;
		t_br.instr_length = dasmInfo.instr_length;
		t_br.instr_type = dasmInfo.instr_type;
		t_br.destination_offset = dasmInfo.destination;
		pBrMap->insert(BRANCHINSTRMAP::value_type(dasmInfo.instr_start, t_br));
	}

}



// Since it's call, we will treat call as a separate block;
void 
updateCallBranchMaps( unsigned int block_start,
				DasmExtraInfo dasmInfo, 
				BLOCKMAP *pBBMap,
				BRANCHINSTRMAP *pBrMap) 
{
	BR_INSTR_INFO t_br;

	BASIC_BLOCK_KEY bb_key;

	BASIC_BLOCK_INFO bblock;

	if (block_start != dasmInfo.instr_start) {
		// update temporary block map;
		bb_key.bb_start = block_start;
		bblock.bb_start_offset = block_start;
		bblock.bb_size = dasmInfo.instr_start - bb_key.bb_start;
		bblock.bb_end_instr_length = 0; 
		bblock.bb_end_instr_type = INSTR_OTHER_TYPE; 
		pBBMap->insert(	BLOCKMAP::value_type(bb_key, bblock));
	}	


	// treat a call as a separate block
	bb_key.bb_start = dasmInfo.instr_start;
	bblock.bb_start_offset = dasmInfo.instr_start;
	bblock.bb_size = dasmInfo.instr_length;
	bblock.bb_end_instr_length = dasmInfo.instr_length; 
	bblock.bb_end_instr_type = dasmInfo.instr_type; 
	pBBMap->insert(	BLOCKMAP::value_type(bb_key, bblock));

	// update temporary jump map;
	if (pBrMap) {
		t_br.instr_offset = dasmInfo.instr_start;
		t_br.instr_length = dasmInfo.instr_length;
		t_br.instr_type = dasmInfo.instr_type;
		t_br.destination_offset = dasmInfo.destination;
		pBrMap->insert(BRANCHINSTRMAP::value_type(dasmInfo.instr_start, t_br));
	}
}



BBAnalysis::BBAnalysis()
{
	m_fd = 0;
	m_elf = NULL;
	m_image_base = 0;
	m_32bit = true;

	cleanup_maps();
}

BBAnalysis::~BBAnalysis()
{
	bba_cleanup();
}

void 
BBAnalysis::cleanup_maps()
{
	m_block_map.clear();
	m_block_iter = m_block_map.end();

	m_valid_addr_set.clear();
	
	m_jmp_map.clear();
	m_call_map.clear();
	m_ret_map.clear();
	
	//m_br_src_map.clear();
	m_br_dest_map.clear();
}


void 
BBAnalysis::bba_cleanup()
{
	cleanup_maps();
	m_section_map.clear();

	if (m_elf) {
		(void) elf_end(m_elf);
		m_elf = NULL;
	}

	if (m_fd > 0) {
		(void) close(m_fd);
		m_fd = 0;
	}
}

int 
BBAnalysis::initialize_elf(const char* filename)
{
	int retval = NOT_ELF;

	// get image base;
	GElf_Phdr phdr;
	GElf_Ehdr ehdr;
	Elf_Scn *scn = NULL;
	GElf_Shdr shdr;	

	if (elf_version(EV_CURRENT) == EV_NONE)	
		goto EXITPLACE;

	if ((m_fd = open(filename, O_RDONLY, 0)) < 0) {
		retval = CANNOT_OPEN;
		goto EXITPLACE;
	}

	if ((m_elf = elf_begin(m_fd, ELF_C_READ, NULL)) == NULL) 
		goto EXITPLACE;

	if (gelf_getehdr(m_elf, &ehdr) == NULL) {
		goto EXITPLACE;
	} else {
		m_32bit = (ehdr.e_ident[EI_CLASS] == ELFCLASS64)? false: true;
	}

	if (gelf_getphdr(m_elf, 0, &phdr) == &phdr) {
		m_image_base = phdr.p_vaddr - phdr.p_offset;
	} else {
		m_image_base = ehdr.e_entry;
	}

	retval = OK;

	while((scn = elf_nextscn(m_elf, scn)) != NULL) {
		if (gelf_getshdr(scn, &shdr) != &shdr)
			continue;

		if (!(shdr.sh_flags & SHF_EXECINSTR))
			continue;
		
		BASIC_BLOCK_KEY s_offset;
		s_offset.bb_start = (unsigned int) shdr.sh_offset;
		unsigned int e_offset = (unsigned int) (shdr.sh_offset + shdr.sh_size);
		m_section_map.insert(SECTIONMAP::value_type( s_offset, e_offset));
	};



EXITPLACE:
	if (retval != OK) {
		if (m_elf) {
			(void) elf_end(m_elf);
			m_elf = NULL;
		}

		(void) close(m_fd);
		m_fd = 0;	
	}

	return retval;

}

unsigned int 
BBAnalysis::bba_get_first_section_offset()
{
	unsigned int val = 0;

	SECTIONMAP::reverse_iterator s_iter;

	s_iter = m_section_map.rbegin();
	if(s_iter != m_section_map.rend())
		val = s_iter->first.bb_start;

	return val;
}


int 
BBAnalysis::enumerate_symbols(const char* filename)
{
	int rc = OK;

	asymbol ** symtab = NULL;
	bfd_init();

	bfd* pbfd = NULL;
	pbfd = bfd_openr(filename, NULL);
	if (NULL == pbfd) {
		rc = CANNOT_OPEN;
		goto EXITPLACE;
	}
	if (!bfd_check_format(pbfd, bfd_object)) {
		rc = NOT_ELF;
		goto EXITPLACE;
	}

	if (bfd_get_file_flags(pbfd) & HAS_SYMS) {
		long symtab_cnt = bfd_get_symtab_upper_bound(pbfd);

		if (symtab_cnt > 0) {
			symtab = (asymbol **) malloc (symtab_cnt);
			if (!symtab) {
				rc = NO_MEMORY;
				goto EXITPLACE;
			}

			symtab_cnt = bfd_canonicalize_symtab(pbfd, symtab);
			if (symtab_cnt <= 0)
				goto EXITPLACE;

			for (int i = 0; i < symtab_cnt; i++) {
				if (!(symtab[i]->section->flags & SEC_CODE)) 
					continue;	// it's not code section ;

				//  need to convert this to offset by substract imagebase;
				bfd_vma tmp_addr = symtab[i]->value + symtab[i]->section->vma;
				unsigned int offset = (unsigned int) (tmp_addr - m_image_base);
				m_valid_addr_set.insert(offset);
			}

		}

	}

EXITPLACE:
	if (symtab) {
		free(symtab);
		symtab = NULL;
	}

	if (pbfd) {
		bfd_close(pbfd);
		pbfd = NULL;
	}

	return rc;
}

        
int 
BBAnalysis::bba_init(const char* filename)
{
	int rc = OK;

	rc = initialize_elf(filename);
	
	if (rc == OK) {
		rc = enumerate_symbols(filename);
	}

	m_modname = filename;
	return rc;
}


void 
BBAnalysis::bba_attach_info(OFFSETLIST samplesList)
{
	OFFSETLIST::iterator iter;
	for (iter = samplesList.begin(); iter != samplesList.end(); iter++) {
		m_valid_addr_set.insert(*iter);
	}

}

DATASET::iterator BBAnalysis::get_next_valid(unsigned int offset)
{
	DATASET::iterator tIter;
	tIter = m_valid_addr_set.lower_bound(offset);
	return tIter;
}


int 
BBAnalysis::analyze_range(unsigned int start, unsigned int end)
{
	int retval = FAILED;

	if (!m_fd || !m_elf)
		return retval;
	if (end <= start)
		return retval;

	// Assumption:
	// start and end are in same section.
	CDisassembler disasm;

	Elf_Scn *scn = NULL;
	GElf_Shdr shdr;	
	Elf_Data *elfdata = NULL;
	unsigned char *pbuffer = NULL;
	unsigned char *pbuffer_end= NULL;
	unsigned char *pcurr = NULL;
	unsigned int curr_offset = 0;
	DasmExtraInfo dasm_info;
	
	BRANCHINSTRMAP t_jmp_map;
	BRANCHINSTRMAP t_call_map;
	BRANCHINSTRMAP t_ret_map;
	BLOCKMAP t_bbmap;
	MEMACCESSMAP	t_LSMap;
	DATASET t_valid; 
	unsigned int block_start;
	unsigned int t_end;

	unsigned int sec_offset;	// section offset to file base (image base)
	DATASET::iterator valid_addr_iter;

	// get section and data
	while((scn = elf_nextscn(m_elf, scn)) != NULL) {
		if (gelf_getshdr(scn, &shdr) != &shdr)
			continue;

		if (!(shdr.sh_flags & SHF_EXECINSTR))
			continue;
		
		sec_offset = (unsigned int) shdr.sh_offset;
		unsigned int e_offset = (unsigned int) (shdr.sh_offset + shdr.sh_size);
		if (sec_offset <= start && start < e_offset)
			break;
	};

	if (NULL == scn)
		goto EXITPLACE;

	elfdata = elf_getdata(scn, elfdata);
	if (!elfdata)
		goto EXITPLACE;

	pbuffer = (unsigned char*) elfdata->d_buf;
	if ((end - sec_offset) < elfdata->d_size) { 
		t_end = end;
		pbuffer_end = pbuffer + (unsigned int) (end - sec_offset);
	} else  {
		t_end = sec_offset + (unsigned int )elfdata->d_size;
		pbuffer_end = pbuffer + (unsigned int) elfdata->d_size;
	}

	pcurr = pbuffer + (start - sec_offset);
	curr_offset = start;
	block_start = start;

	// find the next valid address for later address validation
	valid_addr_iter = m_valid_addr_set.upper_bound(start);

	// enable disassembler
	if (m_32bit) {
		disasm.SetDbit(true);
		disasm.SetLongMode(false);
	} else {
		disasm.SetDbit(false);
		disasm.SetLongMode(true);
	}

	// disassembler is setup to go,
	retval = OK;
	// start disassemble
	while (pcurr < pbuffer_end) {
		if (disassemble_helper(&disasm, pcurr, curr_offset, &dasm_info) == OK) {
			switch (dasm_info.instr_type) {
				case BR_COND_JUMP:
				case BR_RELATIVE_JUMP:
				case BR_ABS_JUMP:
				case BR_ABS_INDIRECT_JUMP:	// don't care jump near or far
					updateBranchMaps(block_start,dasm_info,&t_bbmap,&t_jmp_map);
					block_start = curr_offset + dasm_info.instr_length;
					break;

				case BR_RELATIVE_CALL:
				case BR_ABS_CALL:
				case BR_ABS_INDIRECT_CALL:
				case BR_SYSCALL:
					updateCallBranchMaps(block_start,dasm_info,
									&t_bbmap,&t_call_map);
					block_start = curr_offset + dasm_info.instr_length;
					break;

				case BR_SYSRET:
				// BR_ENTER, INT, IRET/IRETD
				case BR_RET:
					updateBranchMaps(block_start,dasm_info,&t_bbmap,&t_ret_map);
					block_start = curr_offset + dasm_info.instr_length;
					break;
					
				case INSTR_OTHER_TYPE:
				default:		// the type we don't care
					break;
			}
			// determine memory access
			switch(dasm_info.memory_access) {
				case MA_READ:
				case MA_WRITE:
				case MA_READWRITE:
					t_LSMap.insert(MEMACCESSMAP::value_type(curr_offset, 
											dasm_info.memory_access));
					break;

				default:
					break;
			}

			// check if cross valid instruction
			if (valid_addr_iter != m_valid_addr_set.end()) {
				if (curr_offset == *valid_addr_iter) {
					// We hit valid instrution, previous analysіs is correct,
					// we will dump the temporary maps information 
					updateMaps(t_bbmap, t_jmp_map, t_call_map, 
									t_ret_map, t_LSMap);
					// clear temporary maps;
					t_bbmap.clear();	
					t_jmp_map.clear();
					t_call_map.clear();
					t_ret_map.clear();
					t_LSMap.clear();

					// iterate the next valid address
					valid_addr_iter++;
					
					// move to next instr	
					curr_offset += disasm.GetLength();
					pcurr += disasm.GetLength();
				}
				else if (curr_offset > *valid_addr_iter) {
					// this should not happen;
					valid_addr_iter = m_valid_addr_set.upper_bound(curr_offset);
					
					// move to next instr	
					curr_offset += disasm.GetLength();
					pcurr += disasm.GetLength();
				} else if (curr_offset + dasm_info.instr_length > 
								*valid_addr_iter) {

					// current instruction is in the middle of instr;
					// clear temporary maps;
					t_bbmap.clear();	
					t_jmp_map.clear();
					t_call_map.clear();
					t_ret_map.clear();
					t_LSMap.clear();

					block_start = addUnknownBlock(block_start, 
									t_end, curr_offset);
					pcurr = pbuffer + (block_start- sec_offset);
					valid_addr_iter = m_valid_addr_set.upper_bound(block_start);
					retval = UNKNOWN_BLOCK;
					break;
				} else {
					curr_offset += disasm.GetLength();
					pcurr += disasm.GetLength();
				}
			}
			else {
				curr_offset += disasm.GetLength();
				pcurr += disasm.GetLength();
			}


		} else {
			// Failed to disassemble;
			// clear temporary maps;
			t_bbmap.clear();	
			t_jmp_map.clear();
			t_call_map.clear();
			t_ret_map.clear();
			t_LSMap.clear();

			block_start = addUnknownBlock(block_start, 	t_end, curr_offset);
					
			pcurr = pbuffer + (block_start- sec_offset);
			valid_addr_iter = m_valid_addr_set.upper_bound(block_start);

			retval = DASM_ERROR;
		}
	};

	//handle the last part (end of the section or specified region).
	if (pcurr >= pbuffer_end) 
	{
		updateMaps(t_bbmap, t_jmp_map, t_call_map, t_ret_map, t_LSMap);
	}
	else {
		addUnknownBlock(block_start, t_end, t_end);
	}	
	
EXITPLACE:
	return retval;
}

void
BBAnalysis::updateMaps(BLOCKMAP blockMap, BRANCHINSTRMAP jmpMap,
				BRANCHINSTRMAP callMap, BRANCHINSTRMAP retMap,
				MEMACCESSMAP memAccMap)
{
	//update block Map
	BLOCKMAP::iterator b_iter;
	BRANCHINSTRMAP::iterator br_iter;

	for (b_iter = blockMap.begin(); b_iter != blockMap.end(); b_iter++) {
		m_block_map.insert(BLOCKMAP::value_type(b_iter->first, b_iter->second));
	}

	for (br_iter = jmpMap.begin(); br_iter != jmpMap.end(); br_iter++) {
		m_jmp_map.insert(BRANCHINSTRMAP::value_type(br_iter->first, 
								br_iter->second));
		
		if (br_iter->second.destination_offset) {
			//m_br_src_map.insert(MULTIMAP::value_type(br_iter->first,
			//					br_iter->second.destination_offset));
			
			m_br_dest_map.insert(MULTIMAP::value_type(
						br_iter->second.destination_offset,	br_iter->first));

		}
	}	

	for (br_iter = callMap.begin(); br_iter != callMap.end(); br_iter++) {
		m_call_map.insert(BRANCHINSTRMAP::value_type(br_iter->first, 
								br_iter->second));
		if (br_iter->second.destination_offset) {
			//m_br_src_map.insert(MULTIMAP::value_type(br_iter->first,
			//					br_iter->second.destination_offset));
			
			m_br_dest_map.insert(MULTIMAP::value_type(
						br_iter->second.destination_offset,	br_iter->first));
		}
	}	

	for (br_iter = retMap.begin(); br_iter != retMap.end(); br_iter++) {
		m_ret_map.insert(BRANCHINSTRMAP::value_type(br_iter->first, 
								br_iter->second));
	}	

	for (MEMACCESSMAP::iterator miter = memAccMap.begin(); 
				miter != memAccMap.end(); miter++) {
		m_memacc_map.insert(MEMACCESSMAP::value_type(miter->first, 
							miter->second));
	}
}

unsigned int 
BBAnalysis::addUnknownBlock(unsigned int start, unsigned int end, 
				unsigned int current)
{
	unsigned int retVal = end;
		
	DATASET::iterator iter = m_valid_addr_set.upper_bound(current);
	if (iter != m_valid_addr_set.end()) {
		if (end > *iter)
			retVal = *iter;
	} 

	BASIC_BLOCK_KEY bb_key;
	BASIC_BLOCK_INFO bblock;
	bb_key.bb_start = start;
	bblock.bb_start_offset = start;
	bblock.bb_size = retVal -start; 
	bblock.bb_end_instr_length = 0; 
	bblock.bb_end_instr_type = INSTR_UNKNOWN;
	m_block_map.insert(	BLOCKMAP::value_type(bb_key, bblock));
			
	return retVal;	
}

int 
BBAnalysis::bba_analyze_range(unsigned int startoffset, 
				unsigned int endoffset, bool validate)
{
	if (endoffset <= startoffset)
		return FAILED;
	
	if (m_section_map.size() == 0)
		return FAILED;

	unsigned int start = startoffset;
	unsigned int end = endoffset;

	// Check if start and end are in same section.
	BASIC_BLOCK_KEY t_key;
	t_key.bb_start = start;
	SECTIONMAP::iterator s_iter;

	int retval = FAILED;

	s_iter = m_section_map.lower_bound(t_key);

	if (s_iter != m_section_map.end()) {
		if (s_iter->second >= end) {
			s_iter = m_section_map.lower_bound(t_key);
			retval = analyze_range(start, end);
		} else { 
			retval = analyze_range(start, s_iter->second);
			retval = NOT_IN_SAME_SECTION;
		}
				
	};

	if (validate)	
		validate_blocks();
	return retval;	
}


int 
BBAnalysis::bba_analyze_all()
{
	if (m_section_map.size() == 0)
		return FAILED;

	int retval = OK;
	int rc = OK;

	cleanup_maps();


	SECTIONMAP::iterator s_iter = m_section_map.end();

	int secNum = m_section_map.size();
	if (secNum)
		s_iter--;

	int secCnt = 0;
	for (; s_iter != m_section_map.end(); s_iter--) {
		if (secCnt >= secNum)
			break;

		rc = analyze_range(s_iter->first.bb_start, s_iter->second);
			
		if (rc != OK)
			retval = rc;
		secCnt++;
	}

	validate_blocks();
	return retval;	
}

void
BBAnalysis::validate_blocks()
{
	if(m_block_map.size() == 0)
		return;

	//merge the BRNACH instructions with destination
	BRANCHINSTRMAP::iterator br_iter;
	BRANCHINSTRMAP brMap;

	for (br_iter = m_jmp_map.begin(); br_iter != m_jmp_map.end(); br_iter++) {
		if (br_iter->second.destination_offset) {
			brMap.insert(BRANCHINSTRMAP::value_type(
						br_iter->second.destination_offset,
						br_iter->second));
		}
	}	

	for (br_iter = m_call_map.begin(); br_iter != m_call_map.end(); br_iter++) {
		if (br_iter->second.destination_offset) {
			brMap.insert(BRANCHINSTRMAP::value_type(
						br_iter->second.destination_offset,
						br_iter->second));
		}
	}	

	br_iter = brMap.begin();

	// since block map is sorted for descenting order
	BLOCKMAP::iterator block_iter = m_block_map.end();
	block_iter--;
	while (block_iter != m_block_map.end()) {
		if (br_iter == brMap.end())
			break;
	
		if (br_iter->first <= block_iter->first.bb_start) {
			br_iter++;
			continue;
		}

		if (br_iter->first >= block_iter->first.bb_start + 
						block_iter->second.bb_size) {
			block_iter--;
			continue;
		}	

		// at this point, branch is in the range of block
		// br_iter->first >= block_iter->first.bb_start && 
		// br_iter->first < block_iter->first.bb_start + 
		//						block_iter->second.bb_size; 
		//	
		// We need to split the current block into 2 blocks 
		// and move iterator

		// backup block info before split
		BASIC_BLOCK_KEY new_bb_key;
		BASIC_BLOCK_INFO new_block;
		new_bb_key.bb_start = br_iter->first;
		new_block.bb_start_offset = br_iter->first;
		new_block.bb_size = (block_iter->second.bb_start_offset +
				block_iter->second.bb_size) - br_iter->first;
		new_block.bb_end_instr_length = block_iter->second.bb_end_instr_length;
		new_block.bb_end_instr_type = block_iter->second.bb_end_instr_type;

		//block_iter->bb_start_offset = block_start;
		block_iter->second.bb_size = br_iter->first - 
				block_iter->first.bb_start; 
		block_iter->second.bb_end_instr_length = 0; 
		if (block_iter->second.bb_end_instr_type == INSTR_UNKNOWN) 
			block_iter->second.bb_end_instr_type = INSTR_UNKNOWN;
		else
			block_iter->second.bb_end_instr_type = INSTR_OTHER_TYPE;
	
		// insert new block	
		m_block_map.insert(BLOCKMAP::value_type(new_bb_key, new_block));

		// iterate the next
		block_iter--;
	};

	brMap.clear();
}

int 
BBAnalysis::bba_write_output(const char* filename)
{
	int rc = FAILED;

	BLOCKMAP::iterator biter;
	BASIC_BLOCK_INFO *pbblock = NULL;
	BRANCHINSTRMAP::iterator br_iter;
	BR_INSTR_INFO *pbr = NULL;
	MEMACCESSMAP::iterator ma_iter;
	MEMACC_INST ma_instr;

	SMAFileWriter sma;

	rc = sma.createSMAFile(filename, m_modname.c_str(), m_image_base, 
					(m_32bit) ? SMA_x86 : SMA_x86_64, 
					0, 0, 5);
	if (rc != OK)
		return rc;

	// from here, the file had been created

	// add basic block section
	if ((rc = sma.addSection(SMA_SCN_BASICBLOCK)) != OK)
		goto EXIT;

   	biter = m_block_map.begin();
	while (biter != m_block_map.end()) {
		pbblock = (BASIC_BLOCK_INFO *) & (biter->second);
		rc = sma.addSecRecord((void*) pbblock, sizeof(BASIC_BLOCK_INFO), NULL);
		if (rc != OK)
			goto EXIT;
		biter++;
	};
	if ((rc = sma.completeSection(SMA_SCN_BASICBLOCK)) != OK)
		goto EXIT;


	// add jmp section
	if ((rc = sma.addSection(SMA_SCN_JMP)) != OK)
		goto EXIT;
	br_iter = m_jmp_map.begin();
	while (br_iter != m_jmp_map.end()) {
		pbr = (BR_INSTR_INFO *) &(br_iter->second);
		rc = sma.addSecRecord((void*) pbr, sizeof(BR_INSTR_INFO), NULL);
		if (rc != OK)
			goto EXIT;
		br_iter++;
	};	

	if ((rc = sma.completeSection(SMA_SCN_JMP)) != OK)
		goto EXIT;


	// add call section
	if ((rc = sma.addSection(SMA_SCN_CALL)) != OK)
		goto EXIT;
	br_iter = m_call_map.begin();
	while (br_iter != m_call_map.end()) {
		pbr = (BR_INSTR_INFO *) &(br_iter->second);
		rc = sma.addSecRecord((void*) pbr, sizeof(BR_INSTR_INFO), NULL);
		if (rc != OK)
			goto EXIT;
		br_iter++;
	};	
	if ((rc = sma.completeSection(SMA_SCN_CALL)) != OK)
		goto EXIT;


	// add ret section
	if ((rc = sma.addSection(SMA_SCN_RET)) != OK)
		goto EXIT;
	br_iter = m_ret_map.begin();
	while (br_iter != m_ret_map.end()) {
		pbr = (BR_INSTR_INFO *) &(br_iter->second);
		rc = sma.addSecRecord((void*) pbr, sizeof(BR_INSTR_INFO), NULL);
		if (rc != OK)
			goto EXIT;
		br_iter++;
	};	
	if ((rc = sma.completeSection(SMA_SCN_RET)) != OK)
		goto EXIT;

	// add memory access section
	if ((rc = sma.addSection(SMA_SCN_MEMORYACCESS)) != OK)
		goto EXIT;
	ma_iter = m_memacc_map.begin();
	while (ma_iter != m_memacc_map.end()) {
		ma_instr.instr_offset = ma_iter->first;
		ma_instr.instr_memacc_type = ma_iter->second;
		rc = sma.addSecRecord((void*) &ma_instr,  sizeof(MEMACC_INST), NULL);
		if (rc != OK)
			goto EXIT;
		ma_iter++;
	};	
	if ((rc = sma.completeSection(SMA_SCN_MEMORYACCESS)) != OK)
		goto EXIT;
	rc = sma.completeSMAFile();


EXIT:

	if (rc != OK) {
		//remove file
		remove(filename);
	}
	return rc;
}

int 
BBAnalysis::bba_read_datafile(const char* filename)
{
	int rc = FAILED;

	SMAFileReader smard;
	SMA_HEADER * psmahdr = NULL;
	BASIC_BLOCK_INFO bbinfo;
	BR_INSTR_INFO brinfo;
	MEMACC_INST meminstr;
	SMA_SHE sma_she;

	// cleanup maps;
	m_jmp_map.clear();
	m_call_map.clear();
	m_ret_map.clear();
	m_memacc_map.clear();
	m_block_map.clear();
	m_br_dest_map.clear();

	if ((rc = smard.openSMAFile(filename)) != OK)
		goto EXIT;


	if ((psmahdr = smard.getFileHeader()) == NULL)
		goto EXIT;

	m_image_base = psmahdr->mod_imagebase;

	if ((rc = smard.getSectionHeader(SMA_SCN_BASICBLOCK, &sma_she)) != OK) 
		goto EXIT;

	// read basic block section
	if ((rc = smard.setReadSection(SMA_SCN_BASICBLOCK)) != OK)
		goto EXIT;

	while ((rc = smard.getNextSecRecord(&bbinfo, 
						sizeof(BASIC_BLOCK_INFO), 0, 0)) == OK) {
		BASIC_BLOCK_KEY bbkey;
		bbkey.bb_start = bbinfo.bb_start_offset;
		m_block_map.insert(	BLOCKMAP::value_type(bbkey, bbinfo));

	};


	// read jmp section
	if ((rc = smard.setReadSection(SMA_SCN_JMP)) != OK)
		goto EXIT;
	while ((rc = smard.getNextSecRecord(&brinfo, 
						sizeof(BR_INSTR_INFO), 0, 0)) == OK) {
			
		m_jmp_map.insert(BRANCHINSTRMAP::value_type(brinfo.instr_offset, 
								brinfo));
		
		if ( brinfo.destination_offset) { 
			m_br_dest_map.insert(MULTIMAP::value_type(
					brinfo.destination_offset,brinfo.instr_offset));
		}
	};	

	// read call section
	if ((rc = smard.setReadSection(SMA_SCN_CALL)) != OK)
		goto EXIT;
	while ((rc = smard.getNextSecRecord(&brinfo, 
						sizeof(BR_INSTR_INFO), 0, 0)) == OK) {
			
		m_call_map.insert(BRANCHINSTRMAP::value_type(brinfo.instr_offset, 
								brinfo));
		if ( brinfo.destination_offset) { 
			m_br_dest_map.insert(MULTIMAP::value_type(
				brinfo.destination_offset, brinfo.instr_offset));
		}
	};	


	// read return section
	if ((rc = smard.setReadSection(SMA_SCN_RET)) != OK)
		goto EXIT;
	while ((rc = smard.getNextSecRecord(&brinfo, 
						sizeof(BR_INSTR_INFO), 0, 0)) == OK) {
			
		m_ret_map.insert(BRANCHINSTRMAP::value_type(brinfo.instr_offset, 
								brinfo));
	};	

	// add memory access section
	if ((rc = smard.setReadSection(SMA_SCN_MEMORYACCESS)) != OK)
		goto EXIT;
	while ((rc = smard.getNextSecRecord(&meminstr, 
						sizeof(MEMACC_INST), 0, 0)) == OK) {
		m_memacc_map.insert(MEMACCESSMAP::value_type(meminstr.instr_offset, 
							meminstr.instr_memacc_type));
	};	
	rc = OK;

EXIT:
	return rc;
}

int 
BBAnalysis::bba_get_block_num()
{
	return m_block_map.size();
}

int 
BBAnalysis::bba_get_basicblock_info(unsigned int offset, 
				BASIC_BLOCK_INFO *pbbinfo)
{
	int rc = FAILED;
	if (!pbbinfo)
		return rc;
	
	BASIC_BLOCK_KEY tkey;
	tkey.bb_start = offset;
	BLOCKMAP::iterator bb_iter = m_block_map.lower_bound(tkey);

	if (bb_iter != m_block_map.end()) {
		if (bb_iter->first.bb_start + bb_iter->second.bb_size > offset) {
			pbbinfo->bb_start_offset = bb_iter->second.bb_start_offset;
			pbbinfo->bb_size = bb_iter->second.bb_size;
			pbbinfo->bb_end_instr_length = bb_iter->second.bb_end_instr_length;
			pbbinfo->bb_end_instr_type = bb_iter->second.bb_end_instr_type;
			rc = OK;
		}
	}

	return rc;
}

int 
BBAnalysis::bba_get_first_basicblock(BASIC_BLOCK_INFO *pbbinfo)
{
	int rc = FAILED;
	if (!pbbinfo)
		return rc;
	
	if (!m_block_map.size())
		return rc;

	m_block_iter = m_block_map.end();
	m_block_iter--;

	if (m_block_iter != m_block_map.end()) {
		pbbinfo->bb_start_offset = m_block_iter->second.bb_start_offset;
		pbbinfo->bb_size = m_block_iter->second.bb_size;
		pbbinfo->bb_end_instr_length = m_block_iter->second.bb_end_instr_length;
		pbbinfo->bb_end_instr_type = m_block_iter->second.bb_end_instr_type;
		rc = OK;
	}	

	return rc;
}


int 
BBAnalysis::bba_get_next_basicblock(BASIC_BLOCK_INFO *pbbinfo)
{
	int rc = FAILED;
	if (!pbbinfo)
		return rc;

	m_block_iter--;

	if (m_block_iter != m_block_map.end()) {
		pbbinfo->bb_start_offset = m_block_iter->second.bb_start_offset;
		pbbinfo->bb_size = m_block_iter->second.bb_size;
		pbbinfo->bb_end_instr_length = m_block_iter->second.bb_end_instr_length;
		pbbinfo->bb_end_instr_type = m_block_iter->second.bb_end_instr_type;
		rc = OK;
	}	

	return rc;
}
       

long long 
BBAnalysis::bba_get_image_base()
{
	return m_image_base;
}


int 
BBAnalysis::bba_get_memory_accesses(unsigned int block_offset,
			unsigned int *pNumReads, unsigned int *pNumWrites)
{
	int rc = FAILED;

	BASIC_BLOCK_KEY bbKey;
	bbKey.bb_start = block_offset;

	MEMACCESSMAP::iterator mem_iter;
	
	BLOCKMAP::iterator bbIter = m_block_map.find(bbKey);
	if (bbIter != m_block_map.end()) {
		mem_iter = m_memacc_map.lower_bound(block_offset);
		*pNumReads = 0;
		*pNumWrites = 0;
		
		while ( (mem_iter != m_memacc_map.end()) && 
				(mem_iter->first < bbIter->second.bb_start_offset + 
				 					bbIter->second.bb_size)) {
			switch(mem_iter->second) {
				case MA_READ:
					*pNumReads += 1;
					break;
				case MA_WRITE:
					*pNumWrites += 1;
					break;
				case MA_READWRITE:
					*pNumReads += 1;
					*pNumWrites += 1;
					break;
				default:
					break;
			}
			mem_iter++;
		}

		rc = OK;
	}
	return rc;
}
		
