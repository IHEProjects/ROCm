#include "tbswriter.h"

#define DEFAULT_TBPFILEVERSION 9

CTbsWriter::CTbsWriter() 
{
	m_out_file = NULL;
	m_output_name.clear();
	m_stage = evOut_OK;
}

CTbsWriter::~CTbsWriter() 
{
	close();
}

void CTbsWriter::close() 
{
	if (m_out_file) {
		fclose(m_out_file);
		m_out_file = NULL;
	}
}

bool CTbsWriter::open_file_to_write(string path)
{
	bool ret = true;

	m_out_file = fopen(path.c_str(), "w");
	if (NULL == m_out_file  )
		ret = false;
	else 
		m_output_name = path;

	return ret;
}   


bool CTbsWriter::writeEnvHeader(unsigned int ncpu, unsigned int nmodules,
		unsigned int nevents, UINT64 nsamples,
		EventMaskEncodeMap ev_map, unsigned long cpuFamily,
		unsigned long cpuModel, unsigned int missed)
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_OK)
		return false;

	//order is VERY important
	// write version info
	fprintf(m_out_file, "TBPFILEVERSION=%d\n", DEFAULT_TBPFILEVERSION);

	// Start to write environment section
	fprintf(m_out_file, "[ENV]\n");
	fprintf(m_out_file, "CPU=%u\n", ncpu);
	fprintf(m_out_file, "NumEvents=%u\n",nevents);
	fprintf(m_out_file, "MODULES=%u\n", nmodules);
	fprintf(m_out_file, "SAMPS=%llu\n", nsamples);
							    
	// Not currently used but to keep the format consistant
	// Example : TIMESTAMP=Thu Jun 7 09:51:11 2007 
	time_t rawtime;
	time(&rawtime);
	fprintf(m_out_file,"TIMESTAMP=%s",ctime(&rawtime));
										    
	// Not currently used but to keep the format consistant
	// Example : MISSED=0
	fprintf(m_out_file,"MISSED=%u\n", missed);
											    
	fprintf(m_out_file,"CPUFAMILY=%lu,%lu\n", cpuFamily, cpuModel);

	// Now, write the evnet info
	EventMaskEncodeMap::iterator e_it = ev_map.begin();
	EventMaskEncodeMap::iterator e_it_end = ev_map.end();
	for(; e_it != e_it_end; e_it++) {
		float norm = 0;
		if(strncmp("event:IBS_",(*e_it).first.c_str(),10))
		{
			norm = e_it->second.eventCount;
			if (e_it->second.weight != 0)
				norm = norm / e_it->second.weight;
		} else {
			norm = 1;
		}

		// Format : Event <index>,<event+mask>,<norm>
		// Example: Event 0,118,250000.000000
		// Note: calculate event normalization here - althought it was 
		// 		not used in current post processing
		// 
		fprintf(m_out_file, "Event %u,%llu,%6.6f \n",
				e_it->second.sortedIndex,
				(unsigned long long) e_it->second.eventMask,
				norm);
	}
	// save eventmask in case we need it
	m_ev_map = ev_map;

	// write end of environment section
	fprintf(m_out_file, "[END]");
	fprintf(m_out_file, "\n\n");
	fflush(m_out_file);

	return true;
}


bool CTbsWriter::writeProcSectionProlog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_OK)
		return false;

	fprintf(m_out_file,"[PROCESSDATA]");
	fprintf(m_out_file, "\n");
	fflush(m_out_file);

	m_stage = evOut_TaskSummary;

	return true;
}

bool CTbsWriter::writeProcSectionEpilog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_TaskSummary)
		return false;

	fprintf(m_out_file,"[END]");
	fprintf(m_out_file, "\n\n");
	fflush(m_out_file);

	m_stage = evOut_OK;

	return true;
}

// Description: This function writes a line under [PROCESSDATA] section
//
// Format of the line in [PROCESSDATA] section in version 6:
//		PID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,32-BIT-FLAG,CSS-FLAG,
//		MODULE-NAME
// Note: this is only for TBPFILEVERSION_6 or higher.
bool CTbsWriter::writeProcLineData(
			string taskname, unsigned long long taskid, 
			SampleDataMap &data, bool b32Bit, bool bHasCallStack)
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_TaskSummary)
		return false;

	SampleDataMap::iterator it_sample;
	SampleDataMap::iterator sample_end;
	unsigned int eventSetCnt = 0;
	unsigned long long total = 0;

	// PID : Note Linux uses taskID instead
	fprintf (m_out_file, "%llu", taskid);

	it_sample = data.begin();
	sample_end = data.end();
	for (; it_sample != sample_end; it_sample++) {
		if (it_sample->second) {
			total += it_sample->second;
			eventSetCnt++;
		}
	}
	// TOTALSAMPLE 
	fprintf (m_out_file, ",%llu",total);
	// number of EventSet
	fprintf (m_out_file, ",%u",eventSetCnt);

	// [cpu EVENT-INDEX] #SAMPLE
	it_sample = data.begin();
	sample_end = data.end();
	for (; it_sample != sample_end; it_sample++) {
		SampleKey key = it_sample->first;
	
		if (it_sample->second) {
			// Note: I have convert event into index during the transation
			// 		in opdata_handler. 
			fprintf(m_out_file, ",[%u %llu] %u", key.cpu, key.event,
					it_sample->second);
		}
	}
	// 32-bit-Flag
	fprintf(m_out_file, ",%d", b32Bit? 1 : 0);
	// CSSFlag 
	fprintf(m_out_file, ",%d", bHasCallStack ? 1 : 0);

	// task name
	fprintf(m_out_file, ",%s\n", taskname.c_str());

	return true;	
}

bool CTbsWriter::writeModSummaryProlog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_OK)
		return false;

	fprintf(m_out_file,"[MODDATA]");
	fprintf(m_out_file, "\n");
	fflush(m_out_file);

	m_stage = evOut_ModSummary;

	return true;
	
}
bool CTbsWriter::writeModSummaryLine(string mod, unsigned long long taskid,
		SampleDataMap &data, bool b32Bit)
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_ModSummary)
		return false;

	SampleDataMap::iterator it_sample;
	SampleDataMap::iterator sample_end;
	unsigned int eventSetCnt = 0;
	unsigned long long total = 0;

	// taskid 
	fprintf (m_out_file, "%llu", taskid);

	it_sample = data.begin();
	sample_end = data.end();
	for (; it_sample != sample_end; it_sample++) {
		if (it_sample->second) {
			eventSetCnt++;
			total += it_sample->second;
		}
	}	
	// TOTALSAMPLE
	fprintf (m_out_file, ",%llu", total);
	// #EVENTSET
	fprintf (m_out_file, ",%u",eventSetCnt);

	// [CPU EVENT-INDEX] #SAMPLE
	it_sample = data.begin();
	sample_end = data.end();
	for (; it_sample != sample_end; it_sample++) {
		SampleKey key = it_sample->first;
		if (it_sample->second) {
			fprintf(m_out_file, ",[%u %llu] %u", key.cpu, key.event,
							it_sample->second);
		}
	}
	// 32-bit-Flag
	fprintf(m_out_file, ",%d", b32Bit? 1 : 0);

	// module name
	fprintf(m_out_file, ",%s\n", mod.c_str());	

	return true;
}

bool CTbsWriter::writeModSummaryEpilog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_ModSummary)
		return false;

	fprintf(m_out_file,"[END]");
	fprintf(m_out_file, "\n\n");
	fflush(m_out_file);

	m_stage = evOut_OK;

	return true;
}

bool CTbsWriter::writeModDetailProlog(string modname, unsigned int modtype,
		unsigned long long total, unsigned int itemcount,
		unsigned long long base, unsigned int size)
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_OK)
		return false;

	fprintf(m_out_file,"[%s]\n", modname.c_str());
	fprintf (m_out_file, "BASE=%llx\n", base);
	fprintf (m_out_file, "SIZE=%u\n", size);
	fprintf (m_out_file, "SAMPS=%llu\n", total);
	fprintf (m_out_file, "ModuleType=%d\n", modtype);
	fprintf (m_out_file, "LINECOUNT=%u\n", itemcount );
	fflush(m_out_file);

	fflush(m_out_file);

	m_stage = evOut_ModDetail;

	return true;
}


// This function writes a line under [each module] section.
// The format is:
// PID,TID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,OFFSET,FUNCNAME,
//		FUNCBASEA+DDR,SRCFILE,JNCFILE 
//
// Note: Since verison 8, the JNCFile will only contain file name.
//		It's because the path can ge calculated by ebp file path + /jit/.
//	-Lei 08/06/2008.
// 
bool CTbsWriter::writeModDetailLine(
		unsigned long long taskid, 
		unsigned long long threadid,
		unsigned long long sampAddr, 
		SampleDataMap &data) 
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_ModDetail
	&&  m_stage != evOut_JitDetail)
		return false;

	unsigned int eventSetCnt = 0;
	unsigned long long total = 0;
	SampleDataMap::iterator it = data.begin();
	SampleDataMap::iterator it_end = data.end();
	for (; it != it_end; it++) {
		if (it->second) {
			eventSetCnt++;
			total += it->second;
		}
	}

	// PID,TID: 
	fprintf (m_out_file, "%llu,%llu", taskid, threadid);

	// total
	fprintf (m_out_file, ",%llu", total);

	// event set number
	fprintf(m_out_file, ",%u", eventSetCnt);

	it = data.begin();
	it_end = data.end();
	//[CPU EVENT-INDEX] #Sample
	for (; it!= it_end; it++) {
		SampleKey key = it->first;
		if (it->second) {
			fprintf(m_out_file, ",[%u %llu] %u", 
					key.cpu, key.event, it->second);
		}
	}

	fprintf(m_out_file, ",0x%llx\n", sampAddr);

	return true;
}

bool CTbsWriter::writeModDetailEpilog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_ModDetail)
		return false;

	fprintf(m_out_file,"[END]");
	fprintf(m_out_file, "\n\n");
	fflush(m_out_file);

	m_stage = evOut_OK;

	return true;
}


bool CTbsWriter::writeJitProlog( string jitSym, 
		string jitSrc,
		unsigned long long jitAddr,
		unsigned int jitSize,
		unsigned int itemcount)
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_ModDetail)
		return false;

	fprintf(m_out_file,"\n[JIT_BEGIN]\n"); 
	fprintf(m_out_file,"JITSYM=%s\n"  , jitSym.c_str());
	fprintf(m_out_file,"JITSRC=%s\n"   , jitSrc.c_str());
	fprintf(m_out_file,"JITBASE=%llx\n", jitAddr);
	fprintf(m_out_file,"JITSIZE=%u\n"  , jitSize);
	fprintf(m_out_file,"LINECOUNT=%u\n", itemcount );
	fflush(m_out_file);

	m_stage = evOut_JitDetail;

	return true;
}


bool CTbsWriter::writeJitEpilog()
{
	if (!m_out_file)
		return false;

	if (m_stage != evOut_JitDetail)
		return false;

	fprintf(m_out_file,"[JIT_END]");
	fprintf(m_out_file, "\n");
	fflush(m_out_file);

	m_stage = evOut_ModDetail;

	return true;
}
