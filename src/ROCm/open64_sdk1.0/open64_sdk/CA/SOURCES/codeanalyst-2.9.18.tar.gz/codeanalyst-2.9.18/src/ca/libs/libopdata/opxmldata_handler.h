//$Id: opxmldata_handler.h $
// Interface for processing profile data using Oprofile XML output.

/*
// CodeAnalyst for Open Source
// Copyright 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _OPXMLDATA_HANDLER_H_
#define _OPXMLDATA_HANDLER_H_

#include <vector>
#include <map>
#include <list>
#include "opdata_handler.h"
#include "OpreportXMLHandler.h"

class QStringList;

using namespace std;

class opxmldata_handler : public opdata_handler
{
public:
	opxmldata_handler();
	
	virtual ~opxmldata_handler();

	void init();

	virtual void init(EventMaskEncodeMap evt_map);

	void setEventEncodeMap(EventMaskEncodeMap evt_map);
	
	bool generateXML(const char *xmlPath, 
			QStringList taskFilter,
			QString opDataDir);

	bool readXML(const char *xmlPath);

	bool processXMLData();

	int getEvents(OP_EVENT_PROPERTY_MAP &ebp_events_name_map);

protected:
	void dumpresult();

	void dumpDataMap(SampleDataMap &data);
	
	bool attributeSamples(MODULE_SUMMARY_TYPE & mod_data,
				SYMBOL_LIST * pSymbolList,
				SampleDataMap & taskSampMap);

	bool getSampleKeyEvent(EventMaskType& ev, 
				op_event* opEv, 
				unsigned int mask);
	
	int exec_command (QStringList & args);

	
	OpreportXMLHandler		m_xmlHandler;
	std::vector<op_event>		m_eventVec;
	CLASS_MAP			m_classMap;
	BINARY_LIST			m_binaryList;
	std::vector<op_symboldata>	m_symbolVec;
	std::vector<op_symboldetails>	m_symbolDetailsVec;
	bool 				m_isXMLReady;	
};

#endif //_OPSAMPLEDATA_HANDLER_H_
