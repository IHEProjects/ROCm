//$Id: ViewManageDlg.cpp 14389 2008-04-01 16:58:45Z ssuthiku $

/*
// CodeAnalyst for Open Source
// Copyright 2006-2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qtextedit.h>
#include <qlistbox.h>
#include <qcombobox.h>
#include <qlistview.h>
#include <qradiobutton.h>
#include "ViewManageDlg.h"
#include "atuneoptions.h"

#define K7_PLATFORM_STR		"CPU Family 0x6 (K7)"
#define K8_PLATFORM_STR		"CPU Family 0xF (K8)"
#define FAMILY10H_PLATFORM_STR	"CPU Family 0x10"
#define FAMILY11H_PLATFORM_STR	"CPU Family 0x11"
#define FAMILY12H_PLATFORM_STR	"CPU Family 0x12"
#define FAMILY14H_PLATFORM_STR	"CPU Family 0x14"
#define FAMILY15H_PLATFORM_STR	"CPU Family 0x15"

ShownListBoxItem::ShownListBoxItem ( QListBox* listbox, const QString & text, int index)
: QListBoxText( listbox, text)
{
	m_index = index;
}


ViewManageDlg::ViewManageDlg ( QWidget* parent, 
				DiffSession *pDiffSession,
				const char* name, 
				bool modal,
				WFlags fl) 
: iViewManageDlg (parent, name, modal, fl)
{
	m_modified = false;
	m_pViewCol = NULL;
	m_pModViewSelect->setColumnAlignment(0,Qt::AlignRight);
	m_pModViewSelect->setColumnAlignment(1,Qt::AlignRight);
	m_pModViewSelect->setColumnAlignment(2,Qt::AlignRight);
	m_pModViewSelect->setColumnAlignment(3,Qt::AlignCenter);
	m_pModViewSelect->setAllColumnsShowFocus(true);
	m_pModViewSelect->setSorting(-1);

	m_pDiffSession = pDiffSession;

	if(m_pDiffSession != NULL)
	{

		connect (m_pViewNameCombo, SIGNAL (activated(int)), 
				this,SLOT (onViewNameComboChanged()));
		connect (m_pModViewSelect, SIGNAL (selectionChanged(QListViewItem*)), 
				this,SLOT (onSessionSelectionChanged(QListViewItem*)));

		m_pSessInfoVec = m_pDiffSession->getSessionDiffInfo();
		setSessionDiffInfo();
	}else{
		m_pSessInfoVec = NULL;
	}

	// Connect signals/slots for Manage View Configuration	
	connect (m_pPlatformName, SIGNAL (activated (const QString &)), 
		SLOT (onChangePlatform (const QString &)));
	connect (m_pViewName, SIGNAL (activated (const QString &)), 
		SLOT (onChangeView (const QString &)));
	connect (m_pAddShown, SIGNAL (clicked()), SLOT (onModified()));
	connect (m_pRemoveShown, SIGNAL (clicked()), SLOT (onModified()));
	connect (m_pAddShown, SIGNAL (clicked()), SLOT (onAddShown()));
	connect (m_pRemoveShown, SIGNAL (clicked()), SLOT (onRemoveShown()));

	connect (buttonOk, SIGNAL (clicked()), SLOT (onOk ()));
}


ViewManageDlg::~ViewManageDlg()
{
	if(m_pViewCol != NULL)
	{
		m_pViewCol = NULL;	
	}
}


void ViewManageDlg::setViews (QString current, 
			   unsigned long cpuFamily,
			   unsigned long cpuModel)
{

	m_lastView = current;
	m_cpuFamily = cpuFamily;
	m_cpuModel= cpuModel;
	QString platformName = "";
	QStringList views; 
	m_pPlatformName->clear();
	m_pViewName->clear();

	m_pViewCol = &m_ViewCol;
	// Set current text to the cpuFamily
	m_pViewCol->readAvailableViews(cpuFamily);

	views = m_pViewCol->getListOfViews ();

	// For global view management, we list all the supported 
	// platforms
	m_pPlatformName->setEnabled(true);

	// K7
	m_pPlatformName->insertStringList (QString(K7_PLATFORM_STR));

	// K8
	m_pPlatformName->insertStringList (QString(K8_PLATFORM_STR));

	// FAMILY10H
	m_pPlatformName->insertStringList (QString(FAMILY10H_PLATFORM_STR));
	
	// FAMILY11H
	m_pPlatformName->insertStringList (QString(FAMILY11H_PLATFORM_STR));

	switch(cpuFamily)
	{
		case ATHLON_FAMILY:
			m_pPlatformName->setCurrentText(K7_PLATFORM_STR);
			break;
		case OPTERON_FAMILY:
			m_pPlatformName->setCurrentText(K8_PLATFORM_STR);
			break;
		case GREYHOUND_FAMILY:
			m_pPlatformName->setCurrentText(FAMILY10H_PLATFORM_STR);
			break;
		case GRIFFIN_FAMILY:
			m_pPlatformName->setCurrentText(FAMILY11H_PLATFORM_STR);
			break;
		case FAMILY12H_FAMILY:
			m_pPlatformName->setCurrentText(FAMILY12H_PLATFORM_STR);
			break;
		case FAMILY14H_FAMILY:
			m_pPlatformName->setCurrentText(FAMILY14H_PLATFORM_STR);
			break;
		case FAMILY15H_FAMILY:
			m_pPlatformName->setCurrentText(FAMILY15H_PLATFORM_STR);
			break;
		default:
			break;
	}

	// Check current view
	if (current.isEmpty ())
	{
		current = views[0];
	}

	m_pViewName->insertStringList (views);
	m_pViewName->setCurrentText (current);

	updateUi (current);
}

/*
* NOTE: This function should only be called from
* 	 the Global View Configuration
*/ 
void ViewManageDlg::onChangePlatform(const QString & platformName)
{
	QStringList views; 

	if(platformName == K7_PLATFORM_STR)
	{
		m_cpuFamily = ATHLON_FAMILY;
	}
	else if(platformName == K8_PLATFORM_STR)
	{
		m_cpuFamily = OPTERON_FAMILY;
	}
	else if(platformName == FAMILY10H_PLATFORM_STR)
	{
		m_cpuFamily = GREYHOUND_FAMILY;
	}
	else if(platformName == FAMILY11H_PLATFORM_STR)
	{
		m_cpuFamily = GRIFFIN_FAMILY;
	}
	else if(platformName == FAMILY12H_PLATFORM_STR)
	{
		m_cpuFamily = FAMILY12H_FAMILY;
	}
	else if(platformName == FAMILY14H_PLATFORM_STR)
	{
		m_cpuFamily = FAMILY14H_FAMILY;
	}
	else if(platformName == FAMILY15H_PLATFORM_STR)
	{
		m_cpuFamily = FAMILY15H_FAMILY;
	}

	// Save the current selected view
	QString oldView = m_pViewName->currentText();

	m_ViewCol.removeAllView();
	m_ViewCol.readAvailableViews(m_cpuFamily);
	views = m_ViewCol.getListOfViews ();
	m_pViewName->clear();
	m_pViewName->insertStringList (views);

	// Show the previously selected view if exist
	if (!views.contains(oldView))
	{
		oldView = views[0];	
	}
	m_pViewName->setCurrentText(oldView);
	updateUi (oldView);	

}

void ViewManageDlg::onOk ()
{
	if (m_modified)
	{
		updateView (m_pViewName->currentText());
	}
	accept();
}

void ViewManageDlg::onChangeView (const QString & viewName)
{
	if (m_modified)
	{
		updateView (m_lastView);
	}
	m_modified = false;
	m_lastView = viewName;
	updateUi (viewName);
}


void ViewManageDlg::updateUi (QString viewName)
{
	QString description;
	m_pViewCol->getViewTexts (viewName, NULL, &description);
	m_pDescription->setText (description);

	ViewShownData viewData;

	//The 0 is to get the raw data columns
	m_pViewCol->getViewConfig (viewName, &viewData, 0, m_cpuFamily, m_cpuModel);
	m_pAvailable->clear();
	m_pShown->clear();
	//This algorithm is potentially nlogn, but since it handles such small 
	//	sizes of n, it doesn't matter
	for (UINT i = 0; i < viewData.tips.size(); i++)
	{
		IndexVector::iterator it;
		bool found = false;
		for (it = viewData.shown.begin(); it != viewData.shown.end(); ++it)
		{
			//if the index is shown
			if ((*it) == i)
			{
				new ShownListBoxItem (m_pShown, viewData.tips[i], i);
				found = true;
				break;
			}
		}
		if (!found)
		{
			new ShownListBoxItem (m_pAvailable, viewData.tips[i], i);
		}
	}

}  //ViewManageDlg::updateUi


void ViewManageDlg::updateView (QString viewName)
{
	if (0 == m_pShown->count())
	{
		QMessageBox::critical (this, "CodeAnalyst Error",
			"At least one piece of data should be shown.");
		return;
	}
	ViewShownData viewData;

	//The 0 is to get the raw data columns
	m_pViewCol->getViewConfig (viewName, &viewData, 0, m_cpuFamily, m_cpuModel);

	viewData.shown.clear();
	for (UINT i = 0; i < m_pShown->count(); i++)
	{
		ShownListBoxItem *pItem = (ShownListBoxItem *)m_pShown->item (i);
		viewData.shown.push_back (pItem->m_index);
	}
	m_pShown->clear();

	m_pViewCol->setViewConfig (viewName, &viewData, true);
} //ViewManageDlg::updateView

void ViewManageDlg::onAddShown ()
{
	int item = m_pAvailable->currentItem();
	if (-1 == item)
		return;

	ShownListBoxItem *pItem = (ShownListBoxItem *)m_pAvailable->item (item);

	new ShownListBoxItem (m_pShown, m_pAvailable->currentText(), pItem->m_index);
	m_pAvailable->removeItem (item);  //or delete pItem
}


void ViewManageDlg::onRemoveShown ()
{
	int item = m_pShown->currentItem();
	if (-1 == item)
		return;

	ShownListBoxItem *pItem = (ShownListBoxItem *)m_pShown->item (item);

	new ShownListBoxItem (m_pAvailable, m_pShown->currentText(), pItem->m_index);
	m_pShown->removeItem (item);  //or delete pItem
}


void ViewManageDlg::onModified ()
{
	m_modified = true;
}

void ViewManageDlg::onSessionSelectionChanged(QListViewItem *cur)
{
	m_pViewNameCombo->clear();

	int indexDefault = 0;

	///////////////////////////////////////////////////
	// Find current session index
	m_curSessionIndex = 0;
	QListViewItem* tmp = m_pModViewSelect->firstChild();
	QListViewItem* end = m_pModViewSelect->lastItem();
	while(tmp != cur)
	{
		if(tmp == end)
		{
			if(cur != end)
			{
				m_curSessionIndex = -1;
				return;
			}
			break;
		}
		tmp = tmp->nextSibling();	
		m_curSessionIndex++;
	}

	// Get view name list for current session
	QStringList viewList = (*m_pSessInfoVec)[m_curSessionIndex].pViewCollection->getListOfViews (
						(*m_pSessInfoVec)[m_curSessionIndex].pEvArray,
						(*m_pSessInfoVec)[m_curSessionIndex].evCount, 
						&indexDefault);
	// Insert String List
	int index = 0;
	int curViewIndex = 0;
	QStringList::iterator vit     = viewList.begin();
	QStringList::iterator vit_end = viewList.end();
	for(; vit != vit_end ; index++, vit++)
	{
		if(cur->text(3).compare(*vit) == 0)
		{
			curViewIndex = index;
		}
		m_pViewNameCombo->insertItem (*vit);
	}

	m_pViewNameCombo->setCurrentItem(curViewIndex);
	
}

void ViewManageDlg::onViewNameComboChanged()
{
	if(m_curSessionIndex == -1)
		return;

	QString curViewName = m_pViewNameCombo->currentText();
	m_pModViewSelect->currentItem()->setText(3,curViewName);
}

void ViewManageDlg::setSessionDiffInfo()
{
	SESSION_DIFF_INFO_VEC::iterator it = m_pSessInfoVec->begin();
	SESSION_DIFF_INFO_VEC::iterator end = m_pSessInfoVec->end();
	for(; it != end ; it++)
	{
		QListViewItem *pSess = new QListViewItem(m_pModViewSelect,
						m_pModViewSelect->lastItem());
		pSess->setText(0,(*it).sessionFile);
		pSess->setText(1,(*it).task);
		pSess->setText(2,(*it).module);
		pSess->setText(3,(*it).currentViewName);
		m_pModViewSelect->insertItem(pSess);
	}

	// Set first one as default
	m_pModViewSelect->setSelected(m_pModViewSelect->firstChild(),true);

}

bool ViewManageDlg::updateCurrentViewNames()
{
	bool ret = false;
	
	if(m_pSessInfoVec == NULL)
		return ret;

	QListViewItem* cur = m_pModViewSelect->firstChild();
	if(cur == NULL) return ret;

	int count = 0;
	for(; count < m_pModViewSelect->childCount() ; count++ )
	{
		(*m_pSessInfoVec)[count].currentViewName = cur->text(3);
		if((cur = cur->nextSibling()) == NULL)
			break;
	}

	ret = true;
	return ret;	
}

void ViewManageDlg::accept()
{
	updateCurrentViewNames();

	iViewManageDlg::accept();
}
