/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <stdio.h>
#include <unistd.h>
#include <sstream>
#include <fstream>
#include <sys/stat.h>
#include <sys/types.h>
#include "libCAagent.h"

#ifdef __x86_64__
#include <asm/msr.h>
#endif

#include "jpa.h"

// global jvmpi interface pointer
static JVMPI_Interface *jvmpi_interface;
static int i;
static FILE * jcl;
static MethodMap methodMap;
static string jvmCmd = "";
static pid_t jvmPID;
static JVMPI_RawMonitor oprofile_lock;

using namespace std;

/******************************/
void getCPUTimeStamp(__u64 & timeStamp)
{
#ifdef __x86_64__
	__u64 timeStampLow;
	__u64 timeStampHigh;

	rdtsc(timeStampLow, timeStampHigh);

	timeStamp = (timeStampHigh << 32) | timeStampLow;
#else
	__u32 timeStampLow;
	__u32 timeStampHigh;

    __asm__ __volatile__ (
    	"cpuid;" 
        "rdtsc;"    
	    : "=a" (timeStampLow),
          "=d" (timeStampHigh)
	    : "a" (0)
	    : "%ebx", "%ecx"
    );
    timeStamp = timeStampHigh;
    timeStamp = (timeStamp<<32) + timeStampLow;
#endif

}



/******************************/
void onJVM_SHUT_DOWN()
{
#ifdef _DEBUG_
    fprintf(stderr, "shutting down jvm");
    cout << "jvmCmd: " << jvmCmd << endl;
    printf("jvmCmd: %s\n", jvmCmd.c_str());
    printJitMethods();
#endif
}


/******************************/
void onCOMPILED_METHOD_LOAD(JVMPI_Event *event) 
{
	void  * code_addr = event->u.compiled_method_load.code_addr;
	jint code_size = event->u.compiled_method_load.code_size;
	//char * method_name = ap_CatenateStrings(event->u.class_load.methods[i].method_name, 
	//	event->u.class_load.class_name);
	struct ca_jit_shm_entry new_entry;
	char method_name[256];

	new_entry.start_address = (unsigned long)code_addr;
	new_entry.size = (unsigned)code_size;

	MethodMap::iterator it = 
        methodMap.find(event->u.compiled_method_load.method_id);

	if (methodMap.end() != it) {
		MethodMapElement & element = (*it).second;
		snprintf(method_name, sizeof(method_name),
			"%s:%s", element.className.c_str(),
			element.functionName.c_str());

		ca_write_native_code(method_name, code_addr, code_size);
		ca_add_mapping(&new_entry);
	}

}


void printJitMethods()
{
#ifdef _DEBUG_
    MethodMap::iterator it = methodMap.begin();

    fprintf(stdout, "/************* JITTED Functions ******************/\n");
    for (; it != methodMap.end(); it++) {
        MethodMapElement & element = (*it).second;

        if (element.jit) {
            fprintf(stdout, "Function %s:%s\n", 
                element.className.c_str(),
                element.functionName.c_str());
        }
    }
#endif
}


//This saves the class information, including all function names of the class
void onCLASS_LOAD(JVMPI_Event *event) 
{
#ifdef _DEBUG_
    fprintf(stdout, "jpa> Class Load : %s\n", event->u.class_load.class_name);
    fprintf(stdout, "class has %d function\n", event->u.class_load.num_methods);
#endif
        
    for (int i=0; i < event->u.class_load.num_methods; i++) {
        MethodMapElement element;

#ifdef _DEBUG_
        fprintf(stdout, "function name %s\n",  event->u.class_load.methods[i].method_name);
        fprintf(stdout, "method id %d\n", event->u.class_load.methods[i].method_id);
#endif
        element.className = event-> u.class_load.class_name;

        if (event->u.class_load.source_name)
			element.javaSrcFileName = event->u.class_load.source_name;
		else
			element.javaSrcFileName = UNKNOWNSOURCEFILE;
        
        element.functionName = event->u.class_load.methods[i].method_name;
        element.jit = false;

        methodMap[event->u.class_load.methods[i].method_id] = element;
    }
    
}


/******************************/
/* function for handling event notification
 *
 */
void notifyEvent(JVMPI_Event *event) {
    switch(event->event_type) {
    case JVMPI_EVENT_CLASS_LOAD: 
        //fprintf(stderr, "jpa> Class Load : %s\n", event->u.class_load.class_name);
        onCLASS_LOAD(event);
        break;
    case JVMPI_EVENT_OBJECT_MOVE:
//          fprintf (stderr, "> Obj Move: old id %ld new id %ld\n", event->u.obj_move.obj_id, event->u.obj_move.new_obj_id);
            break;
    case JVMPI_EVENT_COMPILED_METHOD_LOAD: 
        onCOMPILED_METHOD_LOAD(event);
            break;
    case JVMPI_EVENT_COMPILED_METHOD_UNLOAD:
        //fprintf(stderr, "> compiled method unload : %d\n", event->u.compiled_method_unload.method_id);
        break;
    case JVMPI_EVENT_JVM_SHUT_DOWN:
        onJVM_SHUT_DOWN();
        break;
    }
        return;

}

void getCmdline()
{
    pid_t pid = jvmPID; 
    stringstream tstream;
    tstream << "/proc/" << pid << "/cmdline";
    string pidDir = tstream.rdbuf()->str(); 
    int end;

    filebuf fb;
    fb.open(pidDir.c_str(), ios::in);
    istream is(&fb);
    while (!is.eof()) {
        is >> jvmCmd;
#ifdef _DEBUG_
        cout << "getCmdline " << jvmCmd << endl;
#endif
    }

    end = jvmCmd.find ("CAJVMPIA\0");
    if (end > -1 ) {
		end += 9; //get it past the "CAJVMPIA "
		jvmCmd.erase (0, end);
    }

	for (int i=0; i < jvmCmd.length(); i++)
		if (0 == jvmCmd[i])
			jvmCmd[i] = ' ';

    char cmdFileName[FILENAME_MAX];
	
    sprintf (cmdFileName, "/var/lib/oprofile/Java/%d", pid);
    FILE * cmdFile = fopen (cmdFileName, "w");
    if (NULL != cmdFile) 
    {
	fprintf (cmdFile, "%s", jvmCmd.c_str());
	fclose (cmdFile);
    }

}

/******************************/
// profiler agent entry point
extern "C" { 
    JNIEXPORT jint JNICALL JVM_OnLoad(JavaVM *jvm, char *options, void *reserved) 
    {
        jint temp;

        jvmPID = getpid();

        char pidDirName[FILENAME_MAX];
        bzero (pidDirName, sizeof(pidDirName));
        getCmdline();
        
        // get jvmpi interface pointer
        if ((jvm->GetEnv((void **)&jvmpi_interface, JVMPI_VERSION_1)) < 0) {
            fprintf(stderr, "jpa> error in obtaining jvmpi interface pointer\n");
            return JNI_ERR;
        } 
    
        // initialize jvmpi interface
        jvmpi_interface->NotifyEvent = notifyEvent;

        // enabling class load event notification
        temp = jvmpi_interface->EnableEvent(JVMPI_EVENT_JVM_SHUT_DOWN, NULL);
    
        // enabling class load event notification
        temp = jvmpi_interface->EnableEvent(JVMPI_EVENT_CLASS_LOAD, NULL);

        //temp = jvmpi_interface->EnableEvent(JVMPI_EVENT_OBJECT_MOVE, NULL);
        //        fprintf (stderr, "Enable event (JVMPI_EVENT_OBJECT_MOVE) returned %d\n",temp);
        temp = jvmpi_interface->EnableEvent(JVMPI_EVENT_COMPILED_METHOD_LOAD, NULL);
        
        temp = jvmpi_interface->EnableEvent(JVMPI_EVENT_COMPILED_METHOD_UNLOAD, NULL);

		ca_open_agent(getpid());
		oprofile_lock =
			jvmpi_interface->RawMonitorCreate("oprofile lock");


        return JNI_OK;
  }
}
