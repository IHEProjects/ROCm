/**
 * @file smm.h
 * Class header to manage shared memory
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#ifndef SMM_H_
#define SMM_H_

#include <bfd.h>
#include "libCAagent.h"

#define CA_SM_VERSION	1

class smm
{
public:
	smm();
	void * open_shared_memory(pid_t tgid, unsigned int page_id, 
					unsigned int size);

	/// size is the number of bytes of the shared memory
	void * create_shared_memory(pid_t tgid, unsigned int page_id,
					unsigned int size);
	
	void remove_shared_memory(pid_t tgid, unsigned int pageid, 
					unsigned int size);
private:
};

#endif /*SMM_H_*/
