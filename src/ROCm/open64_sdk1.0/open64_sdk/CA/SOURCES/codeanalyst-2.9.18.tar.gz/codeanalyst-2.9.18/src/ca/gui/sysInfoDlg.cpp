//$Id: sysInfoDlg.cpp,v 1.3 2006/05/15 22:09:22 jyeh Exp $
//The implementation of the system information dialog.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include "stdafx.h"
#include "sysInfoDlg.h"
#include "helperAPI.h"

#include <qstring.h>
#include <qclipboard.h> 
#include <qtextview.h>


SysInfoDlg::SysInfoDlg( QWidget* parent, const char* name, bool modal, 
					   WFlags fl) : ISysInfoDlg( parent, name, modal, fl )

{
	QObject::connect ( m_copy, SIGNAL (clicked()), 
		SLOT (onCopytoClipboard()) ); 
}


SysInfoDlg::~SysInfoDlg()
{
	// no need to delete child widgets, Qt does it all for us
}


void SysInfoDlg::onOk()
{
	accept();
}


//  Copies the text to the clipboard
//
void SysInfoDlg::onCopytoClipboard()
{
	QClipboard *cb = QApplication::clipboard();
	cb->setText (m_info->text());
}


bool SysInfoDlg::initialize()
{
	QString desc;

	// Determine if we have a local apic for sampling
	desc.append("Local Apic .... ");
	if(hasLocalApic()) {
		desc.append("[OK].\n");
	} else {
		desc.append("[NO].\n");
	}
	m_info->setText (desc);

	// /proc/version
	m_info->append ("\n==================================\n");
	m_info->append ("/proc/version:\n");
	QFile * file = new QFile ("/proc/version");
	if (NULL == file) {
		QMessageBox::critical (this, "Memory Error", 
			"Insufficient memory.");
		return FALSE;
	}
	QTextStream stream (file);

	if (file->open (IO_ReadOnly)) {
		while (!stream.atEnd())
			m_info->append (stream.readLine());
	}
	file->close();
	
	// /proc/cpuinfo
	m_info->append ("\n==================================\n");
	m_info->append ("/proc/cpuinfo:\n");
	file->setName ("/proc/cpuinfo");
	stream.setDevice (file);

	if (file->open (IO_ReadOnly)) {
		while (!stream.atEnd())
			m_info->append (stream.readLine().replace("	"," "));
	}

	file->close();
	delete file;
	return TRUE;
}
