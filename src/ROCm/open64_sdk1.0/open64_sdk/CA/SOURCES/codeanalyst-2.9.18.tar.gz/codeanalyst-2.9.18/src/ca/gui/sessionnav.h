//$Id: sessionnav.h,v 1.4 2005/02/14 16:52:40 jyeh Exp $
// interface for CSessionNavigator class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef SESSNAV_H
#define SESSNAV_H

#include "stdafx.h"
#include <qvaluevector.h>
#include <qstringlist.h>
#include "ViewCollection.h"
#include "cawfile.h"
#include "tbsreader.h"
#include "DataListItem.h"



///////////////////////////////////////////////////////////////////////////////
typedef enum
{
	DV_NONE,
	DV_SYSTEM,
	DV_MODULE,
	DV_DASM,
	DV_SOURCE
} DATA_VIEW_TYPE;

static const char SYS_DATA_STRING[] = "System Data";
static const char SYS_GRAPH_STRING[] = "System Graph";
static const char SYS_TASK_STRING[] = "System Tasks";

static const char SYS_DATA_WIDGET[] = "SysData";
static const char MOD_DATA_WIDGET[] = "ModData";
static const char DASM_WIDGET[] = "DASM";
static const char SRC_VIEW_WIDGET[] = "SRCVIEW";


class HeaderTip : public QToolTip
{
public:
	HeaderTip ( QListView *pParent, ViewShownData *pViewShown, 
		int indexOffset );
	virtual ~HeaderTip () {};

protected:
	virtual void maybeTip (const QPoint &pt);

private:
	QListView *m_pList;
	int m_indexOffset;
	ViewShownData *m_pViewShown;
};

//This tooltip is modified for a specific list view column
class TabListTip : public QToolTip
{
public:
	TabListTip ( int tipColumn, QListView * pParent);
	virtual ~TabListTip() {};

protected:
	virtual void maybeTip (const QPoint &pt);

private:
	QListView * m_pList;
	int m_tipColumn;
};


//all different tabs showing data about a session should be DataTabs.
//They account for the different data shown in a view, a changed viewed, and
//	exporting the data via the main window to a csv file
class DataTab : public QMainWindow
{
	Q_OBJECT;

protected:
	QString m_exportString;
	QListView *m_pList;
	bool m_userCanClose;
	int m_indexOffset; 				// this shows how many columns are 
	// reserved for the tab-specific data
	ViewShownData *m_pViewShown; 	// All session tabs should share one 
	// ViewShownData

	QPopupMenu * m_pColumnMenu;
	HeaderTip *m_pHeaderTip;
	int *m_pColumnIndex;
	QString	m_selectText;
	int m_precision;
	SampleDataMap m_TotalSampleDataMap;

protected:
	bool clearShownColumns ();
	bool addShownColumns ();
	bool initMenu ();
	void keyPressEvent(QKeyEvent *e);

protected slots:
	virtual void OnColumnToggled (int id);
	virtual void onCopySelection();

public:
	DataTab( ViewShownData *pViewShown, QWidget* parent, const char* name, int wflags );
	virtual ~DataTab ();
	virtual QString GetExportString (){return m_exportString;};
	virtual QListView * GetExportList () {return m_pList;};
	//Some tabs should not be closable by the user
	virtual bool CanUserClose () {return m_userCanClose;};

signals:
	void shownDataChange (ViewShownData *p);
	//for relaying to internal toolbars
	void showToolText (bool bShow);

public slots:
//	virtual void onShownChanged ();
	virtual void onViewChanged (ViewShownData* viewShown){Q_UNUSED(viewShown);};
}; //class DataTab 

//Pre-declarations
class SystemDataTab;
class SysGraphView;

//////////////////////////////////////////////////////////////////////////
class CSessionNavigator : public QMainWindow
{
	Q_OBJECT;
	// functions
public:
	CSessionNavigator ( QString sampling_file_path, QWidget * parent, 
		const char * name, int wflags );
	~CSessionNavigator();

	virtual bool display ( QString caption, CawFile *pProject, 
		QString eventProfile );
	QWidget * getCurrentView();

private:
	void calculateEventNorms (QString eventSessionName);
	bool calculateEventNormsEBP (QString eventSessionName);

	bool launchSourceView ( VADDR address, 
		SampleMap *samp_map,
		ProfileAttribute prof_att);

	bool launchDasmTab( VADDR address, SampleMap *samp_map, 
		ProfileAttribute prof_att, QString more_caption = "");

	void addTabToNavigatorBar ( QWidget * widget, QString tab_caption );
	QWidget *findTab (QString caption, QString filePath = QString::null);

public slots:
	void onModuleDblClicked ( QString module_name, TAB_TYPE type,
		unsigned int taskId = SHOW_ALL_TASKS);
	void onSymDblClicked ( VADDR address, 
		SampleMap *samp_map, ProfileAttribute prof_att );
	void onViewSystemGraph();
	void onViewSystemData();
	void onViewSystemTask();
	void onCurrentTabChanged ( QWidget * widget );
	void onDisassembledDone();
	void onDensityVisibilty ();
	void OnTabMessageForStatus (const QString & message, int mS);
	void OnCloseTab ();
	void onGlobalShownChanged (QString viewName);
	void onViewChanged (const QString & view);
	void onViewMaybeTip (const QString &view);
	void onConfigureView ();
	void onViewOneTask (unsigned int taskId, QString name);
	void onViewTasks ();
	void onShownColumnToggled(ViewShownData* viewShown);


signals:
	void DataViewChanged( QString exportStr, QListView *pList );
	void densityVisibilityChanged ();
	void newHotspot ( VADDR addr, QString caption, SampleMap* );
	void shownDataChange (ViewShownData* viewShown);
	void viewChanged ();

	// data
protected:
	QTabWidget *m_pTabWidget;
	QToolBar * m_pViewBar;
	QComboBox *m_pViewBox;
	QPushButton *m_pViewCfg;
	//The button to close old tabs
	QToolButton	*m_pCloseTab;
	SystemDataTab *m_sys_dat_view;
	SysGraphView *	m_sys_graph_view;
	DataTab *m_pTaskTab;
	QString	m_tbp_file_path;
	TbsReader*	m_tbp_file;
	ViewShownData  m_viewShown;
	EventNormValueMap m_normMap;
	//A pointer to the project file that contains the session
	CawFile * m_pProject;
	//All the available views for the given data of the session
	ViewCollection m_views;
	EventConfig *m_evArray;
	unsigned int m_evCount;
};

#endif
