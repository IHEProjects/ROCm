#!/bin/bash
# CodeAnalyst uninstallation script 
PREFIX=$1
AMDCA_GRP=amdca
GREP=/bin/grep
GROUPDEL="/usr/sbin/groupdel"
#ETC="/etc"
#INITD="$ETC/init.d"
#RCD="$ETC/rc.d"
#RC3D="$RCD/rc3.d"
#RC5D="$RCD/rc5.d"
#CODEANALYST_INIT="$INITD/codeanalyst"
#CODEANALYST_LN="S99codeanalyst"
family10=$PREFIX/share/oprofile/x86-64/family10
family10h=$PREFIX/share/oprofile/x86-64/family10h

do_deinit()
{
	# unmount /dev/oprofile if it is mounted
	OPROF_FS_MOUNTED=`grep /dev/oprofile /etc/mtab`
	OPROF_FS=`grep /dev/oprofile /etc/mtab|cut --delimiter=" " --fields=2`
	if test -n "$OPROF_FS_MOUNTED"; then
		umount $OPROF_FS
	fi
	# unload the oprofile module if it is around
	OPROF_MOD=`/sbin/lsmod | grep oprofile`
	if test -n "$OPROF_MOD"; then
		echo "Unloading oprofile module" >& 2
		rmmod oprofile
	fi
}

print_action()
{
	echo -n "* .... $1 ... "
}

print_result()
{
	echo "$1"
}

print_ok_no()
{
	if [ "$1" -eq "0" ] ; then
		echo "OK"
	else	
		echo "NO"
		exit 1
	fi
}

print_error()
{
	echo "$1"
	exit 1;
}

#
# NOTE!!! This should be the reverse order of Setup.sh
#
echo "****************************************"
echo "*  CodeAnalyst Post-Uninstall Clean up *"
echo "****************************************"

#
# Stop codeanalyst service
#
#$CODEANALYST_INIT stop

#
# Remove service at runlevel 3 and 5
#
#if test -e $RCD; then
#	print_action "Remove codeanalyst service in $RC3D"
#	rm -f  $RC3D/$CODEANALYST_LN
#	RETVAL=$?; print_ok_no $RETVAL 
#
#	print_action "Remove codeanalyst service in $RC5D"
#	rm -f  $RC5D/$CODEANALYST_LN
#	RETVAL=$?; print_ok_no $RETVAL 
#fi

#
# Remove codeanalyst service
#
#print_action "Remove $CODEANALYST_INIT script"
#rm -f $CODEANALYST_INIT
#RETVAL=$?; print_ok_no $RETVAL 


#
# Remove ld.so.conf.d/codeanalyst
#
ARCH=`uname -m`
print_action "Remove /etc/ld.so.conf.d/codeanalyst-$ARCH.conf"
if test -f /etc/ld.so.conf.d/codeanalyst-$ARCH.conf ; then
	rm -f /etc/ld.so.conf.d/codeanalyst-$ARCH.conf
	RETVAL=$?; print_ok_no $RETVAL 
else
	print_result "does not exist"
fi


#
# Running ldconfig
#
print_action "Running ldconfig"
/sbin/ldconfig
RETVAL=$?; print_ok_no $RETVAL 


#
# Remove softlink for family10
#
if test ! -L $family10  ; then
	print_action "Remove softlink for $family10 "
	rm -f $family10
	RETVAL=$?; print_ok_no $RETVAL 
fi


#
# Remove amdca 
#
print_action "Remove amdca group"
getent group amdca >/dev/null
if [ "$?" -eq "0" ] ; then 
	$GROUPDEL $AMDCA_GRP
	RETVAL=$?; print_ok_no $RETVAL 
else
	print_result "not exist"
fi

echo "* Post-Uninstall Clean up Finished."
exit 0
