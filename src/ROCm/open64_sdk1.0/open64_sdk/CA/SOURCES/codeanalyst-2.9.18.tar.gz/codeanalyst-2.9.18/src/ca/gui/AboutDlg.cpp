//$Id: AboutDlg.cpp,v 1.4 2006/05/15 22:09:22 jyeh Exp $
//The implementation of the about dialog.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

//Revision history
//$Log: AboutDlg.cpp,v $
//Revision 1.4  2006/05/15 22:09:22  jyeh
//Merge with brach Flat_file
//
//Revision 1.3.2.1  2005/08/30 14:28:02  jyeh
//Updated for Next QA drop.
//
//Revision 1.3  2005/02/14 16:52:29  jyeh
//Updated Header.
//
//Revision 1.2  2005/01/26 21:21:09  jyeh
//Remore Corrupted file.
//
//Revision 1.1.1.1  2004/10/05 17:03:23  jyeh
//initial import into CVS
//
//Revision 1.7  2003/12/09 16:54:50  franksw
//Update to coding standards
//
//Revision 1.6  2003/12/01 21:04:39  franksw
//Cleaned up and styled
//
//Revision 1.5  2003/11/12 22:52:55  franksw
//Code cleanup
//
//Revision 1.4  2003/11/07 00:24:38  franksw
//uses configured paths
//
//Revision 1.3  2003/11/06 16:25:11  franksw
//Uses project version
//
//Revision 1.2  2003/11/03 16:14:34  franksw
//About box works
//

#include <qstring.h>
#include <qtextview.h>
#include <stdlib.h>

#include "AboutDlg.h"


AboutDlg::AboutDlg( QWidget* parent, const char* name, bool modal,
				   WFlags fl) : IAboutDlg( parent, name, modal, fl )

{
	pSplashMap->setPixmap (QPixmap (CA_DATA_DIR "/CASplash.png"));
	txtVersion->setText ("Version " VERSION);

	ldd_process = new QProcess (QString ("ldd"), this);
	if (NULL != ldd_process)
	{
		connect (ldd_process, SIGNAL (readyReadStdout()),
			this, SLOT (readStdout()));

		connect (ldd_process, SIGNAL (processExited()),
			this, SLOT (displayBuffer()));

		ldd_process->addArgument (CA_BIN_DIR "/CodeAnalyst");
		ldd_process->start ();
	} else {
		QMessageBox::critical (this, "Memory error", "Could not allocate"
			" memory");
		m_view_dlls->setText ( "library information unavailable"  );
	}

	buttonOk->setFocus();

}


AboutDlg::~AboutDlg()
{
	// If the qprocess that launched ldd is still in memory, remove it
	if (NULL != ldd_process) {
		delete ldd_process;
		ldd_process = NULL;
	}
	return;
}


//This is signaled when the ldd process exited, so no more input will be
// coming
void AboutDlg::displayBuffer()
{
	for (QStringList::Iterator it = buffer.begin(); it != buffer.end();
		it++) {
			m_view_dlls->append ( *it );
	}
}


//This is signaled when there is input from the ldd process to be read into
// the buffer
void AboutDlg::readStdout()
{
	QString tmp;

	while (QString::null != (tmp = ldd_process->readLineStdout())) {
		buffer += tmp.section ('(',0,0).stripWhiteSpace();
	}
}
