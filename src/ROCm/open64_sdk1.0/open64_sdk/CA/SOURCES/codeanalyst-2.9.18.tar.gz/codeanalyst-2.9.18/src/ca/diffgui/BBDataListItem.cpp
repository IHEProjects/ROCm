
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <qcolor.h>
#include "BBDataListItem.h"

BBDataListItem::BBDataListItem ( ViewShownData *pViewShown, 
				int indexOffset,
				QListView * pParent)
: DataListItem (pViewShown, indexOffset, pParent)
{
}


void BBDataListItem::onChangeView (DataArray data)
{
	m_dataList.clear();
	for (UINT i = 0; i < data.size(); i++) {
		appendData (data[i], *m_pPrecision);
	}
	updateShown ();
}



void BBDataListItem::drawData(DASM_VIEW_INFO *pBBVI,
			bool isPercent)
{

	setText(DASM_ADDR_COL,QString("0x")+QString::number(pBBVI->addr,16));
	setText(DASM_BB_COL,pBBVI->name);
	if(pBBVI->loadCnt != 0)
		setText(DASM_LOAD_COL,QString::number(pBBVI->loadCnt));
	if(pBBVI->storeCnt != 0)
		setText(DASM_STORE_COL,QString::number(pBBVI->storeCnt));
	if(!pBBVI->inlineName.isEmpty())

	{
		setItemColor(QColor(Qt::red));
		setText(DASM_INLINE_COL,pBBVI->inlineName);
	}

	setPrecision(DEFAULT_FLOAT_PRECISION);
	if(isPercent)
	{
		DataListItem::drawPercent(pBBVI->pSamplePercentMap);
	}else{
		DataListItem::drawData(&(pBBVI->aggSampleDataMap),0);
	}
}

/*
QString BBDataListItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	static int updateCounter = 0;
	QString retString;

	// Every 100 sorts, tell the app to handle gui stuff, 
	// for a max of 1 milisecond
	if (0 == (updateCounter++ % 100)) {
		qApp->processEvents (1);
	}
	if ((column < ASM_CODE_BYTES_COLUMN) || (column >  ASM_SYMBOL_COLUMN)) {
		retString.fill ('0', (20 - text (column).length()));
		retString += text (column);
	}
	else {
		retString = text (column);
	}
	return retString;
}
*/

int BBDataListItem::compare( QListViewItem *i, int col, bool ascending) const
{
	Q_UNUSED (ascending);
	bool isOkL, isOkR;
	int ret = 0;

	if (i == NULL)	
		return ret;

	QString txtL = text(col);
	QString txtR = i->text(col);

	//--------------------------------------
	// Try converting to Int
	int left = 0;
	int right = 0;

	// Get Text Left
	if(!txtL.isEmpty())
		left = txtL.toInt(&isOkL,0);
	else{
		left = 0;
		isOkL = true;
	}

	// Get Text Right
	if(!txtR.isEmpty())
		right = txtR.toInt(&isOkR,0);
	else{
		right = 0;
		isOkR = true;
	}

	// Check if can convert to int
	if(isOkL && isOkR)	
	{
		ret = left - right; 
		//ret = right - left; // This is the reverse
		return ret ;
	}

	//--------------------------------------
	// Try converting to Float 
	// Get Text Left
	float leftF = 0;
	float rightF = 0;

	if(!txtL.isEmpty())
		leftF = txtL.toFloat(&isOkL);
	else{
		leftF = 0;
		isOkL = true;	
	}

	// Get Text Right
	if(!txtR.isEmpty())
		rightF = txtR.toFloat(&isOkR);
	else{
		rightF = 0;
		isOkR = true;	
	}

	// Check if can convert to float
	if(isOkL && isOkR)	
	{
		// NOTE: HACK. This is the reverse
		if(leftF < rightF)
			ret = -1;	
		else if(leftF == rightF)
			ret = 0;	
		if(leftF > rightF)
			ret = 1;	
		return ret ;
	}

	//--------------------------------------

	// Do Txt comparison
	ret = txtL.compare(txtR);	
	return ret;
}

