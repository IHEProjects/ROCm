//$Id: application.cpp,v 1.34 2006/05/15 22:09:22 jyeh Exp $
// The main gui that the user will be interacting with

/**
*   (c) 2003-2009 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/

#include "stdafx.h"
#include <stdlib.h>
#include <qradiobutton.h>
#include <qtextedit.h>
#include <qimage.h>
#include <qfile.h>
#include <qvaluelist.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <qstringlist.h>

#include "atuneoptionsdlg.h"
#include "application.h"
#include "auxil.h"
#include "helperAPI.h"
#include "ebpdef.h"
#include "sysInfoDlg.h"
#include "AboutDlg.h"
#include "oprofile_interface.h"
#include "translatedlg.h"
#include "ImportWizard.h"
#include "SessionSettingDlg.h"
#include "TimerCfg.h"
#include "EventCfgDlg.h"
#include "ManageCfgs.h"
#include "ViewCfg.h"
#include "ViewCollection.h"
#include "EventMaskEncoding.h"
#include "NewDiffSessionDlg.h"
#include "catranslate_gui_display.h"

#include "config.h"
#include "helperAPI.h"

#define _CODEANALYST_ICONS_
#include "xpm.h"
#undef  _CODEANALYST_ICONS_


#define DEFAULT_CAPTION "Advanced Micro Devices - CodeAnalyst Analyzer"
#define MAX_MRU_ITEMS   5
#define EMPTY_MRU_LIST  "E;E;E;E;E;"
#define CA_EXT "CodeAnalyst Workspace (*.caw)"

#define NO_SAMPLE_MSG "Oprofile collected no samples.\n" \
		"Suggestion:\n" \
		"- Check the profiling duration\n" \
		"- Check number of counts for events\n" \
		"- Check \"Start delay period\" and \"Start with the profiling paused\" options.\n" 


ApplicationWindow::ApplicationWindow ()
:  QMainWindow (0, "example application main window", WType_TopLevel
				| WStyle_SysMenu | WDestructiveClose)
{

	// Check CPU family for the current running platform
	m_this_cpuFamily = 0;
	m_this_cpuModel  = 0;
	char VenderId[15];
	unsigned long stepping;
	CpuId(VenderId, &m_this_cpuFamily, &m_this_cpuModel, &stepping);

	// Get oprofile events directory 
	QString file = helpGetEventFile(m_this_cpuFamily, m_this_cpuModel);

	m_eventFile.open(file);

	m_euid = geteuid();
	m_pCawFile = 0;
	m_nDocNum = 1;
	m_bFirstDialog = TRUE;
	m_bLegacyTimer = TRUE;
	m_SamplingState = SS_IDLE;
	m_pTranslateProgressDlg = NULL;
	m_pSession = NULL;
	m_pOprofileDaemonDockView = NULL;
	m_pOprofileDriverDockView = NULL;
	m_pWs = NULL;
	m_pFileTools = NULL;

	DWORD font_size = FONT_SIZE_DEFAULT;
	CATuneOptions ao;

	ao.getFontSize (&font_size);
	qApp->setFont (QFont (qApp->font().family(), font_size), TRUE);

	m_tick_per_sec = getTick ();


	//////////////////////////////////////////////////////

	m_profiles.readAvailableProfiles();

	QPixmap openIcon, saveIcon;
	QSize size;
	QIconSet icon;
	icon.setIconSize (QIconSet::Large, size);

	setIcon (QPixmap (amdArrowLogo));

	// ////////////////////////////////////////////////////////////////
	// Instantiate the workspace
	m_pSplitter = new QSplitter (this);
	m_pProjWnd = new ProjectWindow (m_pSplitter);
	m_pVBox = new QVBox (m_pSplitter);
	m_pWs = new QWorkspace (m_pVBox);

	// When we cascade the sessions...
	m_pWs->setScrollBarsEnabled (true);

	m_pVBox->setFrameStyle (QFrame::StyledPanel | QFrame::Sunken);
	m_pProjWnd->resize (200, m_pProjWnd->height ());

	QObject::connect (m_pWs,
		SIGNAL (windowActivated (QWidget *)),
		SLOT (onWindowActivated (QWidget *)));

	connect( m_pProjWnd, SIGNAL (SessionDeletedAndReinit(TRIGGER, QString)),
		SLOT (onSessionDeleted (TRIGGER, QString)));
	connect( m_pProjWnd, SIGNAL (SessionDeletedOnly(TRIGGER, QString)),
		SLOT (onSessionDeletedOnly (TRIGGER, QString)));
	connect( m_pProjWnd, SIGNAL (reinitProjectWindow()),
		SLOT (initProjectWindow ()));


	QObject::connect( m_pProjWnd, SIGNAL(SessionDblClicked (TRIGGER, QString)),
		SLOT(onSessionDblClicked (TRIGGER, QString)) );
	QObject::connect( m_pProjWnd, SIGNAL(SessionRenamed (TRIGGER, QString)),
		SLOT(onSessionRenamed (TRIGGER, QString)) );

	QObject::connect (m_pProjWnd,
		SIGNAL (tbpSessionProperties (QString)),
		SLOT (onTbsSessionProperties (QString)));

	QObject::connect (m_pProjWnd,
		SIGNAL (ebpSessionProperties (QString)),
		SLOT (onEbsSessionProperties (QString)));

	connect (m_pProjWnd, SIGNAL (CopySessionToCurrent (TRIGGER, QString)),
		SLOT (OnCopySessionToCurrent (TRIGGER, QString)));

	connect (m_pProjWnd, SIGNAL (openSessionInDiffAnalyst(DiffSessionInfo *)),
		SLOT (OnOpenDiffAnalyst(DiffSessionInfo *)));

	connect (m_pProjWnd, SIGNAL (openKcachegrind(QString)),
		SLOT (OnOpenKcachegrind(QString)));

	setCentralWidget (m_pSplitter);

	// /////////////////////////////////////////////////////////////////////
	// Fix our Status Bar
	m_pStatusMsg = new QLabel (statusBar (), "Hello There");

	// stretch is used to compute a suitable size for widget as the status
	// bar grows and shrinks.
	int stretch = 4;
	statusBar ()->addWidget (m_pStatusMsg, stretch);

	m_pStatusProgress = new QProgressBar (statusBar (), "Progress Bar");
	stretch = 1;
	statusBar ()->addWidget (m_pStatusProgress, stretch);

	m_pStatusProgress->setCenterIndicator (FALSE);

	setDockMenuEnabled (true);
	// /////////////////////////////////////////////////////////////////////
	// Add the File Tool Bar
	m_pFileTools = new QToolBar (this, "File Tool Bar");
	addToolBar (m_pFileTools, tr ("File Tool Bar"), Top, TRUE);

	new QToolButton (QIconSet (XpmFileNew), "New", QString::null, this,
		SLOT (onFileNew ()), m_pFileTools, "New");
	new QToolButton (QIconSet (XpmFileOpen), "Open", QString::null, this,
		SLOT (onFileOpen ()), m_pFileTools, "Open");

	m_SaveButt = new QToolButton (QIconSet (XpmFileSave), "Save",
		QString::null, this, SLOT (onFileSave ()),
		m_pFileTools, "Save");
	m_SaveButt->setEnabled (FALSE);

	////////////////////////////////////////////////////////////////////////
	// Add the Tools Toolbar
	m_pToolsToolBar = new QToolBar( this, "Tools Toolbar" );
	addToolBar( m_pToolsToolBar, tr( "Tools Toolbar" ), Top, FALSE);

	icon = QIconSet (QPixmap(samplingsettings));
	m_ToolsToolId[TM_SETTINGS] = new QToolButton( icon, "Session Settings", QString::null, this,
		SLOT( OnSessionSettings() ), m_pToolsToolBar );

	QImage img;
	icon = QIconSet ( QPixmap(appopdialog));
	img.loadFromData( disappopdialog, sizeof( disappopdialog ), "PNG" );
	m_ToolsToolId[TM_CAOPTIONS] = new QToolButton( icon, "CodeAnalyst Options", QString::null, this,
		SLOT( onToolsATuneOptions() ), m_pToolsToolBar );

	icon = QIconSet (QPixmap (configdialog));
	img.loadFromData( disconfigdialog, sizeof( disconfigdialog ), "PNG" );
	m_ToolsToolId[TM_EDITPROFILES] = new QToolButton( icon, "Configuration Management", QString::null, this,
		SLOT( OnProfileManage() ), m_pToolsToolBar );

	icon = QIconSet (QPixmap (viewconfig));
	img.loadFromData( disviewconfig, sizeof( disviewconfig ), "PNG" );
	m_ToolsToolId[TM_EDITVIEWS] = new QToolButton( icon, "View Management", QString::null, this,
		SLOT( OnViewManage() ), m_pToolsToolBar );

	icon = QIconSet (QPixmap (sessionDiffIcon));
	m_ToolsToolId[TM_DIFFANALYST] = new QToolButton( icon, "Create Diff Session", QString::null, this,
		SLOT( OnOpenDiffAnalyst() ), m_pToolsToolBar );

	m_ToolsToolId[TM_SETTINGS]->setEnabled( FALSE );
	m_ToolsToolId[TM_DIFFANALYST]->setEnabled( FALSE );

	m_pToolsToolBar->show ();

	// ////////////////////////////////////////////////////////////////////
	// Add Sampling Tool Bar
	//
	pSamplingToolBar = new QToolBar (this, "Sampling Tool Bar");

	addToolBar (pSamplingToolBar, "Sampling Tool Bar", Top, FALSE);

	icon = QIconSet (QPixmap (samplingstart));
	m_SamplingToolId[SM_START] = new QToolButton (icon, "Start",
		QString::null, this,
		SLOT (onSamplingStart ()),
		pSamplingToolBar);

	icon = QIconSet (QPixmap (samplingpause));
	m_SamplingToolId[SM_PAUSE] = new QToolButton( icon, "Pause",
		QString::null, this,
		SLOT( onSamplingPause ()),
		pSamplingToolBar );

	icon = QIconSet (QPixmap (samplingstop));
	m_SamplingToolId[SM_STOP] = new QToolButton (icon, "Stop",
		QString::null, this,
		SLOT (onSamplingStop ()),
		pSamplingToolBar);

	m_SamplingToolId[SM_START]->setEnabled (FALSE);
	m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
	m_SamplingToolId[SM_STOP]->setEnabled (FALSE);
	m_SamplingToolId[SM_PAUSE]->setToggleButton( TRUE );

	pSamplingToolBar->addSeparator ();
	m_pProfileBox = new QComboBox (pSamplingToolBar);
	m_pProfileBox->insertStringList (m_profiles.getListOfProfiles ());
	connect (m_pProfileBox, SIGNAL (activated (const QString &)),
		SLOT (OnProfileChange (const QString &)));
	m_pProfileBox->setEnabled (false);

	// ////////////////////////////////////////////////////////////////////
	// Insert Items under the file menu
	m_pFileMenu = new QPopupMenu (this);
	menuBar ()->insertItem ("&File", m_pFileMenu);

	m_pFileMenu->insertItem (QIconSet (QPixmap (XpmFileNew)), "&New", this,
		SLOT (onFileNew ()), CTRL + Key_N);
	m_pFileMenu->insertItem (QIconSet (QPixmap (XpmFileOpen)), "&Open",
		this, SLOT (onFileOpen ()), CTRL + Key_O);
	m_SaveId = m_pFileMenu->insertItem (QIconSet (QPixmap (XpmFileSave)),
		"&Save", this, SLOT (onFileSave ()),
		CTRL + Key_S);
	m_pFileMenu->setItemEnabled (m_SaveId, false);

	m_pFileMenu->insertSeparator ();

	// export data
	m_ExportDataId = m_pFileMenu->insertItem ("&Export Profiles", this,
		SLOT (onExportData ()));
	m_pFileMenu->setItemEnabled (m_ExportDataId, false);

	// import data
	m_ImportDataId = m_pFileMenu->insertItem ("&Import Profiles", this,
		SLOT (onImportData ()));
	m_pFileMenu->setItemEnabled (m_ImportDataId, false);

	m_pFileMenu->insertSeparator ();

	m_CloseId = m_pFileMenu->insertItem ("&Close", this,
		SLOT (onFileClose ()), CTRL + Key_W);
	m_pFileMenu->setItemEnabled (m_CloseId, false);

	m_pFileMenu->insertItem ("&Quit", this, SLOT (close ()), CTRL + Key_Q);

	QObject::connect (qApp, SIGNAL (aboutToQuit ()), this,
		SLOT (onAboutToQuit ()));

	QObject::connect (m_pFileMenu, SIGNAL (activated (int)),
		SLOT (onMruItemSelected (int)));

	insertMruItems ();

	// /////////////////////////////////////////////////////////////////////
	// Initialize the Sampling Menu Item
	m_pSamplingMenu = new QPopupMenu (this);

	menuBar ()->insertItem ("&Profile", m_pSamplingMenu);

	m_SamplingMenuId[SM_START]
	= m_pSamplingMenu->insertItem (QPixmap (samplingstart), "&Start",
		this, SLOT (onSamplingStart ()));

	m_pSamplingMenu->insertSeparator ();

	m_SamplingToolId[SM_PAUSE]->setToggleButton( TRUE );
	m_SamplingMenuId[SM_PAUSE]
	= m_pSamplingMenu->insertItem ( QPixmap (samplingpause), "&Pause",
		this, SLOT( onSamplingPause()  ));

	m_pSamplingMenu->insertSeparator ();
	m_SamplingMenuId[SM_STOP]
	= m_pSamplingMenu->insertItem (QPixmap (samplingstop), "S&top",
		this, SLOT (onSamplingStop ()));

	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
	m_pSamplingMenu->setItemEnabled( m_SamplingMenuId[SM_PAUSE], FALSE );
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], FALSE);

	// /////////////////////////////////////////////////////////////////////
	// Initialize the Tools Menu
	m_pToolsMenu = new QPopupMenu (this);

	menuBar ()->insertItem ("&Tools", m_pToolsMenu);

	m_ToolsMenuId[TM_SETTINGS]  = m_pToolsMenu->insertItem( QPixmap(samplingsettings), "S&ession Settings", 
		this, SLOT( OnSessionSettings()  ));
	m_ToolsMenuId[TM_CAOPTIONS] = m_pToolsMenu->insertItem( QPixmap(appopdialog), "&CodeAnalyst Options",
		this, SLOT( onToolsATuneOptions()) );
	m_pToolsMenu->insertSeparator();
	m_ToolsMenuId [TM_EDITPROFILES] =  m_pToolsMenu->insertItem( QPixmap (configdialog), "Configuration &Management",
		this, SLOT( OnProfileManage()) );
	m_ToolsMenuId [TM_EDITVIEWS] =  m_pToolsMenu->insertItem( QPixmap (viewconfig), "&View Management",
		this, SLOT( OnViewManage()) );
	m_ToolsMenuId [TM_DIFFANALYST] =  m_pToolsMenu->insertItem( QPixmap (sessionDiffIcon), "Create &Diff Session",
		this, SLOT( OnOpenDiffAnalyst()) );
	m_pToolsMenu->insertSeparator();
	m_ToolsMenuId [TM_DAEMON_MONITOR] =  m_pToolsMenu->insertItem( "&OProfile Daemon Monitor",
		this, SLOT( onOprofileDaemonDockViewToggle()) );
	m_ToolsMenuId [TM_DRIVER_MONITOR] =  m_pToolsMenu->insertItem( "OProfile D&river Monitor",
		this, SLOT( onOprofileDriverDockViewToggle()) );

	m_pToolsMenu->setItemEnabled( m_ToolsMenuId[TM_SETTINGS], FALSE );
	m_pToolsMenu->setItemEnabled( m_ToolsMenuId[TM_DIFFANALYST], FALSE );

	// /////////////////////////////////////////////////////////////////////
	// Insert items under the windows menu
	m_pWindowsMenu = new QPopupMenu (this);
	m_pWindowsMenu->setCheckable (TRUE);
	connect (m_pWindowsMenu, SIGNAL (aboutToShow ()), this,
		SLOT (windowsMenuAboutToShow ()));

	menuBar ()->insertItem ("&Windows", m_pWindowsMenu);

	// /////////////////////////////////////////////////////////////////////
	// Insert items under the help menu
	m_pHelpMenu = new QPopupMenu (this);
	menuBar ()->insertItem ("&Help", m_pHelpMenu);

	m_pHelpMenu->insertItem ("&About", this, SLOT (onHelpAbout ()), Key_F1);
	m_pHelpMenu->insertSeparator ();
	m_pHelpMenu->insertItem ("&Help", this, SLOT (onHelpContents ()));
	m_pHelpMenu->insertSeparator ();
	m_pHelpMenu->insertItem ("&System Info", this, SLOT (onHelpSysInfo ()));

	m_pTranslate = NULL;
	m_pCaTransDisplay = NULL;
	m_pProgress = NULL;

}


ApplicationWindow::~ApplicationWindow ()
{
	deleteOprofileTranslateObjects();
	DELETE_IF_NOT_NULL(m_pProgress);
}


void ApplicationWindow::deleteOprofileTranslateObjects()
{
	//    DELETE_IF_NOT_NULL(m_pTranslate);
	//    DELETE_IF_NOT_NULL(m_pCaTransDisplay);
}



bool ApplicationWindow::createOprofileTranslateObjects()
{
	// Clean up
	if (NULL != m_pTranslate) {
		delete m_pTranslate;
		m_pTranslate = NULL;
	}
	
	if (NULL != m_pCaTransDisplay) {
		delete m_pCaTransDisplay;
		m_pCaTransDisplay = NULL;
	}
	
	if (NULL != m_pTranslateProgressDlg) {
		//delete m_pTranslateProgressDlg;
		m_pTranslateProgressDlg = NULL;
	}

	// Initialize Translator	
	m_pTranslate = new CATranslate();

	// Translation Display
	m_pCaTransDisplay = new ca_translate_gui_display();

	// Translation Dialog
	m_pTranslateProgressDlg = new TranslateDlg (this, "TranslateDlg", true);

	if (m_pTranslate && m_pCaTransDisplay && m_pTranslateProgressDlg) {
		// Finish Setting up
		m_pTranslateProgressDlg->setCaption ("Modules processed");

		connect (m_pTranslateProgressDlg, SIGNAL(dialogClosed()),
			this, SLOT (onModuleProcessingClosed()));

		m_pCaTransDisplay->setDlgEventHandler (this);

		return true;
	} else {
		QMessageBox::critical (this, "Error", "Fail to initialize data translation\n");
		return false;
	}
}


/////////////////////////////////////////////////////////////////////////////
// customEvent()
// -------------
// Our Custom Event that we implement to notify the app that the sampling
// duration has expired
//
void ApplicationWindow::customEvent (QCustomEvent * pCustEvent)
{
	switch (pCustEvent->type())
	{
	case EVENT_DELAY_FINISH:
	{
		if(!m_pStatusProgress) break;	
		m_pStatusProgress->reset ();
		      
		/* NOTE: Users can be clicking pause at this point */ 
		bool isPaused = (m_SamplingState == SS_PAUSED);

		if (m_SamplingState == SS_START_PROFILE
		||  m_pSession->startDelay == 0){
			/* We should have already started profiling
			 * at this point */
			break;
		} else if (m_SamplingState == SS_DELAY ||  isPaused) {

			/* Starting profile */
			if (!setSamplingState(SS_START_PROFILE))
				setSamplingState (SS_IDLE);

			/* To stay paused after starting profile */
			if (m_pSession->startPaused || isPaused)
				setSamplingState (SS_PAUSED);

		} else {
			setSamplingState (SS_IDLE);
		}
	
		break;
	}
	case EVENT_DURATION_FINISH:
		if(!m_pStatusProgress) break;	
		m_pStatusProgress->reset ();
		setSamplingState (SS_FINISHED);
		break;

	case EVENT_SET_PROGRESS:
		if(!m_pStatusProgress) break;	
		m_pStatusProgress->setProgress ((long) pCustEvent->data());
		break;

	case EVENT_RESET_PROGRESS:
		if(!m_pStatusProgress) break;	
		m_pStatusProgress->reset();
		break;

	case EVENT_SET_STEPS:
		if(!m_pStatusProgress) break;	
		m_pStatusProgress->setTotalSteps ((long) pCustEvent->data());
		break;

	case EVENT_LAUNCH_ERROR:
		{
			QString * temp = (QString *) pCustEvent->data();
			QMessageBox::critical (this, "CodeAnalyst profile error", *temp);
			delete temp;
			break;
		}
	case EVENT_UPDATE_PROGRESS_BEGIN:
		{
			if (NULL != m_pTranslateProgressDlg) {
				m_pTranslateProgressDlg->m_pOk->setEnabled(false);
				m_pTranslateProgressDlg->canBeClosed = false;
			}

			break;
		}
	case EVENT_UPDATE_PROGRESS_DONE:
		{
			if (NULL != m_pTranslateProgressDlg) {
				m_pTranslateProgressDlg->m_pOk->setEnabled(true);
				m_pTranslateProgressDlg->m_pOk->setFocus();
				m_pTranslateProgressDlg->canBeClosed = true;
			}
			break;
		}
	case EVENT_UPDATE_PROGRESS:
		{
			QString * temp = (QString *) pCustEvent->data();
			if (NULL != m_pTranslateProgressDlg)
			{
				m_pTranslateProgressDlg->translate_edit->append (*temp);
				m_pTranslateProgressDlg->translate_edit->scrollToBottom ();
				m_pTranslateProgressDlg->update();
			}
			delete temp;
			break;
		}
	case EVENT_UPDATE_ERROR:
		{
			QString * temp = (QString *) pCustEvent->data();
			if (NULL != m_pTranslateProgressDlg)
			{
				m_pTranslateProgressDlg->translate_edit->setColor (Qt::red);
				m_pTranslateProgressDlg->translate_edit->append (*temp);
				m_pTranslateProgressDlg->translate_edit->setColor (Qt::black);
				m_pTranslateProgressDlg->translate_edit->scrollToBottom ();
			}
			delete temp;
			break;
		}
	case EVENT_UPDATE_OPROFILED_MONITOR:
		{
			if (!m_pOprofileDaemonDockView)
				break;
			m_pOprofileDaemonDockView->updateWithSnapshot();
			break;
		}
	case EVENT_UPDATE_OPROFILEDRV_MONITOR:
		{
			if (!m_pOprofileDriverDockView)
				break;
			m_pOprofileDriverDockView->updateWithSnapshot();
			break;
		}
	default:
		break;
	}
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ApplicationWindow::closeEvent()
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* This routine prevents the user from closing atune if a sampling session
* is taking place.
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
void ApplicationWindow::closeEvent (QCloseEvent * pCloseEvent)
{
	if (sampling ())
	{
		QMessageBox::information (this, "Hold on...", "Please wait "
			"for the sampling session to end, "
			"or end it manually.");
		pCloseEvent->ignore ();
	}
	else
	{
		pCloseEvent->accept ();
	}
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ApplicationWindow::sampling()
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Determines is a sampling session is going on
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
bool ApplicationWindow::sampling ()
{
	return (m_SamplingState != SS_IDLE);
}


////////////////////////////////////////////////////////////////////////////
// getCurrentFilePath()
// --------------------
//
QString ApplicationWindow::getCurrentFilePath ()
{
	return m_pCawFile->getPath ();
}


///////////////////////////////////////////////////////////////////////////////
// onFileNew()
// -----------
// Display the Project Options Dialog to allow the user to select the
// appropriate options
//
void ApplicationWindow::onFileNew ()
{
	if( sampling() )
	{
		QMessageBox::warning (this, "Hold on...", 
			"Please wait for the profiling session to end, or end it manually." );
		return ;
	}

	// show the dialog
	m_bFirstDialog = FALSE;

	bool bKeepAsking = false;
	QString newProject;
	NewProjectDlg * pDlg = new NewProjectDlg (this);
	CATuneOptions ao;
	do
	{
		//If a default project directory is available use it,
		QString defaultProjectDir;
		ao.getDefaultProjectDir (defaultProjectDir);
		if (defaultProjectDir.isEmpty ())
		{
			//otherwise use the user's home directory
			defaultProjectDir = QDir::home ().path();
			defaultProjectDir.replace ('\\', '/');
			defaultProjectDir += "/AMD/CodeAnalyst";
		}
		pDlg->m_pProjectDir->setText (defaultProjectDir);

		pDlg->exec();
		if( pDlg->result() == QDialog::Rejected )
		{
			delete pDlg;
			return;
		}

		// Force projDir to end with "/"
		newProject = pDlg->m_pProjectDir->text();
		if (!newProject.endsWith ("/"))
		{
			newProject += "/";
		}

		// creates a directory based on the project name
		if (! newProject.endsWith (pDlg->m_pProjectName->text() + "/"))
			newProject += pDlg->m_pProjectName->text() + "/";

		// Append the projectFileName.caw 
		newProject += pDlg->m_pProjectName->text();
		if (! newProject.endsWith (".caw"))
		{
			newProject += ".caw";
		}

		bKeepAsking = false;
		if (QFile::exists (newProject))
		{
			if (QMessageBox::Yes  != QMessageBox::question (this, "File already exists",
				"The project file already exists, do you want to overwrite it?",
				QMessageBox::Yes, QMessageBox::No))
			{
				bKeepAsking = true;
			}
		}

		QString temp = pDlg->m_pProjectDir->text();
		ao.setDefaultProjectDir (temp );

		//create  project
		if(!CawFile::create (newProject)) {
			bKeepAsking = true;
		}
	} while (bKeepAsking);

	closeAllWindows ();
		
	delete pDlg;

	//Load the new file
	LoadFile (newProject);

	//Pop up profile dialog
	OnSessionSettings ();
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ApplicationWindow::onFileOpen()
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Event handler for selecting File-Open from the menu, or hitting the
* FileOpen button on the tool bar.
*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
void ApplicationWindow::onFileOpen ()
{
	QString dir = "";
	CATuneOptions ao;

	if( sampling() )
	{
		QMessageBox::warning (this, "Hold on...", 
			"Please wait for the profiling session to end, or end it manually." );
		return ;
	}

	ao.getDefaultProjectDir (dir);
	QString fn = QFileDialog::getOpenFileName (dir, CA_EXT, this);

	if (!fn.isEmpty ())
	{
		fn.replace ('\\', '/');	  //Make sure path has front slashes
		LoadFile (fn);
	}
}


///////////////////////////////////////////////////////////////////////////////
// initProjectWindow()
// -------------------
// Enumerates all tbs sessions listed and adds them to the project tree
//
void ApplicationWindow::initProjectWindow ()
{
	m_pProjWnd->deleteAllItems ();
	m_pProjWnd->initialize ();

	// Get the TBS Session Names
	QStringList sessions = m_pCawFile->getSessionList (TIMER_TRIGGER);
	QStringList::Iterator it = sessions.begin ();

	for (unsigned int i = 0; i < sessions.count (); ++i, ++it)
	{
		TBP_OPTIONS opts;
		m_pCawFile->getSessionDetails ((*it).data(), &opts );
		m_pProjWnd->insertTbpSamplingSession ((*it).data(), opts.sessionNote);
	}

	// Get the EBS Session Names
	sessions = m_pCawFile->getSessionList (EVENT_TRIGGER);
	it = sessions.begin ();

	for (unsigned int i = 0; i < sessions.count (); ++i, ++it)
	{
		EBP_OPTIONS opts;
		m_pCawFile->getSessionDetails ((*it).data(), &opts );
		m_pProjWnd->insertEbpSamplingSession ((*it).data(), opts.sessionNote);
	}

	// Set the Column caption for the window
	m_pProjWnd->setCaption (m_pCawFile->getName ());
	m_pProjWnd->expandTbp ();
	m_pProjWnd->expandEbp ();
}


void ApplicationWindow::targetExit()
{
#ifdef _DEBUG_
	qDebug("target exists");
#endif
}


///////////////////////////////////////////////////////////////////////////////
// StartSampling()
// ---------------
//
void ApplicationWindow::onSamplingStart ()
{
	//sync up to reduce chance of io error
	qApp->syncX();

	// Keeps the run disable until we done setting up.
	m_SamplingToolId[SM_START]->setEnabled (FALSE);
	m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
	m_SamplingToolId[SM_STOP]->setEnabled (FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP] , FALSE);

	if (!startProfiling()) {
		// Clean up
		onSamplingStop();
	} else {
		/* Start profiling successfully, 
		 * now users can control pause or stop 
		 */
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], TRUE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], TRUE);
		m_SamplingToolId[SM_PAUSE]->setEnabled (TRUE);
		m_SamplingToolId[SM_STOP]->setEnabled (TRUE);
	} 
}


bool ApplicationWindow::startProfiling ()
{
	/*************************  
	 * BEGIN: DO NOT CHANGE ORDER 
	 */
	/* 1 Check if user has permission */
	m_pStatusMsg->setText ("Verify Permission.");
	if(!m_opIf.havePermissionToProfile())
	{
		QString errMsg 	= QString("Error starting profile:\n\n")
				+ "This user does not have sufficient permission to run a profile.\n\n"
				+ "Please make sure :\n"
				+ "    - You are root or a member of \"amdca\" group.\n" 
				+ "    - amdca group has the permission to run\n\n"
				+ "         sudo " + CA_SBIN_DIR + "/ca_oprofile_controller\n\n"
				+ "Please use \"ca_user_manager\" to manage CodeAnalyst users.";
		QMessageBox::critical(this, "CodeAnalyst Error", errMsg);
		return false;	
	}

	/* 2. Check to make sure that CodeAnalyst service is setup and ready.
	 * otherwise, we will try to start it.
	 */
	m_pStatusMsg->setText ("Verify OProfile Driver status.");
	if (!m_opIf.checkOprofileDriverStatus() && !m_opIf.loadOprofileDriver())
	{
		QMessageBox::critical (this, "Error starting profile",
			"Checking OProfile driver (/dev/oprofile) returns failure\n"
			" and an attempt to load the driver also failed.\n."
			"CodeAnalyst will not be able to run profile.\n\n."
			"Please make sure :\n"
			"  - The user is a member of group amdca\n."
			"  - OProfle driver is installed and can be started properly\n."
		);
		return false;	
	}

	/* 3. Setup OProfile infrastructures. Must be done after driver loaded.*/
	m_pStatusMsg->setText ("Setup OProfile.");
	if(!m_opIf.do_setup())  {
		QMessageBox::critical (this, "Error starting profile",
			QString("Failed to setup OProfile.\n"));
		return false;	
	}

	/* 4. This check is mainly for the case when running on older kernel that doesn't
	 * have support for family10 yet. In this case we suggest them to use the CAKM
	 */
	if (!isCorrectDriverForGH())
	{
		QString errMsg 	= QString("Error starting profile:\n\n")
				+ "Oprofile driver is not loaded.\n\n" 
				+ "or\n\n"
				+ "Incorrect Oprofile driver is loaded.\n"
				+ "CodeAnalyst requires a modified version\n"
				+ "of \"oprofile\" driver to be installed on this system.\n"  
				+ "Please see INSTALLATION instruction.";
		QMessageBox::critical(this, "CodeAnalyst Error", errMsg);
		return false;	
	}
	
	/* 5. Check if Session Setting has been setup properly.
	 */
	RUN_SETTING * runSetting = NULL;
	QString dc;
	if (NULL == (runSetting = m_pCawFile->getLastRunSetting()) 
	||  (dc = runSetting->dcConfig).isEmpty()) {
		QString errMsg 	= QString("Error starting profile:\n\n")
				+ "The Current Session Settings might have not been configured properly.\n" 
				+ "Please check the Session Settings Dialog and retry.\n";
		QMessageBox::critical(this, "CodeAnalyst Error", errMsg);
	
		//Pop up profile dialog
		OnSessionSettings ();

		return false;	
	}

	/*************************  
	 * END: DO NOT CHANGE ORDER 
	 */

	// Get the options from the workspace file
	QString profile = m_pCawFile->getLastProfile ();
	if(!m_profiles.profileExists(profile)) {
		// the DC configuration does not exist in available configs.
		// then use the current config.
		profile = m_pProfileBox->currentText();
		m_pCawFile->setLastProfile(profile);
	}

	// set the current session info (for the duration of the profile) 
	// appropriately
	TRIGGER profileType = m_profiles.getProfileType (profile);
	QString file_ext = "";
	switch (profileType)
	{
	case TIMER_TRIGGER:
		m_pSession = static_cast<SESSION_OPTIONS *>(new TBP_OPTIONS ());
		if (NULL == m_pSession )
		{
			QMessageBox::critical (this, "CodeAnalyst Error", 
							DLG_ALLOC_ERROR_MSG);
			return false;	
		}
		file_ext = TBS_FILE_EXT;
		break;

	case EVENT_TRIGGER:
		m_pSession = static_cast<SESSION_OPTIONS *>(new EBP_OPTIONS ());
		if (NULL == m_pSession )
		{
			QMessageBox::critical (this, "CodeAnalyst Error", 
							DLG_ALLOC_ERROR_MSG);
			return false;	
		}
		file_ext = EBS_FILE_EXT;
		break;

	case NO_TRIGGER:
	default:
		QMessageBox::information (this, "Error",
			"No sampling mechanism is available.\n"
			"The run will abort.");
		return false;	
	}

	// Copy Last RunSetting
	*m_pSession = *(m_pCawFile->getLastRunSetting());

	// at here, profileType is always a valid type
	QString sessionName = m_pCawFile->getNextSessionName (profileType);
	m_pSession->setSessionName(sessionName, file_ext);

	m_profiles.getProfileConfig (profile, m_pSession);

	//TODO: Add opName if missing
	if(m_pSession->getEventContainer()->populateOpNames(&m_eventFile) != 0)
		return false;	

	//TODO: Add PerfEventContainerValidation
	QString errorStr;
	if (!m_pSession->getEventContainer()->validateEvents(errorStr)) {
		QMessageBox::critical(this, "CodeAnalyst Error", errorStr);
		return false;	
	}

	/*
	 * Check for IBS support
	 */		
	if (m_pSession->getEventContainer()->hasIbs()) {
		if (!m_opIf.checkIbsSupportInDriverAndDaemonOk())
			return false;	

		/*
		 * Check for IBS dispatch Op support
		 */
		unsigned long opCount;
		unsigned int  opUmask;
		if (m_pSession->getEventContainer()->getIbsOpCountUmask(opCount, opUmask)) {
			if (opCount > 0 && (opUmask & 0x1) > 0) {
				unsigned long ibsFeatureFlag;
				getCpuIdIbs(&ibsFeatureFlag);
				if ( !isCpuIbsOpDispatchOpOk(ibsFeatureFlag)) {
					if (QMessageBox::Yes == 
					    QMessageBox::question (this, "CodeAnalyst Error",
					    QString("Current system does not support ") +
					    "IBS Op Dispatch-op mode.\n" +
					    "Do you want to continue with dispatch-op mode disable?",
					    QMessageBox::Yes, QMessageBox::No)) {
						// Disable opUmask
						opUmask = opUmask & ~0x1;
						m_pSession->getEventContainer()
							->setIbsOpCountUmask(opCount, opUmask);
					} else { 
						return false;	
					}
				}

				if ( !isDriverIbsOpDispatchOpOk()) {
					if (QMessageBox::Yes == 
					    QMessageBox::question (this, "CodeAnalyst Error",
					    QString("CodeAnalyst Kernel Module does not support ") +
					    "IBS Op Dispatch-op mode.\n" +
					    "Do you want to continue with dispatch-op mode disable?",
					    QMessageBox::Yes, QMessageBox::No)) {
						// Disable opUmask
						opUmask = opUmask & ~0x1;
						m_pSession->getEventContainer()
							->setIbsOpCountUmask(opCount, opUmask);
					} else { 
						return false;	
					}
				}
			}
		}
	}

	/*
	 * Check for MUX support
	 */
	// TODO: [Suravee] This should not be hard coded
	if ((profileType == EVENT_TRIGGER)
	&&  (m_pSession)->getEventContainer()->countPmc() > 4 ){
		// check if driver is ok
		if (!m_opIf.checkMuxSupportInDriver() 
		||   m_opIf.getNumEventCounters() == MAX_EVENTNUM) {
			QMessageBox::warning(this, "CodeAnalyst Warning",QString("Warning:\n\n") +
			+ "Current CodeAnalyst Kernel Module does not support event multiplexing.\n"
			+ "Please use profile which has less than 4 events, or.\n"
			+ "update the CodeAnalyst Kernel Module one event group.");
			return false;	
		}

		// check if daemon is ok
		if (!m_opIf.checkMuxSupportInDaemon()) {
			QMessageBox::warning(this, "CodeAnalyst Warning",QString("Warning:\n\n") +
			+ "Current OProfile daemon does not support event multiplexing.\n"
			+ "Please use profile which has less than 4 events, or.\n"
			+ "update the CodeAnalyst Kernel Module one event group.");
			return false;	
		}
	}

	// For CSS
	// Check if daemon supports CSS
	if (m_pSession->cssEnable && !m_opIf.checkCssSupportInDaemon()) {
		m_pSession->cssEnable = false;
	}
	
	// Check if driver supports CSS
	if (!m_opIf.checkCssSupportInDriver()) {
		if (m_pSession->cssEnable) {
			QMessageBox::warning(this, "CodeAnalyst Warning",QString("Warning:\n\n") +
			+ "Current CodeAnalyst Kernel Module does not support Call-Stack Sampling (CSS).\n"
			+ "CodeAnalyst will start profile with out CSS.\n\n"
			+ "Please update the CodeAnalyst Kernel Module in order to profile with CSS.");
			m_pSession->cssEnable = false;
		}
	} else {
		// Reset CSS	
		m_opIf.set_css(0, 0, 0, 0);
	} 

	// Check CSS bitness
	int is32Bit = -1;
	if (m_pSession->cssEnable
	&& (is32Bit = isCss32Bit()) < 0) {
		QMessageBox::warning(this, "CodeAnalyst Warning",QString("Warning:\n\n") +
		+ "Cannot configure Call-Stack Sampling (CSS) with proper bitness.\n"
		+ "CodeAnalyst will start profile with out CSS.\n\n"
		+ "Please check CSS setting and rerun the profile.");
		m_pSession->cssEnable = false;
	}	

	// Configure driver with CSS setting w/ TGID
	if (m_pSession->cssEnable
	&& !m_opIf.set_css(m_pSession->cssDepth, 
			m_pSession->cssInterval, 
			(m_pSession->cssUseTgid)? m_pSession->cssTgid: 0,
			is32Bit))
	{
		QMessageBox::critical(this, "CodeAnalyst Error",QString("Error:\n\n") +
		QString("Failed to configure CSS interface in CodeAnalyst Kernel Module\n"));
		return false;	
	}

	if( 0 != launchProgressManager()) {
		return false;
	} 
	
	return true;
} // ApplicationWindow::startProfiling()


void ApplicationWindow::setGUIButtonsStart()
{
	// Disable/Enable tool and menu items
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
	//m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], TRUE);
	//m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], TRUE);
	m_pProfileBox->setEnabled (false);

	m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_SETTINGS], FALSE);
	m_ToolsToolId[TM_SETTINGS]->setEnabled( FALSE );

	m_SamplingToolId[SM_START]->setEnabled (FALSE);
	//m_SamplingToolId[SM_PAUSE]->setEnabled (TRUE);
	//m_SamplingToolId[SM_STOP]->setEnabled (TRUE);

	// We do not allow import while profiling
	m_pFileMenu->setItemEnabled (m_ImportDataId, false);
}


int ApplicationWindow::launchProgressManager()
{
	// Sanity check	
	if( m_pSession->duration < 0 
	&& !m_pSession->stopOnAppExit 
	&&  m_pSession->startDelay < 0 ) {
		// This seems like user didn't setup the session properly,
		// force it to use default value
		m_pSession->duration = 20;
		m_pSession->startDelay = 0;
	}

	if(m_pSession->duration <= 0 && !m_pSession->stopOnAppExit) {
		QMessageBox::critical(this,"CodeAnalyst Error",
			QString("Invalid profiling duration (")
			+ QString::number(m_pSession->duration)
			+").\n"
			+"Please specify profiling duration greater than 0,\n"
			+"or specify \"Stop data collection when the app exits\"\n"	
			);	
		return -1;
	}

	if(m_pSession->startDelay < 0 ) {
		QMessageBox::critical(this,"CodeAnalyst Error",
			QString("Invalid start delay (")
			+ QString::number(m_pSession->startDelay)
			+").\n"
			+"Please specify start delay >= 0,\n"
			);	
		return -1;
	}

	////////////////////////////////////////////
	// Start Profiling
	m_pStatusMsg->setText ("Starting OProfile daemon.");

	setGUIButtonsStart();

	if (m_pSession->startDelay > 0) {
		setSamplingState (SS_DELAY);
	} else {
		if (!setSamplingState (SS_START_PROFILE))
			return -1;

		// Pause if needed
		if (m_pSession->startPaused) {
			onSamplingPause();
		} else {
			// NOTE:
			// Add warmup period if no pause at the beginning. 
			// This is required in order to profile the 
			// beginning of the application correctly.
			sleep(1);
		}
	}

	////////////////////////////////////////////
	// Start Application
	if (!setSamplingState(SS_START_APP))
		return -1;

	return 0;
}


///////////////////////////////////////////////////////////////////////////////
// PauseSampling()
// ---------------
//
void ApplicationWindow::onSamplingPause ()
{
	if (m_SamplingState == SS_PAUSED)
		setSamplingState (SS_RESUMED);
	else
		setSamplingState (SS_PAUSED);
}


//////////////////////////////////////////////////////////////////////////////
// StopSampling()
// --------------
//
void ApplicationWindow::onSamplingStop ()
{
	m_pSamplingMenu->setItemEnabled(m_SamplingMenuId[SM_STOP], FALSE);
	m_SamplingToolId[SM_STOP]->setEnabled(FALSE);
	m_pSamplingMenu->setItemEnabled(m_SamplingMenuId[SM_PAUSE], FALSE);
	m_SamplingToolId[SM_PAUSE]->setEnabled(FALSE);

	setSamplingState (SS_FINISHED);
}


void ApplicationWindow::onSessionDblClicked (TRIGGER trigger, QString SessionName)
{
	SESSION_OPTIONS opts;

	if (!m_pCawFile->getSessionCfg (trigger, SessionName, &opts))
		return;

	//session file does not include path
	QString  caption = SessionName + " - " + opts.sessionFile;

	QString sessionPath = m_pCawFile->getDir()
		+ opts.sessionFile + DIR_FILE_EXT + "/" + opts.sessionFile;

	//If the profile session is currently shown
	QWidget *pWindow = findWindow( caption );
	if( pWindow != NULL )
	{
		//make it active
		pWindow->setFocus();
		return;
	}

	if ((NULL != m_pWs->activeWindow()) && (m_pWs->windowList().count() > 0))
	{
		m_pWs->activeWindow()->showNormal();
	}

	qApp->setOverrideCursor (Qt::BusyCursor);

	QWidget *pNewWindow;
	CSessionNavigator *pSessNav = new CSessionNavigator( sessionPath, m_pWs,
					sessionPath, WDestructiveClose );
	RETURN_IF_NULL (pSessNav, this);
	
	pNewWindow = pSessNav;

	QObject::connect( pSessNav,
		SIGNAL( DataViewChanged( QString, QListView *) ),
		SLOT( onDataViewChanged( QString, QListView *) ) );

	QObject::connect (this, SIGNAL (shownChanged (QString)), pSessNav, 
		SLOT(onGlobalShownChanged (QString)));

	QObject::connect (this, SIGNAL (densityVisibilityChanged ()), pSessNav, 
		SLOT (onDensityVisibilty ()));

	pSessNav->setCaption( caption );

	//this will be empty if timer, so the norms won't need to be calculated
	QString eventSessionName;
	if (EVENT_TRIGGER == trigger)
		eventSessionName = SessionName;

	if( !pSessNav->display (SessionName, m_pCawFile, eventSessionName) )
	{
		QMessageBox::critical (this, "CodeAnalyst Error", 
				QString("ERROR: Session : \"") + SessionName
					+ "\" not found.");
		qApp->restoreOverrideCursor();
		delete pSessNav;
		return;
	}

	setDefaultSize(pNewWindow);
	pNewWindow->showMaximized();

	qApp->restoreOverrideCursor ();

}//ApplicationWindow::onSessionDblClicked


// This function deletes the session from the project file, deletes
//  the module information file, and removes the window if it's showing...

void ApplicationWindow::onSessionDeletedOnly (TRIGGER trigger, QString SessionName)
{
	//Check for open window of session
	QString  caption ;
	QString fileName;
	QWidget *p_window;

	SESSION_OPTIONS opts;
	if (!m_pCawFile->getSessionCfg (trigger, SessionName, &opts))
		return;
	fileName = opts.sessionFile;

	caption = SessionName + " - " + fileName;
	p_window = findWindow( caption );

	//If the session window is open
	if( NULL != p_window)
	{
		//close and delete the widget
		p_window->close(TRUE);
	}

	m_pCawFile->deleteSession (trigger, SessionName );
} //ApplicationWindow::onSessionDeletedOnly

void ApplicationWindow::onSessionDeleted (TRIGGER trigger, QString SessionName)
{
	onSessionDeletedOnly(trigger,SessionName);	
	initProjectWindow();
}// ApplicationWindow::OnSessionDeleted


////////////////////////////////////////////////////////////////////////////
// onToolsOptions()
// ----------------
// The user has selected Tools | Options from the menu
// Return the Dialog code i.e. rejected() or accepted()
//
/*int ApplicationWindow::onToolsProjectOptions ()
{
GENERAL_OPTIONS gen;
OptionsDlg *pDlg = new OptionsDlg (FALSE, m_pCawFile, this,
"ProjectOptions", TRUE,
m_bFirstDialog);

if (NULL != pDlg) {
m_bFirstDialog = FALSE;
pDlg->initialize ();
pDlg->exec ();

if (SS_IDLE == m_SamplingState)
setSamplingState (SS_IDLE);

m_pCawFile->getGeneralOptions (&gen);
return pDlg->result ();
}
else {
QMessageBox::critical (this, "Error", DLG_ALLOC_ERROR_MSG);
return QDialog::Rejected;
}

}*/

///////////////////////////////////////////////////////////////////////////
// onToolsATuneOptions()
// ---------------------
//
int ApplicationWindow::onToolsATuneOptions ()
{
	int i_ret = QDialog::Rejected;
	CATuneOptionsDlg *pDlg = new CATuneOptionsDlg (this,
		"CodeAnalyst Options", TRUE);

	if (NULL != pDlg)
	{
		pDlg->exec ();
		i_ret = pDlg->result ();
		delete pDlg;
	}
	else
	{
		QMessageBox::critical (this, "ATuneOptions Error", DLG_ALLOC_ERROR_MSG);
	}

	return i_ret;
}


/////////////////////////////////////////////////////////////////////////////
// onFileSave()
// ------------
// User has clicked File | Save
//
void ApplicationWindow::onFileSave ()
{

	if (m_pCawFile != NULL)
	{
		m_pCawFile->saveCawFile ();
		statusBar()->message("Saved",3000);
	}
}

void ApplicationWindow::onFileClose (bool *isOk)
{
	if( sampling() )
	{
		QMessageBox::warning (this, "Hold on...", 
			"Please wait for the profiling session to end, or end it manually." );
		if(isOk)
			*isOk = false;
		return ;
	}

	closeAllWindows ();

	// Clear the Project Window
	m_pProjWnd->deleteAllItems ();
	m_pProjWnd->setCaption ("No Project Opened");
	setCaption (DEFAULT_CAPTION);

	// Disable sampling menu and Tools | Project Options
	m_pProfileBox->setEnabled (FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], FALSE);
	m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], FALSE);

	m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_SETTINGS], FALSE);
	m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_DIFFANALYST], FALSE);
	m_pFileMenu->setItemEnabled (m_ExportDataId, false);
	m_pFileMenu->setItemEnabled (m_ImportDataId, false);
	m_pFileMenu->setItemEnabled (m_SaveId, false);
	m_pFileMenu->setItemEnabled (m_CloseId, false);
	m_SaveButt->setEnabled (FALSE);

	m_ToolsToolId[TM_SETTINGS]->setEnabled( FALSE );
	m_ToolsToolId[TM_DIFFANALYST]->setEnabled( FALSE );
	m_SamplingToolId[SM_START]->setEnabled (FALSE);
	m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
	m_SamplingToolId[SM_STOP]->setEnabled (FALSE);

	if (m_pCawFile)
		delete m_pCawFile;
	m_pCawFile = NULL;
	if(isOk)
		*isOk = true;
	return ;
}


// Shows version information for CodeAnalyst and any other sos
//
void ApplicationWindow::onHelpAbout ()
{
	AboutDlg *p_dlg = new AboutDlg (this, "About AMD CodeAnalyst", TRUE);

	if (NULL != p_dlg)
	{
		p_dlg->show ();
	} else
		QMessageBox::critical (this, "Error", DLG_ALLOC_ERROR_MSG);
}


void ApplicationWindow::onHelpContents ()
{
	QString invoke = getDefaultPdfReader();

	if (invoke.isEmpty() || !QFile::exists(invoke)) {
		QMessageBox::critical (this, "Error", 
			"Could not locate PDF Reader.");
		return;
	}

	invoke += QString(" ") + CA_DATA_DIR "/doc/cadoc/CodeAnalyst_linux_users_guide.pdf";

	qApp->setOverrideCursor (QCursor (Qt::WaitCursor));
	system (invoke.ascii());
	qApp->restoreOverrideCursor ();
}


void ApplicationWindow::onHelpSysInfo ()
{
	SysInfoDlg *dlg = new SysInfoDlg (this, "System Information", TRUE);

	if (NULL != dlg)
	{
		dlg->initialize ();
		dlg->show ();
	} else
		QMessageBox::critical (this, "Error", DLG_ALLOC_ERROR_MSG);
}


//////////////////////////////////////////////////////////////////////////
// findWindow()
// -------------
//
QWidget *ApplicationWindow::findWindow (QString caption)
{
	QWidgetList windows = m_pWs->windowList ();

	for (unsigned int i = 0; i < windows.count (); ++i)
	{
		QWidget *pWindow = windows.at (i);

		if (pWindow->caption ().compare (caption) == 0)
			return pWindow;
	}

	return NULL;
}


void ApplicationWindow::windowsMenuAboutToShow ()
{
	m_pWindowsMenu->clear ();

	int cascadeId =
		m_pWindowsMenu->insertItem ("&Cascade", this, SLOT (onCascade ()));
	int tileId = m_pWindowsMenu->insertItem ("&Tile", m_pWs, SLOT (tile ()));

	int close_all_id = m_pWindowsMenu->insertItem ("Close Al&l", this,
		SLOT (closeAllWindows ()));

	m_toggleDensityId = m_pWindowsMenu->insertItem ("Show &Density charts",
		this, SLOT (onToggleChartDensity()));
	if (m_pWs->windowList ().isEmpty ())
	{
		m_pWindowsMenu->setItemEnabled (cascadeId, FALSE);
		m_pWindowsMenu->setItemEnabled (tileId, FALSE);
		m_pWindowsMenu->setItemEnabled (close_all_id, FALSE);
	}

	CATuneOptions ao;
	DWORD density = SHOW_CHART_DENSITY;
	ao.getShowChartDensity (&density);

	if (SHOW_CHART_DENSITY == density)
		m_pWindowsMenu->setItemChecked (m_toggleDensityId, true);

	m_pWindowsMenu->insertSeparator ();

	QWidgetList windows = m_pWs->windowList ();

	for (int i = 0; i < int (windows.count ()); ++i)
	{
		int id = m_pWindowsMenu->insertItem (windows.at (i)->caption (),
			this,
			SLOT (windowsMenuActivated (int)));

		m_pWindowsMenu->setItemParameter (id, i);
		m_pWindowsMenu->setItemChecked (id,
			m_pWs->activeWindow () == windows.at (i));
	}
}


void ApplicationWindow::windowsMenuActivated (int id)
{
	QWidget *w = m_pWs->windowList ().at (id);
	if (w)
	{
		w->show ();
		w->setFocus ();

	}
}


///////////////////////////////////////////////////////////////////////////////
// setSamplingState()
// ------------------
// Enables/Disables menu and tool bar items
//
bool ApplicationWindow::setSamplingState (SAMPLING_STATE State)
{
	EventMaskEncodeMap events_map;
	QString ca_result_filename = "";
	QString ca_result_dirname = "";
	QCString fPath = "";
	QCString fpath = "";
	QString session = "";
	QCString f;
	CATuneOptions ao;
	QString tiFileName = "";
	QString vmlinuxName = "";
	QDir dir;

	switch (State)
	{
        case SS_DELAY:
	{
                m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
                m_pSamplingMenu->setItemEnabled(m_SamplingMenuId[SM_PAUSE], FALSE);

                m_pStatusMsg->setText (QString("Delay for ")
                        + QString::number((unsigned int)m_pSession->startDelay)
                        +" seconds before sampling started.");
                m_SamplingState = SS_DELAY;
                break;
	}
	case SS_START_APP:
	{
		// Spawn a thread to manage all the progress of the sampling session
		m_pProgress = new ProgressMgr (m_pSession->startDelay,
						m_pSession->duration, 
						this, 
						m_pSession->launch,
						m_pSession->workDir, 
						m_pSession->stopOnAppExit,
						m_pSession->termAppOnDur);
		if(!m_pProgress)
			return false;

		if( m_pProgress->launch (m_pSession->affinity, 
				 (m_pSession->cssEnable && !m_pSession->cssUseTgid),
				  m_pSession->showTerminalEnable) != 0)
			return false;

		QObject::connect(&(m_pProgress->m_launched), SIGNAL(processExited()),
			this, SLOT(targetExit()) );

		break;
	} 
	case SS_START_PROFILE: 
	{
		//Make sure events are taken care of, before trying a run
		qApp->processEvents();

		switch (m_pSession->Trigger)
		{
		case TIMER_TRIGGER:
			if (!runTbs ())
			{
				if(m_pProgress) m_pProgress->terminate ();
				return false;
			}
			break;

		case EVENT_TRIGGER:
			if (!runEbs ())
			{
				if(m_pProgress) m_pProgress->terminate ();
				return false;
			}
			break;
		default:
			QMessageBox::information (this, "Profile type error",
				"The application is in an unstable state, "
				"please restart CodeAnalyst");
			return false;
		}

		m_pStatusMsg->setText ("Sampling Session Started.");
		m_SamplingState = SS_START_PROFILE;
		break;
	}// case SS_START_PROFILE:

	case SS_FINISHED:
	{
		bool ret = true;
		QString caSession;

		/*
		* SS_FINISHED can be repeated set, ignore the repeated state
		* change if it has been set already.
		*/
		if (m_SamplingState == SS_FINISHED 
		||  m_SamplingState == SS_IDLE) 
		{
			goto SS_FINISHED_OUT;
		}

		setCursor(Qt::WaitCursor);
		m_pStatusMsg->setText ("Stopping daemon");
		m_opIf.do_kill_daemon ();
		unsetCursor();

		m_SamplingState = SS_IDLE;

		m_pStatusMsg->setText ("Processing sampled session");

		fpath = m_pCawFile->getPath ();
		fpath.truncate (fpath.findRev (XPS_PATH_SLASH) + 1);

		if(m_pProgress)
		{
			m_pProgress->stopNow();
			if(m_pProgress->getExitStatus() != 0)
			{
				QString msg = QString(
					"WARNING: Target application exit with status ") + 
					QString::number(m_pProgress->getExitStatus()) + ".\n\n";
			/*	
				if(!m_pProgress->getStdout().isEmpty())
				{
					msg += "Stdout:\n" + m_pProgress->getStdout() + "\n";
				}
			*/	
				if(!m_pProgress->getStderr().isEmpty())
				{
					msg += "Stderr:\n" + m_pProgress->getStderr() + "\n";
				}

				msg += "Please check session setting and rerun the profile.\n";

				QMessageBox::warning(this, "CodeAnalyst Warning:", msg);
			}
			m_pProgress->terminate();
			DELETE_IF_NOT_NULL(m_pProgress);
			m_pProgress = NULL;
		}
		qApp->setOverrideCursor (QCursor (Qt::WaitCursor));
		qApp->restoreOverrideCursor ();

		// Make the new .tbp file
		f = m_pCawFile->getDir ();

		/// get the name of the sampling file we ened to create
		ca_result_dirname = (QString) fpath + m_pSession->sessionFile;
		ca_result_dirname +=  DIR_FILE_EXT ;
		//////////////////////////////////////////
		dir.mkdir(ca_result_dirname );
		caSession = ca_result_dirname;
		ca_result_filename = ca_result_dirname + "/" + m_pSession->sessionFile;

		// Separate the type of samples
		switch (m_pSession->Trigger)
		{
		case TIMER_TRIGGER:
			f.append(m_pSession->sessionFile);
			m_pSession->getEventContainer()->enumerateAllEvents(events_map);
			break;
		case EVENT_TRIGGER:
			f.append (m_pSession->sessionFile);
			m_pSession->getEventContainer()->enumerateAllEvents(events_map);
			break;
		default:
			//should have already returned false...
			ret = false;
			goto SS_FINISHED_OUT;
			break;
		}

		session = OP_SAMPLES_CURRENT_DIR;

		if (!createOprofileTranslateObjects()) {
			QMessageBox::information (this, "Translate Error",
				"failed to create translate object");
			ret = false;
			goto SS_FINISHED_OUT;	
		}

		/*****************************************************************
		* START: Translating Oprofile Samples Phase
		*/	
		m_pTranslate->init( session,
			XpFileContains("/proc/cpuinfo", "processor"),
			caSession, events_map, m_pCaTransDisplay);
		
		if (NULL != m_pTranslateProgressDlg)
			m_pTranslateProgressDlg->show();

		m_processFilter.clear();
		
		if(m_pSession->filterEnable)
			m_processFilter = QStringList::split(",", m_pSession->filterList);

		if (m_pTranslate->translate_op_to_ca(m_this_cpuFamily,
							m_this_cpuModel,
							m_processFilter, 
							ca_result_filename))
		{

			// CSS conversion
			if (m_pSession->cssEnable
			&& !cssConversion(ca_result_dirname)) {
				QMessageBox::critical(this, "CSS Conversion Error",
				QString("Failed to convert CSS data to") +
				"kcachegrind format.\n");
			}

			// Copy the oprofiled.log file
			QFile log (OP_LOG_FILE);
			if (log.exists()) {
				QStringList cmd;
				cmd.append("cp");
				cmd.append("-f");
				cmd.append(OP_LOG_FILE);
				cmd.append(ca_result_dirname);
				QString stdOut, stdErr;	
				int status = 0;	
				ca_exec_command(cmd, stdOut, stdErr, status);
			}

			// Display the new session
			m_pSession->Cpus = XpGetNumCpus ();
			m_pCawFile->addSession (m_pSession);
			m_pCawFile->saveCawFile ();
			initProjectWindow ();

			// Display the system data
			onSessionDblClicked (m_pSession->Trigger, m_pSession->sessionName );
		}
		else
		{
			QMessageBox::information (this, "CodeAnalyst Warning",NO_SAMPLE_MSG);
			folderRemove(ca_result_dirname );
		}
		/*****************************************************************
		* END: Translating Oprofile Samples Phase
		*/	

SS_FINISHED_OUT:
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
		m_pSamplingMenu->setItemChecked (m_SamplingMenuId[SM_PAUSE], FALSE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], FALSE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], FALSE);

		m_SamplingToolId[SM_START]->setEnabled (FALSE);
		m_SamplingToolId[SM_PAUSE]->setOn (FALSE);
		m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
		m_SamplingToolId[SM_STOP]->setEnabled (FALSE);

		// Now we allow seesion import.
		m_pFileMenu->setItemEnabled (m_ImportDataId, true);

		if (!ret)
			return false;

		// Fall-through!!!
	}// case SS_FINISHED:

	case SS_IDLE:
	{
		m_pProfileBox->setEnabled (true);
		m_ToolsToolId[TM_SETTINGS]->setEnabled( true );
		m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_SETTINGS], true);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], TRUE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], FALSE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], FALSE);
		m_SamplingToolId[SM_START]->setEnabled (TRUE);
		m_SamplingToolId[SM_STOP]->setEnabled (FALSE);
		m_SamplingToolId[SM_PAUSE]->setEnabled (FALSE);
		m_pFileMenu->setItemEnabled (m_ImportDataId, true);

		// Reset progress
		m_pStatusProgress->reset ();

		m_pStatusMsg->setText ("Sampling Session Idle.");

		m_SamplingState = SS_IDLE;
		break;
	}// case SS_IDLE:

	case SS_PAUSED:
	{
		m_opIf.do_pause_daemon();

		//show controls...
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], TRUE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], TRUE);
		m_pSamplingMenu->setItemChecked (m_SamplingMenuId[SM_PAUSE], TRUE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
		m_SamplingToolId[SM_PAUSE]->setDown (TRUE);

		m_SamplingToolId[SM_STOP]->setEnabled (TRUE);
		m_SamplingToolId[SM_PAUSE]->setEnabled (TRUE);
		m_SamplingToolId[SM_PAUSE]->setDown (TRUE);
		m_SamplingToolId[SM_START]->setEnabled (FALSE);

		m_pStatusMsg->setText ("Sampling Session Paused...  Waiting for resume...");

		m_SamplingState = SS_PAUSED;
		break;
	}// case SS_PAUSED:

	case SS_RESUMED:
	{
		m_opIf.do_resume_daemon();	
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_STOP], TRUE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_PAUSE], TRUE);
		m_pSamplingMenu->setItemChecked (m_SamplingMenuId[SM_PAUSE], FALSE);
		m_pSamplingMenu->setItemEnabled (m_SamplingMenuId[SM_START], FALSE);
		m_SamplingToolId[SM_STOP]->setEnabled (TRUE);
		m_SamplingToolId[SM_PAUSE]->setEnabled (TRUE);
		m_SamplingToolId[SM_PAUSE]->setOn (FALSE);
		m_SamplingToolId[SM_PAUSE]->setDown (FALSE);
		m_SamplingToolId[SM_START]->setEnabled (FALSE);

		if(m_pProgress) m_pProgress->wakeUp();

		m_pStatusMsg->setText ("Sampling Session Resumed.");

		m_SamplingState = SS_START_PROFILE;
		break;
	}// case SS_RESUMED:

	default:
		//for now, ignore other states
		break;
	}// switch (State)

	m_prevState = State;
	
	qApp->processEvents();

	return true;
}


////////////////////////////////////////////////////////////////////////
// closeAllWindows()
// -----------------
// Closes all open windows in the workspace
//
void ApplicationWindow::closeAllWindows ()
{
	// Close all open windows
	QWidgetList windows = m_pWs->windowList ();

	for (int i = 0; i < int (windows.count ()); ++i)
	{
		windows.at (i)->close ();
	}
}


///////////////////////////////////////////////////////////////////
// resizeAllWindows()
// ------------------
// Resizes all windows in the workspace to a predefined size.
// This is used when the cascade option has been selected.
//
void ApplicationWindow::resizeAllWindows (QSize NewSize)
{
	int numWnd = m_pWs->windowList ().count ();

	for (int i = 0; i < numWnd; ++i)
	{
		QWidget *pWnd = m_pWs->windowList ().at (i);

		pWnd->resize (NewSize);
	}
}


///////////////////////////////////////////////////////////////////////
// LoadFile()
// ----------
// Initializes the CawFile class and reads some of the information
// Initializes the Project Window with the names of the sampling sessions
//
void ApplicationWindow::LoadFile (QString FileName)
{
	bool isOk;
	onFileClose (&isOk);

	if(!isOk)
		return;	

	if (NULL != m_pCawFile) {
		delete m_pCawFile;
		m_pCawFile = NULL;
	}

	m_pCawFile = new CawFile (FileName);
	if (NULL == m_pCawFile) {
		QMessageBox::information (this, "Error",
			"Could not allocate memory for the CawFile");
		return;
	}

	if (!m_pCawFile->openCawFile ()) {
		QMessageBox::information (this, "CAW file Error",
			QString("Could open CawFile:\n") + FileName);
		return;
	}

	// Initialize the Project Window
	initProjectWindow ();

	m_pCawFile->getPath ();

	// Format the Path name for windows if necessary
	QString caption;
	caption.sprintf ("Advanced Micro Devices - CodeAnalyst [%s]",
		m_pCawFile->getPath ().data ());

	setCaption (caption);

	closeAllWindows ();

	// Enable Tools | Project Options Menu
	m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_SETTINGS], TRUE);
	m_ToolsToolId[TM_SETTINGS]->setEnabled( TRUE );
	m_pToolsMenu->setItemEnabled (m_ToolsMenuId[TM_DIFFANALYST], TRUE);
	m_ToolsToolId[TM_DIFFANALYST]->setEnabled( TRUE );

	// Enable Import
	m_pFileMenu->setItemEnabled (m_ImportDataId, true);

	// Enable Save
	m_pFileMenu->setItemEnabled (m_SaveId, true);
	m_SaveButt->setEnabled (true);

	// Enable Close
	m_pFileMenu->setItemEnabled (m_CloseId, true);

	setSamplingState (SS_IDLE);

	// Update MRU file
	updateMruFile (m_pCawFile->getPath ());

	//get the last profileType
	QString profile = m_pCawFile->getLastProfile ();
	if (!profile.isEmpty ()) 
		for (int i = m_pProfileBox->count()-1 ; i >= 0 ; i--)
			if(m_pProfileBox->text(i) == profile)
				m_pProfileBox->setCurrentItem (i);
}


////////////////////////////////////////////////////////////////////////////////////////
// ApplicationWindow::removeMruFile()
// ------------------------------------
//
void ApplicationWindow::removeMruFile (QString filePath)
{
	MruList::Iterator it;
	QString newMruList = "";

	// Remove all item from the menu
	for (it = m_MruList.begin (); it != m_MruList.end (); ++it)
	{
		int temp = (*it).index;
		m_pFileMenu->removeItem (temp);
	}

	// Remove the entry with filePath
	it = m_MruList.begin ();
	for (; it != m_MruList.end (); ++it)
	{
		if ((*it).filePath == filePath)
		{
			m_MruList.remove (it);
			break;
		}
	}

	if (!m_MruList.isEmpty ())
	{
		for (it = m_MruList.begin (); it != m_MruList.end (); ++it)
		{
			int temp = m_pFileMenu->insertItem ((*it).filePath);
			(*it).index = temp;
		}
	}
}


//////////////////////////////////////////////////////////////////////////////////////
// OnWindowShown()
// ---------------
//
void ApplicationWindow::onWindowActivated (QWidget * pWnd)
{
	CSessionNavigator *p_mdi = (CSessionNavigator *) pWnd;
	if (NULL == pWnd)
		m_pFileMenu->setItemEnabled (m_ExportDataId, false);
	else
	{
		if (p_mdi->isVisible ())
		{
			if (NULL == p_mdi->getCurrentView())
				m_pFileMenu->setItemEnabled (m_ExportDataId, false);
			else
				p_mdi->onCurrentTabChanged (p_mdi->getCurrentView ());
		}

		QWidgetList windows = m_pWs->windowList ();
	}
}


void ApplicationWindow::onSessionRenamed (TRIGGER trigger, QString oldName)
{
	SESSION_OPTIONS opts;
	QString  caption ;
	QWidget *p_window;

	QString newName;

	//tryagain:
	while(1) {
		bool isOk = false;
		newName = QInputDialog::getText( "Enter new name for the session", 
			"Rename Session '" + oldName + "'.",
			QLineEdit::Normal,oldName,&isOk,this );

		if (!isOk)
			return;	

		if( newName.isEmpty()) {
			QMessageBox::critical(this,"Error","Please specify session name.\n");
			continue;
		}

		if(newName.compare(oldName) == 0)
			return;	

		QRegExp rex ("[/:\\\\]");
		if (rex.search (newName) != -1) {
			QMessageBox::critical (this, "CodeAnalyst Error",
				"The session name must not contain the characters ':', '\\', or '/'");
			continue;
		}

		if( m_pCawFile->IsSessionNameTaken (trigger, newName) != 0 ) {
			QMessageBox::information( this, "CodeAnalyst Error",
				"That session name is already taken." );
			continue;
		}
		break;
	}

	QString newSessionDir = m_pCawFile->getDir() + newName;
	switch (trigger)
	{
	default:
	case TIMER_TRIGGER:
		newSessionDir += TBS_FILE_EXT;
		break;
	case EVENT_TRIGGER:
		newSessionDir += EBS_FILE_EXT;
		break;
	}
	newSessionDir += DIR_FILE_EXT;
	if (QFile::exists (newSessionDir))
	{
		if (QMessageBox::No == QMessageBox::question (this, "CodeAnalyst Error",
			"The session directory alread exists, do you want to overwrite it?",
			QMessageBox::Yes, QMessageBox::No))
		{
			return;
		}
	}

	if (!m_pCawFile->getSessionCfg (trigger, oldName, &opts))
		return;

	m_pCawFile->renameSession (trigger, oldName, newName);

	caption = oldName + " - " + QString (opts.sessionFile);
	p_window = findWindow( caption );

	//This gets the renamed data
	m_pCawFile->getSessionCfg (trigger, newName, &opts);

	//If the session window is open
	if( NULL != p_window)
	{
		p_window->close ();
		onSessionDblClicked (trigger, newName );
	}

	m_pCawFile->saveCawFile();

	initProjectWindow();
}  //ApplicationWindow::onSessionRenamed


void ApplicationWindow::onTbsSessionProperties (QString SessionName)
{
	TBP_OPTIONS opts;

	if( !m_pCawFile->getSessionDetails (SessionName, &opts ) ) {
		QMessageBox::information( this, "Error",
			"Session Name could not be propogated to the file." );
		return;
	}

	SessionSettingDlg * pDlg = new SessionSettingDlg (m_pCawFile, &m_eventFile, this);
	if (NULL == pDlg) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		return;
	}

	pDlg->initPropertyView(SessionName, TIMER_TRIGGER);
	pDlg->exec();
}


void ApplicationWindow::onEbsSessionProperties (QString SessionName)
{
	EBP_OPTIONS opts;

	if( !m_pCawFile->getSessionDetails (SessionName, &opts ) ) {
		QMessageBox::information( this, "Error",
			"Session Name could not be propogated to the file." );
		return;
	}

	SessionSettingDlg * pDlg = new SessionSettingDlg (m_pCawFile, &m_eventFile, this);
	if (NULL == pDlg) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		return;
	}

	pDlg->initPropertyView(SessionName, EVENT_TRIGGER);
	pDlg->exec();
	
}


void ApplicationWindow::OnCopySessionToCurrent (TRIGGER trigger, QString SessionName)
{
	switch (trigger)
	{
	case TIMER_TRIGGER:
		{
			TBP_OPTIONS opts;
			if( m_pCawFile->getSessionDetails (SessionName, &opts ) )
				m_profiles.setProfileConfig (CURRENT_TIME, &opts);
			//update current
			m_pProfileBox->setCurrentText (CURRENT_TIME);
			m_pCawFile->setLastProfile (CURRENT_TIME);
			break;
		}
	case EVENT_TRIGGER:
		{
			EBP_OPTIONS opts;
			if( m_pCawFile->getSessionDetails (SessionName, &opts ) ) {
				if (opts.getEventContainer()->hasIbs()
				&&  opts.getEventContainer()->countPmc() == 0) {
					m_profiles.setProfileConfig (CURRENT_IBS, &opts);
					//update current
					m_pProfileBox->setCurrentText (CURRENT_IBS);
					m_pCawFile->setLastProfile (CURRENT_IBS);
				} else {
					m_profiles.setProfileConfig (CURRENT_EVENT, &opts);
					//update current
					m_pProfileBox->setCurrentText (CURRENT_EVENT);
					m_pCawFile->setLastProfile (CURRENT_EVENT);
				}
			}
			break;
		}
	default:
		break;
	}
}//ApplicationWindow::OnCopySessionToCurrent


void ApplicationWindow::OnProfileChange (const QString &profile)
{
	m_pCawFile->setLastProfile (profile);
}


//called when the menu item is selected
void ApplicationWindow::OnViewManage ()
{
	//create new ViewCfgDlg
	ViewCfgDlg *pViewCfgDlg = new ViewCfgDlg (this);
	QString lastView = "";
	RETURN_IF_NULL (pViewCfgDlg, this);

	pViewCfgDlg->setCaption("Global View Management");	
	pViewCfgDlg->setViews (QString::null,m_this_cpuFamily,m_this_cpuModel,true);
	pViewCfgDlg->setCurrentViewNamePtr(&lastView);

	if (QDialog::Accepted == pViewCfgDlg->exec())
	{
		emit shownChanged(lastView);
	}
}


void ApplicationWindow::OnOpenDiffAnalyst(DiffSessionInfo *sess)
{	
	QStringList list;
	NewDiffSessionDlg *pDiff = new NewDiffSessionDlg(m_pCawFile->getPath(), this);
	pDiff->init(sess);
	if (QDialog::Accepted == pDiff->exec())
	{
		list = pDiff->getDiffSession();
		QStringList cmd;
		cmd.append(QString(CA_BIN_DIR) + "/DiffAnalyst");
		cmd.append("-0");
		cmd.append(list[0]);
		cmd.append("-1");
		cmd.append(list[1]);

//		fprintf(stderr,"%s\n", cmd.join(" ").ascii());

		qApp->setOverrideCursor (QCursor (Qt::WaitCursor));
		QString stdOut, stdErr;
		int status = 0;
		ca_exec_command (cmd, stdOut, stdErr, status, false);
		qApp->restoreOverrideCursor ();
	}
}


void ApplicationWindow::OnOpenKcachegrind(QString sessionDirName)
{
	QString stdOut, stdErr;
	int status = 0;
	QStringList cmd;
	
	QString dir = m_pCawFile->getDir();
	if (dir.isEmpty() || sessionDirName.isEmpty())
		return;

	QString cgFile = dir + "/" + sessionDirName + "/callgrind.out";
	if (!QFile::exists(cgFile)) {
		QMessageBox::critical (this, "CodeAnalyst Error", 
			"Call-Stack Sampling file (" + cgFile + ") not found.\n"
			+ "Please check CSS setting and rerun the profile.\n");
		return;
	}

	cmd.append("which");
	cmd.append("kcachegrind");
	if (ca_exec_command (cmd, stdOut, stdErr, status) != 0
	||  status != 0) {
		QMessageBox::critical (this, "CodeAnalyst Error", 
			QString("kcachegrind not found. Please make sure it is installed\n")
			+ " in $PATH variable.\n");
		return;
	}

	cmd.clear();
	cmd.append("kcachegrind");
	cmd.append(cgFile);

	//fprintf(stderr,"%s\n", cmd.join(" ").ascii());

	qApp->setOverrideCursor (QCursor (Qt::WaitCursor));
	ca_exec_command (cmd, stdOut, stdErr, status, false);
	qApp->restoreOverrideCursor ();
}

void ApplicationWindow::onDataViewChanged (QString exportString, QListView * pList)
{
	if (exportString.isEmpty ())
	{
		m_pFileMenu->setItemEnabled( m_ExportDataId, false );
	} else {
		m_pFileMenu->changeItem( m_ExportDataId, exportString);
		m_pFileMenu->setItemEnabled( m_ExportDataId, true );
		m_pExportList = pList;
	}
}


void ApplicationWindow::onExportData ()
{
	QString txt;
	QString file_path = QFileDialog::getSaveFileName (m_pCawFile->getDir (),
		"Comma Seperated Value (*.csv)",
		this);
	QFile *file = NULL;
	QTextStream stream;

	if (file_path.isEmpty ())
		return;
	if (NULL == m_pExportList)
		return;

	if (".csv" != file_path.right (4))
		file_path.append (".csv");

	file = new QFile (file_path);

	if (NULL == file)
	{
		QMessageBox::critical (this, "Memory error", "Insufficient memory");
		return;
	}
	// open the file for writing
	if (!file->open (IO_ReadWrite | IO_Translate | IO_Truncate))
	{
		QMessageBox::critical (this, "Error",
			"The file could not be written to.");
		return;
	}
	stream.setDevice (file);

	// put the column headers
	for (int i = 0; i < m_pExportList->columns (); ++i)
		stream << m_pExportList->columnText (i) << ",";

	// forgot to put this extra carriage return
	// after the column headers.
	stream << endl;

	// enumerate the list view data
	QListViewItem *pItem = m_pExportList->firstChild ();
	while (NULL != pItem)
	{
		for (int i = 0; i < pItem->listView ()->columns (); ++i)
		{
			stream << "\"" << pItem->text (i) << "\",";
		}

		stream << endl;
		pItem = pItem->itemBelow ();
	}

	stream.unsetDevice ();
	file->close ();

	delete file;
}


////////////////////////////////////////////////////////////////////////////
// ApplicationWindow::updateMruItemIndex()
// -----------------------------------
//
void ApplicationWindow::updateMruItemIndex (QString file, int index)
{
	MruList::Iterator it;

	for (it = m_MruList.begin (); it != m_MruList.end (); ++it)
	{
		// Remove the item if it is already on the list
		if ((*it).filePath == file)
		{
			(*it).index = index;
			break;
		}
	}
}


void ApplicationWindow::insertMruItems ()
{
	QString mru_list = 0;
	CATuneOptions ao;
	MruEntry entry;
	MruList::Iterator it;

	if (!ao.getMruFileList (mru_list))
	{
		mru_list = EMPTY_MRU_LIST;
	}

	parseMruString (mru_list.data ());

	if (m_MruList.isEmpty () == FALSE)
		m_pFileMenu->insertSeparator ();

	for (it = m_MruList.begin (); it != m_MruList.end (); ++it)
	{
		(*it).index = m_pFileMenu->insertItem ((*it).filePath);
	}
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ApplicationWindow()::parseMruString()
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Takes a string of the form %s;%s;%s;%s;%s; and extracts the strings
* from the expression
*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
*/
void ApplicationWindow::parseMruString (const char *mrustring)
{
	int lastdelimiter = 0;
	int nextdelimiter = 0;
	QString line = mrustring;
	QString onefile;
	MruEntry entry;

	for (int i = 0; i < MAX_MRU_ITEMS; i++)
	{
		// first string
		nextdelimiter = line.find (";", lastdelimiter);
		entry.filePath = line.mid (lastdelimiter,
			nextdelimiter - lastdelimiter);
		if (entry.filePath != "E")
		{
			entry.index = 0;
			m_MruList.append (entry);
		}

		lastdelimiter = nextdelimiter + 1;
	}
}


void ApplicationWindow::onAboutToQuit ()
{
	closeAllWindows ();
	
	// Kill monitoring thread before exit
	if (m_pOprofileDaemonDockView) {
		m_pOprofileDaemonDockView->hide();
		delete m_pOprofileDaemonDockView;
		m_pOprofileDaemonDockView = NULL;
	}

	if (m_pOprofileDriverDockView) {
		m_pOprofileDriverDockView->hide();
		delete m_pOprofileDriverDockView;
		m_pOprofileDriverDockView = NULL;
	}

	saveMRUToReg ();

	setSamplingState (SS_IDLE);

	if (NULL != m_pCawFile)
		delete m_pCawFile;
/*
	if (NULL != m_pWs)
		delete m_pWs;

	if (NULL != m_pFileTools)
		delete m_pFileTools;

	if (NULL != pSamplingToolBar)
		delete pSamplingToolBar;

	if (NULL != m_pWindowsMenu)
		delete m_pWindowsMenu;

	if (NULL != m_pSamplingMenu)
		delete m_pSamplingMenu;

	if (NULL != m_pToolsMenu)
		delete m_pToolsMenu;

	if (NULL != m_pHelpMenu)
		delete m_pHelpMenu;

	if (m_pFileMenu)
		delete m_pFileMenu;
*/
}


void ApplicationWindow::saveMRUToReg ()
{
	int i = 0;
	MruList::Iterator it = m_MruList.begin ();
	CATuneOptions ao;
	QString newMruList;

	for (i = 0, it = m_MruList.begin ();
		it != m_MruList.end () && i < MAX_MRU_ITEMS; ++it)
	{
		newMruList.append ((*it).filePath + QString (";"));
		++i;
	}

	// pad with empty entries
	while (i < (MAX_MRU_ITEMS))
	{
		newMruList.append ("E;");
		++i;
	}

	ao.setMruFileList (newMruList);
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ApplicationWindow::updateMruFile()
* ----------------------------------
* Adds the new path to the most-recently-used file list and
* saves the list out to the registry
*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
void ApplicationWindow::updateMruFile (QString NewFilePath)
{
	MruEntry entry;

	MruList::Iterator it = m_MruList.begin ();
	int i = 0;

	if (0 != m_MruList.count ())
	{
		// Remove all item from the menu
		for (; it != m_MruList.end (); ++it)
		{
			m_pFileMenu->removeItem ((*it).index);
		}
	}
	else
	{
		m_pFileMenu->insertSeparator ();
	}

	// Check if NewFilePath is already in the list
	MruList::Iterator itDel;
	if (TRUE == mruFileContains (NewFilePath))
	{
		itDel = m_MruList.begin ();
		for (; itDel != m_MruList.end (); ++itDel)
		{
			// Remove the item if it is already on the list
			if ((*itDel).filePath == NewFilePath)
			{
				m_MruList.remove (itDel);
				break;
			}
		}
	}
	else
	{
		if (MAX_MRU_ITEMS <= m_MruList.count ())
		{
			itDel = m_MruList.fromLast ();
			if (itDel != m_MruList.end ())
				m_MruList.remove (itDel);
		}

	}

	// Add the new entry to the beginning of the list
	entry.filePath = NewFilePath;
	entry.index = 0;
	m_MruList.prepend (entry);

	for (it = m_MruList.begin ();
		it != m_MruList.end () && i < MAX_MRU_ITEMS; ++it)
	{
		(*it).index = m_pFileMenu->insertItem ((*it).filePath);
	}
}


/////////////////////////////////////////////////////////////////////////
// ApplicationWindow::onMruItemSelected()
// --------------------------------------
//
void ApplicationWindow::onMruItemSelected (int id)
{
	MruList::Iterator it = m_MruList.begin ();
	int i = 0;

	for (; it != m_MruList.end () && i < MAX_MRU_ITEMS; ++it, i++) {
		if ((*it).index == id) {
			QString fileName = (*it).filePath;

			if (!QFile::exists (fileName)) {
				QMessageBox::information (this, "Error", fileName + 
					"\nFile does not exist.");
				removeMruFile (fileName);
				return;
			}
			LoadFile (fileName);
			return;
		}
	}
}


////////////////////////////////////////////////////////////////////////////////////////
// ApplicationWindow::mruFileContains()
// ------------------------------------
//
bool ApplicationWindow::mruFileContains (QString FilePath)
{
	MruList::Iterator it = m_MruList.begin ();

	while (it != m_MruList.end ())
	{
		if ((*it).filePath == FilePath)
			return TRUE;

		++it;
	}

	return FALSE;
}


float ApplicationWindow::translateMSToTicks (float ms)
{
	return m_tick_per_sec / 1000 * ms;
}


BOOL ApplicationWindow::startDaemon(bool vmlinux,
				QString vmlinux_dir, 
				int buffer_size,
				int watershed_size,
				int cpu_buf_size)
{
	BOOL rt = false;
	int oie_rt = OIE_OK;
	QString errMsg = "Oprofile daemon failed to start.\nReason:\n\n";
	EBP_OPTIONS *pEventSession = static_cast <EBP_OPTIONS *> (m_pSession);
	
	/* Check watershed size*/
	if(buffer_size <= watershed_size) {
		errMsg += QString("Invalid OProfile event buffer configuration.\n")
			+ "The watershed size should be less than event buffer size.\n";
		oie_rt = -OIE_ERR;
	}

	if (oie_rt == OIE_OK) {
		if(m_pSession->Trigger == EVENT_TRIGGER)
			oie_rt = m_opIf.do_start_daemon (vmlinux, 
							vmlinux_dir,
							buffer_size, 
							watershed_size, 
							cpu_buf_size, 
							pEventSession->msMpxInterval);
		else
			oie_rt = m_opIf.do_start_daemon (vmlinux, 
							vmlinux_dir,
							buffer_size, 
							watershed_size, 
							cpu_buf_size, 
							0);
	}


	/* ERROR HANDLING */
	if (oie_rt != OIE_OK) {
		// At this point we have already launched progress manager,
		// and the application. If the error occur, stop them immediately.
		if(m_pProgress)
		{
			m_pProgress->stopNow();
			m_pProgress->terminate ();
		}

		switch(oie_rt)
		{
		case -OIE_DAEMON_RUNNING:
			errMsg += "Oprofile daemon is currently running.\n"
				  "Please make sure the profile is not running.\n\n"
				  "Do you want to kill it?";
			if(QMessageBox::Yes == QMessageBox::critical(this, "CodeAnalyst Error", 
				errMsg,
				QMessageBox::Yes,
				QMessageBox::No))
			{
				m_opIf.do_kill_daemon ();
			}
			break;
		case -OIE_LOCK_EXIST:
			errMsg += QString("Stale /var/lib/oprofile/lock exists ") +
				  "and no Oprofile daemon currently running.\n" +
				  "Do you want to remove the lock file?";
			if(QMessageBox::Yes == QMessageBox::critical(this, "CodeAnalyst Error", 
				errMsg,
				QMessageBox::Yes,
				QMessageBox::No))
			{
				m_opIf.remove_lock_file();
			}
			break;
		case -OIE_DAEMON_NOTSTART:
		case -OIE_DRV:
		case -OIE_ERR:
		default:
			errMsg += m_opIf.get_std_err();
			QMessageBox::critical(this, "CodeAnalyst Error", errMsg);
			break;	
		};
	}else{
		rt = true;
	}
	return rt;
}


bool ApplicationWindow::runTbs ()
{
	TBP_OPTIONS *pTbpSession = static_cast <TBP_OPTIONS *> (m_pSession);
	BOOL rt;
	float count = translateMSToTicks (pTbpSession->msInterval);
	
	// Event "unhalted cycles" is used to simulate TBP.
	PmcEvent pe;
	pe.select = 0x76;
	// Converting from Float to unsigned long long
	pe.count  = count;
	pe.opName = QString("CPU_CLK_UNHALTED");
	m_pSession->getEventContainer()->add(pe);
	m_opIf.set_op_events (m_pSession->getEventContainer());

	rt = startDaemon(pTbpSession->vmlinuxEnable, 
			pTbpSession->vmlinux,
			pTbpSession->opBuffer, 
			pTbpSession->opWaterShed, 
			pTbpSession->opCpuBuffer);

	return rt;
} //bool ApplicationWindow::runTbs 


bool ApplicationWindow::runEbs ()
{
	CpuEvent event;
	EBP_OPTIONS *pEventSession = static_cast <EBP_OPTIONS *> (m_pSession);

	if(!m_opIf.set_op_events (pEventSession->getEventContainer())) {
		QMessageBox::critical(this,"CodeAnalyst Error",
			QString("ERROR:\n")
			+ "Failed to set op events.\n");	
		return false;
	}
		

	if(!startDaemon(pEventSession->vmlinuxEnable, 
			pEventSession->vmlinux,
			pEventSession->opBuffer, 
			pEventSession->opWaterShed, 
			pEventSession->opCpuBuffer)
	)
		return false;
	
	return true;
} //ApplicationWindow::runEbs ()


void ApplicationWindow::onImportData ()
{
	bool ret = false;

	ImportWizard * import_wizard = new ImportWizard(this);

	// Setup Process Filter list for the import wizard
	RUN_SETTING * pRunSetting = m_pCawFile->getRunSetting(m_pCawFile->getLastRunSettingName());
	if (pRunSetting)
		import_wizard->setProcessFilter(QStringList::split(",", pRunSetting->filterList));	

	if (QDialog::Rejected == import_wizard->exec())
		return;

	// Setup ImportController Session
	m_importController.setCawFile(m_pCawFile);

	// Setup TranslationDlg
	if (!createOprofileTranslateObjects()) {
		QMessageBox::information (this, "Translate Error",
			"failed to create translate object");
		return;
	}

	m_importController.setTranslationDisplay(m_pCaTransDisplay);
	if (NULL != m_pTranslateProgressDlg)
		m_pTranslateProgressDlg->show();

	// EBP File Import
	if(import_wizard->is_ebp_import()) {
		ret = m_importController.onImportEbpFile(
					import_wizard->get_ebp_path(),
					import_wizard->get_jit_dir_path());
			
	} 
	// XML File Import
	else if(import_wizard->is_xml_import()) {
		ret = m_importController.onImportXmlFile(
					import_wizard->get_xml_path(),
					import_wizard->get_xml_cpuinfo_path());		
	} 
	// LOCAL/REMOTE Import
	else {
		ret = m_importController.onImportLocalRemoteFile(
					import_wizard->get_op_sample_dir(),
					import_wizard->get_cpuinfo_path(),
					import_wizard->isApplyProcessFilter(),
					import_wizard->getProcessFilter(),
					import_wizard->is_remote_import());		
	}

	if(!ret)
	{
		QMessageBox::critical(this, "Error Importing Profile", 
			"There is an error in importing profile data.\n"
			"Please check your setting and try again.\n\n"
			"Reason:\n" + m_importController.getErrorMessage());
	} else {
		initProjectWindow ();
		onSessionDblClicked (m_importController.getCurrentTrigger(),
					m_importController.getCurrentSessionName());
	}
} // void ApplicationWindow::onImportData 


//===========================================================================
//onCascade

//@mfunc This is a custom function because the qt version of cascade() doesn't
//      work right.

//@comm Got the offset values from Qt::QWorkspace.cpp file

//===========================================================================
void ApplicationWindow::onCascade ()
{
	// from QWorkspace.cpp
	const int xoffset = 13;
	const int yoffset = 23;
	const int width = 640;
	const int height = 480;
	int x = 0;
	int y = 0;

	m_pWs->cascade ();
	int numWnd = m_pWs->windowList ().count ();

	for (int i = 0; i < numWnd; ++i)
	{
		QWidget *pWnd = m_pWs->windowList ().at (i);

		if (!pWnd->isHidden ())
		{
			pWnd->showNormal ();
			pWnd->parentWidget ()->setGeometry (x, y, width, height);
			if ((y + yoffset + height) <= m_pWs->height ())
			{
				x += xoffset;
				y += yoffset;
			}
			else
			{
				x = 0;
				y = 0;
			}
		}
	}
}// ApplicationWindow::onCascade

void ApplicationWindow::setDefaultSize(QWidget* pWnd)
{
	const int width = 640;
	const int height = 480;
	int x = 0;
	int y = 0;

	pWnd->showNormal ();
	pWnd->parentWidget ()->setGeometry (x, y, width, height);
}

bool ApplicationWindow::isCorrectDriverForGH()
{
	bool ret = false;
	QString line;
	QTextStream stream;
	
	if( m_this_cpuFamily == GREYHOUND_FAMILY)
	{
		QFile cpu_type("/dev/oprofile/cpu_type");
		if (!cpu_type.open(IO_ReadOnly))
			goto out;

		stream.setDevice(&cpu_type);
		line = stream.readLine();
		if( line == QString("x86-64/family10")	
		||  line == QString("x86-64/family10h"))	
			ret = true;	

		cpu_type.close();
	}else{
		ret = true;
	}
out:
	return ret;
}


void ApplicationWindow::enumerateDir(QString & dirName, PID_MAP_T & map)
{
	QDir dir(dirName, QString::null, QDir::Name, QDir::Dirs );
	QStringList dirList = dir.entryList();

	QStringList::Iterator it = dirList.begin();
	for (; it != dirList.end(); it++)
	{
		bool ok = false;
		QString s = * it;
		unsigned int pid = 0;
		pid = s.toUInt(&ok);

		if (!ok)
			continue;

		map[pid] = 0;
	}
}


void ApplicationWindow::onToggleChartDensity ()
{
	QString toggle_text;
	DWORD density;
	//Toggle here
	if (!m_pWindowsMenu->isItemChecked (m_toggleDensityId))
		density = SHOW_CHART_DENSITY;
	else
		density = NO_SHOW_CHART_DENSITY;

	//I wrapped this in this section, so that the ATuneOptions would be written
	// before the charts checked to see if they should be visible or not.
	{
		CATuneOptions ao;
		ao.setShowChartDensity (density);
	}

	m_pWindowsMenu->setItemChecked (m_toggleDensityId,
		(SHOW_CHART_DENSITY == density));

	//ideally, this signal would be connected to the density charts, however
	//due to data hiding, the signal passes through several levels.
	emit densityVisibilityChanged ();
}


//Because the dialog is non-modal and gets deleted when it's closed to prevent
// memory leaks, there is a signal when it is closed
void ApplicationWindow::onModuleProcessingClosed()
{
	m_pTranslateProgressDlg = NULL;
}


int ApplicationWindow::OnSessionSettings()
{
	if (m_SamplingState != SS_IDLE)
	{
		QMessageBox::warning (this, "CodeAnalyst Warning", "You cannot change "
			"the session options while sampling.");
		return QDialog::Rejected;
	}
	SessionSettingDlg *pDlg = new SessionSettingDlg (m_pCawFile, &m_eventFile, this);
	if (NULL == pDlg)
	{
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		return QDialog::Rejected;
	}

	//send the list of available profile configurations to the dialog
	pDlg->initFromCawFile (&m_profiles);
	int result = pDlg->exec();

	setSamplingState (SS_IDLE);

	QString profile = m_pCawFile->getLastProfile ();

	if (QDialog::Accepted == result)
	{
		m_pProfileBox->clear();
		m_pProfileBox->insertStringList (m_profiles.getListOfProfiles ());
		m_pProfileBox->setCurrentText (profile);
	}
	return result;
}


void ApplicationWindow::OnProfileManage ()
{
	ManageCfgsDlg *pManageDlg = new ManageCfgsDlg (&m_profiles, this);
	RETURN_IF_NULL (pManageDlg, this);

	//IF they changed something in the dialog box, update the display
	pManageDlg->exec();
	//reload profile list...
	m_pProfileBox->clear();
	m_pProfileBox->insertStringList (m_profiles.getListOfProfiles ());

	// Set current profile
	if(!m_pCawFile)
		return;

	QString profile = m_pCawFile->getLastProfile ();
	if (!profile.isEmpty ())
	{
		for (int i = m_pProfileBox->count()-1 ; i >= 0 ; i--)
		{
			if(m_pProfileBox->text(i) == profile)
			{
				m_pProfileBox->setCurrentItem (i);
			}
		}
	}
}

int ApplicationWindow::isCss32Bit()
{

	if (!m_pSession)
		return -1;

	// Get path
	QString path;

	if (m_pSession->cssUseTgid) {
		if (m_pSession->cssTgid > 0) {
			path = QString("/proc/") + QString::number(m_pSession->cssTgid) + "/exe";
			QFileInfo fInfo(path);
			if (fInfo.isSymLink())
				path = fInfo.readLink();	
			else
				return -1;
		} else {
			return -1;
		}
	} else { 
		path = m_pSession->launch.section('"', 1,1);
		if (path.isEmpty())
			return -1;
	}

	int bit = getBitness(path.ascii());
	if (bit == 32)
		return 1;
	else if (bit == 64)
		return 0;
	else
		return -1;
}


void ApplicationWindow::onOprofileDaemonDockViewToggle()
{
	if ((!m_pOprofileDaemonDockView)
	||  (m_pOprofileDaemonDockView &&  m_pOprofileDaemonDockView->isHidden())) {
		onInitOprofileDaemonDockView();
		m_pToolsMenu->setItemChecked(m_ToolsMenuId[TM_DAEMON_MONITOR], true);
	} else {
		m_pOprofileDaemonDockView->hide();
	}
}


void ApplicationWindow::onInitOprofileDaemonDockView()
{
	// DAEMON
	m_pOprofileDaemonDockView = new OprofileDaemonDockView(this, "OprofileDaemonDockView");
	if(m_pOprofileDaemonDockView == NULL) return;
	
	moveDockWindow (m_pOprofileDaemonDockView, Qt::DockBottom);
	connect(m_pOprofileDaemonDockView, SIGNAL(oprofileDockViewNoShow()),
		this, SLOT(onOprofileDaemonDockViewNoShow()));
}


void ApplicationWindow::onOprofileDriverDockViewToggle()
{
	if ((!m_pOprofileDriverDockView)
	||  (m_pOprofileDriverDockView &&  m_pOprofileDriverDockView->isHidden())) {
		onInitOprofileDriverDockView();
		m_pToolsMenu->setItemChecked(m_ToolsMenuId[TM_DRIVER_MONITOR], true);
	} else {
		m_pOprofileDriverDockView->hide();
	}
}


void ApplicationWindow::onInitOprofileDriverDockView()
{
	// DRIVER
	m_pOprofileDriverDockView = new OprofileDriverDockView(this, "OprofileDriverDockView");
	if(m_pOprofileDriverDockView == NULL) return;

	moveDockWindow (m_pOprofileDriverDockView, Qt::DockBottom);
	connect(m_pOprofileDriverDockView, SIGNAL(oprofileDockViewNoShow()),
		this, SLOT(onOprofileDriverDockViewNoShow()));
}


void ApplicationWindow::onOprofileDaemonDockViewNoShow()
{
	if (!m_pOprofileDaemonDockView)
		return;
	m_pToolsMenu->setItemChecked(m_ToolsMenuId[TM_DAEMON_MONITOR], false);
	delete m_pOprofileDaemonDockView;
	m_pOprofileDaemonDockView = NULL;
}

void ApplicationWindow::onOprofileDriverDockViewNoShow()
{
	if (!m_pOprofileDriverDockView)
		return;
	m_pToolsMenu->setItemChecked(m_ToolsMenuId[TM_DRIVER_MONITOR], false);
	delete m_pOprofileDriverDockView;
	m_pOprofileDriverDockView = NULL;
}
