//$Id: TimerCfg.h 17169 2009-10-14 18:11:41Z ssuthiku $
//  This is our derivative of the iTimerCfg.ui
/**
*   (c) 2003-2006 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/

#ifndef TIMER_CFG_H
#define TIMER_CFG_H

#include <qstring.h>
#include "ITimerCfg.h"
#include "cawfile.h"
#include "ProfileCollection.h"
#include "helperAPI.h"


class TimerCfgDlg : public ITimerCfg
{ 
	Q_OBJECT

public:
	TimerCfgDlg ( QWidget* parent = 0, const char* name = 0, bool modal = true,
		WFlags fl = WStyle_Customize | WStyle_DialogBorder | WStyle_Title );
	~TimerCfgDlg ();

	void setProperties (TBP_OPTIONS *pSession);
	void setProfile (ProfileCollection *pProfiles, QString name);
	bool wasModified ();

public slots:
	virtual void onOk ();
	void onModified ();

private:
	QString m_profileName;
	ProfileCollection *m_pProfiles;
	bool m_modified;
	unsigned int m_tick_per_sec;
};
#endif
