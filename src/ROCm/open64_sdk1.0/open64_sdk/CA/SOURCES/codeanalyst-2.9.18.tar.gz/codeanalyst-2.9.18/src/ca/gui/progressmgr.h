
//$Id: progressmgr.h,v 1.6 2006/05/15 22:09:22 jyeh Exp $
// ProgressMgr class definition

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef PROGMGR_H
#define PROGMGR_H

#include <qthread.h>
#include <qpalette.h>
#include <qmutex.h>
#include <sched.h>

class ProgressMgr : public QThread
{
public:
	ProgressMgr (unsigned int delay, unsigned int duration, 
		QObject * app, QString program, QString work_dir,
		bool stop_on_app, bool break_after);

	~ProgressMgr();
	void goToSleep();
	void wakeUp();
	void stopNow();
	int launch(AffinityMask_t afMask, bool setCssTgid = false, bool showTerminal = false);
	void cleanup();
	int getExitStatus(){ return m_exitStatus;};
	QString getStdout() { return m_stdout;};
	QString getStderr() { return m_stderr;};
	int getTgid() {return m_tgid;};


#if QT_3_0 == 1
	virtual void terminate();
#endif

	QProcess	m_launched;

private:
	//static for pthreads
	void run ();
	void doDelay ();

	bool launchApplication(AffinityMask_t afMask, bool showTerminal = false);
	void helpSetAffinityMask(cpu_set_t *set, AffinityMask_t afMask);
	void storeStatusStdoutStderr();

private:
	QMutex          m_mutex;
	unsigned int	m_delay;
	unsigned int	m_duration;
	bool		m_sleep;
	bool		m_term;
	bool		m_stop_on_app;
	bool		m_break_after;
	bool		m_process_launched;
	QString		m_program;
	QString		m_work_dir;
	QObject 	*m_app;
	int		m_exitStatus;
	QString		m_stdout;
	QString		m_stderr;
	int		m_tgid;
};

#endif //#ifndef PROGMGR_H
