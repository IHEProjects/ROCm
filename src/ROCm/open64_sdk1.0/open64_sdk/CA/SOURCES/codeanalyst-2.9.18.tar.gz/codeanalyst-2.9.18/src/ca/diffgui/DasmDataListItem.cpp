
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qcolor.h>
#include "DasmDataListItem.h"

DasmDataListItem::DasmDataListItem ( ViewShownData *pViewShown, 
				int indexOffset,
				QListViewItem* pParent) 
: DataListItem (pViewShown, indexOffset, pParent)
{
	m_hlDiff = false;
	m_isInline = false;
}


void DasmDataListItem::onChangeView (DataArray data)
{
	m_dataList.clear();
	for (UINT i = 0; i < data.size(); i++) {
		appendData (data[i], *m_pPrecision);
	}
	updateShown ();
}

//void DasmDataListItem::drawData(SampleDataMap *pSampMap, 
//			UINT64 sessionTotal, 
//			bool bAssign)
void DasmDataListItem::drawData( DASM_VIEW_INFO *pDasmVI, 
			bool isPercent)
{
	setText(DASM_ADDR_COL,QString("0x") + QString::number(pDasmVI->addr,16));
	setText(DASM_BB_COL,pDasmVI->name);
	setText(DASM_CODEBYTE_COL,pDasmVI->codeByte);
	if(pDasmVI->loadCnt != 0)
		setText(DASM_LOAD_COL,"1");
	if(pDasmVI->storeCnt != 0)
		setText(DASM_STORE_COL,"1");
	if(!pDasmVI->inlineName.isEmpty())
	{
		m_isInline = true;
		setText(DASM_INLINE_COL,pDasmVI->inlineName);
	}

	setPrecision(DEFAULT_FLOAT_PRECISION);
	if(isPercent)
	{		
		DataListItem::drawPercent(pDasmVI->pSamplePercentMap);
	}else
		DataListItem::drawData(&(pDasmVI->aggSampleDataMap),0);
}

/*
QString DasmDataListItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	static int updateCounter = 0;
	QString retString;

	// Every 100 sorts, tell the app to handle gui stuff, 
	// for a max of 1 milisecond
	if (0 == (updateCounter++ % 100)) {
		qApp->processEvents (1);
	}
	if ((column < ASM_CODE_BYTES_COLUMN) || (column >  ASM_SYMBOL_COLUMN)) {
		retString.fill ('0', (20 - text (column).length()));
		retString += text (column);
	}
	else {
		retString = text (column);
	}
	return retString;
}
*/

int DasmDataListItem::compare( QListViewItem *i, int col, bool ascending) const
{
	Q_UNUSED (ascending);
	bool isOkL, isOkR;
	int ret = 0;

	if (i == NULL)	
		return ret;

	QString txtL = text(col);
	QString txtR = i->text(col);

	//--------------------------------------
	// Try converting to Int
	int left = 0;
	int right = 0;

	// Get Text Left
	if(!txtL.isEmpty())
		left = txtL.toInt(&isOkL,0);
	else{
		left = 0;
		isOkL = true;
	}

	// Get Text Right
	if(!txtR.isEmpty())
		right = txtR.toInt(&isOkR,0);
	else{
		right = 0;
		isOkR = true;
	}

	// Check if can convert to int
	if(isOkL && isOkR)	
	{
		ret = left - right; 
		//ret = right - left; // This is the reverse
		return ret ;
	}

	//--------------------------------------
	// Try converting to Float 
	// Get Text Left
	float leftF = 0;
	float rightF = 0;

	if(!txtL.isEmpty())
		leftF = txtL.toFloat(&isOkL);
	else{
		leftF = 0;
		isOkL = true;	
	}

	// Get Text Right
	if(!txtR.isEmpty())
		rightF = txtR.toFloat(&isOkR);
	else{
		rightF = 0;
		isOkR = true;	
	}

	// Check if can convert to float
	if(isOkL && isOkR)	
	{
		// NOTE: HACK. This is the reverse
		if(leftF < rightF)
			ret = -1;	
		else if(leftF == rightF)
			ret = 0;	
		if(leftF > rightF)
			ret = 1;	
		return ret ;
	}

	//--------------------------------------

	// Do Txt comparison
	ret = txtL.compare(txtR);	
	return ret;
}

void DasmDataListItem::paintCell (QPainter * p, const QColorGroup & cg, 
					  int column, int width, int align)
{
	QColorGroup cg1(cg);
	
	// Highlight Difference
	if(m_hlDiff)
	{
		cg1.setColor(QColorGroup::Base, QColor(Qt::red));
		cg1.setColor(QColorGroup::Text, QColor(Qt::white));
	} else if(m_isInline) {
		cg1.setColor(QColorGroup::Text, QColor(Qt::red));
	}else {
		cg1.setColor(QColorGroup::Text, QColor(Qt::blue));
	}

	QListViewItem::paintCell (p, cg1, column, width, align);
} //DasmDataListItem::paintCell

