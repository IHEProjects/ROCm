//$Id: sourceview.cpp,v 1.10 2005/03/28 18:08:11 jyeh Exp $
// source view tab

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qcombobox.h>
#include <qfont.h>
#include <qiconset.h>

#include "sourceview.h"
#include "atuneoptions.h"
#include "stdafx.h"
#include "EventMaskEncoding.h"
#include "auxil.h"
#include "dataagg.h"

#define _SOURCEVIEW_ICONS_
#include "xpm.h"
#undef  _SOURCEVIEW_ICONS_

//**************Class CSourceTabItem

CSourceTabItem::CSourceTabItem (ViewShownData *pViewShown, int indexOffset,
				QListView * parent, SRC_LV_ITEM source_item)
				: DataListItem (pViewShown, indexOffset, parent)
{
	setText (SRC_ADDRESS_COLUMN, source_item.Location);
	if (source_item.lineNumber > 0)
		setText (SRC_LINE_COLUMN, QString::number (source_item.lineNumber));
	setText (SRC_CODE_BYTES_COLUMN, source_item.Codebytes);
	setText (SRC_SOURCE_COLUMN, source_item.SourceLine);

	m_last_child = NULL;
}

CSourceTabItem::CSourceTabItem (ViewShownData *pViewShown, int indexOffset,
		QListView * parent, QListViewItem * after, SRC_LV_ITEM source_item)
		: DataListItem (pViewShown, indexOffset, parent, after)
{
	setText (SRC_ADDRESS_COLUMN, source_item.Location);
	if (source_item.lineNumber > 0)
		setText (SRC_LINE_COLUMN, QString::number (source_item.lineNumber));
	setText (SRC_CODE_BYTES_COLUMN, source_item.Codebytes);
	setText (SRC_SOURCE_COLUMN, source_item.SourceLine);

	m_last_child = NULL;
}


CSourceTabItem::CSourceTabItem (ViewShownData *pViewShown, int indexOffset,
		QListViewItem * pItem, QListViewItem * pAfter, SRC_LV_ITEM source_item)
		: DataListItem (pViewShown, indexOffset, pItem, pAfter)
{
	setText (SRC_ADDRESS_COLUMN, source_item.Location);
	if (source_item.lineNumber > 0)
		setText (SRC_LINE_COLUMN, QString::number (source_item.lineNumber));
	setText (SRC_CODE_BYTES_COLUMN, source_item.Codebytes);
	setText (SRC_SOURCE_COLUMN, source_item.SourceLine);

	m_last_child = NULL;
}


CSourceTabItem::CSourceTabItem (ViewShownData *pViewShown, int indexOffset,
		QListViewItem * pItem, SRC_LV_ITEM source_item)
		: DataListItem (pViewShown, indexOffset, pItem)
{
	setText (SRC_ADDRESS_COLUMN, source_item.Location);
	if (source_item.lineNumber > 0)
		setText (SRC_LINE_COLUMN, QString::number (source_item.lineNumber));
	setText (SRC_CODE_BYTES_COLUMN, source_item.Codebytes);
	setText (SRC_SOURCE_COLUMN, source_item.SourceLine);
	m_last_child = NULL;
}

//This displays the codebytes and disassembly in different colors
//
void CSourceTabItem::paintCell (QPainter * p, const QColorGroup & cg,
				int column, int width, int align)
{
	DWORD font_size = FONT_SIZE_DEFAULT;
	CATuneOptions ao;
	ao.getFontSize (&font_size);

	if(SRC_SOURCE_COLUMN == column ||
		SRC_CODE_BYTES_COLUMN == column)
	{
		// Setting Fonts
		//QFont f("TypeWriter",10,QFont::Normal,false);
		QFont f("Courier",font_size+3,QFont::Normal,false);
		f.setFixedPitch(true);
		p->setFont(f);
	}

	// change color if this is an assembly code line
	QColorGroup cg1 (cg);
	if (SRC_LINE_DEPTH == depth ())
	{
		cg1.setColor (QColorGroup::Text, Qt::blue);
	}
	QListViewItem::paintCell (p, cg1, column, width, align);
}


int CSourceTabItem::width (const QFontMetrics & fm, const QListView * lv,
						   int col) const
{
	int i = QListViewItem::width (fm, lv, col);
	if (SRC_CODE_BYTES_COLUMN == col)
		i += MARGIN;
	return i;
}


//This suppliments the string comparison for sorting of a list view by writing
// the integers to a string with zeros to the left.
//
QString CSourceTabItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	QString retString = text (column);

	// string comparison
	switch (column) {
		case SRC_SOURCE_COLUMN:
		case SRC_CODE_BYTES_COLUMN:
		case SRC_ADDRESS_COLUMN:
			break;
		default:
		case SRC_LINE_COLUMN:
			{
				QString zeroString;
				zeroString.fill ('0', (20 - retString.length()));
				retString.prepend (zeroString);
				break;
			}
	}
	return retString;
}


void CSourceTabItem::fillData (DataArray *pData)
{
	pData->clear();
	for (unsigned int i=0; i < m_dataList.size(); i++) {
		float oldDatum = m_dataList[i].toFloat();
		pData->append (oldDatum);
	}
}


void CSourceTabItem::addData (DataArray data, int precision)
{
	m_dataList.clear();
	for (unsigned int i=0; i < data.size(); i++) {
		appendData (data[i], precision);
	}
	updateShown();
}


//**************Class SourceTab

SourceDataTab::SourceDataTab (ViewShownData *pViewShown, QString module_name,
							  VADDR address, TbsReader* tbp_file,
							  SampleMap *sample_map, QWidget * parent,
							  const char *name, int wflags)
							  :DataTab (pViewShown, parent, name, wflags)
{
	m_list = NULL;
	m_pMenu = NULL;
	m_pSearchToolbar = NULL;
	m_pSearchBox = NULL;
	m_pSearchType = NULL;
	m_density_view = NULL;
	m_pSourceToolbar = NULL;
	m_pExpandCollapse= NULL;

	m_tbp_file = tbp_file;

	m_indexOffset = SRC_OFFSET_INDEX;
	m_exportString = "&Export source data...";
	setDockMenuEnabled (false);

	m_module_name = module_name;
	m_addr = address;
	m_sample_map = sample_map;

	if (SymbolEngine::OKAY != m_symbol_engine.open (m_module_name, true)) {
		m_file_name = "";
		hide ();
		return;
	}
	
	m_symbol_engine.getSymbolForAddr(address,&m_currentSym);

	string filename;
	unsigned int linenum = 0;
	if (SymbolEngine::OKAY == m_symbol_engine.getLineInfoForAddr(
						address, &filename, &linenum)) {
		m_file_name = filename;
		
		if (m_file_name.contains (SymbolEngine::UNKNOWN_FILE_NAME)) {
			m_file_name = "";
		}
	}

	if (m_tbp_file)
		AddModGlobalMap(tbp_file->getPath(), module_name, NULL, NULL);

	setDockMenuEnabled (false);
} // SourceDataTab::SourceDataTab


SourceDataTab::~SourceDataTab ()
{
	//m_sample_map.clear ();
	m_sample_map = NULL;

	if (m_pMenu)
		delete m_pMenu;

	if (m_density_view) 
		delete m_density_view;

	if (m_tbp_file) {
		//RemoveModGlobalMap(m_tbp_file->getPath(), m_module_name);
		m_tbp_file = NULL;
	}
}


void SourceDataTab::onViewChanged (ViewShownData* pShownData)
{
	QListViewItem *pCurrent = m_pList->currentItem ();
	UINT64 saveAddr = 0;
	if (NULL != pCurrent) {
		saveAddr = pCurrent->text (SRC_ADDRESS_COLUMN).toULongLong (NULL, 16);
	}

	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}

	//remove all columns
	clearShownColumns ();
	m_pExpandCollapse->setOn(false);

	//update shown columns
	if (NULL != m_pColumnMenu)
	{
		m_pColumnMenu->clear();
	}

	if (NULL != m_pColumnIndex) 
	{
		delete [] m_pColumnIndex;
		m_pColumnIndex = NULL;
	}

	if(m_pMenu != NULL)
	{
		if (-1 == m_pMenu->idAt (SRC_POP_SHOWN))
			m_pMenu->insertItem ("&Show", m_pColumnMenu);
	}

	// Reentrant displaySource 
	displaySource(m_profile);

	m_list->triggerUpdate();
	if (0 != saveAddr) {
		onNewHotSpot (saveAddr, caption (), NULL);
	}
}//SourceDataTab::onViewChanged 


bool SourceDataTab::displaySource (ProfileAttribute prof_att)
{
	uint use_file;

	//  Make this default
	m_profile = prof_att;

	if(m_list != NULL)
	{
		m_list->clear();	
	}
	else
	{
		// Initialize the list view
		m_list = new ChartListView (this);
		RETURN_FALSE_IF_NULL (m_list, this);

		m_pList = m_list;

		m_pList->addColumn ( "Address", 120 );
		m_pList->setColumnAlignment( SRC_ADDRESS_COLUMN, AlignLeft );
		m_pList->addColumn ( "Line", 50 );
		m_pList->setColumnAlignment( SRC_LINE_COLUMN, AlignRight );
		m_pList->addColumn ( "Source",  300 );
		m_pList->setColumnAlignment( SRC_SOURCE_COLUMN, AlignLeft );
		m_pList->addColumn ( "Code Bytes", 80);
		m_pList->setColumnAlignment( SRC_CODE_BYTES_COLUMN, AlignLeft );


		// Other options for the list view
		m_list->setShowSortIndicator (TRUE);
		m_list->setSorting (SRC_LINE_COLUMN, TRUE);
		m_list->setAllColumnsShowFocus (TRUE);
		m_list->setRootIsDecorated (TRUE);
		m_list->setSelectionMode (QListView::Extended);

		QObject::connect (m_list, SIGNAL (selectionChanged ()),
			SLOT (onSelectionChange ()));

		QObject::connect (m_list, SIGNAL (contentsRedrawn ()),
			this, SLOT (onListRedrawn ()));

		QObject::connect (m_list->header (), SIGNAL (clicked (int)),
			this, SLOT (onHeaderClicked (int)));

		QObject::connect (m_list->header (), SIGNAL (sizeChange(int,int,int)),
			this, SLOT (onHeaderSizeChanged(int,int,int)));

		QObject::connect ( m_list, SIGNAL( rightButtonClicked (
			QListViewItem *, const QPoint &, int ) ),
			SLOT( OnRightClick( QListViewItem *, const QPoint &,
			int ) ) );
		QObject::connect (m_list, SIGNAL (contextMenuRequested (
			QListViewItem *, const QPoint &, int)),
			SLOT (OnRightClick (QListViewItem *, const QPoint &,
			int)));

		QObject::connect(this, SIGNAL (shownDataChange(ViewShownData*)), 
			SLOT( onViewChanged(ViewShownData*)));
	}	
	/***************************************************
	* Source View Density Chart
	*/
	if(m_density_view == NULL)
	{
		m_density_view = new SrcDensityView (this);
		RETURN_FALSE_IF_NULL (m_density_view, this);
		if (!m_density_view->initialize (m_pViewShown, prof_att, m_currentSym.name))
			return false;

		//If the chart is double clicked, go to that address
		QObject::connect (m_density_view, SIGNAL (newHotSpot (VADDR, 
							QString, SampleMap*)),
			this, SLOT (onNewHotSpot (VADDR, QString, SampleMap *)));
	}

	m_density_view->checkVisibility ();

	/***************************************************/

	calculateTotalData();
	
	m_list->setUpdatesEnabled (FALSE);
	use_file = addSourceToList ();

	if (use_file) {
		use_file = addInstToList (use_file);
		onNewHotSpot (m_addr, caption (), NULL);
	}
	m_list->setUpdatesEnabled (TRUE);

	/***************************************************
	* Source View Toolbar
	*/
	//add search toolbar
	if(m_pSearchToolbar == NULL)
	{
		m_pSearchToolbar = new QToolBar ("Search Toolbar", this, this, true);
		RETURN_FALSE_IF_NULL (m_pSearchToolbar, this);

		m_pSearchToolbar->setLabel ("Search Toolbar");

		//add the search text box
		new QLabel ("Search for:", m_pSearchToolbar);

		m_pSearchBox = new QLineEdit (m_pSearchToolbar);
		RETURN_FALSE_IF_NULL (m_pSearchBox, this);

		connect (m_pSearchBox, SIGNAL (returnPressed ()), SLOT (onSearch()));
		QToolTip::add (m_pSearchBox, "Text to search for");

		//The f3 key will be find next
		QAccel *pAccel = new QAccel (this);
		RETURN_FALSE_IF_NULL (pAccel, this);
		pAccel->connectItem (pAccel->insertItem (Key_F3), this, 
						SLOT (onSearch()));

		m_pSearchType = new QComboBox (m_pSearchToolbar);
		RETURN_FALSE_IF_NULL (m_pSearchType, this);
		m_pSearchType->insertItem ("All", SEARCH_ALL);
		m_pSearchType->insertItem ("Line", SEARCH_LINE);
		m_pSearchType->insertItem ("Address", SEARCH_ADDRESS);
		m_pSearchType->insertItem ("Source", SEARCH_SOURCE);
		m_pSearchType->setCurrentItem (SEARCH_ALL);
		QToolTip::add (m_pSearchType, "Which column to search in");

		QPushButton *pGo = new QPushButton ("Go", m_pSearchToolbar);
		RETURN_FALSE_IF_NULL (pGo, this);
		connect (pGo, SIGNAL (clicked()), SLOT (onSearch()));
		QToolTip::add (pGo, "Start Search");

	}

	//add source navigation toolbar
	if(m_pSourceToolbar == NULL)
	{
		m_pSourceToolbar = new QToolBar ("SourceToolbar", this, this, false);
		RETURN_FALSE_IF_NULL (m_pSourceToolbar, this);

		m_pSourceToolbar->setLabel ("Source Toolbar");

		// Expand/Collapse
		QIconSet icon(QPixmap((const char**)expandCollapseIcon));
		m_pExpandCollapse = new QPushButton(icon, "",m_pSourceToolbar);
		m_pExpandCollapse->setMaximumHeight(20);
		m_pExpandCollapse->setMaximumWidth(20);
		m_pExpandCollapse->setToggleButton(true);
		connect(m_pExpandCollapse,SIGNAL(toggled(bool)), 
			this,SLOT(onExpandCollapseToggled(bool)));
		QToolTip::add(m_pExpandCollapse,QString("Expand / Collapse all source line"));
	}

	/***************************************************
	* Source View Right-click menu
	*/
	if(m_pMenu != NULL)
	{
		delete m_pMenu;
		m_pMenu = NULL;	
	}
	m_pMenu = new QPopupMenu( this );
	RETURN_FALSE_IF_NULL (m_pMenu, this);

	// Top level menu
	m_pMenu->insertItem( "Copy selection to buffer", this,
		SLOT(onCopySelection()), CTRL+Key_C );

	// Add view submenu
	if (!initMenu ())
		return false;

	if (NULL != m_pMenu)
	{
		if(m_pMenu->idAt(SRC_POP_SHOWN) == -1)
			m_pMenu->insertItem ("&Show", m_pColumnMenu);
	}

	setFocusProxy (m_list);
	setCentralWidget (m_list);

	return use_file;
}
void SourceDataTab::onExpandCollapseToggled(bool b)
{
	QListViewItem *pLine = m_pList->firstChild();
	while(pLine != NULL)
	{
		m_pList->setOpen(pLine,b);
		pLine = pLine->nextSibling();
	}

	pLine = m_pList->currentItem();
	if(pLine)
	{
		m_pList->ensureItemVisible(pLine);
	}
}

void SourceDataTab::onSearch ()
{
	QListViewItem *pItem = m_pList->currentItem ();
	if (NULL == pItem)
		pItem = m_pList->firstChild();
	QListViewItemIterator it (pItem);
	bool found = false;
	QString target = m_pSearchBox->text();

	it++;		// Current+1
	int start = 0;
	int end = m_pList->columns ();
	switch (m_pSearchType->currentItem ()) {
		default:								  //fall through
		case SEARCH_ALL:
			break;
		case SEARCH_LINE:
			start = SRC_LINE_COLUMN;
			end = SRC_LINE_COLUMN + 1;
			break;
		case SEARCH_ADDRESS:
			start = SRC_ADDRESS_COLUMN;
			end = SRC_ADDRESS_COLUMN + 1;
			break;
		case SEARCH_SOURCE:
			start = SRC_SOURCE_COLUMN;
			end = SRC_SOURCE_COLUMN + 1;
			break;
	}

	// Search from Current+1 to end
	while ((it.current()) && (!found)) {
		for (int i = start; i < end; i++) {
			if (it.current()->text (i).contains (target, false)) {
				moveSelectItem (it.current());
				found = true;
				break;
			}
		}
		it++;
	}

	// Wrap from beginning to Current-1
	if (!found)
	{
		it = QListViewItemIterator (m_pList->firstChild());
		while ((it.current() != pItem) && (!found)) {
			for (int i = start; i < end; i++) {
				if (it.current()->text (i).contains (target, false)) {
					moveSelectItem (it.current());
					statusBar()->message (
						"Search hit bottom, wrap at the beginning",5000);
					found = true;
					break;
				}
			}
			it++;

		}
	}	

	// Search current Line
	if (!found)
	{
		for (int i = start; i < end; i++) {
			if (it.current()->text (i).contains (target, false)) {
				moveSelectItem (it.current());
				found = true;
				statusBar()->message ("Search found on current line.", 5000);
				break;
			}
		}
	}

	if (!found)
		statusBar()->message (
			"Search failed: The given text was not found.", 5000);
}


QString SourceDataTab::getSourceFileName ()
{
	return m_file_name;
}


bool SourceDataTab::checkFileStamp (QString filename)
{
	QFileInfo prof_FI (m_tbp_file->getPath ());
	QFileInfo src_FI (filename);
	return (src_FI.lastModified () > prof_FI.lastModified ());
}


bool SourceDataTab::openSource (QFile * file, QString & filename)
{
	QString search_path;
	bool opened = false;
	CATuneOptions ao;
	uint ask_about_src;

	file->setName (m_file_name);

	// check search paths
	if (!file->open (IO_ReadOnly)) {
		CATuneOptions ao;
		ao.getDebugSearchPaths (search_path);

		for (int i = 0; i < SOURCE_SEARCH_COUNT; i++) {
			QString temp = search_path.section (';', i, i);
			temp += m_file_name.section ('/', -1);

			file->setName (temp);
			if (file->open (IO_ReadOnly)) {
				filename = temp;
				opened = true;
				break;
			}
		}
	}
	else {
		filename = m_file_name;
		opened = true;
	}

	ao.getAlertNoSource (&ask_about_src);
	if (ask_about_src) {
		while (!opened) {
			if(QMessageBox::Yes != QMessageBox::critical(this, 
					"Source View Error",
					QString("Could not open source file:\n")
					+ m_file_name + "\n"
					+ "Do you want to manually locate the file?\n",
					QMessageBox::Yes, QMessageBox::No))
				break;

			// browse for file/directory
			search_path = QFileDialog::getOpenFileName (m_file_name,
				"C++ files (*.c *.cpp *.h)"
				";;All files (*)",
				this, "browse dialog",
				"Please locate file " + m_file_name);
			if (search_path.isEmpty ())
				break;

			file->setName (search_path);

			if (file->open (IO_ReadOnly)) {
				opened = true;
				filename = search_path;
			}
		}
	}

	return opened;
}	// SourceDataTab::OpenSource


bool SourceDataTab::addSourceToList ()
{
	// open source file
	QFile file;
	QTextStream stream;
	QCString line;
	QListViewItem *previous = NULL;
	QString temp_file;
	unsigned int line_count = 1;

	if (!openSource (&file, temp_file))
		return false;

	stream.setDevice (&file);

	// check file stamp
	if (checkFileStamp (temp_file)) {
		QMessageBox::information (this, "Error", "Source file " + temp_file
			+ " has changed since profile");
		return false;
	}
	// for each line in file
	do {
		SRC_LV_ITEM source_line;

		line = stream.readLine ();
		source_line.lineNumber = line_count++;
		source_line.SourceLine = line;

		// add source item
		previous = new CSourceTabItem (m_pViewShown, SRC_OFFSET_INDEX,
			m_list, previous, source_line);
	} while (!stream.atEnd ());

	m_density_view->setMaxLine (line_count);
	m_max_lines = line_count;
	file.close ();
	return true;
}// SourceDataTab::addSourceToList()


void SourceDataTab::calculateTotalData()
{
	m_TotalSampleDataMap.clear();

	SampleMap::iterator smIt    = m_sample_map->begin();
	SampleMap::iterator smEnd   = m_sample_map->end();
	for (;smIt != smEnd ; smIt++)
	{
		SampleDataMap::iterator it    = smIt->second.begin();
		SampleDataMap::iterator itEnd = smIt->second.end();
		for (; it != itEnd; it++) {
			// We use -1 to denote "ALL CPU"
			SampleKey key(-1,it->first.event);
			SampleDataMap::iterator tit  = m_TotalSampleDataMap.find(key);
			SampleDataMap::iterator tend  = m_TotalSampleDataMap.end();
			if( tit != tend)
			{
				tit->second += it->second;
			}else{
				m_TotalSampleDataMap.insert(SampleDataMap::value_type(key,it->second));
				
			}
		}
	}
}

bool SourceDataTab::addDataToInst(CSourceTabItem * dasmItem, 
				  SampleMap::iterator & itsample, 
				  line_list_type::const_iterator & it,
				  QString & functionName,
				  SrcChartSampMap & chartMap)
{
	//---------------------------------------------------------
	// Add Data to CodeDensity chart
	if (!chartMap.contains((*it).line)) 
	{
		SrcChartSample tempSample;
		tempSample.first_addr = (*it).address;
		tempSample.function = functionName;
		chartMap[(*it).line] = tempSample;
	}

	DataArray tempParent;
	tempParent.resize (m_pViewShown->available.count(), 0);
	
	SampleDataMap::iterator sample_it = itsample->second.begin();
	SampleDataMap::iterator sample_end = itsample->second.end();
	for (; sample_it != sample_end; sample_it++) {

		unsigned long long deEvent;
		unsigned char deUMask;
		DecodeEventMask(sample_it->first.event, &deEvent, &deUMask);
		CpuEventType key(sample_it->first.cpu, deEvent, deUMask); 

		if (!m_pViewShown->indexes.contains(key))
			continue;

		//given cpu/event select from profile, find column index
		int index = m_pViewShown->indexes[key];

		//aggregate
		tempParent[index] += sample_it->second;

		(chartMap[(*it).line]).samples = tempParent;

	}

	//---------------------------------------------------------
	// Add Data to dasm line
	dasmItem->drawData(&(itsample->second),0,true);
	return true;
}// SourceDataTab::addDataToInst



bool SourceDataTab::addInstToList (bool use_lines)
{
	if (!m_sample_map)
		return false;

	bool ret_value = true;
	line_list_type line_list;
	CSourceTabItem *parent = NULL;
	CSourceTabItem *dasmItem = NULL;
	CSourceTabItem *oldDasmItem = NULL;
	line_list_type::const_iterator it;
	line_list_type::const_iterator oldIt;
	unsigned long i = 0;
	QString function_name;
	SrcChartSampMap chartMap;

	QProgressDialog progress (this, NULL, true, WStyle_Customize
		| WStyle_NormalBorder | WStyle_Title);
	progress.setLabelText (QString ("Adding disassembled instructions"));

	unsigned int sret = m_symbol_engine.getLineInfo(m_file_name.ascii(), 
					&line_list, m_addr);
	if (SymbolEngine::OKAY != sret)
		return false;

	progress.setTotalSteps (line_list.size ());
	progress.show ();

	// for each instruction,
	SampleMap::iterator itsample = m_sample_map->begin();
	oldIt = it = line_list.begin();


	// Sync the line and sample address
	while ( itsample != m_sample_map->end()
	&& 	itsample->first < (*it).address)
	{
		itsample++;
	}

	while ( it != line_list.end () ) 
	{
		bool annotateCurrentLine = false;
		bool annotatePreviousLine = false;
		SampleDataMap parentData;
		char num[LONG_STR_MAX];
		SRC_LV_ITEM source_line;
		SampleDataMap *cur = NULL;
		line_list_type::const_iterator curIt = it;

		// longs are 64 bit in 64-bit Linux
		sprintf (num, "0x%lx", (unsigned long) (*it).address);

		source_line.lineNumber = 0;
		source_line.Codebytes = (*it).codebytes.data ();
		source_line.Location = num;
		source_line.SourceLine = (*it).disassembly.data ();

		// Show source line information 
		if (use_lines) 
		{
			// Find the source line
			parent = (CSourceTabItem *) m_list->findItem(
						QString::number((*it).line) , SRC_LINE_COLUMN);
			if (NULL == parent) {
				// Can't find source line, skip it
				goto nextLine;
			}

			// add the instruction 
			oldDasmItem = dasmItem;
			parent->m_last_child = dasmItem = 
				new CSourceTabItem (m_pViewShown, SRC_OFFSET_INDEX,
				parent, parent->m_last_child, source_line);

			dasmItem->setTotal(&m_TotalSampleDataMap);

			// ******************************************** 
			// Suravee: We need to pass in something beside 
			//          NULL to the getOffset function here 
			// ********************************************     
			bfd_vma offset;
			bfd_vma max;
			if ((m_symbol_engine.getOffset ((*it).address, 
					&function_name,&offset,&max)) 
					&&  (!function_name.isEmpty ())) 
			{
				SrcFunctionLineRange & function = m_func_map[function_name];
				unsigned int line = parent->text(SRC_LINE_COLUMN).toUInt ();
				if (function.start > line)
					function.start = line;
				if (function.end < line)
					function.end = line;
			}
		}
		// Bypass source directly to dasm
		else 
		{
			dasmItem = new CSourceTabItem (m_pViewShown, SRC_OFFSET_INDEX,
				m_list, dasmItem, source_line);
		}

		/*
		* NOTE: Logic to align the sample address with the instruction.
		* If the address is in between the instruction, tally it with the
		* lower address instruction (Mostly for IBS Fetch)
		*/
		curIt = it;
		if( itsample->first > (*oldIt).address 
		&&  itsample->first < (*it).address 
		&&  oldDasmItem != NULL )
		{
			// Align sample to instruction
			if((cur = oldDasmItem->getItemSamples()) == NULL)
			{
				// New
				addDataToInst(oldDasmItem, itsample,oldIt, function_name, chartMap);
				AggregateSamples(parentData,itsample->second);
			} else {
				// Update
				SampleDataMap tmp;
				AggregateSamples(tmp, *cur);
				AggregateSamples(tmp, itsample->second);
				AggregateSamples(parentData,itsample->second);
				oldDasmItem->drawData(&tmp,0);
			}
			curIt = oldIt;
			annotatePreviousLine = true;

			// We don't need duplicate dasmline
			delete dasmItem;
			dasmItem = oldDasmItem;
			parent->m_last_child = oldDasmItem;

		} else if (itsample->first == (*it).address) {
			/* If the current disassembly address matches the current sample map
			* entry, add the sample data to current disassembly item and its parent.
			*/
			addDataToInst(dasmItem, itsample, it, function_name, chartMap);
			AggregateSamples(parentData,itsample->second);
			annotateCurrentLine = true;
		}


		// *************************************************************
		// ACCUMULATE SAMPLE TO SOURCE LINE (parent)
		parent = (CSourceTabItem *) m_list->findItem(
					QString::number((*curIt).line) , SRC_LINE_COLUMN);
		parent->setTotal(&m_TotalSampleDataMap);
		
		if((cur = parent->getItemSamples()) == NULL)
		{
			// New
			m_lineSampleMap.insert(LineSampleMap::value_type((*curIt).line,parentData));
			LineSampleMap::iterator p_it = m_lineSampleMap.find((*curIt).line);
			parent->drawData(&(p_it->second),0,true);	
		}else{
			// Update
			AggregateSamples(*cur, parentData);
			parent->drawData(cur,0);	
		}


		// Check if progress is cancelled
		if (progress.wasCancelled ()) {
			ret_value = false;
			break;
		}

		// Update progress bar
		if (0 == (i++ % 100)) {
			progress.setProgress (i);
			qApp->processEvents ();
		}

nextLine:
		// If successfully annotate current line, move to next line.
		if (!annotatePreviousLine
		&&  it != line_list.end ()) 
		{
			oldIt = it;
			it++;
		}
		
		/* Locate the next sample data */
		if ( itsample != m_sample_map->end()
		&&  (annotatePreviousLine || annotateCurrentLine) ) 
		{
			itsample++;
		}
	}

	line_list.clear ();
	m_lineSampleMap.clear();

	m_density_view->setFunctions (m_func_map);
	m_density_view->setSamples (chartMap);

	emit disassembledDone();

	return ret_value;
}// SourceDataTab::addInstToList

void SourceDataTab::OnRightClick ( QListViewItem *pItem, const QPoint &pt,
								  int i )
{
	Q_UNUSED (pItem);
	Q_UNUSED (i);
	m_pMenu->popup( pt );
}

void SourceDataTab::onSelectionChange ()
{
	statusBar ()->clear ();
	CSourceTabItem *cur_item = (CSourceTabItem *)  m_list->firstChild ();
	long inst_count = 0;
	//int total = m_tbp_file->getNumSamples ();

	while (NULL != cur_item) {
		CSourceTabItem *next =
			(CSourceTabItem *) cur_item->firstChild ();
		if (NULL == next) {
			if (cur_item->isSelected ()) {
				inst_count++;
			}
			next = (CSourceTabItem *) cur_item->nextSibling ();
		}
		if ((NULL == next) && (NULL != cur_item->parent ()))
			next = (CSourceTabItem *)
			cur_item->parent ()->nextSibling ();
		cur_item = next;
	}

	QString results;
	results.sprintf ("%ld Instruction%s" ,inst_count, ((inst_count > 1) ? "s" : ""));
	statusBar()->message (results);
}


void SourceDataTab::onNewHotSpot (VADDR addr, QString caption, SampleMap* pMap)
{
	Q_UNUSED(pMap);
	/* NOTE:
	* First we have to try to align addr with the instruction address
	*/
	VADDR newAddr = 0;
	line_list_type line_list;
	line_list_type::const_iterator it;
	line_list_type::const_iterator oldIt;

	unsigned int sret = m_symbol_engine.getLineInfo(m_file_name.ascii(), 
				&line_list, m_addr);
	if (SymbolEngine::OKAY == sret)
	{ 
		oldIt = line_list.begin();
		it = line_list.begin();
		for (; it != line_list.end ();oldIt = it,  it++) 
		{
			if( addr > (*oldIt).address
				&& addr < (*it).address )
			{
				newAddr = (*oldIt).address;
			}
			else if (addr == (*it).address)
			{
				newAddr = (*it).address;
			}
		}
	}
	else
	{
		newAddr = addr;
	}		

	/*
	* Second, we try to locate the line with "newAddr".
	*/ 
	if (caption == this->caption ()) {
		QString num;
		// a long is 64 bits in 64-bit linux
		char buffer[LONG_STR_MAX];
		snprintf (buffer, (LONG_STR_MAX-1), "0x%lx", (unsigned long) newAddr);
		num = buffer;

		CSourceTabItem *item = (CSourceTabItem *) m_list->findItem(
					num, SRC_ADDRESS_COLUMN);

		if (NULL != item) {
			moveSelectItem (item);
		}
	}
}


void SourceDataTab::moveSelectItem (QListViewItem * item)
{
	m_list->clearSelection ();
	m_list->setSelected (item, TRUE);
	m_list->setCurrentItem (item);
	m_list->ensureItemVisible (item);

	CSourceTabItem *line_item = (CSourceTabItem *) item->parent ();
	unsigned int line = 1;
	if (NULL == line_item)
		line_item = (CSourceTabItem *) item;

	line = line_item->text (SRC_LINE_COLUMN).toUInt ();
	m_density_view->setInterestPoint (line);
}


void SourceDataTab::onDensityVisibilty ()
{
	m_density_view->checkVisibility ();
}


void SourceDataTab::showEvent (QShowEvent * e)
{
	Q_UNUSED (e);
	m_density_view->checkVisibility ();
}


//check for whether the currently shown list changed.
void SourceDataTab::onListRedrawn ()
{
	UINT64 start = 1;
	UINT64 end = m_max_lines;

	static CSourceTabItem *last_top = NULL;
	static CSourceTabItem *last_bottom = NULL;
	CSourceTabItem *line_item;

	//instead of checking items at these points, I could start at the first
	//item and scroll through all visible items
	QPoint top_point = QPoint (0, 0);
	QPoint bottom_point = QPoint (0, (m_list->visibleHeight () - 1));

	CSourceTabItem *top = (CSourceTabItem *) m_list->itemAt (top_point);
	CSourceTabItem *bottom = (CSourceTabItem *) m_list->itemAt (bottom_point);
	if (NULL != bottom) {
		if (NULL != bottom->itemBelow ())
			bottom = (CSourceTabItem *) bottom->itemBelow ();
	}
	//If the visible items really didn't change...
	if ((last_top == top) && (last_bottom == bottom))
	{
		return;
	}

	last_top = top;
	last_bottom = bottom;

	if (NULL != bottom) {
		//if the bottom line is disassembly
		line_item = (CSourceTabItem *) bottom->parent ();
		if (NULL != line_item)
			end = line_item->text (SRC_LINE_COLUMN).toUInt ();
		else
			end = bottom->text (SRC_LINE_COLUMN).toUInt ();
	}

	if (NULL != top) {
		//if the top line is disassembly
		line_item = (CSourceTabItem *) top->parent ();
		if (NULL != line_item)
			start = line_item->text (SRC_LINE_COLUMN).toUInt ();
		else
			start = top->text (SRC_LINE_COLUMN).toUInt ();
	}

	if (NULL != m_density_view) {
		if (start < end)
			m_density_view->shownDataChanged (start, end);
		else	//in case it's sorted in reverse order...
			m_density_view->shownDataChanged (end, start);
	}
}	//SourceDataTab::OnListRedrawn


//We are paying attention to this because the header click affects the sorting
void SourceDataTab::onHeaderClicked (int column)
{
	Q_UNUSED (column);
}

void SourceDataTab::onHeaderSizeChanged(int section,int oldSize, int newSize)
{
	Q_UNUSED(section);
	Q_UNUSED(oldSize);
	Q_UNUSED(newSize);
	m_pList->triggerUpdate();
}

SrcDensityView::SrcDensityView (QWidget * parent)
:  ZoomDock (parent)
{
}


SrcDensityView::~SrcDensityView ()
{
	if(m_pSrcChart)
		delete m_pSrcChart;
}


bool SrcDensityView::initialize (ViewShownData *pViewShown, 
				ProfileAttribute profile,
				QString curFuncName)
{
	if (!ZoomDock::initialize ())
		return false;

	addZoomLevel ("Source File", SRC_ZOOM_FILE);
	addZoomLevel ("Function", SRC_ZOOM_SECTION);
	addZoomLevel ("Partial", SRC_ZOOM_USER);
	addZoomLevel ("Current", SRC_ZOOM_SHOWN);

	//create the density chart  and hook it up
	m_pSrcChart = new SrcDensityChart (pViewShown, widget (), profile);
	RETURN_FALSE_IF_NULL (m_pSrcChart, this);

	m_pSrcChart->setInterestLine (1);
	if (!m_pSrcChart->initialize ())
		return false;

	setChartArea (m_pSrcChart);
	connect (m_pSrcChart, SIGNAL (doubleClicked (UINT64)), this,
		SLOT (onDoubleClicked (UINT64)));

	setZoomLevel(SRC_ZOOM_SECTION);
	m_pSrcChart->setCurrentFunction(curFuncName);
	return true;
}//SrcDensityView::initialize


void SrcDensityView::shownDataChanged (unsigned int start, unsigned int end)
{
	m_pSrcChart->markRange (start, end);
	//if we are at the currently shown level of zoom, move chart with scrolling
	if (SRC_ZOOM_SHOWN == m_zoom_level)
		m_pSrcChart->zoomChanged (m_zoom_level);
}


void SrcDensityView::setMaxLine (unsigned int max)
{
	m_pSrcChart->setMaxLine (max);
}


void SrcDensityView::setSamples (SrcChartSampMap samp_map)
{
	m_pSrcChart->setSamples (samp_map);

	setZoomLevel (m_zoom_level);
}


void SrcDensityView::setFunctions (SrcFunctionMap function_map)
{
	m_pSrcChart->setFunctions (function_map);
}


//Called when a new hot spot is given to the source view
void SrcDensityView::setInterestPoint (unsigned int interesting)
{
	m_pSrcChart->setInterestLine (interesting);
	//force it to set current reference points
	setZoomLevel (m_zoom_level);
}


//Take the chart's double clicked line number as the new hot spot
void SrcDensityView::onDoubleClicked (UINT64 hot_spot)
{
	emit newHotSpot (hot_spot, m_parent_caption, NULL);
}


void SrcDensityView::setShowCurrentData (bool show_current)
{
	//If the currently shown data doesn't make sense, disable that level of the
	//  zoom
	if (!show_current) {
		if (SRC_ZOOM_SHOWN == m_zoom_level) {
			setZoomLevel (SRC_ZOOM_SECTION);
		}
		//if not just swapping ascending/descending order of samples
		if (SRC_ZOOM_USER != zoomLevelMinimum ()) {
			removeZoomLevel (SRC_ZOOM_SHOWN);
		}
	}
	else {
		addZoomLevel ("Current", SRC_ZOOM_SHOWN);
		//make sure the correct buttons are enabled/disabled.
		setZoomLevel (m_zoom_level);
	}
	setShowMarkedData (show_current);
}


SrcDensityChart::SrcDensityChart (ViewShownData *pViewShown, QWidget * parent,
								  ProfileAttribute profile)
								  :  DensityChartArea (pViewShown, parent)
{
	m_profile = profile;
}


SrcDensityChart::~SrcDensityChart ()
{
	m_sample_map.clear ();
}


void SrcDensityChart::setSamples (SrcChartSampMap samp_map)
{
	m_sample_map = samp_map;
}


//If this returns false, the initialization failed, and the chart area
// shouldn't be used.
//SampleMap is defined in stdafx.h
bool SrcDensityChart::initialize ()
{
	if (!DensityChartArea::initialize (m_profile))
		return false;

	connect (this, SIGNAL (groupDoubleClicked (UINT64)),
		this, SLOT (onGroupDoubleClicked (UINT64)));

	return true;
}

//recalculates shown stuff from current center, and current start/end
void SrcDensityChart::zoomChanged (int zoom_level)
{
	sym_info temp_sym;
	bool currentZoomFailed = false;

	if (!m_initialized)
		return;

	switch (zoom_level) {
		case SRC_ZOOM_FILE:
			m_cur_start = 1;
			m_cur_end = m_total_src_lines;
			break;

		case SRC_ZOOM_SECTION:
			{
#if 0
				SrcChartSampMap::Iterator it;

				it = m_sample_map.find (m_start_interest);

				//if m_start_interest is in a function, show function!
				if ((m_sample_map.end () != it)
					&& (!it.data ().function.isEmpty ())) 
				{
					SrcFunctionLineRange & function = 
						m_function_map[it.data ().function];

					if (-1 == function.start) {
						/* If the double clicked line falls on an inline
						* functions, function.start is -1. In this case change
						* the zoom to entire file.
						*/
						currentZoomFailed = true;
					} else {
						m_cur_start = function.start;
						// we want the line after the end, 
						// so it will show the data of the last line
						m_cur_end = function.end + 1;
					}
				}
				else {
					//otherwise a 500 line region around interest
					if (m_start_interest > 500)
						m_cur_start = m_start_interest - 500;
					else
						m_cur_start = 1;
					m_cur_end = m_start_interest + 500;
				}
#endif

				if(!m_currentFunction.isEmpty())
				{
					SrcFunctionLineRange & function = 
						m_function_map[m_currentFunction];

					if (~0U == function.start) {
						/* If the double clicked line falls on an inline
						* functions, function.start is -1. In this case change
						* the zoom to entire file.
						*/
						currentZoomFailed = true;
					} else {
						m_cur_start = function.start;
						// we want the line after the end, 
						// so it will show the data of the last line
						m_cur_end = function.end + 1;
					}
				}else{
					//otherwise a 500 line region around interest
					if (m_start_interest > 500)
						m_cur_start = m_start_interest - 500;
					else
						m_cur_start = 1;
					m_cur_end = m_start_interest + 500;
				}
			}
			break;

		case SRC_ZOOM_USER:
			//if user specified region
			if (0 != m_end_interest) {
				m_cur_start = m_start_interest;
				m_cur_end = m_end_interest + 1;
			}
			else {
				//otherwise a 100 line region around interest
				if (m_start_interest > 100)
					m_cur_start = m_start_interest - 100;
				else
					m_cur_start = 1;
				m_cur_end = m_start_interest + 100;
			}
			break;

		case SRC_ZOOM_SHOWN:
			m_cur_start = m_mark_start;
			m_cur_end = m_mark_end;
			//at least show one sample
			if (m_cur_end == m_cur_start)
				m_cur_end++;
			break;
	}

	//just in case...
	if (m_cur_start > m_cur_end)
		m_cur_start = 1;
	if (m_cur_end > m_total_src_lines)
		m_cur_end = m_total_src_lines;

	if (currentZoomFailed) { 
		QString msg =  "ERROR: No relevant symbol found.\n";
		msg +=  "Source Density Chart failed to draw. The function maybe an inline function.\n";

		QMessageBox::critical (this, "CodeAnalyst Function Zoom", msg);

		//setZoomLevel(SRC_ZOOM_FILE);
		//zoomChanged(SRC_ZOOM_FILE);
	} else {
		setCurrentRange (m_cur_start, m_cur_end,
			QString::number ((unsigned int) m_cur_start),
			QString::number ((unsigned int) m_cur_end));

		calculateScale ();

	}
} //SrcDensityChart::zoomChanged


//Given the current space, partitions the shown region into groups
// these groups aggregate all samples within them, so the max sample changes
//Note that we do this once per resizing/recalculation/zoom
bool SrcDensityChart::groupData ()
{
	int group;
	m_max_group_sample = 0;

	//allocate new groups
	m_groups = new ChartGroupType[m_group_count];
	RETURN_FALSE_IF_NULL (m_groups, this);

	//sort raw data into groups
	for (group = 0; group < m_group_count; group++) {
		m_groups[group].samples.resize (m_pViewShown->available.size(), 0);

		//saves from recalculating this every time.
		m_groups[group].start = m_group_range * (group) + m_cur_start;
		m_groups[group].end = m_group_range * (group + 1) + m_cur_start - 1;

		//The SrcDensityChart saves the first address with samples within the
		//  range in the group.data member
		m_groups[group].data = 0;
		m_groups[group].label = QString::null;
	}

	//For each sample
	SrcChartSampMap::iterator it;
	for (it = m_sample_map.begin (); it != m_sample_map.end (); ++it) {
		//if the sample is outside the current range, don't add it to a shown
		// group
		if ((m_cur_start > it.key ()) || (m_cur_end <= it.key ())) {
			continue;
		}

		group = (it.key () - m_cur_start) / m_group_range;
		if (group > m_group_count)
			continue;

		//save first sample address in the group as data
		if ((m_groups[group].data > it.data ().first_addr)
			|| (m_groups[group].label.isEmpty ())) {
				m_groups[group].data = it.data ().first_addr;

				//save the function of the address as the label
				m_groups[group].label = it.data ().function;
		}

		for (UINT ev = 0; ev < m_pViewShown->shown.size(); ev++) {
			int index = m_pViewShown->shown[ev];
			//ignore events that aren't currently shown

			if (!it.data ().samples.empty()) 
				m_groups[group].samples[index] += 
						(long) it.data ().samples[index];

			//The max group sample sets the y scale.
			if (m_max_group_sample < m_groups[group].samples[index]) {
				m_max_group_sample = m_groups[group].samples[index];
			}
		}
	} //for each sample

	return true;
} //SrcDensityChart::groupData


void SrcDensityChart::tipGroups ()
{
	QString helper;
	QString tip;

	if (NULL == m_groups)
		return;

	for (int group = 0; group < m_group_count; group++) {
		unsigned int max = 0;

		//Show the range of the group in the tool tip
		if (m_groups[group].start != m_groups[group].end) {
			tip.sprintf ("Line %u to ", (unsigned int) m_groups[group].start);
			helper.sprintf ("line %u", (unsigned int) m_groups[group].end);
			tip += helper;
		} else
			tip.sprintf ("Line %u", (unsigned int) m_groups[group].start);

		//If there was a label for the group, show it.
		if (!m_groups[group].label.isEmpty ()) {
			tip += QString ("\n") + m_groups[group].label;
		}

		for (UINT ev = 0; ev < m_pViewShown->shown.size(); ev++) {
			int index = m_pViewShown->shown[ev];

			tip += QString ("\n\t");
			tip += QString::number (m_groups[group].samples[index]);
			tip += QString (": ");
			tip += m_pViewShown->tips[index];

			if (max < m_groups[group].samples[index])
				max = m_groups[group].samples[index];
		}

		//The tool tip for the group covers all bars in the group
		m_groups[group].tip_rect = groupTipRect (group, max);

		//If there is no chart to show, don't add a tool-tip
		if (0 == m_groups[group].tip_rect.height ()) {
			continue;
		}

		QToolTip::add (this, m_groups[group].tip_rect, tip);
	} //for each group
}	// SrcDensityChart::tipGroups


//When a new hotspot is set, set the point of interest in the chart
void SrcDensityChart::setInterestLine (unsigned int interesting)
{
	m_end_interest = 0;
	m_start_interest = interesting;
	update ();
}


void SrcDensityChart::onGroupDoubleClicked (UINT64 group_data)
{
	emit doubleClicked (group_data);
}


void SrcDensityChart::setMaxLine (unsigned int max)
{
	m_total_src_lines = max;
	update ();
}


void SrcDensityChart::setFunctions (SrcFunctionMap function_map)
{
	m_function_map = function_map;
}
