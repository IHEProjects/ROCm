#ifndef _CATRANSLATE_CONSOLE_DISPLAY_H_
#define _CATRANSLATE_CONSOLE_DISPLAY_H_

#include <iostream>

#include "catranslate_display.h"

class ca_translate_console_display:public ca_translate_display
{
public:
    ca_translate_console_display();
    ~ca_translate_console_display();

    void init();

    void update_display(const char * text);
    void update_display_error(const char * text);
};

#endif
