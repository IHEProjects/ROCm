//$Id: sysdataview.cpp,v 1.5 2005/02/14 16:52:29 jyeh Exp $
// implementation for SystemDataView class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qvaluelist.h>

#include "stdafx.h"
#include "sysdataview.h"
#include "atuneoptions.h"
#include "EventMaskEncoding.h"

SystemItem::SystemItem (ViewShownData *pViewShown, int indexOffset, 
			QListView * pParent)
			:DataListItem (pViewShown, indexOffset, pParent)
{
}


QString SystemItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	QString ret_string;

	if (SYS_MOD_NAME == column) {
		return text(column);
	}

	// for anything else, do integer comparison
	//20 characters is > the max length of a uint64 as a decimal.
	QString targetStr = text (column);
	targetStr.replace(QChar('.'),"");
	targetStr.replace(QChar('%'),"");

	ret_string.fill ('0', (20 - targetStr.length()));
	ret_string.append (targetStr);
	return ret_string;
}


SystemDataTab::SystemDataTab (TbsReader* tbp_file, ViewShownData *pViewShown, 
				  QWidget * parent, const char *name, int wflags)
				  :  DataTab (pViewShown, parent, name, wflags )
{
	m_tbp_file = tbp_file;
	setDockMenuEnabled (false);
	m_userCanClose = false;
	m_exportString = "&Export System Data...";
	m_indexOffset = SYS_OFFSET_INDEX;
}




SystemDataTab::~SystemDataTab ()
{
}


// retrieves system module data from the .tbp file
// this data is located within the [MODDATA] key
//
bool SystemDataTab::readAndDisplayModuleData ()
{
	QValueList<SYS_LV_ITEM> mod_list;
	QValueList<SYS_LV_ITEM> task_list;
	QValueList<SYS_LV_ITEM>::iterator it  ;
	QValueList<SYS_LV_ITEM>::iterator end ;
	map<unsigned int,QString> task_id_map;
	unsigned long tbpVersion = m_tbp_file->getTbpFileVersion();
	
	SampleDataMap totalSample;
	totalSample.clear();

	// Set up TaskName column	
	m_pList->setColumnWidthMode(1,QListView::Manual);		
	if(!m_pViewShown->separateTasks)
	{
		m_pList->hideColumn(SYS_TASK_NAME);		
	}else{
		m_pList->setColumnWidth(1,200);		
	}

	/* 
	* NOTE:
	* We started adding support for separating 
	* by taskname since TBP file version 6.
	*/
	if ( tbpVersion >= 6)
	{
		// Building taskId map
		m_tbp_file->readProcInfo(task_list);

		it  = task_list.begin();
		end = task_list.end();
		for(; it != end; it++) 
		{
			task_id_map[(*it).taskId] = (*it).ModName;
		}

		// Module list
		if (m_pViewShown->separateTasks)
		{
			m_tbp_file->readModInfo(mod_list, &totalSample);
		}
		else
		{
			m_tbp_file->readAggregatedModInfo(mod_list, &totalSample);
		}
	}
	else
	{
		// Module list
		m_tbp_file->readModInfo(mod_list, &totalSample);

		if (m_pViewShown->separateTasks)
		{
			QString msg = "This session contains the old version of TBP file (Version " 
				+ QString::number(tbpVersion) 
				+ " )\n"
				+ ", which does not support separate by task. Please re-profile the application "
				+ "to use this feature.";

			QMessageBox::warning(this,"CodeAnalyst Warning",msg);
		}
	}

	m_TotalSampleDataMap.clear();

	SampleDataMap::iterator sit= totalSample.begin ();
	SampleDataMap::iterator send = totalSample.end ();
	for(; sit != send; ++sit) {
		// We use -1 to denote "ALL CPU"
                SampleKey key(-1,sit->first.event);                                                       
                SampleDataMap::iterator tit  = m_TotalSampleDataMap.find(key);                          
                SampleDataMap::iterator tend  = m_TotalSampleDataMap.end();
                if( tit != tend)
                {
                        tit->second += sit->second;
                }else{
                        m_TotalSampleDataMap.insert(SampleDataMap::value_type(key,sit->second));
                }                                                
	}

	it = mod_list.begin();
	end = mod_list.end();
	for(; it != end; it++) 
	{
		SystemItem *pItem = new SystemItem( m_pViewShown, 
						SYS_OFFSET_INDEX, m_pList);

		RETURN_FALSE_IF_NULL (pItem, this);

		//add column data
		QString name = (*it).ModName;

		// Module Name Column
		if (m_pViewShown->separateTasks &&  tbpVersion >= 6)
		{
			pItem->m_taskId = (*it).taskId;
			//name += " - [ Task " + QString::number ((*it).taskId) + " ]";
		} 
		else 
		{
			pItem->m_taskId = SHOW_ALL_TASKS;
		}
		pItem->setText (SYS_MOD_NAME, name);

		// Task Name Column
		if (m_pViewShown->separateTasks &&  tbpVersion >= 6)
		{
			pItem->setText (SYS_TASK_NAME, task_id_map[pItem->m_taskId]);
		}

		// SixtyFourBit Column
		if ((*it).SixFourBit.toULong () > 0)
			pItem->setChecked (SYS_64_BIT);
		else
			pItem->setChecked (-1);

		// Data Column
		pItem->setTotal(&m_TotalSampleDataMap);
		pItem->drawData(&(*it).CpuSamples, 200, true);
		pItem->updateShown ();
	}
	totalSample.clear();
	return TRUE;
}

void SystemDataTab::onViewChanged (ViewShownData* pShownData)
{
	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}

	m_pList->clear();

	//remove all columns
	clearShownColumns ();

	m_pList->setUpdatesEnabled (false);

	//update shown columns
	if (NULL != m_pColumnMenu)
	{
		m_pColumnMenu->clear();
	}
	if (NULL != m_pColumnIndex)
	{
		delete [] m_pColumnIndex;
		m_pColumnIndex = NULL;
	}

	//add data columns
	if (!initMenu ())
		return;

	if (NULL != m_menu)
	{	
		if (m_menu->idAt (SYS_POP_SHOWN) == -1)
		{
			m_menu->insertItem ("&Show", m_pColumnMenu);
		}
	}

	readAndDisplayModuleData();

	m_pList->setUpdatesEnabled (true);
	m_pList->setCurrentItem (m_pList->firstChild());
	m_pList->triggerUpdate ();

} //SystemDataTab::onViewChanged


// The list view has been double clicked
// We must now get the module name that was clicked, and pass that to the
// function data view window.
//
void SystemDataTab::onDblClicked (QListViewItem * item)
{
	SystemItem *pItem = (SystemItem *) item;
	QApplication::setOverrideCursor (QCursor (Qt::WaitCursor));
	emit moduleDblClicked (pItem->text (MF_MOD_NAME), TAB_DATA, pItem->m_taskId);
	QApplication::restoreOverrideCursor ();
}


// We must create a new GraphView object
// The moduleName parameter will be "" since we want to display module data
//
void SystemDataTab::onViewSystemGraph ()
{
	emit viewGraph ();
}


void SystemDataTab::onViewModuleGraph ()
{
	emit moduleRightClicked (m_item_right_clicked->text (MF_MOD_NAME),
		TAB_GRAPH, m_item_right_clicked->m_taskId);
}


void SystemDataTab::onViewModuleData ()
{
	emit moduleRightClicked (m_item_right_clicked->text (MF_MOD_NAME),
		TAB_DATA, m_item_right_clicked->m_taskId);
}


void SystemDataTab::onViewSystemTask()
{
	emit viewTasks();
}

void SystemDataTab::onRightClick (QListViewItem * item, const QPoint & pt,
								  int col)
{
	Q_UNUSED (col);
	m_item_right_clicked = (SystemItem *)item;

	m_menu->removeItem (m_module_popup_id[POPUP_SEP]);
	m_menu->removeItem (m_module_popup_id[POPUP_DATA]);
	m_menu->removeItem (m_module_popup_id[POPUP_GRAPH]);

	if (m_item_right_clicked) {
		m_module_popup_id[POPUP_SEP] = m_menu->insertSeparator ();
		m_module_popup_id[POPUP_DATA] =
			m_menu->insertItem (item->text (MF_MOD_NAME) + " - Data", this,
			SLOT (onViewModuleData ()));
		m_module_popup_id[POPUP_GRAPH] =
			m_menu->insertItem (item->text (MF_MOD_NAME) + " - Graph", this,
			SLOT (onViewModuleGraph ()));
		if (item->text (MF_MOD_NAME).startsWith ("anon (tgid"))
		{
			m_menu->setItemEnabled (m_module_popup_id[POPUP_DATA], false);
			m_menu->setItemEnabled (m_module_popup_id[POPUP_GRAPH], false);
		}
	}

	m_menu->popup (pt);
}


bool SystemDataTab::display (QString caption)
{
	// Prepare the popup menu
	if(!m_menu)
	{
		delete m_menu;
		m_menu = NULL;
	}

	m_menu = new QPopupMenu (this, "Our Menu");
	if (NULL == m_menu) {
		QMessageBox::critical (this, "Memory Error", "Insufficient memory.");
		return FALSE;
	}

	m_menu->insertItem ("Copy Selection", this, SLOT (onCopySelection()), CTRL + Key_C);
	int id = m_menu->insertItem ("System Data");
	m_menu->setItemEnabled (id, false);
	m_menu->setItemChecked (id, true);

	m_menu->insertItem ("System Graph", this, SLOT (onViewSystemGraph ()));
	m_menu->insertItem ("System Tasks"   , this, SLOT (onViewSystemTask ()));

	// Initialize the list view 
	m_pList = new QListView (this);
	if (NULL == m_pList) {
		QMessageBox::critical (this, "Memory Error", "Insufficient memory.");
		return FALSE;
	}

	m_pList->addColumn ("Module Name");
	m_pList->addColumn ("Task Name");
	m_pList->addColumn( "64-bit", 80 );
	m_pList->setSelectionMode (QListView::Extended);

	m_pList->setColumnAlignment (MF_MOD_NAME, AlignLeft);

	QObject::connect (m_pList, SIGNAL (doubleClicked (QListViewItem *)),
		SLOT (onDblClicked (QListViewItem *)));
	QObject::connect (m_pList, SIGNAL (rightButtonClicked (QListViewItem *,
		const QPoint &, 
		int)),
		SLOT (onRightClick (QListViewItem *, const QPoint &,
		int)));
	QObject::connect (m_pList, SIGNAL (contextMenuRequested (QListViewItem *,
		const QPoint &, 
		int)),
		SLOT (onRightClick (QListViewItem *, const QPoint &,
		int)));

	setFocusProxy (m_pList);
	setCentralWidget (m_pList);

	// Other options for the list view
	m_pList->setShowSortIndicator (TRUE);
	m_pList->setSorting (SYS_OFFSET_INDEX, FALSE);
	m_pList->setAllColumnsShowFocus (TRUE);
	onViewChanged(m_pViewShown);
	setCaption (caption);
	return TRUE;
}// SystemDataTab::display()




