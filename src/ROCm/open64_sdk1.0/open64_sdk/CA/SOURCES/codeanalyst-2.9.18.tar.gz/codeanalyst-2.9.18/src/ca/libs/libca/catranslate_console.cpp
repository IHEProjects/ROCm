#include "catranslate_console.h"
#include "catranslate_console_display.h"

ca_translate_console::ca_translate_console()
{
}

ca_translate_console::~ca_translate_console()
{
}


void ca_translate_console::init(vector < string > &events, 
	op_event_property * event_properties, 
	QString & session,
	unsigned int activeCounterMask,
	unsigned int ncpu,
	QString & jncPath,
	QString & caSession,
	EventMaskEncodeMap & events_map)
{
    CATranslate::init(events, event_properties, 
		session, activeCounterMask, 
		ncpu, 
		caSession,
		events_map);
		

    m_pStatusDisplay = new ca_translate_console_display();
    if (NULL == m_pStatusDisplay)
        return;
}



