
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _NEWSESSIONWIZARD_H_
#define _NEWSESSIONWIZARD_H_

#include "diffStruct.h"
#include "iNewSessionWizard.h"
#include "tbsreader.h"

/*
class SessionListItem : public QDataListItem
{
	Q_OBJECT;
public:

	TbsReader* getTbsReader()
	{ return *m_pTbsReader;};
private:
	TbsReader* m_pTbsReader;	
};
*/
////////////////////////////////////////////////////////

enum
{
	WIZARD_PAGE = 0,
	SESSION_DIFF_PAGE,
	MODULE_DIFF_PAGE
};

class NewSessionWizard : public iNewSessionWizard
{
	Q_OBJECT;
public:
	NewSessionWizard( QWidget* parent = 0, 
			QString nextName = "",
			const char* name = 0, 
			bool modal = FALSE, 
			WFlags fl = 0 );
	~NewSessionWizard();
	bool init();
	int getSessionDiffInfo(SESSION_DIFF_INFO_VEC* vec); 
	QString getSessionDiffName();

public slots:
	virtual void onBrowse();
	virtual void onAdd();
	virtual void onReset();
	virtual void onEdit();
	virtual void onRemove();
	virtual void onModuleAddBtn();
	virtual void onModuleRemoveBtn();
	virtual void onModule1Changed();
	virtual void onCAProfileDiffChanged(bool b);
	virtual void onModuleDiffChanged(bool b);
	
	virtual void next();
	virtual void back();
	
	    
private slots:
	void onSessionFileChanged();
	bool populateTaskComboBox();
	bool populateModuleComboBox();

private:
	TbsReader* m_pTbsReader;	
};

#endif //_NEWSESSIONWIZARD_H_
