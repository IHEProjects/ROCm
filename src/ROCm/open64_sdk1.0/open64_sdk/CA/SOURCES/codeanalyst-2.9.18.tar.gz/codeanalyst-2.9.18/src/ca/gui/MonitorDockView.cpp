
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qtooltip.h>

#include "MonitorDockView.h"

MonitorDockView::MonitorDockView(QWidget * parent, 
			const char * name , 
			WFlags f)
: QDockWindow(parent,name,f)
{
	m_pApp			= parent;
	m_pSnap			= NULL;
	m_pMonitorUpdater	= NULL;
	m_isStop		= false;

	setNewLine(false);
	setResizeEnabled(true);
	setCaption(QString(" Monitoring Tool"));
	setCloseMode(QDockWindow::Always);
}


MonitorDockView::~MonitorDockView()
{

}


void MonitorDockView::undock()
{ 	
	setMinimumWidth(500);
	setMinimumHeight(600);
	QDockWindow::undock();
}


void MonitorDockView::show()
{
	m_isStop = false;

	if (!init())
		return;

	QWidget::show();
}


void MonitorDockView::hide()
{
	if (!m_pMonitorUpdater)
		goto out; 

	m_snapMutex.lock();

	// Signal thread termination	
	m_isStop = true;
	m_snapMutex.unlock();

	// Wait for thread termination
	while(m_pMonitorUpdater->running()) {
		sleep(1);
	}
	
	// Delete Thread;
	if (m_pMonitorUpdater) {
		delete m_pMonitorUpdater;
		m_pMonitorUpdater = NULL;
	}	

out:
	QWidget::hide();
	emit oprofileDockViewNoShow();
}


bool MonitorDockView::init()
{
	///////////////////////////////////////////////////////////
	// Setup Monitor Updater
	if (!m_pMonitorUpdater) {
		m_pMonitorUpdater = new MonitorUpdater(m_pApp,
						&m_snapMutex, 
						m_pSnap,
						&m_isStop);
		if(!m_pMonitorUpdater)
			return false;

		m_pMonitorUpdater->start();
	}
	return true;
}


///////////////////////////////////////////////////////////////////////////////
void MonitorUpdater::run()
{
	// Wait to let the gui start
	sleep(1);
	
	while (m_pApp) {
		bool isSnapOk = false;
	
		m_pSnapMutex->lock();

		if (!*(m_isStop) 
		&& m_pSnapshot
		&& m_pSnapshot->takeSnapshot()) {
			isSnapOk = true;
		}

		m_pSnapMutex->unlock();

		if (!isSnapOk)
			break;

		if (m_pSnapshot)
			m_pSnapshot->signalSnapshotReady(m_pApp);

		msleep(m_msecSleep);
	}

	exit();
}
