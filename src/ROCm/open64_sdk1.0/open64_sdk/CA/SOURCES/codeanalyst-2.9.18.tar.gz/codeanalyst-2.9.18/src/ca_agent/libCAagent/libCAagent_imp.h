/**
 * @file libCAagent_imp.h
 * Actual implementation of the CAagent library
 *
 * @remark Read the file COPYING
 *
 * @author Lei Yu 
 * @author Jason Yeh
 */

#ifndef _LIB_CAAGENT_IMP_H
#define _LIB_CAAGENT_H

#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "smm.h"
#include "slock.h"
#include "ca_agent_bfd.h"
#include "config.h"

#include "list"

using namespace std;
typedef list<ca_jit_shm_entry> ca_jit_entry_list;

//	The shared buffer is used between Java profile agent and Oprofile 
//	daemon to share the Java function JIT info (start address and size).
//	Java profile agent writes into the shared buffer. Oprofile daemon 
//	reads from the buffer.
//
//	The shared buffer format - the shared buffer contains many pages if needed.
//	The first page contains a overall header, ca_shm_header, which has 
//		signature, version, page count and total entries.
// 	Following the overall header, there are page header, ca_shm_page_header
//	and many entries.
//
//	When there is no space for new entry, we will create a new page. The new 
//	page will only contain page header and entries.
//

struct ca_shm_header 
{
	unsigned char	shm_hdr_signature[4];
	unsigned int	shm_hdr_version;
	unsigned int	shm_hdr_page_cnt;
	unsigned int	shm_hdr_total_entries;
} __attribute__((packed));


struct ca_shm_page_header
{
	unsigned int page_index;
	unsigned int page_entry_count;
	unsigned long long next_page;
} __attribute__((packed));

// the structure defined in libCAagent.h
//struct ca_jit_shm_entry
//{
//	unsigned long long start_address;
//	unsigned int size;
//} __attribute__((packed));


class CAagent_buffer 
{
	enum { 
		max_mapping_entry_n = 512 
	};
	
public:
	CAagent_buffer() {
		mm = NULL;
		curr_page_hdr = NULL;
		m_tgid = 0;
		m_page_entry_read = 0;
		m_total_entry_read = 0;
	}


	~CAagent_buffer() {
		close_agent(m_tgid);
	}

	void close_agent(pid_t tgid) {
		if (mm == NULL || tgid == 0)
			return;

		m_lock.lock();
		unsigned int pageNum = shm_header->shm_hdr_page_cnt;
		for(unsigned int i = 0; i < pageNum; i++) {
			mm->remove_shared_memory(tgid, i, get_alloc_size(i));
		}
		m_lock.unlock();

		m_lock.delete_lock(tgid);
		
		if (mm != NULL) {
			delete mm;
			mm = NULL;
		}
	
		shm_header = NULL;
		curr_page_hdr = NULL;
		m_tgid = 0;
	}
	
	// This is used by Java profile agent	
	int open_agent(pid_t tgid) {
		int ret = -1;

		// LEI:TODO: creating dir should not be here.	
		// Make sure the directory exist and if not create it
		struct stat st;
		char jit_dir_pid[PATH_MAX];  
		snprintf(jit_dir_pid, PATH_MAX, "%s/%d/", CA_JIT_DIR, getpid());
		
		if (stat(jit_dir_pid, &st)) {
			 if (mkdir(jit_dir_pid, 0776) < 0) {
				return ret;
			 }
		}
		mm = new smm();
		if (!mm)
			return ret;

		// the overall header and first page which contains a page header 
		// and the many entries.
		unsigned int pageid = 0;
		unsigned int size = get_alloc_size(pageid);

		unsigned char * buffer = NULL;
		buffer = (unsigned char*) mm->create_shared_memory(tgid, 
					pageid, size); 

		if (buffer == NULL) {
			if (mm != NULL) {
				delete mm;
				mm = NULL;
			}
			return ret;
		}
	
		shm_header = (ca_shm_header*) buffer;
		
		curr_page_hdr = (ca_shm_page_header*) (buffer + 
					sizeof(ca_shm_header));

		m_lock.create_semaphore(tgid);

		// enter critical section to write data in the shared buffer
		m_lock.lock();

		// write shared memory header
		shm_header->shm_hdr_signature[0] = 'C';
		shm_header->shm_hdr_signature[1] = 'A';
		shm_header->shm_hdr_signature[2] = 'S';
		shm_header->shm_hdr_signature[3] = 'M';
		shm_header->shm_hdr_version = CA_SM_VERSION;
		shm_header->shm_hdr_page_cnt = 1;
		shm_header->shm_hdr_total_entries = 0;

		curr_page_hdr->page_index = pageid;
		curr_page_hdr->page_entry_count = 0;
		curr_page_hdr->next_page = NULL;

		// leave the critical section
		m_lock.unlock();

		m_tgid = tgid;

		ret = 0;
		return ret;
	}

	// This is used by Java profile agent. This is to write a 
	// JIT entry into shared memory. 
	//
	int add_mapping(ca_jit_shm_entry const * entry) {
		int ret = -1;

		if (!mm || !curr_page_hdr)
			return ret;

		unsigned char * buffer = NULL;
		ca_jit_shm_entry *p_entry = NULL;
		unsigned int page = 0;

		m_lock.lock();
		unsigned int entry_cnt = curr_page_hdr->page_entry_count;
		if (entry_cnt >= max_mapping_entry_n) {
			// there is no space in current page, need to create new page;
			page = shm_header->shm_hdr_page_cnt;
			buffer = (unsigned char*) mm->create_shared_memory(m_tgid, 
					page, get_alloc_size(page));
			if (buffer == NULL) {
				goto out;
			}

			// new page is created, update page count;
			shm_header->shm_hdr_page_cnt = page + 1;

			// update current page header
			curr_page_hdr->next_page = (unsigned long long) buffer;

			// move current page header to new page;
			curr_page_hdr = (ca_shm_page_header*) buffer;
			curr_page_hdr->page_index = page;
			curr_page_hdr->page_entry_count = 0;
			entry_cnt = 0;
		} else {
			buffer = (unsigned char*) curr_page_hdr;
		}

		// write entry info;
		p_entry = (ca_jit_shm_entry *) (buffer + sizeof (ca_shm_page_header)
						+ sizeof(ca_jit_shm_entry) * entry_cnt);
		p_entry->start_address = entry->start_address;
		p_entry->size = entry->size;

		// update page entry count
		curr_page_hdr->page_entry_count = entry_cnt + 1;

		// update total number of entries 
		shm_header->shm_hdr_total_entries++;

		ret = 0;

	out:
		m_lock.unlock();

		return ret;
	}

	// Write the JIT native code into an ELF bianry	
	int write_native_code(const char * symbol_name, 
			const void* code_addr, unsigned int size)
	{
		return m_bfd_out.write_symbol_content(symbol_name, code_addr, size);
	}
	

	// This is used by Oprofile daemon
	//
	int open_agent_read(pid_t tgid)
	{
		int ret = -1;
		
		mm = new smm();
		if (!mm)
			return ret;

		unsigned int pageid = 0;
		unsigned int size = get_alloc_size(pageid);
		unsigned char * buffer = NULL;

		if (m_lock.get_semaphore(tgid) < 0)
			goto out;
		
		
		m_lock.lock();
		buffer = (unsigned char*) mm->open_shared_memory(tgid, 
					pageid, size); 
		if (buffer != NULL) {
			shm_header = (ca_shm_header*) buffer;
		
			curr_page_hdr = (ca_shm_page_header*) (buffer + 
						sizeof(ca_shm_header));

			m_tgid = tgid;
			m_page_entry_read = 0;
			m_total_entry_read = 0;

			ret = 0;

		}
		m_lock.unlock();

	out:
		if (ret!= 0 && mm != NULL) {
			delete mm;
			mm = NULL;
		}

		return ret;
	}

	// This is to read JIT info that had stored in shared buffer.
	// If the entries had been read previously, we will skip them.
	//
	int read_mapping(ca_jit_entry_list &dest) {
		unsigned int total_read = 0;
		if (!mm)
			return total_read;

		ca_jit_shm_entry *p_entry = NULL;

		unsigned char * buffer = NULL;

		m_lock.lock();

		// Get current number of page page  
		unsigned int pageCnt = shm_header->shm_hdr_page_cnt;
	
		// Check if modified from last read
		if (m_total_entry_read == shm_header->shm_hdr_total_entries)
			goto out;	

		// Traverse through each shm page
		for(unsigned int page_id = 0; page_id < pageCnt; page_id++) {
			if (!curr_page_hdr)
				break;

			if(curr_page_hdr->page_entry_count > max_mapping_entry_n)
				break;

			// CASE 1: This page had been read previously
			if (page_id < curr_page_hdr->page_index)
				continue;

			// CASE 2: Check if new page is available
			if (page_id > curr_page_hdr->page_index) {
				buffer = (unsigned char*) mm->open_shared_memory(
							m_tgid, page_id, 
							get_alloc_size(page_id));
				if (buffer == NULL)
					break;

				curr_page_hdr = (ca_shm_page_header*) buffer;
				m_page_entry_read = 0;
			} else {
				// CASE 3: Read current page
				buffer = (unsigned char*) curr_page_hdr;
			}
		
			// Get the first entry of the page	
			p_entry = (ca_jit_shm_entry*) (buffer + sizeof(ca_shm_page_header));

			// Get the newly added entry of the page
			p_entry = p_entry + m_page_entry_read;

			// assert start is less than max_mapping_entry_n here;
			while (m_page_entry_read <  curr_page_hdr->page_entry_count) {
				dest.push_back(*p_entry);
				p_entry++;
				m_page_entry_read++;
				m_total_entry_read++;
				total_read++;
			}

		}
        out:	
		m_lock.unlock();
		return total_read;
	}

	// This is called by daemon to see if there are any new entries	
	int check_for_new_entry() {
		int ret; 
		m_lock.lock();
		ret = shm_header->shm_hdr_total_entries - m_total_entry_read;
		m_lock.unlock();
		return ret;
	}

private:
	unsigned int get_alloc_size(unsigned int page_id) 
	{
		unsigned int size;

		if (page_id == 0){
			// this is first page which contains overall header, 
			// page header and entries
			size = sizeof(ca_jit_shm_entry) * max_mapping_entry_n +
					sizeof( ca_shm_header) + sizeof(ca_shm_page_header);
		} else {
			// this is new page which only contains page header and entries.
			size = sizeof(ca_jit_shm_entry) * max_mapping_entry_n +
					sizeof(ca_shm_page_header);
		}
		return size;
	}


private:
	smm 			* mm;
	ca_shm_header		* shm_header;
	ca_shm_page_header 	* curr_page_hdr;

	// This is only used for reading 
	unsigned int 	m_page_entry_read;
	unsigned int 	m_total_entry_read;
	shared_lock 	m_lock;
	ca_agent_bfd 	m_bfd_out;
	pid_t 		m_tgid;

};


#endif

