
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#ifndef DISASSEMBLER_STANDALONE
#define _INDISASSEMBLERDLL
#endif

#include "disassembler.h"

using namespace n_Disassembler;

unsigned int CExtraInstInfoDisassembler::m_Count = 0;	// number of derivations hooking this disassembler object
unsigned int CExtraInstInfoDisassembler::m_NumRegistered = 0;	// number of registered derivatives.  Vectors are deleted when this goes to zero
std::list <CExtraExtraInstInfo *> CExtraInstInfoDisassembler::m_Hooks;	// list of Vectors allocated

Inst_Info *Get3dnowIndex( CDisassembler *pThis );
Inst_Info *GetFpuIndex( CDisassembler *pThis );
Inst_Info *GetSSEIndex( CDisassembler *pThis );
Inst_Info *GetSSEHiToLoIndex( CDisassembler *pThis );
Inst_Info *GetGroupIndex( CDisassembler *pThis );
Inst_Info *GetArplMovsxdIndex( CDisassembler *pThis );
Inst_Info *Get_2_b8_Index( CDisassembler *pThis );
Inst_Info *Get_2_bd_Index( CDisassembler *pThis );
Inst_Info *GetNopXchgPauseIndex( CDisassembler *pThis );
Inst_Info *GetCliClxStiStxIndex( CDisassembler *pThis );
Inst_Info *GetWDIndex( CDisassembler *pThis );
Inst_Info *GetWDQIndex( CDisassembler *pThis );
Inst_Info *GetWDQIndex64( CDisassembler *pThis );
Inst_Info *GetNewGroupIndex( CDisassembler *pThis );
Inst_Info *GetGroupCIndex( CDisassembler *pThis );
Inst_Info *GetPrefetchIndex( CDisassembler *pThis );
Inst_Info *GetModRmIndex( CDisassembler *pThis );
Inst_Info *GetJcxIndex( CDisassembler *pThis );
Inst_Info *Get_2_38_Index( CDisassembler *pThis );
Inst_Info *Get_2_38_XX_Index( CDisassembler *pThis );
Inst_Info *Get_Typeof_2_3a_Index( CDisassembler *pThis );
Inst_Info *Get_2_3a_Index( CDisassembler *pThis );
Inst_Info *Get_2_3a_XX_Index( CDisassembler *pThis );
Inst_Info *Get_2_3a_Type2_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode3_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode3_Ops_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode3_Oc1_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode3_Oc1_Ops_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode4_Ops_Index( CDisassembler *pThis );
Inst_Info *Get_Opcode4_Oc1_Index( CDisassembler *pThis );
Inst_Info *Get_BNI_Type1_Index( CDisassembler *pThis );

void CInstructionData::LogOpcodeOffset( int offset )
{
	if( m_numOpcodes < MAX_OPCODES )
	{
		for( int i = 0; i < m_numOpcodes; i++ )
			if( offset < m_opcodeOffsets[i] )
			{
				for( int j = m_numOpcodes++; j > i; j-- )
					m_opcodeOffsets[j] = m_opcodeOffsets[j-1];

				m_opcodeOffsets[i] = offset;
				return;
			}

		m_opcodeOffsets[m_numOpcodes++] = offset;
	}
	else
		printf( "ERROR: LogOpcodeOffset: max opcodes (%d) exceeded!!!\n", MAX_OPCODES );
}

CDisassembler::CDisassembler()
{
//	m_bUpperCase = true;
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	m_bUpperCase = false;
	m_opcodeSeperator = " ";
	m_hexPostfix = "h";
	m_rex_prefix = 0;
	m_longmode = m_rex32mode = m_svmmode = false;
	m_dbit = true;
	m_bShowSize = false;
	m_bCalculateRipRelative = false;
	m_mnem = m_mnem_buffer;
	m_alternateDecodings = 0;
}

CDisassembler::~CDisassembler()
{
}

char *CDisassembler::Disassemble( AMD_UINT8 *inst_buf )
{
	m_bCalculateRipRelative = false;
	if( Decode( inst_buf ) )
	{
		Disassemble();
		return( m_mnem );
	}

	return( NULL );
}

char *CDisassembler::Disassemble( AMD_UINT8 *inst_buf, int bufferLength )
{
	m_maxInstructionBytes = bufferLength;
	char * rval = Disassemble( inst_buf );
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	return rval;
}

char *CDisassembler::Disassemble( AMD_UINT8 *inst_buf, int bufferLength, AMD_UINT64 rip )
{
	m_maxInstructionBytes = bufferLength;
	char * rval = Disassemble( inst_buf, rip );
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	return rval;
}

bool CDisassembler::Decode( AMD_UINT8 *inst_buf, int bufferLength )
{
	m_maxInstructionBytes = bufferLength;
	bool rval = Decode( inst_buf );
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	return rval;
}

char *CDisassembler::Disassemble( AMD_UINT8 *inst_buf, int bufferLength, bool dbit )
{
	m_maxInstructionBytes = bufferLength;
	char * rval = Disassemble( inst_buf, dbit );
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	return rval;
}

bool CDisassembler::Decode( AMD_UINT8 *inst_buf, int bufferLength, bool dbit )
{
	m_maxInstructionBytes = (bufferLength <= MAX_INSTRUCTION_BYTES) ? bufferLength : MAX_INSTRUCTION_BYTES;
	bool rval = Decode( inst_buf, dbit );
	m_maxInstructionBytes = MAX_INSTRUCTION_BYTES;
	return rval;
}

char *CDisassembler::Disassemble( AMD_UINT8 *inst_buf, AMD_UINT64 rip )
{
	m_rip = rip;
	m_bCalculateRipRelative = true;

	if( Decode( inst_buf ) )
	{
		Disassemble();
		return( m_mnem );
	}

	return( NULL );
}

char *CDisassembler::Disassemble()
{
	m_mnem[0] = '\0';		// clear mnemonic string

	GetPrefixBytesString( m_mnem );

	strcat( m_mnem, (char *)(m_opcode_table_ptr->mnem) );

	// The immediate value could potentially correspond to multiple operands. Consequently,
	// m_immediateData will be used to facilitate processing multiple operands.
	m_immediateData = m_immd;

	const char * seperator = m_opcodeSeperator;
	for( int i = 0; i < MAX_OPERANDS; i++ )
	{
		int index = m_operand_indices[i];
		m_pOperand = &m_operands[i];
		if( EXPLICIT_OPERAND(*m_pOperand) && (S_DisassembleOperandFnPtrs[m_opcode_table_ptr->operands[index]] != (PVOIDMEMBERFUNC)NULL) )
		{
			strcat( m_mnem, seperator );
			seperator = ",";
			if( m_bShowSize ) m_pOperand->flags |= OPF_SHOWSIZE;
			(this->*S_DisassembleOperandFnPtrs[m_opcode_table_ptr->operands[index]])();
		}
	}

	if( m_bUpperCase )
#if 1
		for( size_t i = 0; i < strlen( m_mnem ); i++ )
			m_mnem[i] = (char)toupper( m_mnem[i] );
#else
		strupr( m_mnem );
#endif

	return( m_mnem );
}

bool CDisassembler::Decode( AMD_UINT8 *inst_buf )
{
	if( m_longmode && m_dbit )
		return( false );

	m_inst_buf = inst_buf;
	m_inst_flags = 0;
	m_len = 0;
	m_rex_prefix = 0;
	m_modrm = 0;
	m_sib = 0;
	m_drex = 0;
	m_disp = (AMD_UINT64)0;
	m_immd = (AMD_UINT64)0;
	m_errorLevel = NO_EXCEPTION;

	m_numOperands = 0;
	m_numOpcodes = 0;
	memset( m_opcodeOffsets, -1, sizeof( m_opcodeOffsets ) );
	m_modrmOffset = -1;
	m_sibOffset = -1;
	m_drexOffset = -1;
	m_displacementOffset = -1;
	m_immediateOffset = -1;
	m_bHasIndex = false;
	m_bHasBase = false;
	m_bModrmDecoded = false;

	m_displacementLength = 0;
	m_immediateLength = 0;

	m_prefix_bytes.ClearBytes();
	
	try
	{
		DecodeOpcodeBytes();
		if( GetInfoPtr() )
		{
			SetInstructionFlags();
			DecodeOperandBytes();
			return true;
		}

		m_errorLevel = FORMAT_EXCEPTION;		// if you got here, then the opcodes must be invalid
	}
	catch( CLengthException )
	{
		m_errorLevel = LENGTH_EXCEPTION;
	}
	catch( CFormatException )
	{
		m_errorLevel = FORMAT_EXCEPTION;
	}

	return false;
}

bool CDisassembler::GetInfoPtr()
{
	m_opcode_table_ptr
	=	(m_inst_flags & INST_LONGOPCODE)
	  ? &S_twoByteOpcodes_tbl[GetOpcode(1)]
	  : &S_oneByteOpcodes_tbl[GetOpcode(0)];

	while( m_opcode_table_ptr->GetInfoPtr != NULL )
	{
		Inst_Info *(*pIndexRoutine)(CDisassembler *pThis) = m_opcode_table_ptr->GetInfoPtr;

		if( (m_opcode_table_ptr = (pIndexRoutine)( this )) == NULL )
			break;
	}

	return( (m_opcode_table_ptr != NULL) && (m_opcode_table_ptr->mnem != NULL) );
}

void CDisassembler::DecodeOpcodeBytes()
{
	AMD_UINT32 escape = 0;
	
	while( 1 )
	{
		AMD_UINT8 instByte = GetByte();

		if( instByte == 0x0F )
		{
			LogOpcodeOffset( m_len - 1 );

			if( escape )	// amd3d instructions (0x0f 0x0f)
			{
				m_inst_flags |= (INST_LONGOPCODE | INST_AMD3D);
				int offset = DecodeAmdOperandBytes();

				PeekByte( offset );
				LogOpcodeOffset( m_len + offset );

				break;		// exit the while loop
			}

			escape = 1;
		}
		else
		{
			if( !escape )
			{
				if
				(	(S_PrefixByteFnPtrs[instByte] != (PVOIDMEMBERFUNC)NULL) 
				 && ((m_longmode || m_rex32mode) || (S_PrefixByteFnPtrs[instByte] != &CDisassembler::PrefixRex))
				)
					m_prefix_bytes.AddByte( instByte );
				else
				{
					LogOpcodeOffset( m_len - 1 );
					break;		// exit the while loop
				}
			}
			else
			{
				LogOpcodeOffset( m_len - 1 );
				m_inst_flags |= INST_LONGOPCODE;

				switch( instByte )
				{
					case 0x38: // MNI instruction
					case 0x3a: // MNI instruction
                    {
                        GetByte();
                        LogOpcodeOffset( m_len - 1 );

                        break;
                    }
					case 0x24:
					case 0x25:
					{
						if( HasRexPrefix() )
							throw CFormatException();

						GetByte();
						LogOpcodeOffset( m_len - 1 );

						break;
					}
					case 0x7A:
					case 0x7B:
					{
						GetByte();
						LogOpcodeOffset( m_len - 1 );

						break;
					}
				}

				break;		// exit the while loop
			}
		}
	} 
	// the REX prefix must be the last prefix or it is ignored
	if( m_longmode || m_rex32mode )
	{
		AMD_UINT8 prefix;
		if( m_prefix_bytes.GetLastByte( &prefix ) && REX_PREFIX( prefix ) )
			m_rex_prefix = prefix;
	}
}

// Determine the length of the operand bytes
int CDisassembler::DecodeAmdOperandBytes()
{
	int length = 0;
	AMD_UINT8 modrm = PeekByte( length++ );
	int addressMode;

	if( !m_longmode )
	{
		if( m_dbit )
			addressMode = ScanForAddressOverride() ? 16 : 32;
		else
			addressMode = ScanForAddressOverride() ? 32 : 16;
	}
	else
		addressMode = 32;

	if( addressMode == 32 )
	{
		if( MEM( modrm ) && (RM( modrm ) == 4) )
		{
			AMD_UINT8 sib = PeekByte( length++ );
				
			switch( MOD( modrm ) )
			{
				case 0:
					if( BASE( sib ) == 5 )
						length += 4;
					break;

				case 1:
					length += 1;
					break;
					
				case 2:
					length += 4;
					break;
			}
		}
		else
		{
			switch( MOD( modrm ) )
			{
				case 0:
					if( RM( modrm ) == 5 )
						length += 4;
					break;

				case 1:
					length += 1;
					break;

				case 2:
					length += 4;
					break;
			}
		}
	}
	else
	{
		if( ((MOD( modrm ) == 0) && (RM( modrm ) == 6)) || (MOD( modrm ) == 2) )
			length += 2;
		else if( MOD( modrm ) == 1 )
			length += 1;
	}

	return length;
}

void CDisassembler::SetInstructionFlags( void )
{
	m_inst_flags |= m_opcode_table_ptr->instruction_flags;

	if( m_longmode )
	{
		if( (m_inst_flags & INST_AMD64INVALID) != 0 )
			throw CFormatException();
			
		m_inst_flags |= (INST_DATA32 | INST_ADDR64);
	}
	else if( m_dbit )
		m_inst_flags |= (INST_DATA32 | INST_ADDR32);
	else
		m_inst_flags |= (INST_DATA16 | INST_ADDR16);

	AMD_UINT8 prefix;
	for( int i = 0; m_prefix_bytes.GetByte( i, &prefix ); i++ )
		(this->*S_PrefixByteFnPtrs[prefix])();
}

void CDisassembler::ConfigureBniOperands( void )
{
	if( (m_inst_flags & INST_NO_OC) == 0 )
	{
		if( m_numOperands == 4 )
		{
			switch( (OPCODE3_OC1(GetOpcode(2)) << 1) | DREX_OC0(m_drex) )
			{
				case 0:
					m_operands[3] = m_operands[2];
					m_operands[2] = m_operands[1];
					m_operands[1] = m_operands[0];
					m_operand_indices[3] = 2;
					m_operand_indices[2] = 1;
					m_operand_indices[1] = 0;
					break;
	
				case 1:
					m_operands[3] = m_operands[1];
					m_operands[1] = m_operands[0];
					m_operand_indices[1] = 0;
					m_operand_indices[3] = 1;
					break;
	
				case 2:
					m_operands[3] = m_operands[0];
					m_operand_indices[3] = 0;
					break;
	
				case 3:
					m_operands[3] = m_operands[1]; // temporary
					m_operands[1] = m_operands[2];
					m_operands[2] = m_operands[3];
					m_operands[3] = m_operands[0];
					m_operand_indices[1] = 2;
					m_operand_indices[2] = 1;
					m_operand_indices[3] = 0;
					break;
			}
		}
		else
		{
			if( DREX_OC0(m_drex) == 1 )
			{
				m_operands[3] = m_operands[1]; // temporary
				m_operands[1] = m_operands[2];
				m_operands[2] = m_operands[3];
				m_operand_indices[1] = 2;
				m_operand_indices[2] = 1;
			}
		}
	}
	else if( (m_numOperands == 4) && (m_operands[3].type == OPERANDTYPE_NONE) )
	{
		m_operands[3] = m_operands[0];
		m_operand_indices[3] = 0;
	}
}

// At this point m_len should index the byte following the opcode (except for 3dnow).
// At the end of this routine, m_len will contain the number of bytes
// in the instruction (i.e it will index the byte following the last byte).
void CDisassembler::DecodeOperandBytes()
{
	if( m_inst_flags & INST_DREX )
	{
		if( REX_PREFIX(m_rex_prefix) )
			throw CFormatException();

		// Get drex byte
		GetModrmByte();
		DecodeModrm();
	}

	int i;
	for( i = 0; i < MAX_OPERANDS; i++ )
	{
		if( m_opcode_table_ptr->operands[i] == OPRND_na )
		{
			m_numOperands = i;
			break;
		}
		else if( i == (MAX_OPERANDS - 1) )
			m_numOperands = MAX_OPERANDS;

		m_operand_indices[i] = i;
		m_pOperand = &m_operands[i];
		m_pOperand->Initialize( m_opcode_table_ptr->operand_flags[i] );

		if( S_DecodeOperandFnPtrs[m_opcode_table_ptr->operands[i]] != (PVOIDMEMBERFUNC)NULL )
			(this->*S_DecodeOperandFnPtrs[m_opcode_table_ptr->operands[i]])();
	}
	for( ; i < MAX_OPERANDS; i++ )
		m_operand_indices[i] = i;

	if( (m_inst_flags & INST_DREX) != 0 )
		ConfigureBniOperands();

	if( HasLockPrefix() )
		CheckLockPrefix();

	// If this is an AMD instruction, we can now (after scanning remainder of instruction) 
	//	increment m_len to account for the opcode byte at the end of the instruction bytes
	if( (m_inst_flags & INST_AMD3D) != 0 )
		m_len++;
}

int CDisassembler::GetDataSize()
{
	if( m_longmode )
	{
		AMD_UINT8 prefix;

		if( m_prefix_bytes.GetLastByte( &prefix ) && REX_PREFIX( prefix ) && REX_OPERAND64( prefix ) )
			return( 64 );

		// going backwards (last prefix takes precedence)
		for( int i = m_prefix_bytes.GetCount() - 1; i >= 0; i-- )
			if( m_prefix_bytes.GetByte( i, &prefix ) && (prefix == PREFIX_DATA) )
				return( 16 );

		return( 32 );
	}
	else
	{
		AMD_UINT8 prefix;

		// going backwards (last prefix takes precedence)
		for( int i = m_prefix_bytes.GetCount() - 1; i >= 0; i-- )
			if( m_prefix_bytes.GetByte( i, &prefix ) && (prefix == PREFIX_DATA) )
				return( m_dbit ? 16 : 32 );

		return( m_dbit ? 32 : 16 );
	}
}

void CDisassembler::HandleExtraPrefixOpcode()
{
	// going forwards (first prefix takes precedence)
	AMD_UINT32 count = m_prefix_bytes.GetCount();
	for( AMD_UINT32 i = 0; i < count; i++ )
	{
		AMD_UINT8 prefix;
		if( m_prefix_bytes.GetByte( i, &prefix ) )
		{
			switch( prefix )
			{
				case PREFIX_DATA:
					m_prefix_bytes.RemoveIndex( i );
					LogOpcodeOffset( i );
					return;

				case PREFIX_REPNE:
					m_prefix_bytes.RemoveIndex( i );
					LogOpcodeOffset( i );
					return;

				case PREFIX_REP:
					m_prefix_bytes.RemoveIndex( i );
					LogOpcodeOffset( i );
					return;
			}
		}
	}
}

void CDisassembler::HandleExtraRepOpcode()
{
	// going forwards (first prefix takes precedence)
	AMD_UINT32 count = m_prefix_bytes.GetCount();
	for( AMD_UINT32 i = 0; i < count; i++ )
	{
		AMD_UINT8 prefix;
		if( m_prefix_bytes.GetByte( i, &prefix ) )
		{
			if( prefix == PREFIX_REP )
			{
				m_prefix_bytes.RemoveIndex( i );
				LogOpcodeOffset( i );
				return;
			}
		}
	}
}

void CDisassembler::HandleExtraF3Opcode()
{
	// going backward (last prefix takes precedence)
	int count = m_prefix_bytes.GetCount();
	for( int i = (count - 1); i >= 0; i-- )
	{
		AMD_UINT8 prefix;
		if( m_prefix_bytes.GetByte( i, &prefix ) )
		{
			if( prefix == PREFIX_REP )
			{
				m_prefix_bytes.RemoveIndex( i );
				LogOpcodeOffset( i );
				return;
			}
			else if( prefix == PREFIX_REPNE )
				return;
		}
	}
}

AMD_UINT8 CDisassembler::GetByte()
{
	if( m_len < m_maxInstructionBytes )
		return m_inst_buf[m_len++];
	else
		throw CLengthException();
}

AMD_UINT8 CDisassembler::PeekByte( int offset )	// used only to get offset to 3dx opcode
{
	if( (m_len + offset) < m_maxInstructionBytes )
		return m_inst_buf[m_len + offset];
	else
		throw CLengthException();
}

const char *CDisassembler::S_PrefixByteStrings[] =
{
	/* 0x00-7 */	"", "", "", "", "", "", "", "",
	/* 0x08-f */	"", "", "", "", "", "", "", "",
	/* 0x10-7 */	"", "", "", "", "", "", "", "",
	/* 0x18-f */	"", "", "", "", "", "", "", "",
	/* 0x20-7 */	"", "", "", "", "", "", "", "",
	/* 0x28-f */	"", "", "", "", "", "", "", "",
	/* 0x30-7 */	"", "", "", "", "", "", "", "",
	/* 0x38-f */	"", "", "", "", "", "", "", "",
#if 0
	/* 0x40-7 */	"rex_0 ", "rex_1 ", "rex_2 ", "rex_3 ", "rex_4 ", "rex_5 ", "rex_6 ", "rex_7 ",
	/* 0x48-f */	"rex_8 ", "rex_9 ", "rex_a ", "rex_b ", "rex_c ", "rex_d ", "rex_e ", "rex_f ",
#else
	/* 0x40-7 */	"", "", "", "", "", "", "", "",
	/* 0x48-f */	"", "", "", "", "", "", "", "",
#endif
	/* 0x50-7 */	"", "", "", "", "", "", "", "",
	/* 0x58-f */	"", "", "", "", "", "", "", "",
	/* 0x60-7 */	"", "", "", "", "", "", "", "",
	/* 0x68-f */	"", "", "", "", "", "", "", "",
	/* 0x70-7 */	"", "", "", "", "", "", "", "",
	/* 0x78-f */	"", "", "", "", "", "", "", "",
	/* 0x80-7 */	"", "", "", "", "", "", "", "",
	/* 0x88-f */	"", "", "", "", "", "", "", "",
	/* 0x90-7 */	"", "", "", "", "", "", "", "",
	/* 0x98-f */	"", "", "", "", "", "", "", "",
	/* 0xa0-7 */	"", "", "", "", "", "", "", "",
	/* 0xa8-f */	"", "", "", "", "", "", "", "",
	/* 0xb0-7 */	"", "", "", "", "", "", "", "",
	/* 0xb8-f */	"", "", "", "", "", "", "", "",
	/* 0xc0-7 */	"", "", "", "", "", "", "", "",
	/* 0xc8-f */	"", "", "", "", "", "", "", "",
	/* 0xd0-7 */	"", "", "", "", "", "", "", "",
	/* 0xd8-f */	"", "", "", "", "", "", "", "",
	/* 0xe0-7 */	"", "", "", "", "", "", "", "",
	/* 0xe8-f */	"", "", "", "", "", "", "", "",
	/* 0xf0	  */	"lock ",
	/* 0xf1	  */	"",
	/* 0xf2	  */	"repne ",
	/* 0xf3	  */	"rep ",
	/* 0xf4-7 */	"", "", "", "",
	/* 0xf8-f */	"", "", "", "", "", "", "", ""
};

void CDisassembler::GetPrefixBytesString( char *str )
{
	for( AMD_UINT32 i = 0; i < m_prefix_bytes.GetCount(); i++ )
	{
		AMD_UINT8 prefix;
		if( m_prefix_bytes.GetByte( i, &prefix ) )
			if( (prefix != PREFIX_LOCK) || ((m_inst_flags & INST_LOCK_OVERUSED) == 0) )
				strcat( str, S_PrefixByteStrings[prefix] );
	}
}

Inst_Info CDisassembler::S_oneByteOpcodes_tbl[]	=
{
	{ /* 0x00 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"push es", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"pop es", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x08 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x09 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0a */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0b */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0c */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0d */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0e */ 
		"push cs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x10 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x11 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x12 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x13 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x14 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x15 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x16 */ 
		"push ss", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x17 */ 
		"pop ss", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x18 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x19 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1a */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1b */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1c */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1d */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1e */ 
		"push ds", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1f */ 
		"pop ds", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x20 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x21 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x22 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x23 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x24 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x25 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x26 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x27 */ 
		"daa", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x28 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x29 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2a */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2b */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2c */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2d */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2e */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x2f */ 
		"das", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x30 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x31 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x32 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x33 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x34 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x35 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x36 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x37 */ 
		"aaa", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x38 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x39 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3a */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3b */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3c */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3d */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3e */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x3f */ 
		"aas", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x40 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x41 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x42 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x43 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x44 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x45 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x46 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x47 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x48 */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x49 */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4a */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4b */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4c */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4d */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4e */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x4f */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x50 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x51 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x52 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x53 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x54 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x55 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x56 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x57 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x58 */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x59 */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5a */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5b */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5c */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5d */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5e */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x5f */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_64,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x60 */ 
		S_group_1_60_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x61 */ 
		S_group_1_61_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x62 */ 
		"bound", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Gv,		OPRND_M,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x63 */ 
		S_group_1_63_tbl, GetArplMovsxdIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x64 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x65 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x66 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x67 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x68 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_Iv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x69 */ 
		"imul", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_Iv,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6a */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_Ib,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6b */ 
		"imul", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6c */ 
		"insb", NULL, INST_NONE, NULL,
		{ OPRND_Yb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6d */ 
		S_group_1_6d_tbl, GetWDIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6e */ 
		"outsb", NULL, INST_NONE, NULL,
		{ OPRND_Xb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x6f */ 
		S_group_1_6f_tbl, GetWDIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x70 */ 
		"jo", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x71 */ 
		"jno", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x72 */ 
		"jb", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x73 */ 
		"jnb", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x74 */ 
		"jz", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x75 */ 
		"jnz", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x76 */ 
		"jbe", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x77 */ 
		"jnbe", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x78 */ 
		"js", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x79 */ 
		"jns", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7a */ 
		"jp", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7b */ 
		"jnp", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7c */ 
		"jl", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7d */ 
		"jnl", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7e */ 
		"jle", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x7f */ 
		"jnle", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x80 */ 
		S_group_1_80_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x81 */ 
		S_group_1_81_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x82 */ 
		S_group_1_82_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x83 */ 
		S_group_1_83_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x84 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x85 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x86 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_LOCK,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x87 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_LOCK,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x88 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x89 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8a */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Gb,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8b */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8c */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_Sw,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8d */ 
		"lea", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_M,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8e */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Sw,		OPRND_Ew,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8f */ 
		"pop", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x90 */ 
		S_group_1_90_tbl, GetNopXchgPauseIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x91 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x92 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x93 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x94 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x95 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x96 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x97 */ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x98 */ 
		S_group_1_98_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x99 */ 
		S_group_1_99_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9a */ 
		"call", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Ap,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9b */ 
		"fwait", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9c */ 
		S_group_1_9c_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9d */ 
		S_group_1_9d_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9e */ 
		"sahf", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9f */ 
		"lahf", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa0 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ob,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa1 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Ov,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa2 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Ob,		OPRND_AL,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa3 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Ov,		OPRND_eAX,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa4 */ 
		"movsb", NULL, INST_NONE, NULL,
		{ OPRND_Yb,		OPRND_Xb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa5 */ 
		S_group_1_a5_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa6 */ 
		"cmpsb", NULL, INST_NONE, NULL,
		{ OPRND_Yb,		OPRND_Xb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa7 */ 
		S_group_1_a7_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa8 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa9 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xaa */ 
		"stosb", NULL, INST_NONE, NULL,
		{ OPRND_Yb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xab */ 
		S_group_1_ab_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xac */ 
		"lodsb", NULL, INST_NONE, NULL,
		{ OPRND_Xb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xad */ 
		S_group_1_ad_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xae */ 
		"scasb", NULL, INST_NONE, NULL,
		{ OPRND_Yb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xaf */ 
		S_group_1_af_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb0 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb1 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb2 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb3 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb4 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb5 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb6 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb7 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_breg,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb8 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb9 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xba */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbb */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbc */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbd */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbe */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbf */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_Iv64,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_64,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		S_group_1_c0_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		S_group_1_c1_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		S_group_1_c2_tbl, GetWDQIndex64, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		S_group_1_c3_tbl, GetWDQIndex64, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"les", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Gv,		OPRND_Mp,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"lds", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Gv,		OPRND_Mp,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"enter", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"leave", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		S_group_1_ca_tbl, GetWDQIndex64, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		S_group_1_cb_tbl, GetWDQIndex64, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"int3", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"int", NULL, INST_NONE, NULL,
		{ OPRND_Ib,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"into", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		S_group_1_cf_tbl, GetWDQIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		S_group_1_d0_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		S_group_1_d1_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		S_group_1_d2_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		S_group_1_d3_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"aam", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Ib,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"aad", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Ib,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"salc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"xlat", NULL, INST_NONE, NULL,
		{ OPRND_eBXAl,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		S_group_1_d8_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		S_group_1_d9_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		S_group_1_da_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		S_group_1_db_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		S_group_1_dc_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		S_group_1_dd_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		S_group_1_de_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		S_group_1_df_tbl, GetFpuIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"loopne", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"loope", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"loop", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		S_group_1_e3_tbl, GetJcxIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"in", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"in", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		"out", NULL, INST_NONE, NULL,
		{ OPRND_Ib,		OPRND_AL,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		"out", NULL, INST_NONE, NULL,
		{ OPRND_Ib,		OPRND_eAX,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"call", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"jmp", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"jmp", NULL, INST_AMD64INVALID, NULL,
		{ OPRND_Ap,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"jmp", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"in", NULL, INST_NONE, NULL,
		{ OPRND_AL,		OPRND_DX,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"in", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_DX,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"out", NULL, INST_NONE, NULL,
		{ OPRND_DX,		OPRND_AL,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"out", NULL, INST_NONE, NULL,
		{ OPRND_DX,		OPRND_eAX,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"icebp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"hlt", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"cmc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		S_group_1_f6_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		S_group_1_f7_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		"clc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		"stc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		S_group_1_fa_tbl, GetCliClxStiStxIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		S_group_1_fb_tbl, GetCliClxStiStxIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		"cld", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		"std", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		S_group_1_fe_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		S_group_1_ff_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

// two byte	opcodes	(0x0f as first byte)
Inst_Info CDisassembler::S_twoByteOpcodes_tbl[]=
{ 
	{ /* 0x0f 0x00 */ 
		S_group_2_00_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x01 */ 
		S_group_2_01_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x02 */ 
		"lar", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ew,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x03 */ 
		"lsl", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x04 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x05 */ 
		"syscall", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x06 */ 
		"clts", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x07 */ 
		"sysret", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x08 */ 
		"invd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x09 */ 
		"wbinvd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0a */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0b */ 
		"ud2", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0c */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0d */ 
		S_group_2_0d_tbl, GetPrefetchIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0e */ 
		"femms", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x0f */ 
		S_group_2_0f_tbl, Get3dnowIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x10 */ 
		S_group_2_10_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x11 */ 
		S_group_2_11_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x12 */ 
		S_group_2_12_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x13 */ 
		S_group_2_13_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x14 */ 
		S_group_2_14_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x15 */ 
		S_group_2_15_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x16 */ 
		S_group_2_16_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x17 */ 
		S_group_2_17_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x18 */ 
		S_group_2_18_tbl, GetGroupCIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x19 */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1a */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1b */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1c */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1d */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1e */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x1f */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x20 */ 
		"mov", NULL, INST_LOCK_OVERUSED, NULL,
		{ OPRND_Rd,		OPRND_Cd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x21 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Rd,		OPRND_Dd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x22 */ 
		"mov", NULL, INST_LOCK_OVERUSED, NULL,
		{ OPRND_Cd,		OPRND_Rd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x23 */ 
		"mov", NULL, INST_NONE, NULL,
		{ OPRND_Dd,		OPRND_Rd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x24 */ 
		S_group_2_24_tbl, Get_Opcode3_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x25 */ 
		S_group_2_25_tbl, Get_Opcode3_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x26 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x27 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x28 */ 
		S_group_2_28_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x29 */ 
		S_group_2_29_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2a */ 
		S_group_2_2a_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2b */ 
		S_group_2_2b_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2c */ 
		S_group_2_2c_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2d */ 
		S_group_2_2d_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2e */ 
		S_group_2_2e_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x2f */ 
		S_group_2_2f_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x30 */ 
		"wrmsr", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x31 */ 
		"rdtsc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x32 */ 
		"rdmsr", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x33 */ 
		"rdpmc", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x34 */ 
		"sysenter", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x35 */ 
		"sysexit", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x36 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x37 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x38 */ 
		S_group_2_38_tbl, Get_2_38_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x39 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3a */ 
		S_group_Typeof_2_3a_tbl, Get_Typeof_2_3a_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3b */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3c */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3d */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3e */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x3f */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x40 */ 
		"cmovo", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x41 */ 
		"cmovno", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x42 */ 
		"cmovb", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x43 */ 
		"cmovae", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x44 */ 
		"cmove", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x45 */ 
		"cmovne", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x46 */ 
		"cmovbe", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x47 */ 
		"cmova", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x48 */ 
		"cmovs", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x49 */ 
		"cmovns", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4a */ 
		"cmovp", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4b */ 
		"cmovnp", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4c */ 
		"cmovl", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4d */ 
		"cmovge", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4e */ 
		"cmovle", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x4f */ 
		"cmovg", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x50 */ 
		S_group_2_50_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x51 */ 
		S_group_2_51_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x52 */ 
		S_group_2_52_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x53 */ 
		S_group_2_53_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x54 */ 
		S_group_2_54_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x55 */ 
		S_group_2_55_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x56 */ 
		S_group_2_56_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x57 */ 
		S_group_2_57_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x58 */ 
		S_group_2_58_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x59 */ 
		S_group_2_59_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5a */ 
		S_group_2_5a_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5b */ 
		S_group_2_5b_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5c */ 
		S_group_2_5c_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5d */ 
		S_group_2_5d_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5e */ 
		S_group_2_5e_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x5f */ 
		S_group_2_5f_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x60 */ 
		S_group_2_60_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x61 */ 
		S_group_2_61_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x62 */ 
		S_group_2_62_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x63 */ 
		S_group_2_63_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x64 */ 
		S_group_2_64_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x65 */ 
		S_group_2_65_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x66 */ 
		S_group_2_66_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x67 */ 
		S_group_2_67_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x68 */ 
		S_group_2_68_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x69 */ 
		S_group_2_69_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6a */ 
		S_group_2_6a_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6b */ 
		S_group_2_6b_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6c */ 
		S_group_2_6c_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6d */ 
		S_group_2_6d_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6e */ 
		S_group_2_6e_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x6f */ 
		S_group_2_6f_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x70 */ 
		S_group_2_70_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x71 */ 
		S_group_2_71_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x72 */ 
		S_group_2_72_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x73 */ 
		S_group_2_73_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x74 */ 
		S_group_2_74_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x75 */ 
		S_group_2_75_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x76 */ 
		S_group_2_76_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x77 */ 
		"emms", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x78 */ 
		S_group_2_78_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x79 */ 
		S_group_2_79_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7a */ 
		S_group_2_7a_tbl, Get_Opcode3_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7b */ 
		S_group_2_7b_tbl, Get_Opcode3_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7c */ 
		S_group_2_7c_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7d */ 
		S_group_2_7d_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7e */ 
		S_group_2_7e_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x7f */ 
		S_group_2_7f_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x80 */ 
		"jo", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x81 */ 
		"jno", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x82 */ 
		"jb", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x83 */ 
		"jnb", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x84 */ 
		"jz", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x85 */ 
		"jnz", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x86 */ 
		"jbe", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x87 */ 
		"jnbe", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x88 */ 
		"js", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x89 */ 
		"jns", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8a */ 
		"jp", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8b */ 
		"jnp", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8c */ 
		"jl", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8d */ 
		"jnl", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8e */ 
		"jle", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x8f */ 
		"jnle", NULL, INST_NONE, NULL,
		{ OPRND_Jv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x90 */ 
		"seto", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x91 */ 
		"setno", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x92 */ 
		"setb", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x93 */ 
		"setnb", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x94 */ 
		"setz", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x95 */ 
		"setnz", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x96 */ 
		"setbe", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x97 */ 
		"setnbe", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x98 */ 
		"sets", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x99 */ 
		"setns", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9a */ 
		"setp", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9b */ 
		"setnp", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9c */ 
		"setl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9d */ 
		"setnl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9e */ 
		"setle", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0x9f */ 
		"setnle", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa0 */ 
		"push fs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa1 */ 
		"pop fs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa2 */ 
		"cpuid", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa3 */ 
		"bt", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa4 */ 
		"shld", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa5 */ 
		"shld", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_CL,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa8 */ 
		"push gs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xa9 */ 
		"pop gs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xaa */ 
		"rsm", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xab */ 
		"bts", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xac */ 
		"shrd", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xad */ 
		"shrd", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_CL,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xae */ 
		S_group_2_ae_tbl, GetNewGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xaf */ 
		"imul", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb0 */ 
		"cmpxchg", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb1 */ 
		"cmpxchg", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb2 */ 
		"lss", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Mp,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb3 */ 
		"btr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb4 */ 
		"lfs", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Mp,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb5 */ 
		"lgs", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Mp,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb6 */ 
		"movzx", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb7 */ 
		"movzx", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ew,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb8 */ 
		S_group_2_b8_tbl, Get_2_b8_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xb9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xba */ 
		S_group_2_ba_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xbb */ 
		"btc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xbc */ 
		"bsf", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xbd */ 
		S_group_2_bd_tbl, Get_2_bd_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xbe */ 
		"movsx", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Eb,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xbf */ 
		"movsx", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ew,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc0 */ 
		"xadd", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Gb,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc1 */ 
		"xadd", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Gv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc2 */ 
		S_group_2_c2_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc3 */ 
		"movnti", NULL, INST_NONE, NULL,
		{ OPRND_Md_q,	OPRND_Gd_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc4 */ 
		S_group_2_c4_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc5 */ 
		S_group_2_c5_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc6 */ 
		S_group_2_c6_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc7 */ 
		S_group_2_c7_tbl, GetGroupIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc8 */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xc9 */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xca */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xcb */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xcc */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xcd */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xce */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xcf */ 
		"bswap", NULL, INST_NONE, NULL,
		{ OPRND_vreg,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd0 */ 
		S_group_2_d0_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd1 */ 
		S_group_2_d1_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd2 */ 
		S_group_2_d2_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd3 */ 
		S_group_2_d3_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd4 */ 
		S_group_2_d4_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd5 */ 
		S_group_2_d5_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd6 */ 
		S_group_2_d6_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd7 */ 
		S_group_2_d7_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd8 */ 
		S_group_2_d8_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xd9 */ 
		S_group_2_d9_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xda */ 
		S_group_2_da_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xdb */ 
		S_group_2_db_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xdc */ 
		S_group_2_dc_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xdd */ 
		S_group_2_dd_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xde */ 
		S_group_2_de_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xdf */ 
		S_group_2_df_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe0 */ 
		S_group_2_e0_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe1 */ 
		S_group_2_e1_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe2 */ 
		S_group_2_e2_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe3 */ 
		S_group_2_e3_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe4 */ 
		S_group_2_e4_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe5 */ 
		S_group_2_e5_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe6 */ 
		S_group_2_e6_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe7 */ 
		S_group_2_e7_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe8 */ 
		S_group_2_e8_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xe9 */ 
		S_group_2_e9_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xea */ 
		S_group_2_ea_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xeb */ 
		S_group_2_eb_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xec */ 
		S_group_2_ec_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xed */ 
		S_group_2_ed_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xee */ 
		S_group_2_ee_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xef */ 
		S_group_2_ef_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf0 */ 
		S_group_2_f0_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf1 */ 
		S_group_2_f1_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf2 */ 
		S_group_2_f2_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf3 */ 
		S_group_2_f3_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf4 */ 
		S_group_2_f4_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf5 */ 
		S_group_2_f5_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf6 */ 
		S_group_2_f6_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf7 */ 
		S_group_2_f7_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf8 */ 
		S_group_2_f8_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xf9 */ 
		S_group_2_f9_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xfa */ 
		S_group_2_fa_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xfb */ 
		S_group_2_fb_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xfc */ 
		S_group_2_fc_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xfd */ 
		S_group_2_fd_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xfe */ 
		S_group_2_fe_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f 0xff */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_60_tbl[]=
{ 
	{ /* 0x00 */ 
		"pusha", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"pushad", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"pushaq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_61_tbl[]=
{ 
	{ /* 0x00 */ 
		"popa", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"popad", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		NULL, NULL, INST_AMD64INVALID, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_63_tbl[]=
{ 
	{ /* 0x63 */ 
		"arpl", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_Gw,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x63 */ 
		"movsxd", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ed,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_6d_tbl[]=
{ 
	{ /* 0x00 */ 
		"insw", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"insd", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_6f_tbl[]=
{ 
	{ /* 0x00 */ 
		"outsw", NULL, INST_NONE, NULL,
		{ OPRND_Xv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"outsd", NULL, INST_NONE, NULL,
		{ OPRND_Xv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_80_tbl[]=
{ 
	{ /* 0x00 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_81_tbl[]=
{ 
	{ /* 0x00 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_82_tbl[]=
{ 
	{ /* 0x00 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_83_tbl[]=
{ 
	{ /* 0x00 */ 
		"add", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"or", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"adc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"sbb", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"and", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"sub", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"xor", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_LOCK,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"cmp", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_90_tbl[]=
{ 
	{ /*no prefix*/ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rex	prefx*/ 
		"xchg", NULL, INST_NONE, NULL,
		{ OPRND_eAX,	OPRND_vreg,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"pause", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_98_tbl[]=
{ 
	{ /* 0x00 */ 
		"cbw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"cwde", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"cdqe", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_99_tbl[]=
{ 
	{ /* 0x00 */ 
		"cwd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"cdq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"cqo", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_9c_tbl[]=
{ 
	{ /* 0x00 */ 
		"pushfw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"pushfd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"pushfq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_9d_tbl[]=
{ 
	{ /* 0x00 */ 
		"popfw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"popfd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"popfq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_a5_tbl[]=
{ 
	{ /* 0x00 */ 
		"movsw", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"movsd", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"movsq", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_a7_tbl[]=
{ 
	{ /* 0x00 */ 
		"cmpsw", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"cmpsd", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"cmpsq", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_Xv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_ab_tbl[]=
{ 
	{ /* 0x00 */ 
		"stosw", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"stosd", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"stosq", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_ad_tbl[]=
{ 
	{ /* 0x00 */ 
		"lodsw", NULL, INST_NONE, NULL,
		{ OPRND_Xv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"lodsd", NULL, INST_NONE, NULL,
		{ OPRND_Xv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"lodsq", NULL, INST_NONE, NULL,
		{ OPRND_Xv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_af_tbl[]=
{ 
	{ /* 0x00 */ 
		"scasw", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"scasd", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"scasq", NULL, INST_NONE, NULL,
		{ OPRND_Yv,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_c0_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_c1_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_c2_tbl[]=
{ 
	{ /* 0x00 */ 
		"retnw", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"retnd", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"retnq", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_c3_tbl[]=
{ 
	{ /* 0x00 */ 
		"retnw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"retnd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"retnq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_ca_tbl[]=
{ 
	{ /* 0x00 */ 
		"retfw", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"retfd", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"retfq", NULL, INST_NONE, NULL,
		{ OPRND_Iw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_cb_tbl[]=
{ 
	{ /* 0x00 */ 
		"retfw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"retfd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"retfq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_cf_tbl[]=
{ 
	{ /* 0x00 */ 
		"iretw", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"iretd", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"iretq", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_d0_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_d1_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_1,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_d2_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_d3_tbl[]=
{ 
	{ /* 0x00 */ 
		"rol", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"ror", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"rcl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"rcr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"shr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"shl", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"sar", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_CL,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_d8_tbl[]=
{ 
	{ /* 0x00 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_d9_tbl[]=
{ 
	{ /* 0x00 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fldenv", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fldcw", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fstenv", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fstcw", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fxch", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fnop", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fchs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fabs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"ftst", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"fxam", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fld1", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fldl2t", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fldl2e", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fldpi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fldlg2", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fldln2", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fldz", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"f2xm1", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fyl2x", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fptan", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fpatan", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fxtract", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fprem1", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fdecstp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fincstp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		"fprem", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		"fyl2xp1", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		"fsqrt", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		"fsincos", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		"frndint", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		"fscale", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		"fsin", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		"fcos", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_da_tbl[]=
{ 
	{ /* 0x00 */ 
		"fiadd", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fimul", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"ficom", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"ficomp", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fisub", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fisubr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fidiv", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fidivr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"fcmovb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fcmove", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"fcmovbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		"fcmovu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fucompp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_db_tbl[]=
{ 
	{ /* 0x00 */ 
		"fild", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fisttp", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fist", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fistp", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_Mt,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_Mt,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"fcmovnb", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fcmovne", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"fcmovnbe", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		"fcmovnu", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"feni", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fdisi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"fclex", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		"finit", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"fsetpm", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fucomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fcomi", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_dc_tbl[]=
{ 
	{ /* 0x00 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fcom", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fcomp", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"fadd", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fmul", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		"fsubr", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fsub", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fdivr", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		"fdiv", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_dd_tbl[]=
{ 
	{ /* 0x00 */ 
		"fld", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fisttp", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"frstor", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fsave", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fstsw", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"ffree", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"fst", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		"fstp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		"fucom", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fucomp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_de_tbl[]=
{ 
	{ /* 0x00 */ 
		"fiadd", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fimul", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"ficom", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"ficomp", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fisub", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fisubr", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fidiv", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fidivr", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"faddp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		"fmulp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		"fcomp5", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		"fcompp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		"fsubrp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fsubp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fdivrp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		"fdivp", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_ST,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_df_tbl[]=
{ 
	{ /* 0x00 */ 
		"fild", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"fisttp", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"fist", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"fistp", NULL, INST_NONE, NULL,
		{ OPRND_Mw,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"fbld", NULL, INST_NONE, NULL,
		{ OPRND_Mt,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"fild", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"fbstp", NULL, INST_NONE, NULL,
		{ OPRND_Mt,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"fistp", NULL, INST_NONE, NULL,
		{ OPRND_Mq,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc0 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST0,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc1 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST1,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc2 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST2,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc3 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST3,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc4 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST4,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc5 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST5,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc6 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST6,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc7 */ 
		"ffreep", NULL, INST_NONE, NULL,
		{ OPRND_ST7,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xc9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xca */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xce */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xcf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd0 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xd9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xda */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xde */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xdf */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe0 */ 
		"fstsw", NULL, INST_NONE, NULL,
		{ OPRND_FPU_AX,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe1 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe2 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe3 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe4 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe5 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe6 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe7 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe8 */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xe9 */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xea */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xeb */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xec */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xed */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xee */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xef */ 
		"fucomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf0 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST0,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf1 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST1,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf2 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST2,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf3 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST3,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf4 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST4,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf5 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST5,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf6 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST6,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf7 */ 
		"fcomip", NULL, INST_NONE, NULL,
		{ OPRND_ST,		OPRND_ST7,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf8 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xf9 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfa */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfb */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfc */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfd */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xfe */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xff */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_e3_tbl[]=
{
	{ /*16-bit*/ 
		"jcxz", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*32-bit*/ 
		"jecxz", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*64-bit*/ 
		"jrcxz", NULL, INST_NONE, NULL,
		{ OPRND_Jb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_f6_tbl[]=
{ 
	{ /* 0x00 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"not", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"neg", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"mul", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"imul", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"div", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"idiv", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_f7_tbl[]=
{ 
	{ /* 0x00 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"test", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Iv,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"not", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"neg", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"mul", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"imul", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"div", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"idiv", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_fa_tbl[]=
{
	{ /*no prefix*/ 
		"cli", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f0 prefix*/ 
		"clx", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_fb_tbl[]=
{
	{ /*no prefix*/ 
		"sti", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f0 prefix*/ 
		"stx", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_1_fe_tbl[]=
{ 
	{ /* 0x00 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_Eb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_1_ff_tbl[]=
{ 
	{ /* 0x00 */ 
		"inc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"dec", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"call", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"call", NULL, INST_NONE, NULL,
		{ OPRND_Ep,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"jmp", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"jmp", NULL, INST_NONE, NULL,
		{ OPRND_Ep,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"push", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_SS_64,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_00_tbl[]=
{ 
	{ /* 0x00 */ 
		"sldt", NULL, INST_NONE, NULL,
		{ OPRND_Ew_v,	OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"str", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"lldt", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		"ltr", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"verr", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"verw", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_01_tbl[]=
{ 
	{ /* 0x00 */ 
		"sgdt", NULL, INST_NONE, NULL,
		{ OPRND_Ms,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		S_group_2_01_01_tbl, GetModRmIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		"lgdt", NULL, INST_NONE, NULL,
		{ OPRND_Ms,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		S_group_2_01_03_tbl, GetModRmIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"smsw", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"lmsw", NULL, INST_NONE, NULL,
		{ OPRND_Ew,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		S_group_2_01_07_tbl, GetModRmIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_01_01_tbl[]=
{ 
	{ /*mod	!= 3 */ 
		"sidt", NULL, INST_NONE, NULL,
		{ OPRND_Ms,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 000 */ 
		"monitor", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 001 */ 
		"mwait", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 010 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 011 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 100 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 101 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 110 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 111 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_01_03_tbl[]=
{ 
	{ /*mod	!= 3 */ 
		"lidt", NULL, INST_NONE, NULL,
		{ OPRND_Ms,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 000 */ 
		"vmrun", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 001 */ 
		"vmmcall", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 010 */ 
		"vmload", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 011 */ 
		"vmsave", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 100 */ 
		"stgi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 101 */ 
		"clgi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 110 */ 
		"skinit", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 111 */ 
		"invlpga", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_01_07_tbl[]=
{ 
	{ /*mod	!= 3 */ 
		"invlpg", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 000 */ 
		"swapgs", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 001 */ 
		"rdtscp", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 010 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 011 */ 
		"stgi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 100 */ 
		"clgi", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 101 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 110 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*rm = 111 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_0d_tbl[]=
{ 
	{ /* 0x00 */ 
		"prefetch", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		"prefetchw", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_0f_tbl[]=
{ 
	{ /* 0x0c */ 
		"pi2fw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0d */ 
		"pi2fd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1c */ 
		"pf2iw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1d */ 
		"pf2id", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8a */ 
		"pfnacc", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x8e */ 
		"pfpnacc", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x90 */ 
		"pfcmpge", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x94 */ 
		"pfmin", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x96 */ 
		"pfrcp", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x97 */ 
		"pfrsqrt", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9a */ 
		"pfsub", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x9e */ 
		"pfadd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa0 */ 
		"pfcmpgt", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa4 */ 
		"pfmax", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa6 */ 
		"pfrcpit1", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xa7 */ 
		"pfrsqit1", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xaa */ 
		"pfsubr", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xae */ 
		"pfacc", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb0 */ 
		"pfcmpeq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb4 */ 
		"pfmul", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb6 */ 
		"pfrcpit2", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xb7 */ 
		"pmulhrw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbb */ 
		"pswapd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0xbf */ 
		"pavgusb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_10_tbl[]=
{
	{ /*no prefix*/ 
		"movups", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movupd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"movsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_11_tbl[]=
{
	{ /*no prefix*/ 
		"movups", NULL, INST_NONE, NULL,
		{ OPRND_Wps,	OPRND_Vps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movupd", NULL, INST_NONE, NULL,
		{ OPRND_Wpd,	OPRND_Vpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"movsd", NULL, INST_NONE, NULL,
		{ OPRND_Wsd,	OPRND_Vsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movss", NULL, INST_NONE, NULL,
		{ OPRND_Wss,	OPRND_Vss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_12_tbl[]=
{
	{ /*no prefix*/ 
		S_group_2_12_00_tbl, GetSSEHiToLoIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movlpd", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_MEMORY,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"movddup", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movsldup", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_12_00_tbl[]=
{
	{ /*mod!=3*/ 
		"movlps", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_MEMORY,		OPF_NONE,	OPF_NONE }
	},
	{ /*mod==3*/ 
		"movhlps", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_13_tbl[]=
{
	{ /*no prefix*/ 
		"movlps", NULL, INST_NONE, NULL,
		{ OPRND_Wq,		OPRND_Vq,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movlpd", NULL, INST_NONE, NULL,
		{ OPRND_Wpd,	OPRND_Vpd,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_14_tbl[]=
{
	{ /*no prefix*/ 
		"unpcklps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"unpcklpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_15_tbl[]=
{
	{ /*no prefix*/ 
		"unpckhps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"unpckhpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_16_tbl[]=
{
	{ /*no prefix*/ 
		S_group_2_16_00_tbl, GetSSEHiToLoIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movhpd", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_MEMORY,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movshdup", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_16_00_tbl[]=
{
	{ /*mod!=3*/ 
		"movhps", NULL, INST_NONE, NULL,
		{ OPRND_Vq,	OPRND_Wq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,	OPF_MEMORY,		OPF_NONE,	OPF_NONE }
	},
	{ /*mod==3*/ 
		"movlhps", NULL, INST_NONE, NULL,
		{ OPRND_Vq,	OPRND_Wq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,	OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_17_tbl[]=
{
	{ /*no prefix*/ 
		"movhps", NULL, INST_NONE, NULL,
		{ OPRND_Wq,		OPRND_Vq,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movhpd", NULL, INST_NONE, NULL,
		{ OPRND_Wq,		OPRND_Vq,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_18_tbl[]=
{ 
	{ /* modrm.reg == 0 */	//MOD!=0x3
		"prefetchnta", NULL, INST_NONE, NULL,	
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 1 */ 
		"prefetcht0", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 2 */ 
		"prefetcht1", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 3 */ 
		"prefetcht2", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 4 */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 5 */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 6 */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 7 */ 
		"nop", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	//MOD==0x3
	{ /* modrm.reg == 0 */
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 1 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 2 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 3 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 4 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 5 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 6 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* modrm.reg == 7 */ 
		"nop", NULL, INST_NONE, NULL,	
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_tbl[]=
{
	{ /* Opcode3.opcode == 00 */
		S_group_2_24_00_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 01 */
		S_group_2_24_01_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 02 */
		S_group_2_24_02_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 03 */
		S_group_2_24_03_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 04 */
		S_group_2_24_04_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 05 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 06 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 07 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 08 */
		S_group_2_24_08_tbl, Get_Opcode3_Oc1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 09 */
		S_group_2_24_09_tbl, Get_Opcode3_Oc1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 10 */
		S_group_2_24_10_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 11 */
		S_group_2_24_11_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 12 */
		S_group_2_24_12_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 13 */
		S_group_2_24_13_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 14 */
		S_group_2_24_14_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 15 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 16 */
		S_group_2_24_16_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 17 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 18 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 19 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_00_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"fmaddps", NULL, INST_DREX, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"fmaddpd", NULL, INST_DREX, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"fmaddss", NULL, INST_DREX, NULL,
		{ OPRND_Bss,	OPRND_Vss,	OPRND_Wss,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"fmaddsd", NULL, INST_DREX, NULL,
		{ OPRND_Bsd,	OPRND_Vsd,	OPRND_Wsd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_01_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"fmsubps", NULL, INST_DREX, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"fmsubpd", NULL, INST_DREX, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"fmsubss", NULL, INST_DREX, NULL,
		{ OPRND_Bss,	OPRND_Vss,	OPRND_Wss,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"fmsubsd", NULL, INST_DREX, NULL,
		{ OPRND_Bsd,	OPRND_Vsd,	OPRND_Wsd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_02_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"fnmaddps", NULL, INST_DREX, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"fnmaddpd", NULL, INST_DREX, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"fnmaddss", NULL, INST_DREX, NULL,
		{ OPRND_Bss,	OPRND_Vss,	OPRND_Wss,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"fnmaddsd", NULL, INST_DREX, NULL,
		{ OPRND_Bsd,	OPRND_Vsd,	OPRND_Wsd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_03_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"fnmsubps", NULL, INST_DREX, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"fnmsubpd", NULL, INST_DREX, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"fnmsubss", NULL, INST_DREX, NULL,
		{ OPRND_Bss,	OPRND_Vss,	OPRND_Wss,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"fnmsubsd", NULL, INST_DREX, NULL,
		{ OPRND_Bsd,	OPRND_Vsd,	OPRND_Wsd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_04_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"permps", NULL, INST_DREX, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"permpd", NULL, INST_DREX, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pcmov", NULL, INST_DREX, NULL,
		{ OPRND_BsO,	OPRND_VsO,	OPRND_WsO,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pperm", NULL, INST_DREX, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_08_tbl[]=
{
	{ /* Opcode3.oc1 == 0 */
		S_group_2_24_08_00_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.oc1 == 1 */
		S_group_2_24_08_01_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_08_00_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"protb", NULL, INST_DREX, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"protw", NULL, INST_DREX, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"protd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"protq", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpQ,	OPRND_WpQ,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_08_01_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"pshlb", NULL, INST_DREX, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pshlw", NULL, INST_DREX, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pshld", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pshlq", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpQ,	OPRND_WpQ,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_09_tbl[]=
{
	{ /* Opcode3.oc1 == 0 */
		S_group_2_24_09_00_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.oc1 == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_09_00_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"pshab", NULL, INST_DREX, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pshaw", NULL, INST_DREX, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pshad", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pshaq", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpQ,	OPRND_WpQ,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_10_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pmacssww", NULL, INST_DREX, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmacsswd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pmacssdql", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_11_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmacssdd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pmacssdqh", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_12_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pmacsww", NULL, INST_DREX, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmacswd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pmacsdql", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_13_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmacsdd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pmacsdqh", NULL, INST_DREX, NULL,
		{ OPRND_BpQ,	OPRND_VpD,	OPRND_WpD,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_14_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmadcsswd", NULL, INST_DREX, NULL,
		{ OPRND_BpD,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_24_16_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pmadcswd", NULL, INST_DREX, NULL,	
		{ OPRND_BpD,	OPRND_VpW,	OPRND_WpW,	OPRND_oc },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_25_tbl[]=
{
	{ /* Opcode3.opcode == 00 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 01 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 02 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 03 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 04 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 05 */
		S_group_2_25_05_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 06 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 07 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 08 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 09 */
		S_group_2_25_09_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0d */
		S_group_2_25_0d_tbl, Get_BNI_Type1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 10 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 11 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 12 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 13 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 14 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 15 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 16 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 17 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 18 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 19 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_25_05_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"comps", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_Bps,	OPRND_Vps,	OPRND_Wps,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"compd", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_Bpd,	OPRND_Vpd,	OPRND_Wpd,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"comss", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_Bss,	OPRND_Vss,	OPRND_Wss,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"comsd", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_Bsd,	OPRND_Vsd,	OPRND_Wsd,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_25_09_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"pcomb", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pcomw", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pcomd", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pcomq", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpQ,	OPRND_VpQ,	OPRND_WpQ,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_25_0d_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"pcomub", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpB,	OPRND_VpB,	OPRND_WpB,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"pcomuw", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpW,	OPRND_VpW,	OPRND_WpW,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"pcomud", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpD,	OPRND_VpD,	OPRND_WpD,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"pcomuq", NULL, INST_DREX | INST_NO_OC, NULL,
		{ OPRND_BpQ,	OPRND_VpQ,	OPRND_WpQ,	OPRND_CCb },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_28_tbl[]=
{
	{ /*no prefix*/ 
		"movaps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movapd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_29_tbl[]=
{
	{ /*no prefix*/ 
		"movaps", NULL, INST_NONE, NULL,
		{ OPRND_Wps,	OPRND_Vps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movapd", NULL, INST_NONE, NULL,
		{ OPRND_Wpd,	OPRND_Vpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2a_tbl[]=
{
	{ /*no prefix*/ 
		"cvtpi2ps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvtpi2pd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cvtsi2sd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Ed_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvtsi2ss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Ed_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_SS,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2b_tbl[]=
{
	{ /*no prefix*/ 
		"movntps", NULL, INST_NONE, NULL,
		{ OPRND_Wps,	OPRND_Vps,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movntpd", NULL, INST_NONE, NULL,
		{ OPRND_Wpd,	OPRND_Vpd,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"movntsd", NULL, INST_NONE, NULL,
		{ OPRND_Wsd,	OPRND_Vsd,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movntss", NULL, INST_NONE, NULL,
		{ OPRND_Wss,	OPRND_Vss,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2c_tbl[]=
{
	{ /*no prefix*/ 
		"cvttps2pi", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Wps,	OPRND_na,	OPRND_na },		// intel says Qq but I think Pq
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvttpd2pi", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cvttsd2si", NULL, INST_NONE, NULL,
		{ OPRND_Gd_q,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvttss2si", NULL, INST_NONE, NULL,
		{ OPRND_Gd_q,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2d_tbl[]=
{
	{ /*no prefix*/ 
		"cvtps2pi", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Wps,	OPRND_na,	OPRND_na },		// intel says Qq but I think Pq
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvtpd2pi", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cvtsd2si", NULL, INST_NONE, NULL,
		{ OPRND_Gd_q,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvtss2si", NULL, INST_NONE, NULL,
		{ OPRND_Gd_q,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2e_tbl[]=
{
	{ /*no prefix*/ 
		"ucomiss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"ucomisd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_2f_tbl[]=
{
	{ /*no prefix*/ 
		"comiss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"comisd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_tbl[]=
{
	{ /* 0x00 */ 
		S_group_2_38_00_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		S_group_2_38_01_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		S_group_2_38_02_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		S_group_2_38_03_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		S_group_2_38_04_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		S_group_2_38_05_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		S_group_2_38_06_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		S_group_2_38_07_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x08 */ 
		S_group_2_38_08_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x09 */ 
		S_group_2_38_09_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0a */ 
		S_group_2_38_0a_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0b */ 
		S_group_2_38_0b_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0c */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0d */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0e */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x10 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x11 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x12 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x13 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x14 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x15 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x16 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x17 */ 
		S_group_2_38_17_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x18 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x19 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1a */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1b */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1c */ 
		S_group_2_38_1c_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1d */ 
		S_group_2_38_1d_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1e */ 
		S_group_2_38_1e_tbl, Get_2_38_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x1f */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_00_tbl[]=
{
	{ /*no prefix*/ 
		"pshufb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pshufb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_01_tbl[]=
{
	{ /*no prefix*/ 
		"phaddw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phaddw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_02_tbl[]=
{
	{ /*no prefix*/ 
		"phaddd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phaddd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_03_tbl[]=
{
	{ /*no prefix*/ 
		"phaddsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phaddsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_04_tbl[]=
{
	{ /*no prefix*/ 
		"pmaddubsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmaddubsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_05_tbl[]=
{
	{ /*no prefix*/ 
		"phsubw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phsubw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_06_tbl[]=
{
	{ /*no prefix*/ 
		"phsubd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phsubd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_07_tbl[]=
{
	{ /*no prefix*/ 
		"phsubsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"phsubsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_08_tbl[]=
{
	{ /*no prefix*/ 
		"psignb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psignb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_09_tbl[]=
{
	{ /*no prefix*/ 
		"psignw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psignw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_0a_tbl[]=
{
	{ /*no prefix*/ 
		"psignd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psignd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_0b_tbl[]=
{
	{ /*no prefix*/ 
		"pmulhrsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmulhrsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_17_tbl[]=
{
	{ /*no prefix*/
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/
		"ptest", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_1c_tbl[]=
{
	{ /*no prefix*/ 
		"pabsb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pabsb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_1d_tbl[]=
{
	{ /*no prefix*/ 
		"pabsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pabsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_38_1e_tbl[]=
{
	{ /*no prefix*/ 
		"pabsd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pabsd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_Typeof_2_3a_tbl[]=
{
	{	/* original */
		S_group_2_3a_tbl, Get_2_3a_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{	/* Type 2 */
		S_group_2_3a_Type2_tbl, Get_2_3a_Type2_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_3a_tbl[]=
{
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x08 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x09 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0a */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0b */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0c */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0d */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0e */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x0f */ 
		S_group_2_3a_0f_tbl, Get_2_3a_XX_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_3a_0f_tbl[]=
{
	{ /*no prefix*/ 
		"palignr", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"palignr", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_3a_Type2_tbl[]=
{
	{ /* Opcode3.opcode == 00 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 01 */
		S_group_2_3a_01_Type2_tbl, Get_Opcode4_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 02 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 03 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 04 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 05 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 06 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 07 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 08 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 09 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 10 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 11 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 12 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 13 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 14 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 15 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 16 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 17 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 18 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 19 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_3a_01_Type2_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"roundps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"roundpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"roundss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"roundsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_50_tbl[]=
{
	{ /*no prefix*/ 
		"movmskps", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Wps,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movmskpd", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Wpd,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_51_tbl[]=
{
	{ /*no prefix*/ 
		"sqrtps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"sqrtpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"sqrtsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"sqrtss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_52_tbl[]=
{
	{ /*no prefix*/ 
		"rsqrtps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"rsqrtss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_53_tbl[]=
{
	{ /*no prefix*/ 
		"rcpps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"rcpss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_54_tbl[]=
{
	{ /*no prefix*/ 
		"andps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"andpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_55_tbl[]=
{
	{ /*no prefix*/ 
		"andnps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"andnpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_56_tbl[]=
{
	{ /*no prefix*/ 
		"orps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"orpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_57_tbl[]=
{
	{ /*no prefix*/ 
		"xorps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"xorpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_58_tbl[]=
{
	{ /*no prefix*/ 
		"addps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"addpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"addsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"addss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_59_tbl[]=
{
	{ /*no prefix*/ 
		"mulps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"mulpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"mulsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"mulss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5a_tbl[]=
{
	{ /*no prefix*/ 
		"cvtps2pd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvtpd2ps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cvtsd2ss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvtss2sd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5b_tbl[]=
{
	{ /*no prefix*/ 
		"cvtdq2ps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvtps2dq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvttps2dq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5c_tbl[]=
{
	{ /*no prefix*/ 
		"subps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"subpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"subsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"subss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5d_tbl[]=
{
	{ /*no prefix*/ 
		"minps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"minpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"minsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"minss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5e_tbl[]=
{
	{ /*no prefix*/ 
		"divps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"divpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"divsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"divss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_5f_tbl[]=
{
	{ /*no prefix*/ 
		"maxps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"maxpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"maxsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"maxss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_60_tbl[]=
{
	{ /*no prefix*/ 
		"punpcklbw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpcklbw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_61_tbl[]=
{
	{ /*no prefix*/ 
		"punpcklwd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpcklwd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_62_tbl[]=
{
	{ /*no prefix*/ 
		"punpckldq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpckldq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_63_tbl[]=
{
	{ /*no prefix*/ 
		"packsswb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"packsswb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_64_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpgtb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpgtb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_65_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpgtw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpgtw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_66_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpgtd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpgtd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_67_tbl[]=
{
	{ /*no prefix*/ 
		"packuswb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"packuswb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_68_tbl[]=
{
	{ /*no prefix*/ 
		"punpckhbw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpckhbw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_69_tbl[]=
{
	{ /*no prefix*/ 
		"punpckhwd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpckhwd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6a_tbl[]=
{
	{ /*no prefix*/ 
		"punpckhdq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpckhdq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6b_tbl[]=
{
	{ /*no prefix*/ 
		"packssdw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"packssdw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6c_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpcklqdq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6d_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"punpckhqdq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6e_tbl[]=
{
	{ /*no prefix*/ 
		"movd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Ed_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Ed_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_6f_tbl[]=
{
	{ /*no prefix*/ 
		"movq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movdqa", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movdqu", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_70_tbl[]=
{
	{ /*no prefix*/ 
		"pshufw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pshufd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"pshuflw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"pshufhw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_71_tbl[]=
{ 
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		S_group_2_71_02_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		S_group_2_71_04_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		S_group_2_71_06_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};


Inst_Info CDisassembler::S_group_2_71_02_tbl[]=
{
	{ /*no prefix*/ 
		"psrlw", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrlw", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_71_04_tbl[]=
{
	{ /*no prefix*/ 
		"psraw", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psraw", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_71_06_tbl[]=
{
	{ /*no prefix*/ 
		"psllw", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psllw", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_72_tbl[]=
{ 
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		S_group_2_72_02_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		S_group_2_72_04_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		S_group_2_72_06_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_72_02_tbl[]=
{ 
	{ /*no prefix*/ 
		"psrld", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrld", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_72_04_tbl[]=
{ 
	{ /*no prefix*/ 
		"psrad", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrad", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_72_06_tbl[]=
{ 
	{ /*no prefix*/ 
		"pslld", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pslld", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_73_tbl[]=
{ 
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		S_group_2_73_02_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		S_group_2_73_03_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"psraq", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		S_group_2_73_06_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		S_group_2_73_07_tbl, GetSSEIndex, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_73_02_tbl[]=
{ 
	{ /*no prefix*/ 
		"psrlq", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrlq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_73_03_tbl[]=
{ 
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrldq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_73_06_tbl[]=
{ 
	{ /*no prefix*/ 
		"psllq", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psllq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_73_07_tbl[]=
{ 
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pslldq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_REGISTER,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_74_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpeqb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpeqb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_75_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpeqw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpeqw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_76_tbl[]=
{
	{ /*no prefix*/ 
		"pcmpeqd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pcmpeqd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_78_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"extrq", NULL, INST_NONE, NULL,
		{ OPRND_Wq,		OPRND_Ib,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"insertq", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,	OPRND_Ib,	OPRND_Ib },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_79_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"extrq", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"insertq", NULL, INST_NONE, NULL,
		{ OPRND_Vq,		OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_tbl[]=
{
	{ /* Opcode3.opcode == 00 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 01 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 02 */
		S_group_2_7a_02_tbl, Get_Opcode3_Oc1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 03 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 04 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 05 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 06 */
		S_group_2_7a_06_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 07 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 08 */
		S_group_2_7a_08_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 09 */
		S_group_2_7a_09_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0a */
		S_group_2_7a_0a_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0b */
		S_group_2_7a_0b_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0c */
		S_group_2_7a_0c_tbl, Get_Opcode3_Oc1_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 10 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 11 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 12 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 13 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 14 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 15 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 16 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 17 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 18 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 19 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_02_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		S_group_2_7a_02_00_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_02_00_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"frczps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"frczpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"frczss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"frczsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_06_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		"cvtph2ps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		"cvtps2ph", NULL, INST_NONE, NULL,
		{ OPRND_Wq,		OPRND_Vps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_08_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		"phaddbw", NULL, INST_NONE, NULL,
		{ OPRND_VpW,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		"phaddbd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		"phaddbq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		"phaddwd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpW,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		"phaddwq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpW,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_09_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		"phadddq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpD,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_0a_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		"phaddubw", NULL, INST_NONE, NULL,
		{ OPRND_VpW,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		"phaddubd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		"phaddubq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		"phadduwd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpW,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		"phadduwq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpW,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_0b_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		"phaddudq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpD,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7a_0c_tbl[]=
{
	{ /* (Opcode3 & 7) == 0 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 1 */
		"phsubbw", NULL, INST_NONE, NULL,
		{ OPRND_VpW,	OPRND_WpB,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 2 */
		"phsubwd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpW,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 3 */
		"phsubdq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpD,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 4 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 5 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 6 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* (Opcode3 & 7) == 7 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7b_tbl[]=
{
	{ /* Opcode3.opcode == 00 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 01 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 02 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 03 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 04 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 05 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 06 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 07 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 08 */
		S_group_2_7b_08_tbl, Get_Opcode3_Oc1_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 09 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 0f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 10 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 11 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 12 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 13 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 14 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 15 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 16 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 17 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 18 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 19 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1a */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1b */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1c */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1d */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1e */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.opcode == 1f */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7b_08_tbl[]=
{
	{ /* Opcode3.oc1 == 0 */
		S_group_2_7b_08_00_tbl, Get_Opcode3_Ops_Index, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.oc1 == 1 */
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7b_08_00_tbl[]=
{
	{ /* Opcode3.ops == 0 */
		"protb", NULL, INST_NONE, NULL,
		{ OPRND_VpB,	OPRND_WpB,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 1 */
		"protw", NULL, INST_NONE, NULL,
		{ OPRND_VpW,	OPRND_WpW,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 2 */
		"protd", NULL, INST_NONE, NULL,
		{ OPRND_VpD,	OPRND_WpD,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* Opcode3.ops == 3 */
		"protq", NULL, INST_NONE, NULL,
		{ OPRND_VpQ,	OPRND_WpQ,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7c_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"haddpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"haddps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7d_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"hsubpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"hsubps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7e_tbl[]=
{
	{ /*no prefix*/ 
		"movd", NULL, INST_NONE, NULL,
		{ OPRND_Ed_q,	OPRND_Pd_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movd", NULL, INST_NONE, NULL,
		{ OPRND_Ed_q,	OPRND_Vd_q,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_7f_tbl[]=
{
	{ /*no prefix*/ 
		"movq", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Pq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movdqa", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Vdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movdqu", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Vdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ae_tbl[]=
{ 
	// MOD != 0x3
	{ /* rm = 000 */ 
		"fxsave", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 001 */ 
		"fxrstor", NULL, INST_NONE, NULL,
		{ OPRND_M,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 002 */ 
		"ldmxcsr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 003 */ 
		"stmxcsr", NULL, INST_NONE, NULL,
		{ OPRND_Md,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 004 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 005 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 006 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 007 */ 
		"clflush", NULL, INST_NONE, NULL,
		{ OPRND_Mb,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	//MOD==0x3
	{ /* rm = 000 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },		
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 001 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 002 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 003 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 004 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 005 */ 
		"lfence", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 006 */ 
		"mfence", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* rm = 007 */ 
		"sfence", NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_b8_tbl[]=
{
	{ /*(no f3 prefix) and (alternate not enabled)*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*(f3 prefix) or (alternate enabled)*/ 
		"popcnt", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_ba_tbl[]=
{ 
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		"bt", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		"bts", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		"btr", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		"btc", NULL, INST_NONE, NULL,
		{ OPRND_Ev,		OPRND_Ib,	OPRND_na,	OPRND_na },
		{ OPF_SS_LOCK,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_bd_tbl[]=
{
	{ /*not f3 prefix*/ 
		"bsr", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"lzcnt", NULL, INST_NONE, NULL,
		{ OPRND_Gv,		OPRND_Ev,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_c2_tbl[]=
{
	{ /*no prefix*/ 
		"cmpps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cmppd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cmpsd", NULL, INST_NONE, NULL,
		{ OPRND_Vsd,	OPRND_Wsd,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cmpss", NULL, INST_NONE, NULL,
		{ OPRND_Vss,	OPRND_Wss,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_c4_tbl[]=
{
	{ /*no prefix*/ 
		"pinsrw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Ew,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pinsrw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Ew,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_c5_tbl[]=
{
	{ /*no prefix*/ 
		"pextrw", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Qq,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_REG,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pextrw", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Wdq,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_REG,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_c6_tbl[]=
{
	{ /*no prefix*/ 
		"shufps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"shufpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_Ib,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_c7_tbl[]=
{ 
	{ /* 0x00 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x01 */
		"cmpxchg", NULL, INST_NONE, NULL,
		{ OPRND_Mq_dq,			OPRND_na,	OPRND_na,	OPRND_na },
		{ (OPF_LOCK | OPF_SS),	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x02 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x03 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x04 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x05 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x06 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /* 0x07 */ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_d0_tbl[]=
{
	{ /*no prefix*/ 
		NULL	, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"addsubpd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"addsubps", NULL, INST_NONE, NULL,
		{ OPRND_Vps,	OPRND_Wps,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d1_tbl[]=
{
	{ /*no prefix*/ 
		"psrlw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrlw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d2_tbl[]=
{
	{ /*no prefix*/ 
		"psrld", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrld", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d3_tbl[]=
{
	{ /*no prefix*/ 
		"psrlq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrlq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d4_tbl[]=
{
	{ /*no prefix*/ 
		"paddq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d5_tbl[]=
{
	{ /*no prefix*/ 
		"pmullw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmullw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};
	
Inst_Info CDisassembler::S_group_2_d6_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Vq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"movdq2q", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"movq2dq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d7_tbl[]=
{
	{ /*no prefix*/ 
		"pmovmskb", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmovmskb", NULL, INST_NONE, NULL,
		{ OPRND_Gd,		OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d8_tbl[]=
{
	{ /*no prefix*/ 
		"psubusb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubusb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_d9_tbl[]=
{
	{ /*no prefix*/ 
		"psubusw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubusw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_da_tbl[]=
{
	{ /*no prefix*/ 
		"pminub", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pminub", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_db_tbl[]=
{
	{ /*no prefix*/ 
		"pand", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pand", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_dc_tbl[]=
{
	{ /*no prefix*/ 
		"paddusb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddusb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_dd_tbl[]=
{
	{ /*no prefix*/ 
		"paddusw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddusw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_de_tbl[]=
{
	{ /*no prefix*/ 
		"pmaxub", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmaxub", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_df_tbl[]=
{
	{ /*no prefix*/ 
		"pandn", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pandn", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e0_tbl[]=
{
	{ /*no prefix*/ 
		"pavgb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pavgb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e1_tbl[]=
{
	{ /*no prefix*/ 
		"psraw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psraw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e2_tbl[]=
{
	{ /*no prefix*/ 
		"psrad", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psrad", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e3_tbl[]=
{
	{ /*no prefix*/ 
		"pavgw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pavgw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e4_tbl[]=
{
	{ /*no prefix*/ 
		"pmulhuw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmulhuw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e5_tbl[]=
{
	{ /*no prefix*/ 
		"pmulhw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmulhw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e6_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"cvttpd2dq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"cvtpd2dq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wpd,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		"cvtdq2pd", NULL, INST_NONE, NULL,
		{ OPRND_Vpd,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e7_tbl[]=
{
	{ /*no prefix*/ 
		"movntq", NULL, INST_NONE, NULL,
		{ OPRND_Qq,		OPRND_Pq,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"movntdq", NULL, INST_NONE, NULL,
		{ OPRND_Wdq,	OPRND_Vdq,	OPRND_na,	OPRND_na },
		{ OPF_MEMORY,	OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e8_tbl[]=
{
	{ /*no prefix*/ 
		"psubsb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubsb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_e9_tbl[]=
{
	{ /*no prefix*/ 
		"psubsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ea_tbl[]=
{
	{ /*no prefix*/ 
		"pminsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pminsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_eb_tbl[]=
{
	{ /*no prefix*/ 
		"por", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"por", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ec_tbl[]=
{
	{ /*no prefix*/ 
		"paddsb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddsb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ed_tbl[]=
{
	{ /*no prefix*/ 
		"paddsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ee_tbl[]=
{
	{ /*no prefix*/ 
		"pmaxsw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmaxsw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_ef_tbl[]=
{
	{ /*no prefix*/ 
		"pxor", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pxor", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f0_tbl[]=
{
	{ /*no prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		"lddqu", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_MEMORY,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f1_tbl[]=
{
	{ /*no prefix*/ 
		"psllw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psllw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f2_tbl[]=
{
	{ /*no prefix*/ 
		"pslld", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pslld", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f3_tbl[]=
{
	{ /*no prefix*/ 
		"psllq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psllq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f4_tbl[]=
{
	{ /*no prefix*/ 
		"pmuludq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmuludq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f5_tbl[]=
{
	{ /*no prefix*/ 
		"pmaddwd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"pmaddwd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f6_tbl[]=
{
	{ /*no prefix*/ 
		"psadbw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psadbw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f7_tbl[]=
{
	{ /*no prefix*/ 
		"maskmovq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"maskmovdqu", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_REGISTER,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,		OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,		OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f8_tbl[]=
{
	{ /*no prefix*/ 
		"psubb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_f9_tbl[]=
{
	{ /*no prefix*/ 
		"psubw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_fa_tbl[]=
{
	{ /*no prefix*/ 
		"psubd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_fb_tbl[]=
{
	{ /*no prefix*/ 
		"psubq", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"psubq", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_fc_tbl[]=
{
	{ /*no prefix*/ 
		"paddb", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddb", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_fd_tbl[]=
{
	{ /*no prefix*/ 
		"paddw", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddw", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info CDisassembler::S_group_2_fe_tbl[]=
{
	{ /*no prefix*/ 
		"paddd", NULL, INST_NONE, NULL,
		{ OPRND_Pq,		OPRND_Qq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*66 prefix*/ 
		"paddd", NULL, INST_NONE, NULL,
		{ OPRND_Vdq,	OPRND_Wdq,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f2 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
	{ /*f3 prefix*/ 
		NULL, NULL, INST_NONE, NULL,
		{ OPRND_na,		OPRND_na,	OPRND_na,	OPRND_na },
		{ OPF_NONE,		OPF_NONE,	OPF_NONE,	OPF_NONE }
	},
};

Inst_Info *CDisassembler::S_3dnow_ptrs[] =
{
	/* 0x00-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x08-b	*/ NULL, NULL, NULL, NULL,
	/* 0x0c		*/ &S_group_2_0f_tbl[0],
	/* 0x0d		*/ &S_group_2_0f_tbl[1],
	/* 0x0e-f	*/ NULL, NULL,
	/* 0x10-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x18-b	*/ NULL, NULL, NULL, NULL,
	/* 0x1c		*/ &S_group_2_0f_tbl[2],
	/* 0x1d		*/ &S_group_2_0f_tbl[3],
	/* 0x1e-f	*/ NULL, NULL,
	/* 0x20-8	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x28-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x30-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x38-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x40-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x48-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x50-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x58-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x60-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x68-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x70-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x78-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x80-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x88-f	*/ NULL, NULL,
	/* 0x8a		*/ &S_group_2_0f_tbl[4],
	/* 0x8b-d	*/ NULL, NULL, NULL,
	/* 0x8e		*/ &S_group_2_0f_tbl[5],
	/* 0x8f		*/ NULL,
	/* 0x90		*/ &S_group_2_0f_tbl[6],
	/* 0x91-3	*/ NULL, NULL, NULL,
	/* 0x94		*/ &S_group_2_0f_tbl[7],
	/* 0x95		*/ NULL,
	/* 0x96		*/ &S_group_2_0f_tbl[8],
	/* 0x97		*/ &S_group_2_0f_tbl[9],
	/* 0x98-9	*/ NULL, NULL,
	/* 0x9a		*/ &S_group_2_0f_tbl[10],
	/* 0x9b-d	*/ NULL, NULL, NULL,
	/* 0x9e		*/ &S_group_2_0f_tbl[11],
	/* 0x9f		*/ NULL,
	/* 0xa0		*/ &S_group_2_0f_tbl[12],
	/* 0xa1-3	*/ NULL, NULL, NULL,
	/* 0xa4		*/ &S_group_2_0f_tbl[13],
	/* 0xa5		*/ NULL,
	/* 0xa6		*/ &S_group_2_0f_tbl[14],
	/* 0xa7		*/ &S_group_2_0f_tbl[15],
	/* 0xa8-9	*/ NULL, NULL,
	/* 0xaa		*/ &S_group_2_0f_tbl[16],
	/* 0xab-d	*/ NULL, NULL, NULL,
	/* 0xae		*/ &S_group_2_0f_tbl[17],
	/* 0xaf		*/ NULL,
	/* 0xb0		*/ &S_group_2_0f_tbl[18],
	/* 0xb1-3	*/ NULL, NULL, NULL,
	/* 0xb4		*/ &S_group_2_0f_tbl[19],
	/* 0xb5		*/ NULL,
	/* 0xb6		*/ &S_group_2_0f_tbl[20],
	/* 0xb7		*/ &S_group_2_0f_tbl[21],
	/* 0xb8-a	*/ NULL, NULL, NULL, 
	/* 0xbb		*/ &S_group_2_0f_tbl[22],
	/* 0xbc-e	*/ NULL, NULL, NULL,
	/* 0xbf		*/ &S_group_2_0f_tbl[23],
	/* 0xc0-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xc8-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xd0-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xd8-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xe0-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xe8-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xf0-7	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xf8-f	*/ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
};

Inst_Info *Get3dnowIndex( CDisassembler *pThis )
{
	return( pThis->S_3dnow_ptrs[pThis->GetOpcode(2)] );
}

Inst_Info *GetFpuIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	if( pThis->m_modrm < 0xc0 )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[pThis->m_modrm_reg] );
	else
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[pThis->m_modrm - 0xc0 + 8] );
}

Inst_Info *GetSSEIndex( CDisassembler *pThis )
{
	int index;

	pThis->HandleExtraPrefixOpcode();

	switch( pThis->GetOpcode( 0 ) )
	{
		case PREFIX_DATA:
			index = 1;
			break;

		case PREFIX_REPNE:
			index = 2;
			break;

		case PREFIX_REP:
			index = 3;
			break;

		default:
			index = 0;
	}

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *GetSSEHiToLoIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[((pThis->m_modrm_mod == 3) ? 1 : 0)] );
}

Inst_Info *GetGroupIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[pThis->m_modrm_reg] );
}

Inst_Info *GetArplMovsxdIndex( CDisassembler *pThis )
{
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[(pThis->IsLongMode() || pThis->IsRex32Mode()) ? 1 : 0] );
}

Inst_Info *Get_2_b8_Index( CDisassembler *pThis )
{
	if( !pThis->AlternateEnabled( ALTERNATE_POPCNT ) )
	{
		pThis->HandleExtraF3Opcode();
		if( pThis->GetOpcode(0) == PREFIX_REP )
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
		else
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
	}
	else
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
}

Inst_Info *Get_2_bd_Index( CDisassembler *pThis )
{
	if( !pThis->AlternateEnabled( ALTERNATE_LZCNT ) )
		pThis->HandleExtraF3Opcode();

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[(pThis->GetOpcode(0) == PREFIX_REP) ? 1 : 0] );
}

Inst_Info *GetNopXchgPauseIndex( CDisassembler *pThis )
{
	if( REX_MODRM_RM(pThis->GetRexPrefix()) )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	else
	{
		pThis->HandleExtraRepOpcode();
		if( pThis->GetOpcode(0) == PREFIX_REP )
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[2] );
		else
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
	}
}
	
Inst_Info *GetCliClxStiStxIndex( CDisassembler *pThis )
{
//	if( pThis->IsLongMode() && pThis->IsLastPrefix( PREFIX_LOCK ) )
	if( pThis->IsRex32Mode() && pThis->IsLastPrefix( PREFIX_LOCK ) )
	{
		// convert the LOCK prefix from a prefix byte to an opcode byte
		pThis->RemoveLastPrefix();
		pThis->m_inst_flags &= ~INST_LOCK;
		pThis->LogOpcodeOffset( pThis->GetPrefixCount() );

		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	}
	else
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
}

Inst_Info *GetWDIndex( CDisassembler *pThis )
{
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[((pThis->GetDataSize() == 32) ? 1 : 0)] );
}

Inst_Info *GetWDQIndex( CDisassembler *pThis )
{
	int index;
	switch( pThis->GetDataSize() )
	{
		case 64:
			index = 2;
			break;
		case 32:
			index = 1;
			break;
		default:
			index = 0;
	}

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *GetWDQIndex64( CDisassembler *pThis )
{
	int index;
	switch( pThis->GetDataSize() )
	{
		case 64:
			index = 2;
			break;
		case 32:
			index = pThis->IsLongMode() ? 2 : 1;
			break;
		default:
			index = 0;
	}

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *GetNewGroupIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	int index = pThis->m_modrm_reg;
	if( pThis->m_modrm_mod == 0x3 )
		index |= 0x8;

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *GetGroupCIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	int index = pThis->m_modrm_reg;
	if( pThis->m_modrm_mod == 0x3 )
		index |= 0x8;

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *GetPrefetchIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[((pThis->m_modrm_reg == 1) ? 1 : 0)] );
}

Inst_Info *GetModRmIndex( CDisassembler *pThis )
{
	pThis->GetModrmByte();
	if( pThis->m_modrm_mod != 3 )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
	else
	{
		AMD_UINT8 rm = pThis->m_modrm_rm;
		if( rm <= 7 )
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[rm+1] );
	}

	return( NULL );
}

Inst_Info *GetJcxIndex( CDisassembler *pThis )
{
	if( pThis->m_longmode )
	{
		if( pThis->m_prefix_bytes.FindByte( PREFIX_ADDR ) == -1 )	// not found
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[2] );
		else
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	}
	else if( pThis->m_dbit )
	{
		if( pThis->m_prefix_bytes.FindByte( PREFIX_ADDR ) == -1 )	// not found
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
		else
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
	}
	else
	{
		if( pThis->m_prefix_bytes.FindByte( PREFIX_ADDR ) == -1 )	// not found
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
		else
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	}
}

Inst_Info *Get_Opcode3_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OPCODE( pThis->GetOpcode(2) );
	return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];
}

Inst_Info *Get_Opcode3_Ops_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OPS( pThis->GetOpcode(2) );
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *Get_Opcode4_Ops_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OPS( pThis->GetOpcode(3) );
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *Get_Opcode3_Oc1_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OC1( pThis->GetOpcode(2) );
	return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];
}

Inst_Info *Get_Opcode4_Oc1_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OC1( pThis->GetOpcode(3) );
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

Inst_Info *Get_Opcode3_Oc1_Ops_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OC1_OPS( pThis->GetOpcode(2) );
	return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];
}

Inst_Info *Get_BNI_Type1_Index( CDisassembler *pThis )
{
	AMD_UINT8 opcode = pThis->GetOpcode(2);
	if( OPCODE3_OC1( opcode ) == 1 )
	{
		pThis->m_inst_flags |= INST_OC_2;

		int index = OPCODE3_OPS( opcode );
		return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];
	}
	
	return NULL;
}

Inst_Info *Get_2_38_Index( CDisassembler *pThis )
{
	AMD_UINT8 index = pThis->GetOpcode(2);
	if( index < 0x20 )
		return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];
	
	return NULL;
}

Inst_Info *Get_2_38_XX_Index( CDisassembler *pThis )
{
// TODO: Need to determine how other overused prefix bytes (f2 and f3 (ie not 66)) affect decode
	pThis->HandleExtraPrefixOpcode();

	AMD_UINT8 firstOpcode = pThis->GetOpcode(0);
	if( firstOpcode == PREFIX_DATA )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	else // if( firstOpcode == 0x0f )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
}

Inst_Info *Get_Typeof_2_3a_Index( CDisassembler *pThis )
{
// TODO: Need to determine how other overused prefix bytes (f2 and f3 (ie not 66)) affect decode
	pThis->HandleExtraPrefixOpcode();

	AMD_UINT8 firstOpcode = pThis->GetOpcode(0);
	if( firstOpcode == PREFIX_DATA )
	{
		AMD_UINT8 fourthOpcode = pThis->GetOpcode(3);
		if( fourthOpcode != 0x0f )
			return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	}

	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
}

Inst_Info *Get_2_3a_Index( CDisassembler *pThis )
{
	AMD_UINT8 index;
	AMD_UINT8 firstOpcode = pThis->GetOpcode(0);
	if( firstOpcode == 0x0f )
		index = pThis->GetOpcode(2);
	else
		index = pThis->GetOpcode(3);

	if( index < 0x10 )
		return &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index];

	return NULL;
}

Inst_Info *Get_2_3a_XX_Index( CDisassembler *pThis )
{
	AMD_UINT8 firstOpcode = pThis->GetOpcode(0);
	if( firstOpcode == PREFIX_DATA )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[1] );
	else // if( firstOpcode == 0x0f )
		return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[0] );
}

Inst_Info *Get_2_3a_Type2_Index( CDisassembler *pThis )
{
	int index = OPCODE3_OPCODE( pThis->GetOpcode(3) );
	return( &((Inst_Info *)pThis->m_opcode_table_ptr->mnem)[index] );
}

int Inst_Info::SizeofNestedTable()
{
	if( GetInfoPtr == GetFpuIndex )
		return 72;
	else if( GetInfoPtr == GetSSEIndex )
		return 4;
	else if( GetInfoPtr == GetSSEHiToLoIndex )
		return 2;
	else if( GetInfoPtr == Get3dnowIndex )
		return 24;
	else if( GetInfoPtr == GetGroupIndex )
		return 8;
	else if( GetInfoPtr == GetGroupCIndex )
		return 16;
	else if( GetInfoPtr == GetNewGroupIndex )
		return 16;
	else if( GetInfoPtr == GetArplMovsxdIndex )
		return 2;
	else if( GetInfoPtr == GetCliClxStiStxIndex )
		return 2;
	else if( GetInfoPtr == GetNopXchgPauseIndex )
		return 3;
	else if( GetInfoPtr == GetWDIndex )
		return 2;
	else if( GetInfoPtr == GetWDQIndex )
		return 3;
	else if( GetInfoPtr == GetWDQIndex64 )
		return 3;
	else if( GetInfoPtr == GetPrefetchIndex )
		return 2;
	else if( GetInfoPtr == GetModRmIndex )
		return 9;
	else if( GetInfoPtr == GetJcxIndex )
		return 3;
	else if( GetInfoPtr == Get_2_38_Index )
		return 32;
	else if( GetInfoPtr == Get_2_38_XX_Index )
		return 2;
	else if( GetInfoPtr == Get_Typeof_2_3a_Index )
		return 2;
	else if( GetInfoPtr == Get_2_3a_Index )
		return 16;
	else if( GetInfoPtr == Get_2_3a_XX_Index )
		return 2;
	else if( GetInfoPtr == Get_2_3a_Type2_Index )
		return 32;
	else if( GetInfoPtr == Get_2_b8_Index )
		return 2;
	else if( GetInfoPtr == Get_2_bd_Index )
		return 2;
	else if( GetInfoPtr == Get_Opcode3_Index )
		return 32;
	else if( GetInfoPtr == Get_Opcode3_Ops_Index )
		return 4;
	else if( GetInfoPtr == Get_Opcode3_Oc1_Index )
		return 2;
	else if( GetInfoPtr == Get_Opcode3_Oc1_Ops_Index )
		return 8;
	else if( GetInfoPtr == Get_Opcode4_Ops_Index )
		return 4;
	else if( GetInfoPtr == Get_Opcode4_Oc1_Index )
		return 2;
	else if( GetInfoPtr == Get_BNI_Type1_Index )
		return 4;
	else
		return 0;
}

PVOIDMEMBERFUNC CDisassembler::S_PrefixByteFnPtrs[] =
{
	/* 0x00-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x08-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x10-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x18-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x20-5   */	NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x26		*/	&CDisassembler::PrefixEsSegOveride,
	/* 0x27		*/	NULL,
	/* 0x28-d   */	NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x2e		*/	&CDisassembler::PrefixCsSegOveride,
	/* 0x2f		*/	NULL,
	/* 0x30-5   */	NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x36		*/	&CDisassembler::PrefixSsSegOveride,
	/* 0x37		*/	NULL,
	/* 0x38-d   */	NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x3e		*/	&CDisassembler::PrefixDsSegOveride,
	/* 0x3f		*/	NULL,
	/* 0x40-3   */	&CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex,
	/* 0x44-7	*/	&CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex,
	/* 0x48-b   */	&CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex,
	/* 0x4c-f	*/	&CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex, &CDisassembler::PrefixRex,
	/* 0x50-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x58-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x60-3   */	NULL, NULL, NULL, NULL,
	/* 0x64		*/	&CDisassembler::PrefixFsSegOveride,
	/* 0x65		*/	&CDisassembler::PrefixGsSegOveride,
	/* 0x66		*/	&CDisassembler::PrefixDataSize,
	/* 0x67		*/	&CDisassembler::PrefixAddressSize,
	/* 0x68-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x70-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x78-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x80-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x88-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x90-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0x98-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xa0-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xa8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xb0-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xb8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xc0-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xc8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xd0-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xd8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xe0-7   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xe8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	/* 0xf0		*/	&CDisassembler::PrefixLock,
	/* 0xf1		*/	NULL,
	/* 0xf2		*/	&CDisassembler::PrefixRepne,
	/* 0xf3		*/	&CDisassembler::PrefixRep,
	/* 0xf4-7   */	NULL, NULL, NULL, NULL,
	/* 0xf8-f   */	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
};

void CDisassembler::PrefixRex()
{
	if( REX_OPERAND64( m_rex_prefix ) )
	{
		m_inst_flags |= INST_DATA64;
		m_inst_flags &= ~INST_DATA32;
	}
}

void CDisassembler::PrefixEsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_ES;
}

void CDisassembler::PrefixCsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_CS;
}

void CDisassembler::PrefixSsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_SS;
}

void CDisassembler::PrefixDsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_DS;
}

void CDisassembler::PrefixFsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_FS;
}

void CDisassembler::PrefixGsSegOveride()
{
	m_inst_flags |= INST_SEGOVRD;
	m_seg_reg = REG_GS;
}

void CDisassembler::PrefixDataSize()
{
	if( m_longmode )
	{
		if( !REX_OPERAND64( m_rex_prefix ) )
		{
			m_inst_flags |= INST_DATAOVRD;
			m_inst_flags |= INST_DATA16;
			m_inst_flags &= ~INST_DATA32;
		}
	}
	else
	{
		m_inst_flags |= INST_DATAOVRD;
		if( m_dbit )
		{
			m_inst_flags |= INST_DATA16;
			m_inst_flags &= ~INST_DATA32;
		}
		else
		{
			m_inst_flags |= INST_DATA32;
			m_inst_flags &= ~INST_DATA16;
		}
	}
}

void CDisassembler::PrefixAddressSize()
{
	m_inst_flags |= INST_ADDROVRD;
	if( m_longmode )
	{
		m_inst_flags |= INST_ADDR32;
		m_inst_flags &= ~INST_ADDR64;
	}
	else
	{
		if( m_dbit )
		{
			m_inst_flags |= INST_ADDR16;
			m_inst_flags &= ~INST_ADDR32;
		}
		else
		{
			m_inst_flags |= INST_ADDR32;
			m_inst_flags &= ~INST_ADDR16;
		}
	}
}

void CDisassembler::PrefixLock()
{
	m_inst_flags |= INST_LOCK;
}

void CDisassembler::PrefixRepne()
{
	m_inst_flags &= ~INST_REP;		// last rep/repne prefix takes precedence
	m_inst_flags |= INST_REPNE;
}

void CDisassembler::PrefixRep()
{
	m_inst_flags &= ~INST_REPNE;	// last rep/repne prefix takes precedence
	m_inst_flags |= INST_REP;
}

PVOIDMEMBERFUNC CDisassembler::S_DisassembleOperandFnPtrs[] =
{
	/* OPRND_na */		NULL,
	/* OPRND_1 */		&CDisassembler::_1Str,
	/* OPRND_AL */		&CDisassembler::RegALStr,
	/* OPRND_AX */		&CDisassembler::RegAXStr,
	/* OPRND_eAX */		&CDisassembler::RegeAXStr,
	/* OPRND_Ap */		&CDisassembler::AddressStr,
	/* OPRND_CL */		&CDisassembler::RegCLStr,
	/* OPRND_Cd */		&CDisassembler::ControlRegStr,
	/* OPRND_Dd */		&CDisassembler::DebugRegStr,
	/* OPRND_DX */		&CDisassembler::RegDXStr,
	/* OPRND_eDX */		&CDisassembler::RegeDXStr,
	/* OPRND_Eb */		&CDisassembler::ModrmStr,
	/* OPRND_Ew */		&CDisassembler::ModrmStr,
	/* OPRND_Ed */		&CDisassembler::ModrmStr,
	/* OPRND_Ev */		&CDisassembler::ModrmStr,
	/* OPRND_Ep */		&CDisassembler::ModrmStr,
	/* OPRND_Mt */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Gb */		&CDisassembler::ByteRegStr,
	/* OPRND_Gw */		&CDisassembler::WordRegStr,
	/* OPRND_Gd */		&CDisassembler::DwordRegStr,
	/* OPRND_Gq */		&CDisassembler::QwordRegStr,
	/* OPRND_Gv */		&CDisassembler::WDQRegStr,
	/* OPRND_Ib */		&CDisassembler::ByteImmediateStr,
	/* OPRND_Iv */		&CDisassembler::WordOrDwordImmediateStr,
	/* OPRND_Iw */		&CDisassembler::WordImmediateStr,
	/* OPRND_Jb */		&CDisassembler::SignedByteJumpStr,
	/* OPRND_Jv */		&CDisassembler::SignedWordOrDwordJumpStr,
	/* OPRND_M */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Mp */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Mq */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Ms */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Ob */		&CDisassembler::OffsetStr,
	/* OPRND_Ov */		&CDisassembler::OffsetStr,
	/* OPRND_Pq */		&CDisassembler::MMXRegStr,
	/* OPRND_Pd */		&CDisassembler::MMXRegStr,
	/* OPRND_Qq */		&CDisassembler::MMXModrmStr,
	/* OPRND_Rd */		&CDisassembler::RegisterStr,
	/* OPRND_Sw */		&CDisassembler::SegmentRegStr,
	/* OPRND_Xb */		&CDisassembler::DsEsiStr,
	/* OPRND_Xv */		&CDisassembler::DsEsiStr,
	/* OPRND_Yb */		&CDisassembler::EsEdiStr,
	/* OPRND_Yv */		&CDisassembler::EsEdiStr,
	/* OPRND_breg */	&CDisassembler::ByteRegStr,
	/* OPRND_vreg */	&CDisassembler::WDQRegStr,
	/* OPRND_ST */		&CDisassembler::FpuStr,
	/* OPRND_ST0 */		&CDisassembler::FpuStr,
	/* OPRND_ST1 */		&CDisassembler::FpuStr,
	/* OPRND_ST2 */		&CDisassembler::FpuStr,
	/* OPRND_ST3 */		&CDisassembler::FpuStr,
	/* OPRND_ST4 */		&CDisassembler::FpuStr,
	/* OPRND_ST5 */		&CDisassembler::FpuStr,
	/* OPRND_ST6 */		&CDisassembler::FpuStr,
	/* OPRND_ST7 */		&CDisassembler::FpuStr,
	/* OPRND_Vps */		&CDisassembler::SimdRegStr,
	/* OPRND_Vq */		&CDisassembler::SimdRegStr,
	/* OPRND_Vss */		&CDisassembler::SimdRegStr,
	/* OPRND_Wps */		&CDisassembler::SimdModrmStr,
	/* OPRND_Wq */		&CDisassembler::SimdModrmStr,
	/* OPRND_Wss */		&CDisassembler::SimdModrmStr,
	/* OPRND_Vpd */		&CDisassembler::SimdRegStr,
	/* OPRND_Wpd */		&CDisassembler::SimdModrmStr,
	/* OPRND_Vsd */		&CDisassembler::SimdRegStr,
	/* OPRND_Wsd */		&CDisassembler::SimdModrmStr,
	/* OPRND_Vdq */		&CDisassembler::SimdRegStr,
	/* OPRND_Wdq */		&CDisassembler::SimdModrmStr,
	/* OPRND_Vd */		&CDisassembler::SimdRegStr,
	/* OPRND_FPU_AX */	&CDisassembler::RegAXStr,
	/* OPRND_Mw */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Md */		&CDisassembler::MemoryModrmStr,
	/* OPRND_Iv64 */	&CDisassembler::WDQImmediateStr,
	/* OPRND_eBXAl */	&CDisassembler::RegeBXAndALStr,
	/* OPRND_Ed_q */	&CDisassembler::ModrmStr,
	/* OPRND_Pd_q */	&CDisassembler::MMXRegStr,
	/* OPRND_Vd_q */	&CDisassembler::SimdRegStr,
	/* OPRND_Gd_q */	&CDisassembler::WDQRegStr,
	/* OPRND_Md_q */	&CDisassembler::MemoryModrmStr,
	/* OPRND_Ew_v */	&CDisassembler::ModrmStr,
	/* OPRND_Mq_dq */	&CDisassembler::MemoryModrmStr,
	/* OPRND_Mb */		&CDisassembler::MemoryModrmStr,

	/* OPRND_Bss */		&CDisassembler::SimdRegStr,
	/* OPRND_Bsd */		&CDisassembler::SimdRegStr,
	/* OPRND_Bps */		&CDisassembler::SimdRegStr,
	/* OPRND_Bpd */		&CDisassembler::SimdRegStr,

	/* OPRND_BsB */		&CDisassembler::SimdRegStr,
	/* OPRND_BsW */		&CDisassembler::SimdRegStr,
	/* OPRND_BsD */		&CDisassembler::SimdRegStr,
	/* OPRND_BsQ */		&CDisassembler::SimdRegStr,
	/* OPRND_BsO */		&CDisassembler::SimdRegStr,

	/* OPRND_VsB */		&CDisassembler::SimdRegStr,
	/* OPRND_VsW */		&CDisassembler::SimdRegStr,
	/* OPRND_VsD */		&CDisassembler::SimdRegStr,
	/* OPRND_VsQ */		&CDisassembler::SimdRegStr,
	/* OPRND_VsO */		&CDisassembler::SimdRegStr,

	/* OPRND_WsB */		&CDisassembler::SimdModrmStr,
	/* OPRND_WsW */		&CDisassembler::SimdModrmStr,
	/* OPRND_WsD */		&CDisassembler::SimdModrmStr,
	/* OPRND_WsQ */		&CDisassembler::SimdModrmStr,
	/* OPRND_WsO */		&CDisassembler::SimdModrmStr,

	/* OPRND_BpB */		&CDisassembler::SimdRegStr,
	/* OPRND_BpW */		&CDisassembler::SimdRegStr,
	/* OPRND_BpD */		&CDisassembler::SimdRegStr,
	/* OPRND_BpQ */		&CDisassembler::SimdRegStr,

	/* OPRND_VpB */		&CDisassembler::SimdRegStr,
	/* OPRND_VpW */		&CDisassembler::SimdRegStr,
	/* OPRND_VpD */		&CDisassembler::SimdRegStr,
	/* OPRND_VpQ */		&CDisassembler::SimdRegStr,

	/* OPRND_WpB */		&CDisassembler::SimdModrmStr,
	/* OPRND_WpW */		&CDisassembler::SimdModrmStr,
	/* OPRND_WpD */		&CDisassembler::SimdModrmStr,
	/* OPRND_WpQ */		&CDisassembler::SimdModrmStr,

	/* OPRND_oc */		NULL,
	/* OPRND_CCb */		&CDisassembler::BniConditionStr,
};

const char *CDisassembler::S_modrm16_str[]		= { "bx+si", "bx+di", "bp+si", "bp+di", "si", "di", "bp", "bx" };
const char *CDisassembler::S_rex_byte_regs[]	= { "al", "cl", "dl", "bl", "spl", "bpl", "sil", "dil",
													"r8b", "r9b", "r10b", "r11b", "r12b", "r13b", "r14b", "r15b",
													"r16b", "r17b", "r18b", "r19b", "r20b", "r21b", "r22b", "r23b",
													"r24b", "r25b", "r26b", "r27b", "r28b", "r29b", "r30b", "r31b" };
const char *CDisassembler::S_byte_regs[]		= { "al", "cl", "dl", "bl", "ah", "ch", "dh", "bh" };
const char *CDisassembler::S_word_regs[]		= { "ax", "cx", "dx", "bx", "sp", "bp", "si", "di",
													"r8w", "r9w", "r10w", "r11w", "r12w", "r13w", "r14w", "r15w",
													"r16w", "r17w", "r18w", "r19w", "r20w", "r21w", "r22w", "r23w",
													"r24w", "r25w", "r26w", "r27w", "r28w", "r29w", "r30w", "r31w" };
const char *CDisassembler::S_dword_regs[]		= { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi",
													"r8d", "r9d", "r10d", "r11d", "r12d", "r13d", "r14d", "r15d",
													"r16d", "r17d", "r18d", "r19d", "r20d", "r21d", "r22d", "r23d",
													"r24d", "r25d", "r26d", "r27d", "r28d", "r29d", "r30d", "r31d" };
const char *CDisassembler::S_qword_regs[]		= { "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
													"r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
													"r16", "r17", "r18", "r19", "r20", "r21", "r22", "r23",
													"r24", "r25", "r26", "r27", "r28", "r29", "r30", "r31" };
const char *CDisassembler::S_control_regs[]		= { "cr0", "cr1", "cr2", "cr3", "cr4", "cr5", "cr6", "cr7",
													"cr8", "cr9", "cr10", "cr11", "cr12", "cr13", "cr14", "cr15" };
const char *CDisassembler::S_debug_regs[]		= { "dr0", "dr1", "dr2", "dr3", "dr4", "dr5", "dr6", "dr7",
													"dr8", "dr9", "dr10", "dr11", "dr12", "dr13", "dr14", "dr15" };
const char *CDisassembler::S_segment_regs[]		= { "es", "cs", "ss", "ds", "fs", "gs", "res", "res" };
const char *CDisassembler::S_fpu_regs[]			= { "st0", "st1", "st2", "st3", "st4", "st5", "st6", "st7", "st" };
const char *CDisassembler::S_mmx_regs[]			= { "mm0", "mm1", "mm2", "mm3", "mm4", "mm5", "mm6", "mm7" };
const char *CDisassembler::S_xmmx_regs[]		= { "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7",
													"xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15",
													"xmm16", "xmm17", "xmm18", "xmm19", "xmm20", "xmm21", "xmm22", "xmm23",
													"xmm24", "xmm25", "xmm26", "xmm27", "xmm28", "xmm29", "xmm30", "xmm31" };

const char *CDisassembler::S_size_qualifiers[]	= { "byte ", "word ", "dword ", "fword ", "qword ", "tword ", "dqword ", "" };

// Routine to help compilation issues for 64-bit printf's
char *CDisassembler::UINT64HexString( AMD_UINT64 val )
{
	static char buffer[32];
#ifdef WIN32
	sprintf( buffer, "%.16I64x", val );
#else
	sprintf( buffer, "%.16llx", val );
#endif
	return buffer;
}

// can't use SignedString multiple times in sprintf calls (overwrites static buffer)
char *CDisassembler::SignedString( AMD_INT64 value, int width, bool prependPlus )
{
	static char signed_string[32];
	char formatStr[32];
 
//	if( width != 16 )
//	{
		if( value < 0 )
		{
			sprintf( formatStr, "-%%.%dx%s", width, m_hexPostfix );
			value = -value;
		}
		else
			sprintf( formatStr, (prependPlus ? "+%%.%dx%s" : "%%.%dx%s"), width, m_hexPostfix );

		sprintf( signed_string, formatStr, (AMD_UINT32)value );

//	}
//	else
//	{
//		if( value & MIN_INT64 )
//		{
//			value = -(AMD_INT64)value;
//			sprintf( formatStr, "-%%s%s", m_hexPostfix );
//		}
//		else
//			sprintf( formatStr, (prependPlus ? "+%%%dx%s" : "%%%dx%s"), width, m_hexPostfix );
//	
//		sprintf( signed_string, formatStr, UINT64HexString(value) );
//	}

	return signed_string;
}

// can't use multiple times in sprintf calls (overwrites static buffer)
char *CDisassembler::UnsignedString( AMD_UINT64 value, int width, bool prependPlus )
{
	static char unsigned_string[32];
	char formatStr[32];
	if( width != 16 )
	{
		sprintf( formatStr, (prependPlus ? "+%%.%dx%s" : "%%.%dx%s"), width, m_hexPostfix );
		sprintf( unsigned_string, formatStr, (AMD_UINT32)value );
	}
	else
	{
		sprintf( formatStr, (prependPlus ? "+%%s%s" : "%%s%s"), m_hexPostfix );
		sprintf( unsigned_string, formatStr, UINT64HexString(value) );
	}

	return unsigned_string;
}

void CDisassembler::ModrmStr()
{
	(m_modrm_mod == 3) ? RegisterModrmStr() : MemoryModrmStr();
}

void CDisassembler::MemoryModrmStrWithoutSIB()
{
	if( m_pOperand->flags & OPF_SHOWSIZE )
		strcat( m_mnem, GetSizeQualifier() );

	if( m_inst_flags & INST_SEGOVRD )
	{
		strcat( m_mnem, S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)] );
		strcat( m_mnem, ":[" );
	}
	else
		strcat( m_mnem, "[" );

	if( m_modrm_mod == 0 )
	{
		if( m_modrm_rm == 5 )
		{
			if( m_longmode )
			{
				if( m_bCalculateRipRelative )
					sprintf( &m_mnem[strlen(m_mnem)], "loc_%s", UnsignedString( (m_rip+m_disp+GetLength()), GetAddressWidth(), false ) );
				else
					sprintf( &m_mnem[strlen(m_mnem)], "$%s", SignedString((m_disp+GetLength()),8,true) );
			}
			else
				sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((AMD_UINT32)m_disp,8,false) );
		}
		else
			strcat( m_mnem, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_base] : S_dword_regs[m_base] );
		strcat( m_mnem, "]" );
	}
	else if( m_modrm_mod == 1 )
	{
		strcat( m_mnem, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_base] : S_dword_regs[m_base] );
		sprintf( &m_mnem[strlen(m_mnem)], "%s]", SignedString(m_disp,2,true) );
	}
	else
	{
		strcat( m_mnem, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_base] : S_dword_regs[m_base] );
		sprintf( &m_mnem[strlen(m_mnem)], "%s]", SignedString(m_disp,8,true) );
	}
}

void CDisassembler::MemoryModrmStrWithSIB()
{
	char disp_str[16] = "";
	char base_str[16] = "";
	char idx_str[16] = "";
	char scale_st[16] = "";
	
	if( BASE( m_sib ) == 5 )
	{
		if( m_modrm_mod != 0 )
			strcat( base_str, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_base] : S_dword_regs[m_base] );
		
		if( m_modrm_mod == 1 )
		{
			strncpy( disp_str, SignedString(m_disp,2,true), 16 );
			disp_str[15] = '\0';
		}
		else if ( m_modrm_mod == 2 )
		{
			strncpy( disp_str, SignedString(m_disp,8,true), 16 );
			disp_str[15] = '\0';
		}
		else if( m_modrm_mod == 0 )
		{
			if( (IDX(m_sib) != 4) || (IsLongMode() && DREX_X(m_drex)) || REX_SIB_INDEX(m_rex_prefix) )
			{
				strncpy( disp_str, SignedString(m_disp,8,true), 16 );
				disp_str[15] = '\0';
			}
			else
			{
				strncpy( disp_str, UnsignedString((AMD_UINT32)m_disp,8,false), 16 );
				disp_str[15] = '\0';
			}
		}
	}
	else
	{
		strcat( base_str, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_base] : S_dword_regs[m_base] );
		
		if( m_modrm_mod == 1 )
		{
			strncpy( disp_str, SignedString(m_disp,2,true), 16 );
			disp_str[15] = '\0';
		}
		else if( m_modrm_mod == 2 )
		{
			strncpy( disp_str, SignedString(m_disp,8,true), 16 );
			disp_str[15] = '\0';
		}
	}
	
	if( (IDX( m_sib ) != 4) || (IsLongMode() && DREX_X(m_drex)) || REX_SIB_INDEX(m_rex_prefix) )
	{
		strcat( idx_str, (m_inst_flags & INST_ADDR64) ? S_qword_regs[m_index] : S_dword_regs[m_index] );
		
		if( SS( m_sib ) == 1 )
			strcat( scale_st, "*2" );
		else if( SS( m_sib ) == 2 )
			strcat( scale_st, "*4" );
		else if( SS( m_sib ) == 3 )
			strcat( scale_st, "*8" );
	}
	
	// concat all these strings together
	
	if( m_pOperand->flags & OPF_SHOWSIZE )
		strcat( m_mnem, GetSizeQualifier() );
	
	if( m_inst_flags & INST_SEGOVRD )
	{
		strcat( m_mnem, S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)] );
		strcat( m_mnem, ":[" );
	}
	else
		strcat( m_mnem, "[" );
	
	strcat( m_mnem, base_str );
	
	if( idx_str[0] != '\0' )
	{
		if( base_str[0] != '\0')
			strcat( m_mnem, "+" );
		
		strcat( m_mnem, idx_str );
	}
	
	if( scale_st[0] != '\0' )
		strcat( m_mnem, scale_st );
	
	if( disp_str[0] != '\0' )
		strcat( m_mnem, disp_str );
	
	strcat( m_mnem, "]" );
}

void CDisassembler::MemoryModrmStr()
{
	if( m_inst_flags & (INST_ADDR32 | INST_ADDR64) )
	{
		if( m_modrm_rm == 4 )
			MemoryModrmStrWithSIB();
		else
			MemoryModrmStrWithoutSIB();
	}
	else		// 16 bit mode
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			strcat( m_mnem, GetSizeQualifier() );

		if( m_inst_flags & INST_SEGOVRD )
		{
			strcat( m_mnem, S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)] );
			strcat( m_mnem, ":[" );
		}
		else
			strcat( m_mnem, "[" );
		
		if( m_modrm_mod == 0 )
		{
			if( m_modrm_rm == 6 )
				sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((AMD_UINT16)m_disp,4,false) );
			else
				strcat( m_mnem, S_modrm16_str[m_modrm_rm] );
			strcat( m_mnem, "]" );
		}
		else if( m_modrm_mod == 1 )
		{
			strcat( m_mnem, S_modrm16_str[m_modrm_rm] );
			sprintf( &m_mnem[strlen(m_mnem)], "%s]", SignedString(m_disp,2,true) );
		}
		else
		{
			strcat( m_mnem, S_modrm16_str[m_modrm_rm] );
			sprintf( &m_mnem[strlen(m_mnem)], "%s]", SignedString(m_disp,4,true) );
		}
	}
}

void CDisassembler::RegisterModrmStr()
{
	if( m_pOperand->flags & OPF_FARPTR )
	{
		if( m_pOperand->size == OPERANDSIZE_48 )
			strcat( m_mnem, S_dword_regs[m_pOperand->reg] );
		else
			strcat( m_mnem, S_word_regs[m_pOperand->reg] );
	}
	else
	{
		if( m_pOperand->size == OPERANDSIZE_8 )
		{
			if( REX_PREFIX(m_rex_prefix) )
				strcat( m_mnem, S_rex_byte_regs[m_pOperand->reg] );
			else if( m_pOperand->IsHighByte() )
				strcat( m_mnem, S_byte_regs[m_pOperand->reg + 4] );
			else
				strcat( m_mnem, S_byte_regs[m_pOperand->reg] );
		}
		else if( m_pOperand->size == OPERANDSIZE_16 )
			strcat( m_mnem, S_word_regs[m_pOperand->reg] );
		else if( m_pOperand->size == OPERANDSIZE_32 )
			strcat( m_mnem, S_dword_regs[m_pOperand->reg] );
		else
			strcat( m_mnem, S_qword_regs[m_pOperand->reg] );
	}
}

void CDisassembler::ByteRegStr()
{
	if( REX_PREFIX(m_rex_prefix) )
		strcat( m_mnem, S_rex_byte_regs[m_pOperand->reg] );
	else if( m_pOperand->IsHighByte() )
		strcat( m_mnem, S_byte_regs[m_pOperand->reg + 4] );
	else
		strcat( m_mnem, S_byte_regs[m_pOperand->reg] );
}

void CDisassembler::WordRegStr()
{
	strcat( m_mnem, S_word_regs[m_pOperand->reg] );
}

void CDisassembler::DwordRegStr()
{
	strcat( m_mnem, S_dword_regs[m_pOperand->reg] );
}

void CDisassembler::QwordRegStr()
{
	strcat( m_mnem, S_qword_regs[m_pOperand->reg] );
}

void CDisassembler::WDQRegStr()
{
	if( m_pOperand->size == OPERANDSIZE_64 )
		strcat( m_mnem, S_qword_regs[m_pOperand->reg] );
	else if( m_pOperand->size == OPERANDSIZE_32 )
		strcat( m_mnem, S_dword_regs[m_pOperand->reg] );
	else
		strcat( m_mnem, S_word_regs[m_pOperand->reg] );
}

void CDisassembler::ByteImmediateStr()
{
	if( m_pOperand->flags & OPF_SPECIAL64 )
	{
		if( m_longmode )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_QWORD], UnsignedString((m_immediateData & 0xff),2,false) );
		else
		{
			if( m_pOperand->flags & OPF_SHOWSIZE )
				sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_BYTE], UnsignedString((m_immediateData & 0xff),2,false) );
			else
				sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString(m_immediateData,2,false) );
		}
	}
	else
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_BYTE], UnsignedString((m_immediateData & 0xff),2,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xff),2,false) );
	}

	m_immediateData >>= 8;
}

void CDisassembler::WordImmediateStr()
{
	if( m_pOperand->flags & OPF_SHOWSIZE )
		sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_WORD], UnsignedString((m_immediateData & 0xffff),4,false) );
	else
		sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xffff),4,false) );

	m_immediateData >>= 16;
}

void CDisassembler::WordOrDwordImmediateStr()
{
	if( (m_inst_flags & (INST_DATA32 | INST_DATA64)) == 0 )
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_WORD], UnsignedString((m_immediateData & 0xffff),4,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xffff),4,false) );

		m_immediateData >>= 16;
	}
	else
	{
		if( m_longmode && ((m_pOperand->flags & OPF_SPECIAL64) != 0) )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_QWORD], UnsignedString((m_immediateData & 0xffffffff),8,false) );
		else if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_DWORD], UnsignedString((m_immediateData & 0xffffffff),8,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xffffffff),8,false) );

		m_immediateData >>= 32;
	}
}

void CDisassembler::WDQImmediateStr()
{
	if( m_inst_flags & INST_DATA64 )
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_QWORD], UnsignedString(m_immediateData,16,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString(m_immediateData,16,false) );

		m_immediateData = 0;
	}
	else if( m_inst_flags & INST_DATA32 )
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_DWORD], UnsignedString((m_immediateData & 0xffffffff),8,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xffffffff),8,false) );

		m_immediateData >>= 32;
	}
	else
	{
		if( m_pOperand->flags & OPF_SHOWSIZE )
			sprintf( &m_mnem[strlen(m_mnem)], "%s%s", S_size_qualifiers[SIZE_WORD], UnsignedString((m_immediateData & 0xffff),4,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xffff),4,false) );

		m_immediateData >>= 16;
	}
}

void CDisassembler::SignedByteJumpStr()
{
	if( m_bCalculateRipRelative )
		sprintf( &m_mnem[strlen(m_mnem)], "loc_%s", UnsignedString( (m_rip+m_disp+GetLength()), GetAddressWidth(), false ) );
	else
		sprintf( &m_mnem[strlen(m_mnem)], "$%s", SignedString((m_disp+GetLength()),2,true) );
}

void CDisassembler::SignedWordOrDwordJumpStr()
{
	if( m_bCalculateRipRelative )
	{
		if( m_pOperand->size == OPERANDSIZE_16 )
			sprintf( &m_mnem[strlen(m_mnem)], "loc_%s", UnsignedString( (AMD_UINT16)(m_rip+m_disp+GetLength()), GetAddressWidth(), false ));
		else
			sprintf( &m_mnem[strlen(m_mnem)], "loc_%s", UnsignedString( (m_rip+m_disp+GetLength()), GetAddressWidth(), false ));
	}
	else
	{
		if( m_pOperand->size == OPERANDSIZE_16 )
			sprintf( &m_mnem[strlen(m_mnem)], "$%s", SignedString((m_disp+GetLength()),4,true));
		else
			sprintf( &m_mnem[strlen(m_mnem)], "$%s", SignedString((m_disp+GetLength()),8,true));
	}
}

void CDisassembler::_1Str()
{
	strcat( m_mnem, "1" );
}

void CDisassembler::RegCLStr()
{
	strcat( m_mnem, "cl" );
}

void CDisassembler::RegALStr()
{
	strcat( m_mnem, "al" );
}

void CDisassembler::RegAXStr()
{
	strcat( m_mnem, "ax" );
}

void CDisassembler::RegeAXStr()
{
	if( m_pOperand->size == OPERANDSIZE_16 )
		strcat( m_mnem, "ax" );
	else if( m_pOperand->size == OPERANDSIZE_32 )
		strcat( m_mnem, "eax" );
	else
		strcat( m_mnem, "rax" );
}

void CDisassembler::RegDXStr()
{
	strcat( m_mnem, "dx" );
}

void CDisassembler::RegeDXStr()
{
	if( m_pOperand->size == OPERANDSIZE_16 )
		strcat( m_mnem, "dx" );
	else if( m_pOperand->size == OPERANDSIZE_32 )
		strcat( m_mnem, "edx" );
	else
		strcat( m_mnem, "rdx" );
}

void CDisassembler::AddressStr()
{
	// can't use UnsignedString/SignedString multiple times in sprintf calls (overwrites static buffer)
	if( m_pOperand->size == OPERANDSIZE_32 )
		sprintf( &m_mnem[strlen(m_mnem)], "%.4x:%.4x%s", (AMD_UINT16)(m_immd >> 16), (AMD_UINT16)m_immd, m_hexPostfix );
	else
		sprintf( &m_mnem[strlen(m_mnem)], "%.4x:%.8x%s", (AMD_UINT16)(m_immd >> 32), (AMD_UINT32)m_immd, m_hexPostfix );
}

void CDisassembler::OffsetStr()
{
	if( m_pOperand->flags & OPF_SHOWSIZE )
		strcat( m_mnem, GetSizeQualifier() );

	if( m_inst_flags & INST_SEGOVRD )
	{
		if( m_inst_flags & INST_ADDR64 )
			sprintf( &m_mnem[strlen(m_mnem)], "%s:[%s]", S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)], UnsignedString(m_immd,16,false) );
		else if( m_inst_flags & INST_ADDR32 )
			sprintf( &m_mnem[strlen(m_mnem)], "%s:[%s]", S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)], UnsignedString(m_immd,8,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "%s:[%s]", S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)], UnsignedString(m_immd,4,false) );
	}
	else
	{
		if( m_inst_flags & INST_ADDR64 )
			sprintf( &m_mnem[strlen(m_mnem)], "[%s]", UnsignedString(m_immd,16,false) );
		else if( m_inst_flags & INST_ADDR32 )
			sprintf( &m_mnem[strlen(m_mnem)], "[%s]", UnsignedString(m_immd,8,false) );
		else
			sprintf( &m_mnem[strlen(m_mnem)], "[%s]", UnsignedString(m_immd,4,false) );
	}
}

void CDisassembler::MMXRegStr()
{
	strcat( m_mnem, S_mmx_regs[m_pOperand->reg] );
}

void CDisassembler::MMXModrmStr()
{
	if( m_modrm_mod == 3 )
		strcat( m_mnem, S_mmx_regs[m_pOperand->reg] );
	else
		MemoryModrmStr();
}

void CDisassembler::RegisterStr()
{
	strcat( m_mnem, (m_longmode ? S_qword_regs[m_pOperand->reg] : S_dword_regs[m_pOperand->reg]) );
}

void CDisassembler::ControlRegStr()
{
	strcat( m_mnem, S_control_regs[m_pOperand->reg] );
}

void CDisassembler::DebugRegStr()
{
	strcat( m_mnem, S_debug_regs[m_pOperand->reg] );
}

void CDisassembler::SegmentRegStr()
{
	strcat( m_mnem, S_segment_regs[m_pOperand->reg] );
}

void CDisassembler::DsEsiStr()
{
	if( m_inst_flags & INST_ADDR64 )
		strcat( m_mnem, "[rsi]" );
	else
	{
		if( m_inst_flags & INST_SEGOVRD )
		{
			strcat( m_mnem, S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)] );
			strcat( m_mnem, ":[" );

			if( m_inst_flags & INST_ADDR32 )
				strcat( m_mnem, "esi]" );
			else
				strcat( m_mnem, "si]" );
		}
		else if( m_inst_flags & INST_ADDR32 )
			strcat( m_mnem, "ds:[esi]" );
		else
			strcat( m_mnem, "ds:[si]" );
	}
}

void CDisassembler::EsEdiStr()
{
	if( m_inst_flags & INST_ADDR64 )
		strcat( m_mnem, "[rdi]" );
	else if( m_inst_flags & INST_ADDR32 )
		strcat( m_mnem, "es:[edi]" );
	else
		strcat( m_mnem, "es:[di]" );
}

void CDisassembler::FpuStr()
{
	strcat( m_mnem, S_fpu_regs[m_pOperand->reg] );
}

void CDisassembler::SimdModrmStr()
{
	if( m_modrm_mod == 3 )
		strcat( m_mnem, S_xmmx_regs[m_pOperand->reg] );
	else
		MemoryModrmStr();
}
		
void CDisassembler::SimdRegStr()
{
	strcat( m_mnem, S_xmmx_regs[m_pOperand->reg] );
}

void CDisassembler::RegeBXAndALStr()
{
	if( m_inst_flags & (INST_SEGOVRD | INST_ADDROVRD) )
	{
		if( m_inst_flags & INST_SEGOVRD )
		{
			strcat( m_mnem, S_segment_regs[NORMALIZE_SEGREG(m_seg_reg)] );
			strcat( m_mnem, ":" );
		}

		if( m_inst_flags & INST_ADDR64 )
			strcat( m_mnem, "[rbx+al]" );
		else if( m_inst_flags & INST_ADDR32 )
			strcat( m_mnem, "[ebx+al]" );
		else
			strcat( m_mnem, "[bx+al]" );
	}
}

void CDisassembler::BniConditionStr()
{
	sprintf( &m_mnem[strlen(m_mnem)], "%s", UnsignedString((m_immediateData & 0xff),2,false) );
	m_immediateData >>= 8;
}

PVOIDMEMBERFUNC CDisassembler::S_DecodeOperandFnPtrs[] =
{
	/* OPRND_na	*/		NULL,
	/* OPRND_1	*/		NULL,
	/* OPRND_AL	*/		&CDisassembler::GetRegAL,
	/* OPRND_AX	*/		&CDisassembler::GetRegAX,
	/* OPRND_eAX */		&CDisassembler::GetRegeAX,
	/* OPRND_Ap	*/		&CDisassembler::GetDwordOrFwordDirect,
	/* OPRND_CL	*/		&CDisassembler::GetRegCL,
	/* OPRND_Cd	*/		&CDisassembler::GetControlRegister,
	/* OPRND_Dd	*/		&CDisassembler::GetDebugRegister,
	/* OPRND_DX	*/		&CDisassembler::GetRegDX,
	/* OPRND_eDX */		&CDisassembler::GetRegeDX,
	/* OPRND_Eb	*/		&CDisassembler::GetByteModrm,
	/* OPRND_Ew	*/		&CDisassembler::GetWordModrm,
	/* OPRND_Ed	*/		&CDisassembler::GetDwordModrm,
	/* OPRND_Ev	*/		&CDisassembler::GetWDQModrm,
	/* OPRND_Ep	*/		&CDisassembler::GetDwordOrFwordMemory,
	/* OPRND_Mt	*/		&CDisassembler::GetTwordMemory,
	/* OPRND_Gb	*/		&CDisassembler::GetByteRegFromReg,
	/* OPRND_Gw	*/		&CDisassembler::GetWordRegFromReg,
	/* OPRND_Gd	*/		&CDisassembler::GetDwordRegFromReg,
	/* OPRND_Gq	*/		&CDisassembler::GetQwordRegFromReg,
	/* OPRND_Gv	*/		&CDisassembler::GetWDQRegFromReg,
	/* OPRND_Ib	*/		&CDisassembler::GetByteImmediate,
	/* OPRND_Iv	*/		&CDisassembler::GetWordOrDwordImmediate,
	/* OPRND_Iw	*/		&CDisassembler::GetWordImmediate,
	/* OPRND_Jb	*/		&CDisassembler::GetByteJump,
	/* OPRND_Jv	*/		&CDisassembler::GetWordOrDwordJump,
	/* OPRND_M	*/		&CDisassembler::GetMemoryModrm,
	/* OPRND_Mp	*/		&CDisassembler::GetDwordOrFwordMemory,
	/* OPRND_Mq	*/		&CDisassembler::GetQwordMemory,
	/* OPRND_Ms	*/		&CDisassembler::GetFwordMemory,
	/* OPRND_Ob	*/		&CDisassembler::GetOffsetByte,
	/* OPRND_Ov	*/		&CDisassembler::GetOffsetWDQ,
	/* OPRND_Pq	*/		&CDisassembler::GetMMXQwordReg,
	/* OPRND_Pd	*/		&CDisassembler::GetMMXDwordReg,
	/* OPRND_Qq	*/		&CDisassembler::GetMMXQwordModrm,
	/* OPRND_Rd	*/		&CDisassembler::GetDwordOrQwordReg,
	/* OPRND_Sw	*/		&CDisassembler::GetWordSegmentRegister,
	/* OPRND_Xb	*/		&CDisassembler::GetByteMemoryEsi,
	/* OPRND_Xv	*/		&CDisassembler::GetWDQMemoryEsi,
	/* OPRND_Yb	*/		&CDisassembler::GetByteMemoryEdi,
	/* OPRND_Yv	*/		&CDisassembler::GetWDQMemoryEdi,
	/* OPRND_breg */	&CDisassembler::GetByteRegFromOpcode,
	/* OPRND_vreg */	&CDisassembler::GetWDQRegFromOpcode,
	/* OPRND_ST	*/		&CDisassembler::GetSTReg,
	/* OPRND_ST0 */		&CDisassembler::GetST0Reg,
	/* OPRND_ST1 */		&CDisassembler::GetST1Reg,
	/* OPRND_ST2 */		&CDisassembler::GetST2Reg,
	/* OPRND_ST3 */		&CDisassembler::GetST3Reg,
	/* OPRND_ST4 */		&CDisassembler::GetST4Reg,
	/* OPRND_ST5 */		&CDisassembler::GetST5Reg,
	/* OPRND_ST6 */		&CDisassembler::GetST6Reg,
	/* OPRND_ST7 */		&CDisassembler::GetST7Reg,
	/* OPRND_Vps */		&CDisassembler::GetSimdOwordReg,
	/* OPRND_Vq	*/		&CDisassembler::GetSimdQwordReg,
	/* OPRND_Vss */		&CDisassembler::GetSimdDwordReg,
	/* OPRND_Wps */		&CDisassembler::GetSimdOwordModrm,
	/* OPRND_Wq	*/		&CDisassembler::GetSimdQwordModrm,
	/* OPRND_Wss */		&CDisassembler::GetSimdDwordModrm,
	/* OPRND_Vpd */		&CDisassembler::GetSimdOwordReg,
	/* OPRND_Wpd */		&CDisassembler::GetSimdOwordModrm,
	/* OPRND_Vsd */		&CDisassembler::GetSimdQwordReg,
	/* OPRND_Wsd */		&CDisassembler::GetSimdQwordModrm,
	/* OPRND_Vdq */		&CDisassembler::GetSimdOwordReg,
	/* OPRND_Wdq */		&CDisassembler::GetSimdOwordModrm,
	/* OPRND_Vd */		&CDisassembler::GetSimdDwordReg,
	/* OPRND_FPU_AX */	&CDisassembler::GetFpuAx,
	/* OPRND_Mw	*/		&CDisassembler::GetWordMemory,
	/* OPRND_Md	*/		&CDisassembler::GetDwordMemory,
	/* OPRND_Iv64 */	&CDisassembler::GetWDQImmediate,
	/* OPRND_eBXAl */	&CDisassembler::GeteBXAndAL,
	/* OPRND_Ed_q */	&CDisassembler::GetDQModrm,
	/* OPRND_Pd_q */	&CDisassembler::GetMMXDQwordReg,
	/* OPRND_Vd_q */	&CDisassembler::GetSimdDQwordReg,
	/* OPRND_Gd_q */	&CDisassembler::GetDQRegFromReg,
	/* OPRND_Md_q */	&CDisassembler::GetDwordOrQwordMemory,
	/* OPRND_Ew_v */	&CDisassembler::GetWordMemoryOrWDQRegModrm,
	/* OPRND_Mq_dq */	&CDisassembler::GetQwordOrOwordMemory,
	/* OPRND_Mb	*/		&CDisassembler::GetByteMemory,

	/* OPRND_Bss */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_Bsd */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_Bps */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_Bpd */		&CDisassembler::GetBniOwordOpcode,

	/* OPRND_BsB */		&CDisassembler::GetBniByteOpcode,
	/* OPRND_BsW */		&CDisassembler::GetBniWordOpcode,
	/* OPRND_BsD */		&CDisassembler::GetBniDwordOpcode,
	/* OPRND_BsQ */		&CDisassembler::GetBniQwordOpcode,
	/* OPRND_BsO */		&CDisassembler::GetBniOwordOpcode,

	/* OPRND_VsB */		&CDisassembler::GetBniByteReg,
	/* OPRND_VsW */		&CDisassembler::GetBniWordReg,
	/* OPRND_VsD */		&CDisassembler::GetBniDwordReg,
	/* OPRND_VsQ */		&CDisassembler::GetBniQwordReg,
	/* OPRND_VsO */		&CDisassembler::GetBniOwordReg,

	/* OPRND_WsB */		&CDisassembler::GetBniByteModrm,
	/* OPRND_WsW */		&CDisassembler::GetBniWordModrm,
	/* OPRND_WsD */		&CDisassembler::GetBniDwordModrm,
	/* OPRND_WsQ */		&CDisassembler::GetBniQwordModrm,
	/* OPRND_WsO */		&CDisassembler::GetBniOwordModrm,

	/* OPRND_BpB */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_BpW */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_BpD */		&CDisassembler::GetBniOwordOpcode,
	/* OPRND_BpQ */		&CDisassembler::GetBniOwordOpcode,

	/* OPRND_VpB */		&CDisassembler::GetBniOwordReg,
	/* OPRND_VpW */		&CDisassembler::GetBniOwordReg,
	/* OPRND_VpD */		&CDisassembler::GetBniOwordReg,
	/* OPRND_VpQ */		&CDisassembler::GetBniOwordReg,

	/* OPRND_WpB */		&CDisassembler::GetBniOwordModrm,
	/* OPRND_WpW */		&CDisassembler::GetBniOwordModrm,
	/* OPRND_WpD */		&CDisassembler::GetBniOwordModrm,
	/* OPRND_WpQ */		&CDisassembler::GetBniOwordModrm,

	/* OPRND_oc */		NULL,
	/* OPRND_CCb */		&CDisassembler::GetBniByteCondition,
};

void CDisassembler::DecodeModrm()
{
	if( !m_bModrmDecoded )
	{
		m_bModrmDecoded = true;

		if( m_inst_flags & (INST_ADDR32 | INST_ADDR64) )
		{
			if( m_modrm_mod != 3 )
			{
				if( m_modrm_rm != 4 )
				{ 
					// no SIB

					if( (m_inst_flags & INST_DREX) != 0 )
					{
						GetDrexByte();
						if( (m_modrm_mod != 0) || (m_modrm_rm != 5) )
						{
							int regOffset = (IsLongMode() && DREX_B(m_drex)) ? 8 : 0;
							SetBase( (AMD_UINT8)(m_modrm_rm + regOffset) );
						}
					}
					else
					{
						if( (m_modrm_mod != 0) || (m_modrm_rm != 5) )
						{
							int regOffset = REX_MODRM_RM(m_rex_prefix) ? 8 : 0;
							SetBase( (AMD_UINT8)(m_modrm_rm + regOffset) );
						}
					}

					if( (m_modrm_mod == 0) && (m_modrm_rm == 5) )
						GetDisplacementDword();
					else if( m_modrm_mod == 2 )
						GetDisplacementDword();
					else if( m_modrm_mod == 1 )
						GetDisplacementByte();
				}
				else
				{
					// SIB
					m_sib = GetByte();
					m_sibOffset = m_len;

					if( (m_inst_flags & INST_DREX) != 0 )
					{
						GetDrexByte();
						if( IsLongMode() && (DREX_X(m_drex) != 0) )
							SetIndex( (AMD_UINT8)(IDX(m_sib) + 8) );
						else if( IDX( m_sib ) != 4 )
							SetIndex( IDX(m_sib) );
					}
					else
					{
						if( REX_SIB_INDEX(m_rex_prefix) )
							SetIndex( (AMD_UINT8)(IDX(m_sib) + 8) );
						else if( IDX( m_sib ) != 4 )
							SetIndex( IDX(m_sib) );
					}

					if( BASE( m_sib ) == 5 )
					{
						if( m_modrm_mod != 0 )
						{
							int regOffset;
							if( (m_inst_flags & INST_DREX) != 0 )
								regOffset = (IsLongMode() && DREX_B(m_drex)) ? 8 : 0;
							else
								regOffset = REX_SIB_BASE(m_rex_prefix) ? 8 : 0;
							SetBase( (AMD_UINT8)(REG_EBP + regOffset) );
						}

						if( m_modrm_mod == 1 )
							GetDisplacementByte();
						else
							GetDisplacementDword();
					}
					else
					{
						int regOffset;
						if( (m_inst_flags & INST_DREX) != 0 )
							regOffset = (IsLongMode() && DREX_B(m_drex)) ? 8 : 0;
						else
							regOffset = REX_SIB_BASE(m_rex_prefix) ? 8 : 0;
						SetBase( (AMD_UINT8)(BASE(m_sib) + regOffset) );

						if( m_modrm_mod == 1 )
							GetDisplacementByte();
						else if( m_modrm_mod == 2 )
							GetDisplacementDword();
					}
				}
			}
			else if( (m_inst_flags & INST_DREX) != 0 )
				GetDrexByte();
		}
		else
		{
			switch( m_modrm_rm )
			{
				case 0:
					SetBase( REG_EBX );
					SetIndex( REG_ESI );
					break;
				case 1:
					SetBase( REG_EBX );
					SetIndex( REG_EDI );
					break;
				case 2:
					SetBase( REG_EBP );
					SetIndex( REG_ESI );
					break;
				case 3:
					SetBase( REG_EBP );
					SetIndex( REG_EDI );
					break;
				case 4:
					SetIndex( REG_ESI );
					break;
				case 5:
					SetIndex( REG_EDI );
					break;
				case 6:
					if( m_modrm_mod != 0 )
						SetBase( REG_EBP );
					break;
				case 7:
					SetBase( REG_EBX );
					break;
			}

			if( (m_inst_flags & INST_DREX) != 0 )
				GetDrexByte();

			switch( m_modrm_mod )
			{
				case 0:
				{
					if( m_modrm_rm == 6 )
						GetDisplacementWord();
					break;
				} 
				case 1:
				{
					GetDisplacementByte();
					break;
				} 
				case 2:
				{
					GetDisplacementWord();
					break;
				} 
			}
		}
	}
}

void CDisassembler::OperandModrm()
{
	GetModrmByte();
	if( m_modrm_mod == 3 )
		OperandRegisterModrm();
	else
		OperandMemoryModrm();
}

void CDisassembler::OperandMemoryModrm()
{
	GetModrmByte();
	DecodeModrm();

	if( m_modrm_mod == 3 )
		throw CFormatException();

	if( m_pOperand->flags & OPF_REGISTER )
		throw CFormatException();

	m_pOperand->type = OPERANDTYPE_MEMORY;		// may be overwritten in longmode (see below)

	if( m_inst_flags & (INST_ADDR32 | INST_ADDR64) )
	{
		if( m_modrm_rm != 4 )
		{ 
			// no SIB
			if( (m_modrm_mod == 0) && (m_modrm_rm == 5) )
				if( m_longmode )
					m_pOperand->type = OPERANDTYPE_RIPRELATIVE;
		}
	}
}

void CDisassembler::OperandRegisterModrm()
{
	GetModrmByte();
	DecodeModrm();

	if( m_modrm_mod != 3 )
		throw CFormatException();

	if( m_pOperand->flags & OPF_MEMORY )
		throw CFormatException();

	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_MODRM_RM;

	if( (m_inst_flags & INST_DREX) != 0 )
	{
		int regOffset = (IsLongMode() && DREX_B(m_drex)) ? 8 : 0;
		m_pOperand->reg = (AMD_UINT8)(m_modrm_rm + regOffset);
	}
	else if( REX_PREFIX(m_rex_prefix) || (m_pOperand->size != OPERANDSIZE_8) )
	{
		int regOffset = REX_MODRM_RM(m_rex_prefix) ? 8 : 0;
		m_pOperand->reg = (AMD_UINT8)(m_modrm_rm + regOffset);
	}
	else
	{
		m_pOperand->reg = (AMD_UINT8)(m_modrm_rm & 0x3);

		if( (m_modrm_rm & 0x4) != 0 )
			m_pOperand->flags |= OPF_BYTEHIGH;
	}
}

void CDisassembler::GetModrmByte()
{
	if( m_modrmOffset == -1 )
	{
		m_modrmOffset = m_len;
		m_modrm = GetByte();
		
		m_modrm_mod = MOD( m_modrm );
		m_modrm_reg = REG( m_modrm );
		m_modrm_rm = RM( m_modrm );
	}
}

void CDisassembler::GetDrexByte()
{
	if( m_drexOffset == -1 )
	{
		m_drexOffset = m_len;
		m_drex = GetByte();
	}
}

void CDisassembler::GetImmediateByte()
{
	if( m_immediateOffset == -1 )
	{
		m_immediateOffset = m_len;
		m_immediateLength = 1;
		m_immd = GetByte();
	}
	else
	{	// this must be the second immediate
		switch( m_len - m_immediateOffset )
		{
			case 1:
			{
				m_immd |= (GetByte() << 8);
				m_immediateLength++;
				break;
			}
			case 2:
			{
				m_immd |= (GetByte() << 16);
				m_immediateLength++;
				break;
			}
			default:
				throw CFormatException();
		}
	}
}

void CDisassembler::GetImmediateWord()
{
	m_immediateOffset = m_len;
	m_immediateLength = 2;
	m_immd = GetByte();
	m_immd |= GetByte() << 8;
}

void CDisassembler::GetImmediateDword()
{
	m_immediateOffset = m_len;
	m_immediateLength = 4;
	m_immd = GetByte();
	m_immd |= GetByte() << 8;
	m_immd |= GetByte() << 16;
	m_immd |= ((AMD_UINT64)GetByte()) << 24;
}

void CDisassembler::GetImmediateFword()
{
	m_immediateOffset = m_len;
	m_immediateLength = 6;
	m_immd = GetByte();
	m_immd |= GetByte() << 8;
	m_immd |= GetByte() << 16;
	m_immd |= ((AMD_UINT64)GetByte()) << 24;
	m_immd |= (((AMD_UINT64)GetByte()) << 32);
	m_immd |= (((AMD_UINT64)GetByte()) << 40);
}

void CDisassembler::GetImmediateQword()
{
	m_immediateOffset = m_len;
	m_immediateLength = 8;
	m_immd = GetByte();
	m_immd |= GetByte() << 8;
	m_immd |= GetByte() << 16;
	m_immd |= (((AMD_UINT64)GetByte()) << 24);
	m_immd |= (((AMD_UINT64)GetByte()) << 32);
	m_immd |= (((AMD_UINT64)GetByte()) << 40);
	m_immd |= (((AMD_UINT64)GetByte()) << 48);
	m_immd |= (((AMD_UINT64)GetByte()) << 56);
}

void CDisassembler::GetDisplacementByte()
{
	m_displacementOffset = m_len;
	m_displacementLength = 1;
	m_disp = GetByte();
	m_disp = (AMD_INT8)m_disp;		// sign extend
}

void CDisassembler::GetDisplacementWord()
{
	m_displacementOffset = m_len;
	m_displacementLength = 2;
	m_disp = GetByte();
	m_disp |= GetByte() << 8;
	m_disp = (AMD_INT16)m_disp;		// sign extend
}

void CDisassembler::GetDisplacementDword()
{
	m_displacementOffset = m_len;
	m_displacementLength = 4;
	m_disp = GetByte();
	m_disp |= GetByte() << 8;
	m_disp |= GetByte() << 16;
	m_disp |= ((AMD_UINT64)GetByte()) << 24;
	m_disp = (AMD_INT32)m_disp;		// sign extend
}

void CDisassembler::GetDisplacementQword()
{
	m_displacementOffset = m_len;
	m_displacementLength = 8;
	m_disp = GetByte();
	m_disp |= GetByte() << 8;
	m_disp |= GetByte() << 16;
	m_disp |= GetByte() << 24;
	m_disp |= (((AMD_UINT64)GetByte()) << 32);
	m_disp |= (((AMD_UINT64)GetByte()) << 40);
	m_disp |= (((AMD_UINT64)GetByte()) << 48);
	m_disp |= (((AMD_UINT64)GetByte()) << 56);
}

void CDisassembler::GetByteModrm()
{
	m_pOperand->size = OPERANDSIZE_8;
	OperandModrm();
}

void CDisassembler::GetWordModrm()
{
	m_pOperand->size = OPERANDSIZE_16; 
	OperandModrm();
}

void CDisassembler::GetDwordModrm()
{
	m_pOperand->size = OPERANDSIZE_32; 
	OperandModrm();
}

void CDisassembler::GetWordMemoryOrWDQRegModrm()
{
	GetModrmByte();
	m_pOperand->size = (m_modrm_mod == 3) ? GetWDQOperandSize() : OPERANDSIZE_16; 
	DecodeModrm();
	OperandModrm();
}

void CDisassembler::GetWDQModrm()
{
	if( m_pOperand->flags & OPF_SPECIAL64 )
	{
		if( m_longmode )
			m_pOperand->size = (m_inst_flags & INST_DATA16) ? OPERANDSIZE_16 : OPERANDSIZE_64;
		else
			m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_16;
	}
	else
	{
		if( REX_PREFIX(m_rex_prefix) )
			m_pOperand->size = GetWDQOperandSize();
		else
			m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_16;
	}
	OperandModrm();
}

void CDisassembler::GetDQModrm()
{
	if( m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_64;
	else
		m_pOperand->size = OPERANDSIZE_32;
	OperandModrm();
}

void CDisassembler::GetOwordModrm()
{
	m_pOperand->size = OPERANDSIZE_128;
	OperandModrm();
}

void CDisassembler::GetRegFromReg()
{
	GetModrmByte();

	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_MODRM_REG;

	int regOffset = 0;
	if( (m_inst_flags & INST_DREX) != 0 )
		regOffset = (IsLongMode() && DREX_R(m_drex)) ? 8 : 0;
	else if( REX_PREFIX(m_rex_prefix) )
		regOffset = REX_MODRM_REG(m_rex_prefix) ? 8 : 0;

	m_pOperand->reg = (AMD_UINT8)(m_modrm_reg + regOffset);
}

void CDisassembler::GetByteRegFromReg()
{
	GetModrmByte();

	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_MODRM_REG;

	if( REX_PREFIX(m_rex_prefix) )
	{
		int regOffset = REX_MODRM_REG(m_rex_prefix) ? 8 : 0;
		m_pOperand->reg = (AMD_UINT8)(m_modrm_reg + regOffset);
	}
	else
	{
		m_pOperand->reg = (AMD_UINT8)(m_modrm_reg & 0x3);

		if( (m_modrm_reg & 0x4) != 0 )
			m_pOperand->flags |= OPF_BYTEHIGH;
	}
}

void CDisassembler::GetWordRegFromReg()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetRegFromReg();
}

void CDisassembler::GetDwordRegFromReg()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetRegFromReg();
}

void CDisassembler::GetQwordRegFromReg()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetRegFromReg();
}

void CDisassembler::GetWDQRegFromReg()
{
	m_pOperand->size = GetWDQOperandSize();
	GetRegFromReg();
}

void CDisassembler::GetDQRegFromReg()
{
	if( m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_64;
	else
		m_pOperand->size = OPERANDSIZE_32;
	GetRegFromReg();
}

void CDisassembler::GetByteImmediate()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	GetImmediateByte();
}

void CDisassembler::GetWordImmediate()
{
	m_pOperand->size = OPERANDSIZE_16;
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	GetImmediateWord();
}

void CDisassembler::GetWordOrDwordImmediate()
{
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	if( m_inst_flags & (INST_DATA32 | INST_DATA64) )
	{
		m_pOperand->size = OPERANDSIZE_32;
		GetImmediateDword();
	}
	else
	{
		m_pOperand->size = OPERANDSIZE_16;
		GetImmediateWord();
	}
}

void CDisassembler::GetWDQImmediate()
{
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	if( m_inst_flags & INST_DATA64 )
	{
		m_pOperand->size = OPERANDSIZE_64;
		GetImmediateQword();
	}
	else if( m_inst_flags & INST_DATA32 )
	{
		m_pOperand->size = OPERANDSIZE_32;
		GetImmediateDword();
	}
	else
	{
		m_pOperand->size = OPERANDSIZE_16;
		GetImmediateWord();
	}
}

void CDisassembler::GetByteJump()
{
	m_pOperand->type = OPERANDTYPE_PCOFFSET;
	m_pOperand->size = OPERANDSIZE_8;
	GetDisplacementByte();
}

void CDisassembler::GetWordOrDwordJump()
{
	m_pOperand->type = OPERANDTYPE_PCOFFSET;
	if( m_inst_flags & (INST_DATA32 | INST_DATA64) )
	{
		m_pOperand->size = OPERANDSIZE_32;
		GetDisplacementDword();
	}
	else
	{
		m_pOperand->size = OPERANDSIZE_16;
		GetDisplacementWord();
	}
}

void CDisassembler::GetByteRegFromOpcode()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;

	AMD_UINT8 opcode = GetOpcode( 0 );
	if( REX_PREFIX(m_rex_prefix) )
	{
		int regOffset = REX_OPCODE_REG(m_rex_prefix) ? 8 : 0;
		m_pOperand->reg = (AMD_UINT8)(RM(opcode) + regOffset);
	}
	else
	{
		m_pOperand->reg = (AMD_UINT8)(RM(opcode) & 0x3);

		if( (RM(opcode) & 0x4) != 0 )
			m_pOperand->flags |= OPF_BYTEHIGH;
	}
}

void CDisassembler::GetWDQRegFromOpcode()
{
	if( (m_pOperand->flags & OPF_SPECIAL64) && m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA16) ? OPERANDSIZE_16 : OPERANDSIZE_64;
	else
		m_pOperand->size = GetWDQOperandSize();

	AMD_UINT8 opcode = GetOpcode( IsLongopcode() ? 1 : 0 );
	m_pOperand->type = OPERANDTYPE_REGISTER;
	int regOffset = REX_OPCODE_REG(m_rex_prefix) ? 8 : 0;
	m_pOperand->reg = (AMD_UINT8)(RM(opcode) + regOffset);
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegAL()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = REG_EAX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegAX()
{
	m_pOperand->size = OPERANDSIZE_16;
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = REG_EAX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegeAX()
{
	m_pOperand->size = GetWDQOperandSize();
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = REG_EAX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegCL()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->reg = REG_ECX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegDX()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_16;
	m_pOperand->reg = REG_EDX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetRegeDX()
{
	m_pOperand->size = GetWDQOperandSize();
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = REG_EDX;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetFpuAx()
{
	GetModrmByte();
	GetRegAX();
}

// No size associated with this memory (either sizeless or irregularly sized)
void CDisassembler::GetMemoryModrm()
{
	OperandMemoryModrm();
}

void CDisassembler::GetDwordOrFwordMemory()
{
	m_pOperand->flags |= OPF_FARPTR;
	m_pOperand->size = (m_inst_flags & (INST_DATA32 | INST_DATA64)) ? OPERANDSIZE_48 : OPERANDSIZE_32;
	OperandMemoryModrm();
}

void CDisassembler::GetFwordMemory()
{
	m_pOperand->flags |= OPF_FARPTR;
	m_pOperand->size = OPERANDSIZE_48;
	OperandMemoryModrm();
}

void CDisassembler::GetDwordOrFwordDirect()
{
	m_pOperand->size = (m_inst_flags & (INST_DATA32 | INST_DATA64)) ? OPERANDSIZE_48 : OPERANDSIZE_32;
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	(m_pOperand->size == OPERANDSIZE_48) ? GetImmediateFword() : GetImmediateDword();
}

void CDisassembler::GetOffsetByte()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_MEMORY;

	if( m_inst_flags & INST_ADDR64 )
		GetImmediateQword();
	else if( m_inst_flags & INST_ADDR32 )
		GetImmediateDword();
	else
		GetImmediateWord();
}

void CDisassembler::GetOffsetWDQ()
{
	m_pOperand->size = GetWDQOperandSize();
	m_pOperand->type = OPERANDTYPE_MEMORY;

	if( m_inst_flags & INST_ADDR64 )
		GetImmediateQword();
	else if( m_inst_flags & INST_ADDR32 )
		GetImmediateDword();
	else
		GetImmediateWord();
}

void CDisassembler::GetMMXReg()
{
	GetRegFromReg();
	UndoRegisterExtensions();
	m_pOperand->regBlock = REG_MM0;
}

void CDisassembler::GetMMXDwordReg()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetMMXReg();
}

void CDisassembler::GetMMXQwordReg()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetMMXReg();
}

void CDisassembler::GetMMXDQwordReg()
{
	if( m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_64;
	else
		m_pOperand->size = OPERANDSIZE_32;

	GetMMXReg();
}

void CDisassembler::GetMMXQwordModrm()
{
	m_pOperand->size = OPERANDSIZE_64;

	OperandModrm();
	UndoRegisterExtensions();
	m_pOperand->regBlock = REG_MM0;
}

// this is for the Control Registers and Debug Registers mov instructions (GP register operand)
void CDisassembler::GetDwordOrQwordReg()
{
	m_pOperand->size = (m_longmode || m_rex32mode) ? OPERANDSIZE_64 : OPERANDSIZE_32;
	GetModrmByte();

	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_MODRM_RM;

	int regOffset = REX_MODRM_RM(m_rex_prefix) ? 8 : 0;
	m_pOperand->reg = (AMD_UINT8)(m_modrm_rm + regOffset);
}

void CDisassembler::GetDebugRegister()
{
	m_pOperand->size = m_longmode ? OPERANDSIZE_64 : OPERANDSIZE_32;
	GetRegFromReg();
	m_pOperand->regBlock = REG_DR0;
}

void CDisassembler::GetControlRegister()
{
	m_pOperand->size = m_longmode ? OPERANDSIZE_64 : OPERANDSIZE_32;
	GetRegFromReg();

	if( HasLockPrefix() && !REX_MODRM_REG(m_rex_prefix) )
		m_pOperand->reg += 8;

	if( m_pOperand->reg >= NUM_CONTROL_REGISTERS )
		throw CFormatException();

	m_pOperand->regBlock = REG_CR0;
}

void CDisassembler::GetWordSegmentRegister()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetRegFromReg();
	UndoRegisterExtensions();
	m_pOperand->regBlock = REG_ES;
}

void CDisassembler::GetByteMemoryEsi()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_MEMORY;
	m_pOperand->reg = REG_ESI;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
	m_pOperand->flags |= OPF_STRING;
}

void CDisassembler::GetWDQMemoryEsi()
{
	m_pOperand->size = GetWDQOperandSize();
	m_pOperand->type = OPERANDTYPE_MEMORY;
	m_pOperand->reg = REG_ESI;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
	m_pOperand->flags |= OPF_STRING;
}

void CDisassembler::GetByteMemoryEdi()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_MEMORY;
	m_pOperand->reg = REG_EDI;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
	m_pOperand->flags |= OPF_STRING;
}

void CDisassembler::GetWDQMemoryEdi()
{
	m_pOperand->size = GetWDQOperandSize();
	m_pOperand->type = OPERANDTYPE_MEMORY;
	m_pOperand->reg = REG_EDI;
	m_pOperand->regBlock = REG_EAX;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
	m_pOperand->flags |= OPF_STRING;
}

void CDisassembler::GetST0Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 0;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST1Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 1;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST2Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 2;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST3Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 3;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST4Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 4;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST5Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 5;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST6Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 6;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetST7Reg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 7;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetSTReg()
{
	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->size = OPERANDSIZE_80;
	m_pOperand->reg = 8;
	m_pOperand->regBlock = REG_ST0;
	m_pOperand->regOrigin = REGORIGIN_OPCODE;
}

void CDisassembler::GetSimdReg()
{
	GetRegFromReg();
	m_pOperand->regBlock = REG_XMM0;
}

void CDisassembler::GetSimdDwordReg()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetSimdReg();
}

void CDisassembler::GetSimdQwordReg()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetSimdReg();
}

void CDisassembler::GetSimdDQwordReg()
{
	if( m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_64;
	else
		m_pOperand->size = OPERANDSIZE_32;

	GetSimdReg();
}

void CDisassembler::GetSimdOwordReg()
{
	m_pOperand->size = OPERANDSIZE_128;
	GetSimdReg();
}
 
void CDisassembler::GetSimdModrm()
{
	OperandModrm();

	if( m_pOperand->type == OPERANDTYPE_REGISTER )
		m_pOperand->regBlock = REG_XMM0;
}

void CDisassembler::GetSimdDwordModrm()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetSimdModrm();
}
 
void CDisassembler::GetSimdQwordModrm()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetSimdModrm();
}
 
void CDisassembler::GetSimdOwordModrm()
{
	m_pOperand->size = OPERANDSIZE_128;
	GetSimdModrm();
}

void CDisassembler::GetMemory()
{
	OperandMemoryModrm();
}

void CDisassembler::GetByteMemory()
{
	m_pOperand->size = OPERANDSIZE_8;
	GetMemory();
}

void CDisassembler::GetWordMemory()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetMemory();
}

void CDisassembler::GetDwordMemory()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetMemory();
}

void CDisassembler::GetDwordOrQwordMemory()
{
	if( m_longmode )
		m_pOperand->size = (m_inst_flags & INST_DATA32) ? OPERANDSIZE_32 : OPERANDSIZE_64;
	else
		m_pOperand->size = OPERANDSIZE_32;

	GetMemory();
}

void CDisassembler::GetQwordOrOwordMemory()
{
	m_pOperand->size = (m_inst_flags & INST_DATA64) ? OPERANDSIZE_128 : OPERANDSIZE_64;
	GetMemory();
}

void CDisassembler::GetWordOrDwordMemory()
{
	m_pOperand->size = (m_inst_flags & INST_DATA16) ? OPERANDSIZE_16 : OPERANDSIZE_32;
	GetMemory();
}

void CDisassembler::GetQwordMemory()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetMemory();
}

void CDisassembler::GetTwordMemory()
{
	m_pOperand->size = OPERANDSIZE_80;
	GetMemory();
}

void CDisassembler::GeteBXAndAL()
{
	m_pOperand->type = OPERANDTYPE_MEMORY;
}

void CDisassembler::GetBniOpcodeOperand()
{
	if( ((m_inst_flags & INST_OC_2) != 0) && (DREX_OC0(m_drex) != 0) )
		throw CFormatException();

	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = IsLongMode() ? DREX_DEST(m_drex) : (DREX_DEST(m_drex) & 7);
	m_pOperand->regBlock = REG_XMM0;
	m_pOperand->regOrigin = REGORIGIN_DREX;
}

void CDisassembler::GetBniByteOpcode()
{
	m_pOperand->size = OPERANDSIZE_8;
	GetBniOpcodeOperand();
}

void CDisassembler::GetBniWordOpcode()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetBniOpcodeOperand();
}

void CDisassembler::GetBniDwordOpcode()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetBniOpcodeOperand();
}

void CDisassembler::GetBniQwordOpcode()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetBniOpcodeOperand();
}

void CDisassembler::GetBniOwordOpcode()
{
	m_pOperand->size = OPERANDSIZE_128;
	GetBniOpcodeOperand();
}

void CDisassembler::GetBniReg()
{
	GetModrmByte();

	int regOffset;
	if( (m_inst_flags & INST_DREX) != 0 )
		regOffset = (IsLongMode() && DREX_R(m_drex)) ? 8 : 0;
	else
		regOffset = REX_MODRM_REG(m_rex_prefix) ? 8 : 0;

	m_pOperand->type = OPERANDTYPE_REGISTER;
	m_pOperand->reg = (AMD_UINT8)(m_modrm_reg + regOffset);
	m_pOperand->regBlock = REG_XMM0;
	m_pOperand->regOrigin = REGORIGIN_MODRM_REG;
}

void CDisassembler::GetBniByteReg()
{
	m_pOperand->size = OPERANDSIZE_8;
	GetBniReg();
}

void CDisassembler::GetBniWordReg()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetBniReg();
}

void CDisassembler::GetBniDwordReg()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetBniReg();
}

void CDisassembler::GetBniQwordReg()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetBniReg();
}

void CDisassembler::GetBniOwordReg()
{
	m_pOperand->size = OPERANDSIZE_128;
	GetBniReg();
}

void CDisassembler::GetBniModrm()
{
	OperandModrm();
	if( m_pOperand->type == OPERANDTYPE_REGISTER )
		m_pOperand->regBlock = REG_XMM0;
}

void CDisassembler::GetBniByteModrm()
{
	m_pOperand->size = OPERANDSIZE_8;
	GetBniModrm();
}

void CDisassembler::GetBniWordModrm()
{
	m_pOperand->size = OPERANDSIZE_16;
	GetBniModrm();
}

void CDisassembler::GetBniDwordModrm()
{
	m_pOperand->size = OPERANDSIZE_32;
	GetBniModrm();
}

void CDisassembler::GetBniQwordModrm()
{
	m_pOperand->size = OPERANDSIZE_64;
	GetBniModrm();
}

void CDisassembler::GetBniOwordModrm()
{
	m_pOperand->size = OPERANDSIZE_128;
	GetBniModrm();
}

void CDisassembler::GetBniByteCondition()
{
	m_pOperand->size = OPERANDSIZE_8;
	m_pOperand->type = OPERANDTYPE_IMMEDIATE;
	GetImmediateByte();
}

bool CDisassembler::TablesHooked()
{
	try
	{
		int i;

		for( i = 0; i < 256; i++ )
		{
			CheckHook( S_oneByteOpcodes_tbl[i], "S_oneByteOpcodes_tbl" );
			CheckHook( S_twoByteOpcodes_tbl[i], "S_twoByteOpcodes_tbl" );
		}

		for( i = 0; i < 3; i++ )
		{
			CheckHook( S_group_1_60_tbl[i], "S_group_1_60_tbl" );
			CheckHook( S_group_1_61_tbl[i], "S_group_1_61_tbl" );
		}

		for( i = 0; i < 2; i++ )
		{
			CheckHook( S_group_1_63_tbl[i], "S_group_1_63_tbl" );
			CheckHook( S_group_1_6d_tbl[i], "S_group_1_6d_tbl" );
			CheckHook( S_group_1_6f_tbl[i], "S_group_1_6f_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_1_80_tbl[i], "S_group_1_80_tbl" );
			CheckHook( S_group_1_81_tbl[i], "S_group_1_81_tbl" );
			CheckHook( S_group_1_82_tbl[i], "S_group_1_82_tbl" );
			CheckHook( S_group_1_83_tbl[i], "S_group_1_83_tbl" );
		}


		for( i = 0; i < 3; i++ )
		{
			CheckHook( S_group_1_90_tbl[i], "S_group_1_90_tbl" );
			CheckHook( S_group_1_98_tbl[i], "S_group_1_98_tbl" );
			CheckHook( S_group_1_99_tbl[i], "S_group_1_99_tbl" );
			CheckHook( S_group_1_9c_tbl[i], "S_group_1_9c_tbl" );
			CheckHook( S_group_1_9d_tbl[i], "S_group_1_9d_tbl" );
			CheckHook( S_group_1_a5_tbl[i], "S_group_1_a5_tbl" );
			CheckHook( S_group_1_a7_tbl[i], "S_group_1_a7_tbl" );
			CheckHook( S_group_1_ab_tbl[i], "S_group_1_ab_tbl" );
			CheckHook( S_group_1_ad_tbl[i], "S_group_1_ad_tbl" );
			CheckHook( S_group_1_af_tbl[i], "S_group_1_af_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_1_c0_tbl[i], "S_group_1_c0_tbl" );
			CheckHook( S_group_1_c1_tbl[i], "S_group_1_c1_tbl" );
		}

		for( i = 0; i < 3; i++ )
		{
			CheckHook( S_group_1_c2_tbl[i], "S_group_1_c2_tbl" );
			CheckHook( S_group_1_c3_tbl[i], "S_group_1_c3_tbl" );
			CheckHook( S_group_1_ca_tbl[i], "S_group_1_ca_tbl" );
			CheckHook( S_group_1_cb_tbl[i], "S_group_1_cb_tbl" );
			CheckHook( S_group_1_cf_tbl[i], "S_group_1_cf_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_1_d0_tbl[i], "S_group_1_d0_tbl" );
			CheckHook( S_group_1_d1_tbl[i], "S_group_1_d1_tbl" );
			CheckHook( S_group_1_d2_tbl[i], "S_group_1_d2_tbl" );
			CheckHook( S_group_1_d3_tbl[i], "S_group_1_d3_tbl" );
		}

		for( i = 0; i < 72; i++ )
		{
			CheckHook( S_group_1_d8_tbl[i], "S_group_1_d8_tbl" );
			CheckHook( S_group_1_d9_tbl[i], "S_group_1_d9_tbl" );
			CheckHook( S_group_1_da_tbl[i], "S_group_1_da_tbl" );
			CheckHook( S_group_1_db_tbl[i], "S_group_1_db_tbl" );
			CheckHook( S_group_1_dc_tbl[i], "S_group_1_dc_tbl" );
			CheckHook( S_group_1_dd_tbl[i], "S_group_1_dd_tbl" );
			CheckHook( S_group_1_de_tbl[i], "S_group_1_de_tbl" );
			CheckHook( S_group_1_df_tbl[i], "S_group_1_df_tbl" );
		}

		for( i = 0; i < 3; i++ )
			CheckHook( S_group_1_e3_tbl[i], "S_group_1_e3_tbl" );

		for( i = 0; i < 2; i++ )
		{
			CheckHook( S_group_1_fa_tbl[i], "S_group_1_fa_tbl" );
			CheckHook( S_group_1_fb_tbl[i], "S_group_1_fb_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_1_f6_tbl[i], "S_group_1_f6_tbl" );
			CheckHook( S_group_1_f7_tbl[i], "S_group_1_f7_tbl" );
			CheckHook( S_group_1_fe_tbl[i], "S_group_1_fe_tbl" );
			CheckHook( S_group_1_ff_tbl[i], "S_group_1_ff_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_2_00_tbl[i], "S_group_2_00_tbl" );
			CheckHook( S_group_2_01_tbl[i], "S_group_2_01_tbl" );
		}

		for( i = 0; i < 9; i++ )
		{
			CheckHook( S_group_2_01_01_tbl[i], "S_group_2_01_01_tbl" );
			CheckHook( S_group_2_01_03_tbl[i], "S_group_2_01_03_tbl" );
			CheckHook( S_group_2_01_07_tbl[i], "S_group_2_01_07_tbl" );
		}

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_0d_tbl[i], "S_group_2_0d_tbl" );

		for( i = 0; i < 24; i++ )
			CheckHook( S_group_2_0f_tbl[i], "S_group_2_0f_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_10_tbl[i], "S_group_2_10_tbl" );
			CheckHook( S_group_2_11_tbl[i], "S_group_2_11_tbl" );
			CheckHook( S_group_2_12_tbl[i], "S_group_2_12_tbl" );
		}

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_12_00_tbl[i], "S_group_2_12_00_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_13_tbl[i], "S_group_2_13_tbl" );
			CheckHook( S_group_2_14_tbl[i], "S_group_2_14_tbl" );
			CheckHook( S_group_2_15_tbl[i], "S_group_2_15_tbl" );
			CheckHook( S_group_2_16_tbl[i], "S_group_2_16_tbl" );
		}

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_16_00_tbl[i], "S_group_2_16_00_tbl" );

		for( i = 0; i < 4; i++ )
			CheckHook( S_group_2_17_tbl[i], "S_group_2_17_tbl" );

		for( i = 0; i < 16; i++ )
			CheckHook( S_group_2_18_tbl[i], "S_group_2_18_tbl" );

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_24_tbl[i], "S_group_2_24_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_24_00_tbl[i], "S_group_2_24_00_tbl" );
			CheckHook( S_group_2_24_01_tbl[i], "S_group_2_24_01_tbl" );
			CheckHook( S_group_2_24_02_tbl[i], "S_group_2_24_02_tbl" );
			CheckHook( S_group_2_24_03_tbl[i], "S_group_2_24_03_tbl" );
			CheckHook( S_group_2_24_04_tbl[i], "S_group_2_24_04_tbl" );
		}

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_24_08_tbl[i], "S_group_2_24_08_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_24_08_00_tbl[i], "S_group_2_24_08_00_tbl" );
			CheckHook( S_group_2_24_08_01_tbl[i], "S_group_2_24_08_01_tbl" );
		}

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_24_09_tbl[i], "S_group_2_24_09_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_24_09_00_tbl[i], "S_group_2_24_09_00_tbl" );
			CheckHook( S_group_2_24_10_tbl[i], "S_group_2_24_10_tbl" );
			CheckHook( S_group_2_24_11_tbl[i], "S_group_2_24_11_tbl" );
			CheckHook( S_group_2_24_12_tbl[i], "S_group_2_24_12_tbl" );
			CheckHook( S_group_2_24_13_tbl[i], "S_group_2_24_13_tbl" );
			CheckHook( S_group_2_24_14_tbl[i], "S_group_2_24_14_tbl" );
			CheckHook( S_group_2_24_16_tbl[i], "S_group_2_24_16_tbl" );
		}

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_24_tbl[i], "S_group_2_25_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_25_05_tbl[i], "S_group_2_25_05_tbl" );
			CheckHook( S_group_2_25_09_tbl[i], "S_group_2_25_09_tbl" );
			CheckHook( S_group_2_25_0d_tbl[i], "S_group_2_25_0d_tbl" );
		}

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_28_tbl[i], "S_group_2_28_tbl" );
			CheckHook( S_group_2_29_tbl[i], "S_group_2_29_tbl" );
			CheckHook( S_group_2_2a_tbl[i], "S_group_2_2a_tbl" );
			CheckHook( S_group_2_2b_tbl[i], "S_group_2_2b_tbl" );
			CheckHook( S_group_2_2c_tbl[i], "S_group_2_2c_tbl" );
			CheckHook( S_group_2_2d_tbl[i], "S_group_2_2d_tbl" );
			CheckHook( S_group_2_2e_tbl[i], "S_group_2_2e_tbl" );
			CheckHook( S_group_2_2f_tbl[i], "S_group_2_2f_tbl" );
		}

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_38_tbl[i], "S_group_2_38_tbl" );

		for( i = 0; i < 2; i++ )
		{
			CheckHook( S_group_2_38_00_tbl[i], "S_group_2_38_00_tbl" );
			CheckHook( S_group_2_38_01_tbl[i], "S_group_2_38_01_tbl" );
			CheckHook( S_group_2_38_02_tbl[i], "S_group_2_38_02_tbl" );
			CheckHook( S_group_2_38_03_tbl[i], "S_group_2_38_03_tbl" );
			CheckHook( S_group_2_38_04_tbl[i], "S_group_2_38_04_tbl" );
			CheckHook( S_group_2_38_05_tbl[i], "S_group_2_38_05_tbl" );
			CheckHook( S_group_2_38_06_tbl[i], "S_group_2_38_06_tbl" );
			CheckHook( S_group_2_38_07_tbl[i], "S_group_2_38_07_tbl" );
			CheckHook( S_group_2_38_08_tbl[i], "S_group_2_38_08_tbl" );
			CheckHook( S_group_2_38_09_tbl[i], "S_group_2_38_09_tbl" );
			CheckHook( S_group_2_38_0a_tbl[i], "S_group_2_38_0a_tbl" );
			CheckHook( S_group_2_38_0b_tbl[i], "S_group_2_38_0b_tbl" );
			CheckHook( S_group_2_38_17_tbl[i], "S_group_2_38_17_tbl" );
			CheckHook( S_group_2_38_1c_tbl[i], "S_group_2_38_1c_tbl" );
			CheckHook( S_group_2_38_1d_tbl[i], "S_group_2_38_1d_tbl" );
			CheckHook( S_group_2_38_1e_tbl[i], "S_group_2_38_1e_tbl" );
		}

		for( i = 0; i < 16; i++ )
			CheckHook( S_group_2_3a_tbl[i], "S_group_2_3a_tbl" );

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_3a_0f_tbl[i], "S_group_2_3a_0f_tbl" );

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_3a_Type2_tbl[i], "S_group_2_3a_Type2_tbl" );

		for( i = 0; i < 4; i++ )
			CheckHook( S_group_2_3a_01_Type2_tbl[i], "S_group_2_3a_01_Type2_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_50_tbl[i], "S_group_2_50_tbl" );
			CheckHook( S_group_2_51_tbl[i], "S_group_2_51_tbl" );
			CheckHook( S_group_2_52_tbl[i], "S_group_2_52_tbl" );
			CheckHook( S_group_2_53_tbl[i], "S_group_2_53_tbl" );
			CheckHook( S_group_2_54_tbl[i], "S_group_2_54_tbl" );
			CheckHook( S_group_2_55_tbl[i], "S_group_2_55_tbl" );
			CheckHook( S_group_2_56_tbl[i], "S_group_2_56_tbl" );
			CheckHook( S_group_2_57_tbl[i], "S_group_2_57_tbl" );
			CheckHook( S_group_2_58_tbl[i], "S_group_2_58_tbl" );
			CheckHook( S_group_2_59_tbl[i], "S_group_2_59_tbl" );
			CheckHook( S_group_2_5a_tbl[i], "S_group_2_5a_tbl" );
			CheckHook( S_group_2_5b_tbl[i], "S_group_2_5b_tbl" );
			CheckHook( S_group_2_5c_tbl[i], "S_group_2_5c_tbl" );
			CheckHook( S_group_2_5d_tbl[i], "S_group_2_5d_tbl" );
			CheckHook( S_group_2_5e_tbl[i], "S_group_2_5e_tbl" );
			CheckHook( S_group_2_5f_tbl[i], "S_group_2_5f_tbl" );
			CheckHook( S_group_2_60_tbl[i], "S_group_2_60_tbl" );
			CheckHook( S_group_2_61_tbl[i], "S_group_2_61_tbl" );
			CheckHook( S_group_2_62_tbl[i], "S_group_2_62_tbl" );
			CheckHook( S_group_2_63_tbl[i], "S_group_2_63_tbl" );
			CheckHook( S_group_2_64_tbl[i], "S_group_2_64_tbl" );
			CheckHook( S_group_2_65_tbl[i], "S_group_2_65_tbl" );
			CheckHook( S_group_2_66_tbl[i], "S_group_2_66_tbl" );
			CheckHook( S_group_2_67_tbl[i], "S_group_2_67_tbl" );
			CheckHook( S_group_2_68_tbl[i], "S_group_2_68_tbl" );
			CheckHook( S_group_2_69_tbl[i], "S_group_2_69_tbl" );
			CheckHook( S_group_2_6a_tbl[i], "S_group_2_6a_tbl" );
			CheckHook( S_group_2_6b_tbl[i], "S_group_2_6b_tbl" );
			CheckHook( S_group_2_6c_tbl[i], "S_group_2_6c_tbl" );
			CheckHook( S_group_2_6d_tbl[i], "S_group_2_6d_tbl" );
			CheckHook( S_group_2_6e_tbl[i], "S_group_2_6e_tbl" );
			CheckHook( S_group_2_6f_tbl[i], "S_group_2_6f_tbl" );
			CheckHook( S_group_2_70_tbl[i], "S_group_2_70_tbl" );
		}

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_2_71_tbl[i], "S_group_2_71_tbl" );
			CheckHook( S_group_2_72_tbl[i], "S_group_2_72_tbl" );
			CheckHook( S_group_2_73_tbl[i], "S_group_2_73_tbl" );
		}

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_71_02_tbl[i], "S_group_2_71_02_tbl" );
			CheckHook( S_group_2_71_04_tbl[i], "S_group_2_71_04_tbl" );
			CheckHook( S_group_2_71_06_tbl[i], "S_group_2_71_06_tbl" );
			CheckHook( S_group_2_72_02_tbl[i], "S_group_2_72_02_tbl" );
			CheckHook( S_group_2_72_04_tbl[i], "S_group_2_72_04_tbl" );
			CheckHook( S_group_2_72_06_tbl[i], "S_group_2_72_06_tbl" );
			CheckHook( S_group_2_73_02_tbl[i], "S_group_2_73_02_tbl" );
			CheckHook( S_group_2_73_03_tbl[i], "S_group_2_73_03_tbl" );
			CheckHook( S_group_2_73_06_tbl[i], "S_group_2_73_06_tbl" );
			CheckHook( S_group_2_73_07_tbl[i], "S_group_2_73_07_tbl" );
		}

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_74_tbl[i], "S_group_2_74_tbl" );
			CheckHook( S_group_2_75_tbl[i], "S_group_2_75_tbl" );
			CheckHook( S_group_2_76_tbl[i], "S_group_2_76_tbl" );
			CheckHook( S_group_2_78_tbl[i], "S_group_2_78_tbl" );
			CheckHook( S_group_2_79_tbl[i], "S_group_2_79_tbl" );
		}

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_7a_tbl[i], "S_group_2_7a_tbl" );

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_7a_02_tbl[i], "S_group_2_7a_02_tbl" );

		for( i = 0; i < 4; i++ )
			CheckHook( S_group_2_7a_02_00_tbl[i], "S_group_2_7a_02_00_tbl" );

		for( i = 0; i < 8; i++ )
		{
			CheckHook( S_group_2_7a_06_tbl[i], "S_group_2_7a_06_tbl" );
			CheckHook( S_group_2_7a_08_tbl[i], "S_group_2_7a_08_tbl" );
			CheckHook( S_group_2_7a_09_tbl[i], "S_group_2_7a_09_tbl" );
			CheckHook( S_group_2_7a_0a_tbl[i], "S_group_2_7a_0a_tbl" );
			CheckHook( S_group_2_7a_0b_tbl[i], "S_group_2_7a_0b_tbl" );
			CheckHook( S_group_2_7a_0c_tbl[i], "S_group_2_7a_0c_tbl" );
		}

		for( i = 0; i < 32; i++ )
			CheckHook( S_group_2_7b_tbl[i], "S_group_2_7b_tbl" );

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_7b_08_tbl[i], "S_group_2_7b_08_tbl" );

		for( i = 0; i < 4; i++ )
			CheckHook( S_group_2_7b_08_00_tbl[i], "S_group_2_7b_08_00_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_7c_tbl[i], "S_group_2_7c_tbl" );
			CheckHook( S_group_2_7d_tbl[i], "S_group_2_7d_tbl" );
			CheckHook( S_group_2_7e_tbl[i], "S_group_2_7e_tbl" );
			CheckHook( S_group_2_7f_tbl[i], "S_group_2_7f_tbl" );
		}

		for( i = 0; i < 16; i++ )
			CheckHook( S_group_2_ae_tbl[i], "S_group_2_ae_tbl" );

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_b8_tbl[i], "S_group_2_b8_tbl" );

		for( i = 0; i < 8; i++ )
			CheckHook( S_group_2_ba_tbl[i], "S_group_2_ba_tbl" );

		for( i = 0; i < 2; i++ )
			CheckHook( S_group_2_bd_tbl[i], "S_group_2_bd_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_c2_tbl[i], "S_group_2_c2_tbl" );
			CheckHook( S_group_2_c4_tbl[i], "S_group_2_c4_tbl" );
			CheckHook( S_group_2_c5_tbl[i], "S_group_2_c5_tbl" );
			CheckHook( S_group_2_c6_tbl[i], "S_group_2_c6_tbl" );
		}

		for( i = 0; i < 8; i++ )
			CheckHook( S_group_2_c7_tbl[i], "S_group_2_c7_tbl" );

		for( i = 0; i < 4; i++ )
		{
			CheckHook( S_group_2_d0_tbl[i], "S_group_2_d0_tbl" );
			CheckHook( S_group_2_d1_tbl[i], "S_group_2_d1_tbl" );
			CheckHook( S_group_2_d2_tbl[i], "S_group_2_d2_tbl" );
			CheckHook( S_group_2_d3_tbl[i], "S_group_2_d3_tbl" );
			CheckHook( S_group_2_d4_tbl[i], "S_group_2_d4_tbl" );
			CheckHook( S_group_2_d5_tbl[i], "S_group_2_d5_tbl" );
			CheckHook( S_group_2_d6_tbl[i], "S_group_2_d6_tbl" );
			CheckHook( S_group_2_d7_tbl[i], "S_group_2_d7_tbl" );
			CheckHook( S_group_2_d8_tbl[i], "S_group_2_d8_tbl" );
			CheckHook( S_group_2_d9_tbl[i], "S_group_2_d9_tbl" );
			CheckHook( S_group_2_da_tbl[i], "S_group_2_da_tbl" );
			CheckHook( S_group_2_db_tbl[i], "S_group_2_db_tbl" );
			CheckHook( S_group_2_dc_tbl[i], "S_group_2_dc_tbl" );
			CheckHook( S_group_2_dd_tbl[i], "S_group_2_dd_tbl" );
			CheckHook( S_group_2_de_tbl[i], "S_group_2_de_tbl" );
			CheckHook( S_group_2_df_tbl[i], "S_group_2_df_tbl" );
			CheckHook( S_group_2_e0_tbl[i], "S_group_2_e0_tbl" );
			CheckHook( S_group_2_e1_tbl[i], "S_group_2_e1_tbl" );
			CheckHook( S_group_2_e2_tbl[i], "S_group_2_e2_tbl" );
			CheckHook( S_group_2_e3_tbl[i], "S_group_2_e3_tbl" );
			CheckHook( S_group_2_e4_tbl[i], "S_group_2_e4_tbl" );
			CheckHook( S_group_2_e5_tbl[i], "S_group_2_e5_tbl" );
			CheckHook( S_group_2_e6_tbl[i], "S_group_2_e6_tbl" );
			CheckHook( S_group_2_e7_tbl[i], "S_group_2_e7_tbl" );
			CheckHook( S_group_2_e8_tbl[i], "S_group_2_e8_tbl" );
			CheckHook( S_group_2_e9_tbl[i], "S_group_2_e9_tbl" );
			CheckHook( S_group_2_ea_tbl[i], "S_group_2_ea_tbl" );
			CheckHook( S_group_2_eb_tbl[i], "S_group_2_eb_tbl" );
			CheckHook( S_group_2_ec_tbl[i], "S_group_2_ec_tbl" );
			CheckHook( S_group_2_ed_tbl[i], "S_group_2_ed_tbl" );
			CheckHook( S_group_2_ee_tbl[i], "S_group_2_ee_tbl" );
			CheckHook( S_group_2_ef_tbl[i], "S_group_2_ef_tbl" );
			CheckHook( S_group_2_f0_tbl[i], "S_group_2_f0_tbl" );
			CheckHook( S_group_2_f1_tbl[i], "S_group_2_f1_tbl" );
			CheckHook( S_group_2_f2_tbl[i], "S_group_2_f2_tbl" );
			CheckHook( S_group_2_f3_tbl[i], "S_group_2_f3_tbl" );
			CheckHook( S_group_2_f4_tbl[i], "S_group_2_f4_tbl" );
			CheckHook( S_group_2_f5_tbl[i], "S_group_2_f5_tbl" );
			CheckHook( S_group_2_f6_tbl[i], "S_group_2_f6_tbl" );
			CheckHook( S_group_2_f7_tbl[i], "S_group_2_f7_tbl" );
			CheckHook( S_group_2_f8_tbl[i], "S_group_2_f8_tbl" );
			CheckHook( S_group_2_f9_tbl[i], "S_group_2_f9_tbl" );
			CheckHook( S_group_2_fa_tbl[i], "S_group_2_fa_tbl" );
			CheckHook( S_group_2_fb_tbl[i], "S_group_2_fb_tbl" );
			CheckHook( S_group_2_fc_tbl[i], "S_group_2_fc_tbl" );
			CheckHook( S_group_2_fd_tbl[i], "S_group_2_fd_tbl" );
			CheckHook( S_group_2_fe_tbl[i], "S_group_2_fe_tbl" );
		}

		return true;
	}
	catch( CTableException exc )
	{
		fprintf( stderr, "CTableException: bad table '%s'\n", exc.GetTablename() );
		return false;
	}
}
//////////////////////////////////////////////////////////
#ifdef _DEBUG
char *CInstructionData::OperandSizeString( e_OperandSize size )
{
	static char *operandSizeStrings [] =
	{
		"8",
		"16",
		"32",
		"48",
		"64",
		"80",
		"128",
		"NO SIZE"
	};

	return operandSizeStrings[size];
}

char *CInstructionData::OperandTypeString( e_OperandType type )
{
	static char *operandTypeStrings [] =
	{
		"REGISTER",
		"IMMEDIATE",
		"PCOFFSET",
		"MEMORY",
		"RIPRELATIVE",
		"NONE"
	};

	return operandTypeStrings[type];
}

char *CInstructionData::RegisterString( e_Registers reg )
{
	static char *registerStrings [] =
	{
		"REG_EAX",
		"REG_ECX",
		"REG_EDX",
		"REG_EBX",
		"REG_ESP",
		"REG_EBP",
		"REG_ESI",
		"REG_EDI",
		"REG_R8",
		"REG_R9",
		"REG_R10",
		"REG_R11",
		"REG_R12",
		"REG_R13",
		"REG_R14",
		"REG_R15",

		"REG_ST0",
		"REG_ST1",
		"REG_ST2",
		"REG_ST3",
		"REG_ST4",
		"REG_ST5",
		"REG_ST6",
		"REG_ST7",
		"REG_ST",

		"REG_MM0",
		"REG_MM1",
		"REG_MM2",
		"REG_MM3",
		"REG_MM4",
		"REG_MM5",
		"REG_MM6",
		"REG_MM7",

		"REG_XMM0",
		"REG_XMM1",
		"REG_XMM2",
		"REG_XMM3",
		"REG_XMM4",
		"REG_XMM5",
		"REG_XMM6",
		"REG_XMM7",
		"REG_XMM8",
		"REG_XMM9",
		"REG_XMM10",
		"REG_XMM11",
		"REG_XMM12",
		"REG_XMM13",
		"REG_XMM14",
		"REG_XMM15",

		"REG_CR0",
		"REG_CR1",
		"REG_CR2",
		"REG_CR3",
		"REG_CR4",
		"REG_CR5",
		"REG_CR6",
		"REG_CR7",
		"REG_CR8",
		"REG_CR9",
		"REG_CR10",
		"REG_CR11",
		"REG_CR12",
		"REG_CR13",
		"REG_CR14",
		"REG_CR15",

		"REG_DR0",
		"REG_DR1",
		"REG_DR2",
		"REG_DR3",
		"REG_DR4",
		"REG_DR5",
		"REG_DR6",
		"REG_DR7",
		"REG_DR8",
		"REG_DR9",
		"REG_DR10",
		"REG_DR11",
		"REG_DR12",
		"REG_DR13",
		"REG_DR14",
		"REG_DR15",

		"REG_ES",
		"REG_CS",
		"REG_SS",
		"REG_DS",
		"REG_FS",
		"REG_GS"
	};

	return registerStrings[reg];
}

void CInstructionData::ShowOperands()
{
	int numOperands = GetNumOperands();
	for( int i = 0; i < numOperands; i++ )
	{
		e_OperandType opType = GetOperandType( i );

		printf( "Operand%d(%s): ", (i + 1), OperandTypeString( opType ) );

		switch( opType )
		{
			case OPERANDTYPE_REGISTER:
				printf( "Size(%s) ", OperandSizeString( GetOperandSize( i ) ) );
				printf( "Register(%s) ", RegisterString( GetRegister( i ) ) );
				printf( "\n" );
				break;

			case OPERANDTYPE_IMMEDIATE:
				printf( "Size(%s) ", OperandSizeString( GetOperandSize( i ) ) );
				if( HasImmediate() )
					printf( "Immediate(%llx) ", GetImmediate() );
				else
					printf( "Error: OPERANDTYPE == IMMEDIATE but HasImmediate() returns false" );
				printf( "\n" );
				break;

			case OPERANDTYPE_PCOFFSET:
				printf( "Size(%s) ", OperandSizeString( GetOperandSize( i ) ) );
				if( HasDisplacement() )
					printf( "Displacement(%llx) ", GetDisplacement() );
				else
					printf( "Error: OPERANDTYPE == PCOFFSET but HasDisplacement() returns false" );
				printf( "\n" );
				break;

			case OPERANDTYPE_MEMORY:
				printf( "Size(%s) ", OperandSizeString( GetOperandSize( i ) ) );
				if( HasModrm() )
				{
					printf( "Modrm(%02x) ", GetModrm() );

					if( HasSib() )
					{
						printf( "SIB(true) " );
						if( HasScale() )
							printf( "Scale(%d) ", GetSibScale() );
					}

					if( HasDrex() )
						printf( "Drex(%02x) ", GetDrex() );

					if( HasBase() )
						printf( "Base(%s) ", RegisterString( GetBaseRegister() ) );

					if( HasIndex() )
						printf( "Index(%s) ", RegisterString( GetIndexRegister() ) );

					if( HasDisplacement() )
						printf( "Displacement(%llx) ", GetDisplacement() );
				}
				else if( HasImmediate() )
					printf( "Offset(%llx) ", GetImmediate() );
				else if( OperandHasIndex( i ) )
					printf( "Index(%s) ", RegisterString( GetOperandIndexRegister( i ) ) );
				else
					printf( "Error: OPERANDTYPE == MEMORY but HasModrm(), HasIndex(), and HasImmediate() returns false" );

				printf( "\n" );
				break;

			case OPERANDTYPE_RIPRELATIVE:
				printf( "Size(%s) ", OperandSizeString( GetOperandSize( i ) ) );
				if( HasDisplacement() )
					printf( "Displacement(%llx) ", GetDisplacement() );
				else
					printf( "Error: OPERANDTYPE == RIPRELATIVE but HasDisplacement() returns false" );
				printf( "\n" );
				break;
			default:
				break;
		}
	}
}

void CInstructionData::ShowOpcodes()
{
	for( int i = 0; i < m_numOpcodes; i++ )
	{
		if( i > 0 ) printf( ", " );
		printf( "Opcode%d(%02x), Offset(%02d)", i, GetOpcode( i ), GetOpcodeOffset( i ) );
	}
	printf( "\n" );
}

#ifdef DISASSEMBLER_STANDALONE
void main( void )
{
	CDisassembler disassembler;

	unsigned count = 0;
	char line[256];
	while( gets( line ) )
	{
		count++;

		AMD_UINT8 instBuf[16];
		int len = 0;
		char *ptr = line;

#ifdef CONVEY_RIP
		AMD_UINT64 rip = strtoul( ptr, &ptr, 16 );
#endif

		while( *ptr != '\0' )
			instBuf[len++] = strtoul( ptr, &ptr, 16 );

		disassembler.SetDbit( instBuf[len-2] );
		disassembler.SetLongMode( instBuf[len-1] );

#ifdef CONVEY_RIP
		if( disassembler.Disassemble( instBuf, rip ) != NULL )
#else
		if( disassembler.Disassemble( instBuf ) != NULL )
#endif
			printf( "%s\n", disassembler.GetMnemonic() );
		else
			printf( "%08d: Unable to disassemble\n", count );
	}
}
#endif
#endif

#if 0
PVOIDMEMBERFUNC CTestDisassembler::S_EncodeOperandFnPtrs[] =
{
	/* OPRND_na	*/		NULL,
	/* OPRND_1	*/		NULL,
	/* OPRND_AL	*/		NULL,
	/* OPRND_AX	*/		NULL,
	/* OPRND_eAX */		NULL,
	/* OPRND_Ap	*/		&CTestDisassembler::EncodeDwordOrFwordDirect,
	/* OPRND_CL	*/		NULL,
	/* OPRND_Cd	*/		&CTestDisassembler::EncodeControlRegister,
	/* OPRND_Dd	*/		&CTestDisassembler::EncodeDebugRegister,
	/* OPRND_DX	*/		NULL,
	/* OPRND_eDX */		NULL,
	/* OPRND_Eb	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Ew	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Ed	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Ev	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Ep	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Mt	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Gb	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Gw	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Gd	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Gq	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Gv	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Ib	*/		&CTestDisassembler::EncodeImmediateByte,
	/* OPRND_Iv	*/		&CTestDisassembler::EncodeWordOrDwordImmediate,
	/* OPRND_Iw	*/		&CTestDisassembler::EncodeImmediateWord,
	/* OPRND_Jb	*/		&CTestDisassembler::EncodeByteJump,
	/* OPRND_Jv	*/		&CTestDisassembler::EncodeWordOrDwordJump,
	/* OPRND_M	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Mp	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Mq	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Ms	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Ob	*/		&CTestDisassembler::EncodeOffset,
	/* OPRND_Ov	*/		&CTestDisassembler::EncodeOffset,
	/* OPRND_Pq	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Pd	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Qq	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Rd	*/		&CTestDisassembler::EncodeModrmRm,
	/* OPRND_Sw	*/		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Xb	*/		NULL,
	/* OPRND_Xv	*/		NULL,
	/* OPRND_Yb	*/		NULL,
	/* OPRND_Yv	*/		NULL,
	/* OPRND_breg */	&CTestDisassembler::EncodeByteRegFromOpcode,
	/* OPRND_vreg */	&CTestDisassembler::EncodeModrmRm,
	/* OPRND_ST	*/		&CTestDisassembler::EncodeSTReg,
	/* OPRND_ST0 */		&CTestDisassembler::EncodeST0Reg,
	/* OPRND_ST1 */		&CTestDisassembler::EncodeST1Reg,
	/* OPRND_ST2 */		&CTestDisassembler::EncodeST2Reg,
	/* OPRND_ST3 */		&CTestDisassembler::EncodeST3Reg,
	/* OPRND_ST4 */		&CTestDisassembler::EncodeST4Reg,
	/* OPRND_ST5 */		&CTestDisassembler::EncodeST5Reg,
	/* OPRND_ST6 */		&CTestDisassembler::EncodeST6Reg,
	/* OPRND_ST7 */		&CTestDisassembler::EncodeST7Reg,
	/* OPRND_Vps */		&CTestDisassembler::EncodeSimdOwordReg,
	/* OPRND_Vq	*/		&CTestDisassembler::EncodeSimdQwordReg,
	/* OPRND_Vss */		&CTestDisassembler::EncodeSimdDwordReg,
	/* OPRND_Wps */		&CTestDisassembler::EncodeModrm,
	/* OPRND_Wq	*/		&CTestDisassembler::EncodeModrm,
	/* OPRND_Wss */		&CTestDisassembler::EncodeModrm,
	/* OPRND_Vpd */		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Wpd */		&CTestDisassembler::EncodeModrm,
	/* OPRND_Vsd */		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Wsd */		&CTestDisassembler::EncodeModrm,
	/* OPRND_Vdq */		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_Wdq */		&CTestDisassembler::EncodeModrm,
	/* OPRND_Vd */		&CTestDisassembler::EncodeModrmReg,
	/* OPRND_FPU_AX */	&CTestDisassembler::EncodeFpuAx,
	/* OPRND_Mw	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Md	*/		&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Iv64 */	&CTestDisassembler::EncodeWDQImmediate,
	/* OPRND_eBXAl */	NULL,
	/* OPRND_Ed_q */	&CTestDisassembler::EncodeDQModrm,
	/* OPRND_Pd_q */	&CTestDisassembler::EncodeMMXDQwordReg,
	/* OPRND_Vd_q */	&CTestDisassembler::EncodeSimdDQwordReg,
	/* OPRND_Gd_q */	&CTestDisassembler::EncodeDQRegFromReg,
	/* OPRND_Md_q */	&CTestDisassembler::EncodeMemoryModrm,
	/* OPRND_Ew_v */	&CTestDisassembler::EncodeWordMemoryOrWDQRegModrm,
	/* OPRND_Mq_dq */	&CTestDisassembler::EncodeMemoryModrm,
}

class CEncodedBytes
{
	list <UINT8> m_Bytes;

public:
	CEncodedBytes( UINT8 * pByte, ... )
	{
		va_list pArg;
		va_start( pArg, pByte );
		m_Bytes.push_back( pByte, pArg );
		va_end( pArg );
	}
};

list <CEncodeBytes> m_EncodedOperandBytes;
static list <CEncodedBytes> m_EncodedMemoryModrmBytes[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedRegisterModrmBytes[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedImmediateBytes[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedImmediateWords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedImmediateDwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedImmediateFwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedImmediateQwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedOffsetBytes[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedOffsetWords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedOffsetDwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedOffsetQwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedDisplacementBytes[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedDisplacementWords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedDisplacementDwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

static list <CEncodedBytes> m_EncodedDisplacementQwords[] =
{
	CEncodedBytes( 0xf8 ),
	CEncodedBytes( 0xC0, 0xFE, 0xED, 0xFA, 0xCE ),
};

void CTestDisassembler::EncodeMemoryModrm()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedMemoryModrmBytes.begin();
	while( extract != m_EncodedMemoryModrmBytes.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeRegisterModrm()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedRegisterModrmBytes.begin();
	while( extract != m_EncodedRegisterModrmBytes.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeModrm()
{
	if( m_pOperand->flags & OPF_REGISTER )
		EncodeRegisterModrm();
	else if( m_pOperand->flags & OPF_MEMORY )
		EncodeMemoryModrm();
	else
	{
		EncodeRegisterModrm();
		EncodeMemoryModrm();
	}
}

void CTestDisassembler::EncodeImmediateByte()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedImmediateBytes.begin();
	while( extract != m_EncodedImmediateBytes.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeImmediateWord()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedImmediateWords.begin();
	while( extract != m_EncodedImmediateWords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeImmediateDword()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedImmediateDwords.begin();
	while( extract != m_EncodedImmediateDwords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeImmediateFword()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedImmediateFwords.begin();
	while( extract != m_EncodedImmediateFwords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeImmediateQword()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedImmediateQwords.begin();
	while( extract != m_EncodedImmediateQwords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeDisplacementByte()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedDisplacementBytes.begin();
	while( extract != m_EncodedDisplacementBytes.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeDisplacementWord()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedDisplacementWords.begin();
	while( extract != m_EncodedDisplacementWords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeDisplacementDword()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedDisplacementDwords.begin();
	while( extract != m_EncodedDisplacementDwords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeDisplacementQword()
{
	insert_iterator <list <CEncodedBytes>> insert( m_EncodedOperandBytes, m_EncodedOperandBytes.end() );
	std::list <CEncodedBytes>::iterator extract = m_EncodedDisplacementQwords.begin();
	while( extract != m_EncodedDisplacementQwords.end() )
		*insert++ = *extract++;
}

void CTestDisassembler::EncodeWordOrDwordImmediate()
{
	if( m_inst_flags & (INST_DATA32 | INST_DATA64) )
		EncodeImmediateDword();
	else
		EncodeImmediateWord;
}

void CTestDisassembler::EncodeWDQImmediate()
{
	if( m_inst_flags & INST_DATA64 )
		EncodeImmediateQword();
	else if( m_inst_flags & INST_DATA32 )
		EncodeImmediateDword();
	else
		EncodeImmediateWord;
}

void CTestDisassembler::EncodeByteJump()
{
	EncodeOffsetByte();
}

void CTestDisassembler::EncodeWordOrDwordJump()
{
	if( m_inst_flags & (INST_DATA32 | INST_DATA64) )
		EncodeOffsetDword();
	else
		EncodeOffsetWord();
}

void CTestDisassembler::EncodeFpuAx()
{
	EncodeModrm();
}

void CTestDisassembler::EncodeDwordOrFwordDirect()
{
	(m_pOperand->size == OPERANDSIZE_48) ? EncodeImmediateFword() : EncodeImmediateDword();
}

void CTestDisassembler::EncodeOffset()
{
	if( m_inst_flags & INST_ADDR64 )
		EncodeImmediateQword();
	else if( m_inst_flags & INST_ADDR32 )
		EncodeImmediateDword();
	else
		EncodeImmediateWord();
}

void CTestDisassembler::SetMMXDwordReg()
{
	EncodeModrmRegByte();
}

void CTestDisassembler::EncodeMMXQwordReg()
{
	EncodeModrmRegByte();
}

void CTestDisassembler::EncodeMMXDQwordReg()
{
	EncodeModrmRegByte();
}

void CTestDisassembler::EncodeMMXQwordModrm()
{
	if( m_pOperand->flags & OPF_REGISTER )
		EncodeRegisterModrm();
	else if( m_pOperand->flags & OPF_MEMORY )
		EncodeMemoryModrm();
	else
		EncodeModrm();
}

// this is for the Control Registers and Debug Registers
void CTestDisassembler::EncodeDwordOrQwordReg()
{
	EncodeModrmRm();
}

void CTestDisassembler::EncodeDebugRegister()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeControlRegister()
{
	EncodeModrmReg();

	if( IsSvmMode() && IsLastEncodedPrefix( PREFIX_LOCK ) )
	{
		// convert the LOCK prefix from a prefix byte to an opcode byte
		RemoveLastEncodedPrefix();
	}
}

void CTestDisassembler::EncodeWordSegmentRegister()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeST0Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST1Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST2Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST3Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST4Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST5Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST6Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeST7Reg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeSTReg()
{
	EncodeFpuModrm();
}

void CTestDisassembler::EncodeSimdReg()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeSimdDwordReg()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeSimdQwordReg()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeSimdDQwordReg()
{
	EncodeModrmReg();
}

void CTestDisassembler::EncodeSimdOwordReg()
{
	EncodeModrmReg();
}
 
void CTestDisassembler::EncodeSimdDwordModrm()
{
	EncodeModrm();
}
 
void CTestDisassembler::EncodeSimdQwordModrm()
{
	EncodeModrm();
}
 
void CTestDisassembler::EncodeSimdOwordModrm()
{
	EncodeModrm();
}


void CTestDisassembler::EncodeWordMemoryOrWDQRegModrm()
{
	EncodeModrm();
}

void CTestDisassembler::EncodeFmacOpcodeOperand()
{
	EncodeFmacOpcodeOperand();	// last two opcode bytes at the end
}

void CTestDisassembler::EncodeInstructionBytes()
{
	for( i = 0; i < NUM_PREFIX_BYTES; i++ )
	{
		if( (m_TestPrefixFlags & (1 << 1)) != 0 )
			EncodePrefixByte( m_TestPrefixBytes[i] );

		cout << opcode;

		switch( operandBytes )
		{
		}
	}
}

void CTestDisassembler::EncodeInstructions()
{
	int opcode;

	// first do one opcode byte instructions
	for( opcode = 0; opcode < 256; opcode++ )
	{
		m_opcode_table_ptr = &S_oneByteOpcodes_tbl[opcode];
		while( m_opcode_table_ptr->GetInfoPtr != NULL )
		{
			Inst_Info *(*pIndexRoutine)(CDisassembler *pThis) = m_opcode_table_ptr->GetInfoPtr;

//			if( pIndexRoutine == GetSSEIndex )
//				HandleExtraPrefixOpcode();
//			else if( pIndexRoutine == GetNopXchgPauseIndex )
//				HandleExtraRepOpcode();

			if( (m_opcode_table_ptr = (pIndexRoutine)( this )) == NULL )
				break;
		}

		// EncodePrefixBytes();
		// EncodeOperandBytes();
		// GenerateInstructionsBytes();
	}
}
#endif

