
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "stdafx.h"
#include "ViewConfigAPI.h"

//this static function will calculate a number, based on the predefined 
//      complex relationship.  Currently, only +, -, *, and \ are allowed between 
//      two basic values
//the complexcomponent defines the relationship and holds the indexes into the
//      data given.
//Note that to make the values more meaningful, the raw data has been 
//      normalized to a per-group/count value
float ViewShownData::setComplex (ComplexComponents *pComplex, DataArray *pData)
{
        float calc = 0;
        float normOp1 = (*pData)[pComplex->op1Index] * pComplex->op1NormValue;
        float normOp2 = (*pData)[pComplex->op2Index] * pComplex->op2NormValue;
        switch (pComplex->complexType)
        {
        case ColumnRatio:
                if (0 != normOp2)
                {
                        calc = normOp1 / normOp2;
                }
                break;
        case ColumnSum:
                calc = normOp1 + normOp2;
                break;
        case ColumnDifference:
                calc = normOp1 - normOp2;
                break;
        case ColumnProduct:
                calc = normOp1 * normOp2;
                break;
        default:
                break;
        }
        return calc;
}

