
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdlib.h>
#include <time.h>

#include <qworkspace.h>
#include <qmessagebox.h>
#include "DiffSession.h"
#include "qdatetime.h"
#include "DiffAnalystWindow.h"

#define _DIFFANALYST_ICONS_
#include "../gui/xpm.h"
#undef  _DIFFANALYST_ICONS_

#define DA_DEBUG 0

#if DA_DEBUG 

	#define TIMER_START(s)	\
	fprintf(stderr,"TIMER START: %s : %s\n",s, ((QTime::currentTime()).toString()).data());

	#define TIMER_STOP(s)	\
		fprintf(stderr,"TIMER STOP: %s = %s\n",s,((QTime::currentTime()).toString()).data());
#else
	#define TIMER_START(s)
	#define TIMER_STOP(s)

#endif


//--------------------------------------------------------------

DiffSession:: DiffSession(QWidget * parent, 
			const char * name, 
			WFlags f)
: QMainWindow(parent, name, f)
{
	m_pSymbolLV = NULL;
	m_numDiff = 0;
	setDockMenuEnabled (false);
	m_pDiffViewShown = NULL;
	m_aggregateInline = false;
	m_pDiffAnalystWindow = (DiffAnalystWindow*) parentWidget()->parentWidget()
				->parentWidget()->parentWidget();
	for(int i=0 ; i<MAX_NUM_DIFF ; i++)
	{
		m_pTbsReader[i] = NULL;
		m_taskId[i]	= 0;
		m_alreadyCheckedTime[i] = false;
	}

	setIcon(QPixmap(amdArrowLogo));
	setDockMenuEnabled(false);
}

DiffSession::~DiffSession()
{

	if(m_pSymbolLV !=NULL)
	{
		delete m_pSymbolLV;
		m_pSymbolLV = NULL;
	}

	for(int i=0 ; i<MAX_NUM_DIFF ; i++)
	{
		if(m_pTbsReader[i] != NULL)
		{
			delete m_pTbsReader[i];
			m_pTbsReader[i] = NULL;
		}
	}
}

bool DiffSession::init(SESSION_DIFF_INFO_VEC &diffInfoVec)
{
	bool ret = false;

	// Setup caption
	setCaption(QString("Diff Session : ")+name());

	initViewToolBar();

	m_diffInfoVec = diffInfoVec;
	m_numDiff = m_diffInfoVec.size();

	// For each profile to diff,
	for(unsigned int i=0 ; i<m_numDiff ; i++)
	{
		TIMER_START("Read EBP");
		// Get samples and store them in TaskSampleMap
		if (!getInfoFromEbpFile( &(m_taskSampleMap[i]), 
					m_diffInfoVec[i].sessionFile,
					m_diffInfoVec[i].task,
					m_diffInfoVec[i].module, i)) 
		{
			return ret;
		}
		TIMER_STOP("Read EBP");

		// By this time we need to have the column list ready
		if (!aggregateSamplesForModule( i,
					&(m_taskSampleMap[i]),
					m_diffInfoVec[i].module))
		{
			QMessageBox::critical(this,"DiffAnalyst Error",
				QString("Cannot aggregate samples for module\n\n\"")
				+ m_diffInfoVec[i].module + "\".\n\n"
				+ "The file's symbol table might be corrupted or have changed.\n"
				+ "Please rerun profile\n");
			return ret;
		}
	}

	// Populate Symbol View
	populateDataToSymbolView();

	ret = true;
	return ret;
} // init(SESSION_DIFF_INFO_VEC &diffInfoVec)

bool DiffSession::initViewToolBar()
{
	QIconSet icon;
	bool ret=false;
	
	// ////////////////////////////////////////////////////////////////////
	// SYMBOLVIEW TOOLBAR
	m_pSymViewToolbar = new QToolBar (this, "Symbol View Toolbar");
	if(m_pSymViewToolbar == NULL) return false;
	m_pSymViewToolbar->boxLayout()->setSpacing(5);

	QPushButton *pPushBtn;
	
	icon = QIconSet (QPixmap((const char**)LeftRightIcon));
	m_pToolId [DiffSession::TM_LEFTRIGHT] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_LEFTRIGHT] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	
	//Set default value
	m_pToolId [DiffSession::TM_LEFTRIGHT]->setOn(true);
	m_diffViewOptions.showLeftRight  = true;

	connect(pPushBtn,SIGNAL(clicked()), this,SLOT(onClickedLeftRight()));
	QToolTip::add(pPushBtn,QString("Show Column Left-Right"));

	icon = QIconSet (QPixmap((const char**)SideBySideIcon));
	m_pToolId [DiffSession::TM_SIDEBYSIDE] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_SIDEBYSIDE] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	connect(pPushBtn,SIGNAL(clicked()), this,SLOT(onClickedSideBySide()));
	QToolTip::add(pPushBtn,QString("Show Column Side-by-side"));

	icon = QIconSet (QPixmap((const char**)DeltaIcon));
	m_pToolId [DiffSession::TM_DELTA] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_DELTA] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	connect(pPushBtn,SIGNAL(clicked()), this,SLOT(onClickedDelta()));
	QToolTip::add(pPushBtn,QString("Show Column Delta"));

	m_pSymViewToolbar->addSeparator();

	icon = QIconSet (QPixmap((const char**)SeparateCpuIcon));
	m_pToolId [DiffSession::TM_SEPARATECPU] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_SEPARATECPU] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	connect(pPushBtn,SIGNAL(toggled(bool)), this,SLOT(onSeparateCpu(bool)));
	QToolTip::add(pPushBtn,QString("Toggle Separate Cpu "));

	icon = QIconSet (QPixmap((const char**)percentIcon));
	m_pToolId [DiffSession::TM_PERCENT] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_PERCENT] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	connect(pPushBtn,SIGNAL(toggled(bool)), this,SLOT(onTogglePercent(bool)));
	QToolTip::add(pPushBtn,QString("Toggle Raw Data / Percent"));

	icon = QIconSet (QPixmap((const char**)InlineInstanceIcon));
	m_pToolId [DiffSession::TM_INLINE] =  new QPushButton( icon,QString("") , m_pSymViewToolbar);
	pPushBtn = m_pToolId [DiffSession::TM_INLINE] ;
	pPushBtn->setMaximumHeight(20);
	pPushBtn->setMaximumWidth(20);
	pPushBtn->setToggleButton(true);
	connect(pPushBtn,SIGNAL(toggled(bool)), this,SLOT(onAggregateInline(bool)));
	QToolTip::add(pPushBtn,QString("Toggle Aggregate In-line Function"));

	ret = true;
	return ret;
}

bool DiffSession::initViewCfg(unsigned int diffIndex)
{
	bool ret = false;
	unsigned long cpuFamily = m_pTbsReader[diffIndex]->getCpuFamily();
	unsigned long model = m_pTbsReader[diffIndex]->getCpuModel();

	if((m_diffInfoVec[diffIndex]).pViewCollection != NULL)
	{
		(m_diffInfoVec[diffIndex]).pViewCollection->removeAllView();

		(m_diffInfoVec[diffIndex]).pViewCollection->addAllDataView (
							(m_diffInfoVec[diffIndex]).pEvArray, 
							(m_diffInfoVec[diffIndex]).evCount, 
							cpuFamily,model);
	}else {

		(m_diffInfoVec[diffIndex]).pViewCollection = new ViewCollection();
	
		//*********************************************************
		QValueList<unsigned long long> tempEv;

		// Get list of event from TBP files
		// Note: In TBP version 6, these events are 64-bit Event+UMask encoded.
		tempEv = m_pTbsReader[diffIndex]->getEventList ();

		// Change data structure 
		if((m_diffInfoVec[diffIndex]).pEvArray == NULL)
		{
			(m_diffInfoVec[diffIndex]).pEvArray = new EventConfig[tempEv.size()];
			RETURN_FALSE_IF_NULL ((m_diffInfoVec[diffIndex]).pEvArray, this);
		}

		for (UINT i = 0; i < tempEv.size(); i++)
		{
			(m_diffInfoVec[diffIndex]).pEvArray[i] = (tempEv[i]);
			(m_diffInfoVec[diffIndex]).evCount++;
		}

		// Add all data view config
		(m_diffInfoVec[diffIndex]).pViewCollection->addAllDataView (
							(m_diffInfoVec[diffIndex]).pEvArray, 
							(m_diffInfoVec[diffIndex]).evCount, 
							cpuFamily,model);
		(m_diffInfoVec[diffIndex]).currentViewName = ALL_DATA_VIEW;

	}
	
	// Read available view
	if (cpuFamily != 0)
	{
		(m_diffInfoVec[diffIndex]).pViewCollection->readAvailableViews(cpuFamily);
		ret = true;
	}

	return ret;
} //DiffSession::initViewCfg


// RE-ENTRANT
bool DiffSession::populateDataToSymbolView()
{
	// Setting up ListView
	if(m_pSymbolLV != NULL)
	{
		m_maxEntMap.clear();
		m_pSymbolLV->clear();
		int numCol = m_pSymbolLV->columns();
		for(int i = numCol ; i >= 0 ;  i--)
			m_pSymbolLV->removeColumn(i);
	}else{
		m_pSymbolLV = new QListView(this);
		if(m_pSymbolLV == NULL) return false;

		m_pSymbolLV->setSelectionMode(QListView::Extended);	
		m_pSymbolLV->setAllColumnsShowFocus(true);
		m_pSymbolLV->setShowSortIndicator(true);
		m_pSymbolLV->setRootIsDecorated(true);
		
		setCentralWidget(m_pSymbolLV);

		//Connect QListView double-click signal to DiffSession to prepare data to be
		//sent to DasmDockView 
		//connect(m_pSymbolLV, SIGNAL(currentChanged(QListViewItem*)),
		connect(m_pSymbolLV, SIGNAL(doubleClicked(QListViewItem*,const QPoint&,int)),
			this,SLOT(onPrepareToUpdateDasmDockView(QListViewItem*)));	

		if(m_pDiffAnalystWindow !=NULL)
		{
			//Connect DiffSession signal to the DiffAnalystWindow
			connect(this, SIGNAL(updateDasmDockView(QListViewItem*)),
					(m_pDiffAnalystWindow), SLOT(onUpdateDasmDockView(QListViewItem*)));	
		}

		connect(m_pSymbolLV, SIGNAL(rightButtonClicked(QListViewItem*,const QPoint &, int)),
			this, SLOT(onRightClicked(QListViewItem*,const QPoint &, int)));	

	}

	////////////////////////////////////////////////

	// Setup DiffViewShownData
	if(m_pDiffViewShown != NULL)
	{
		delete m_pDiffViewShown;
		m_pDiffViewShown = NULL;
	}

	m_pDiffViewShown = new DiffViewShownData();
	if(m_pDiffViewShown == NULL) return false;
	m_pDiffViewShown->setDiffViewOptions(&m_diffViewOptions);


	for(int diffIndex = 0 ; diffIndex < MAX_NUM_DIFF ; diffIndex++)
	{	
		// Get current View Configuration
		initViewCfg(diffIndex);

		// NOTE: We overide the configuration (separateCPU, showPercentage, separateThread,
		// and  separateTasks in the View Configuration) in the ViewConfig XML files 
		// with our own setting.
		(m_diffInfoVec[diffIndex]).pViewCollection->setSeparateCpu(
					m_diffInfoVec[diffIndex].currentViewName,
					m_diffViewOptions.separateCpus);
		(m_diffInfoVec[diffIndex]).pViewCollection->setShowPercentage(
					m_diffInfoVec[diffIndex].currentViewName,
					false);
		(m_diffInfoVec[diffIndex]).pViewCollection->setSeparateThread(
					m_diffInfoVec[diffIndex].currentViewName,
					false);
		(m_diffInfoVec[diffIndex]).pViewCollection->setSeparateTask(
					m_diffInfoVec[diffIndex].currentViewName,
					false);
		
		// Get viewShown
		(m_diffInfoVec[diffIndex]).pViewCollection->getViewConfig (
					m_diffInfoVec[diffIndex].currentViewName,
					&(m_viewShown[diffIndex]), 
					m_pTbsReader[diffIndex]->getNumCpus(), 
					m_pTbsReader[diffIndex]->getCpuFamily(),
					m_pTbsReader[diffIndex]->getCpuModel(),	
					NULL);

		m_pDiffViewShown->addViewShownData(&(m_viewShown[diffIndex]));
	}
		
	m_pDiffViewShown->rearrangeView(m_diffViewOptions.separateCpus);
	
	int numCol = m_pDiffViewShown->getNumColumn();

	DiffViewColumnInfoMap *dMap = NULL;
	ComplexColumnInfoMap  *cMap = NULL;
	m_pDiffViewShown->getSampleColumnMap(&dMap);
	m_pDiffViewShown->getComplexColumnMap(&cMap);

	////////////////////////////////////////////////
	// Adding column
	for(int i = 0 ; i < numCol ; i++)
	{
		m_pSymbolLV->addColumn(QString());
	}

	////////////////////////////////////////////////
	// Setting column header
	DiffViewColumnInfoMap::iterator d_it = dMap->begin();
	DiffViewColumnInfoMap::iterator d_end = dMap->end();
	for(; d_it != d_end ; d_it++)
	{
		m_pSymbolLV->setColumnText((d_it.data()).colIndex, (d_it.data()).colName);
		if(d_it.data().colType == DATA_COL)
			m_pSymbolLV->setColumnAlignment((d_it.data()).colIndex, Qt::AlignRight);
		if(d_it.data().isShown == false)
		{
			m_pSymbolLV->setColumnWidthMode((d_it.data()).colIndex, QListView::Manual);
			m_pSymbolLV->setColumnWidth((d_it.data()).colIndex, 0);
		}else{
			m_pSymbolLV->setColumnWidth((d_it.data()).colIndex, 100);
		}
	}

	// Set Manual Width for Symbol column
	m_pSymbolLV->setColumnWidthMode(0, QListView::Manual);
	m_pSymbolLV->setColumnWidth(0, 500);
	
	
	ComplexColumnInfoMap::iterator c_it = cMap->begin(); 
	ComplexColumnInfoMap::iterator c_end = cMap->end(); 
	for(; c_it != c_end ; c_it++)
	{
		m_pSymbolLV->setColumnText((c_it.data()).colIndex, (c_it.data()).colName);
		if(c_it.data().colType == COMPLEX_COL)
			m_pSymbolLV->setColumnAlignment((c_it.data()).colIndex, Qt::AlignRight);
		if(c_it.data().isShown == false)
		{
			m_pSymbolLV->setColumnWidthMode((c_it.data()).colIndex, QListView::Manual);
			m_pSymbolLV->setColumnWidth((c_it.data()).colIndex, 0);
		}else{
			m_pSymbolLV->setColumnWidth((c_it.data()).colIndex, 100);

		}
	}

	
	////////////////////////////////////////////////
	// Populate Data for each symbol
	SYMBOL_VIEW_INFO_MAP::iterator it  = m_symViewInfoMap.begin();
	SYMBOL_VIEW_INFO_MAP::iterator end = m_symViewInfoMap.end();
	for(; it != end ; it++)
	{

		if(m_diffViewOptions.showPercentage == true)
		{
			for(int diffIndex = 0 ; diffIndex < MAX_NUM_DIFF ; diffIndex++)
				calculateSamplePercentMap(&(it->second.samplePercentMap[diffIndex]), 
					&(it->second.sampleDataMap[diffIndex]),
					&(m_moduleTotalMap[diffIndex]));
		}

		// New QListViwItem	
		DiffDataListItem *item = new DiffDataListItem(m_pDiffViewShown,
					m_pSymbolLV, 	//Parent
					m_pSymbolLV->lastItem()); //After

		item->drawData(&(it->second),m_diffViewOptions.separateCpus,&m_maxEntMap);

		// Check if this is an inline function
		if(it->second.inlineInstance.size() > 0)
		{
			SYMBOL_VIEW_INFO_MAP::iterator iIt = it->second.inlineInstance.begin();
			SYMBOL_VIEW_INFO_MAP::iterator iIt_end = it->second.inlineInstance.end();
			for(; iIt != iIt_end ; iIt++)
			{

				if(m_diffViewOptions.showPercentage == true)
				{
					for(int diffIndex = 0 ; diffIndex < MAX_NUM_DIFF ; diffIndex++)
						calculateSamplePercentMap(&(iIt->second.samplePercentMap[diffIndex]), 
							&(iIt->second.sampleDataMap[diffIndex]),
							&(m_moduleTotalMap[diffIndex]));
				}

				DiffDataListItem *iItem = new DiffDataListItem(m_pDiffViewShown,
								item);
				iItem->drawData((SYMBOL_VIEW_INFO*)&(iIt->second),m_diffViewOptions.separateCpus,&m_maxEntMap);
								

			}
		}

	}

	////////////////////////////////////////////////
	// Highlight Max
	MAX_ENTRY_MAP::iterator mit = m_maxEntMap.begin();
	MAX_ENTRY_MAP::iterator mend = m_maxEntMap.end();
	for(; mit != mend ; mit++)
	{
		DiffDataListItem* pItem = (DiffDataListItem*) mit.data();
		pItem->addMaxCol(mit.key());	
		pItem->repaint();
	}

	return true;
} //DiffSession::populateDataToSymbolView


bool DiffSession::aggregateSamplesForModule( unsigned int diffIndex,
					TaskSampleMap* pTaskSampleMap,
					QString module)
{
	bool ret = false;
	sym_info symInfo;
	sym_info inlineInfo;

	//////////////////////////////////////////	
	// Initialize symbol engine
	if(m_symEng[diffIndex].isOpen())
	{
		m_symEng[diffIndex].closeEngine();
	}
	
	if(m_symEng[diffIndex].open(module.data(),true) != SymbolEngine::OKAY)
		return ret;

	//////////////////////////////////////////	
	// Work through the samples
	TaskSampleMap::iterator	tsmIt  = pTaskSampleMap->begin();
	TaskSampleMap::iterator	tsmEnd = pTaskSampleMap->end();
	for( ; tsmIt != tsmEnd ; tsmIt++)
	{
		if(tsmIt->first != m_taskId[diffIndex])
		{
			continue;
		}

		TIMER_START("Process Sample");	
		/*
		 * Optimization Note:
		 * The samples in the EBP files are grouped by symbol.
		 * Based on this, we can reduce the number of times we 
		 * query the symbol engine by 
		 * - Caching the retrieved symbol information
		 * - Caching the pointer to QListViewItem
		 */
		bfd_vma cached_start = 0;
		bfd_vma cached_end = 0;
		QString cached_symName;

		bfd_vma cached_inst_start = 0;
		bfd_vma cached_inst_end = 0;
		QString cached_inst_symName;

		bool cached_isInlineInst = false;
		bool isCacheValid = false;
		SYMBOL_VIEW_INFO_MAP::iterator cached_svi_it;

		SampleMap::iterator smIt = tsmIt->second.begin(); 	
		SampleMap::iterator smEnd = tsmIt->second.end(); 
		for( ; smIt != smEnd ; smIt++)
		{
			// Modify SampleDataMap to contain the SumOfAllCpus
			sumAllCpusInSampleDataMap(&(smIt->second));
			
			// Aggregate Total	
			aggregateTotalSamples(smIt->second, diffIndex);

			//------------------------------------------------------------------------------
			// Check if cached is still valid
			if( (smIt->first < cached_start) || (smIt->first >= cached_end) )
			{
				/////////////////////////////////
				// CACHE NOT VALID
				/////////////////////////////////

				// Query symbol engine
				m_symEng[diffIndex].getSymbolForAddr(smIt->first,&symInfo,&inlineInfo);	
				
				// NOTE: We strip white space from symbol to avoid symbol mismatching
				//       in case compiler generate slightly different symbol name
				//       we should make this optional.
				symInfo.name = symInfo.name.replace(" ",""); 
				
				// NOTE: In case of PGI, replace foo(void) with foo()
				symInfo.name = symInfo.name.replace("(void)","()");

				SYMBOL_VIEW_INFO_MAP::iterator it = m_symViewInfoMap.find(symInfo.name);
				if( it == m_symViewInfoMap.end()) // Symbol not found
				{
					SYMBOL_VIEW_INFO newSymbol;
					newSymbol.symName = symInfo.name;
					newSymbol.startAddr[diffIndex] = symInfo.sym_start;
					newSymbol.stopAddr[diffIndex]  = symInfo.possible_end;
					//fprintf(stderr,"Insert symbol = %s\n",symInfo.name.data());	
					m_symViewInfoMap.insert( SYMBOL_VIEW_INFO_MAP::value_type(symInfo.name,newSymbol));
				}else{ // Symbol found
					if ( it->second.startAddr[diffIndex] == 0)
					{
						it->second.startAddr[diffIndex] = symInfo.sym_start;
						it->second.stopAddr[diffIndex]  = symInfo.possible_end;
					}
				}

				// Store primary cached values
				cached_symName	= symInfo.name;
				cached_start	= symInfo.sym_start;
				cached_end	= symInfo.possible_end;

				// Check if this function has any inline instances
				if( m_aggregateInline 
				&& symInfo.sym_start != 0
				&& m_symEng[diffIndex].getNumInlineDwarf(symInfo.sym_start) != 0)
				{
					 // If the function has inline instance, we try to 
					 // query inline instance block.
					cached_inst_start 	= symInfo.sym_start;	
					cached_inst_end 	= symInfo.possible_end;	
					cached_inst_symName 	= symInfo.name;	

					buildInlineBlockMap(diffIndex,symInfo.sym_start);
					getInlineBlockMap(diffIndex, smIt->first,
								cached_symName,
								cached_isInlineInst,
								cached_start,
								cached_end);

					// If this sample is in inline instance	
					if(cached_isInlineInst)
					{
						//Try to find inline function
						SYMBOL_VIEW_INFO_MAP::iterator it = m_symViewInfoMap.find(cached_symName);
						if(it == m_symViewInfoMap.end()) 
						{ 
							SYMBOL_VIEW_INFO sInfo;
							sInfo.symName = cached_symName;
							sInfo.startAddr[diffIndex] = 0;
							sInfo.stopAddr[diffIndex]  = 0;
						
							//fprintf(stderr,"Insert symbol = %s\n",cached_symName.data());	
							m_symViewInfoMap.insert(SYMBOL_VIEW_INFO_MAP::value_type(
											cached_symName,
											sInfo));
							it = m_symViewInfoMap.find(cached_symName);
						}

						// Try to find inline instance 
						QString instanceName = QString("Instance : ")+ symInfo.name + 
								" [ 0x" +QString::number(cached_start,16)+
								" : 0x"+QString::number(cached_end,16)+" )";

						SYMBOL_VIEW_INFO_MAP::iterator il_it = 
							it->second.inlineInstance.find(instanceName);
						if(il_it == it->second.inlineInstance.end())
						{ // Inline instance not found
							SYMBOL_VIEW_INFO ilInstViewInfo;
							ilInstViewInfo.symName              = instanceName;
							ilInstViewInfo.startAddr[diffIndex] = cached_start;	
							ilInstViewInfo.stopAddr[diffIndex]  = cached_end;	
							ilInstViewInfo.isInlineInstance     = true;	
							SYMBOL_VIEW_INFO_MAP::iterator callerFunc_it = m_symViewInfoMap.find(symInfo.name);
							if( callerFunc_it == m_symViewInfoMap.end())
							{
								ilInstViewInfo.pCallerFunc = NULL;
								//fprintf(stderr,"Not found caller %s\n",symInfo.name.data());
							}else{
								ilInstViewInfo.pCallerFunc = &(callerFunc_it->second);
								//fprintf(stderr,"Found caller %s for inline instance %s\n",
								//	ilInstViewInfo.pCallerFunc->symName.data(),
								//	cached_symName.data());
							}
							it->second.inlineInstance.insert(
								SYMBOL_VIEW_INFO_MAP::value_type(
											instanceName,ilInstViewInfo)); 
						} else{ // Inline instance found
							if(il_it->second.startAddr[diffIndex] == 0)
							{
								// Fill-in address if not exist
								il_it->second.startAddr[diffIndex] = cached_start;
								il_it->second.stopAddr[diffIndex] = cached_end;
							}

						} // end if
					} // end if is inline instance 
				} // end if this function has inline instance 

				isCacheValid	= false;
			}else{
				/////////////////////////////////
				// CACHE VALID
				/////////////////////////////////
				isCacheValid	= true;
			} // end if isCacheValid
			
			//==============================================================================
			// Find symbol from map.
			SYMBOL_VIEW_INFO_MAP::iterator it; 
			if(!isCacheValid)	
			{
				it = m_symViewInfoMap.find(cached_symName);
			}
			
			//==============================================================================
			// Cache not valid "AND" not found in map
			if( isCacheValid
			|| !isCacheValid && it != m_symViewInfoMap.end())
			{
				// If cache not valid  but found in the map 
				if( !isCacheValid )
				{
					cached_svi_it = it; 	
				}

				aggregateSamplesForSymbol(smIt->second,
							cached_svi_it->second.sampleDataMap[diffIndex]);
		
				// If this is in an inline instance, Find and update the instance
				if(cached_isInlineInst)
				{
					QString instanceName = QString("Instance : ")+ cached_inst_symName+ 
							" [ 0x"+QString::number(cached_start,16)+
							" : 0x"+QString::number(cached_end,16)+" )";
					
					SYMBOL_VIEW_INFO_MAP::iterator il_it = 
						cached_svi_it->second.inlineInstance.find(instanceName);
					if(il_it != cached_svi_it->second.inlineInstance.end())
					{
						aggregateSamplesForSymbol(smIt->second,
									il_it->second.sampleDataMap[diffIndex]);
						
						aggregateSamplesForSymbol(smIt->second,
									il_it->second.pCallerFunc->sampleDataMapTotal[diffIndex]);
					}
				}
			}// end if
			//------------------------------------------------------------------------------
		
		} // end for each sample
		TIMER_STOP("Process Sample");	
	} // end for  each task
		
	ret = true;
	return ret;
} //DiffSession::aggregateSamplesForModule

void DiffSession::aggregateTotalSamples( SampleDataMap& pSampleDataMap, 
					unsigned int diffIndex)
{
	SampleDataMap::iterator it = pSampleDataMap.begin();	
	SampleDataMap::iterator end = pSampleDataMap.end();	
	for(; it != end ; it++)
	{
		if(it->first.cpu == -1)
			continue;	// This is calculated value. We don't aggregate this.

		SampleKey key(-1,it->first.event);
		SampleDataMap::iterator tmp = (m_moduleTotalMap[diffIndex]).find(key);
		if(tmp != (m_moduleTotalMap[diffIndex]).end())
		{
			tmp->second += it->second;
		}else{
			(m_moduleTotalMap[diffIndex]).
				insert(SampleDataMap::value_type(key,it->second));
		}
	}

#if DA_DEBUG
// DA_DEBUG MAP
	SampleDataMap::iterator sdmIt  = (m_moduleTotalMap[diffIndex]).begin();	
	SampleDataMap::iterator sdmEnd = (m_moduleTotalMap[diffIndex]).end();	
	for(; sdmIt != sdmEnd ; sdmIt++)
	{
		fprintf(stderr,"DA_DEBUG: aggregateTotalSamples: i = %d, cpu = %u, event = %lx, count = %u\n",
				diffIndex,sdmIt->first.cpu, sdmIt->first.event, sdmIt->second);
	}
#endif
}

void DiffSession::aggregateSamplesForSymbol( SampleDataMap& pSampleDataMap,
				SampleDataMap& pSampleDataMapDest)
{
	SampleDataMap::iterator it = pSampleDataMap.begin();	
	SampleDataMap::iterator end = pSampleDataMap.end();	
	for(; it != end ; it++)
	{
		SampleDataMap::iterator tmp = pSampleDataMapDest.find(it->first);
		if(tmp != pSampleDataMapDest.end())
		{
			tmp->second += it->second;
		}else{
			pSampleDataMapDest.insert(SampleDataMap::value_type(it->first,it->second));
		}
	}


#if DA_DEBUG 
// DA_DEBUG MAP
	SampleDataMap::iterator sdmIt  = pSampleDataMapDest.begin();	
	SampleDataMap::iterator sdmEnd = pSampleDataMapDest.end();	
	for(int j = 0; sdmIt != sdmEnd ; j++,sdmIt++)
	{
		fprintf(stderr,"DA_DEBUG: aggregateSamplesForSymbol: j = %d, count = %u\n",
				j, sdmIt->second);
	}
#endif

}

bool DiffSession::getInfoFromEbpFile( TaskSampleMap* pTaskSampleMap,
				QString sessionFile, 
				QString task,
				QString module,
				unsigned int diffIndex)
{
	bool ret = false;
	ProfileAttribute attr;

	//Initialize TbpReaders
	m_pTbsReader[diffIndex] = new TbsReader();
	RETURN_FALSE_IF_NULL(m_pTbsReader[diffIndex],this);

	if (!m_pTbsReader[diffIndex]->OpenTbsFile(sessionFile)) 
	{
		return false;
	}

	//------------------------------------------------------------
	// Check TBP Timestamp
	if(!m_alreadyCheckedTime[diffIndex])
	{
		m_alreadyCheckedTime[diffIndex] = true;
		QString tbp_dt_str = QString(m_pTbsReader[diffIndex]->getTimestamp()).simplifyWhiteSpace();

		/* NOTE:
		* We need to do this since QT has a bug in function
		* QDateTime::fromString() !!!!
		*/
		struct tm tmp_dt;
		strptime(tbp_dt_str.data(),"%a %b %d %H:%M:%S %Y",&tmp_dt);
		time_t tmp_dt2 = mktime(&tmp_dt);

		QDateTime tbp_dt ;
		tbp_dt.setTime_t(tmp_dt2);

		QString oldModuleName = "";
		QFileInfo f_info = QFileInfo(module);

		// Check modules
		//fprintf(stderr,"Tbp datetime    = %s\n",tbp_dt.toString().data());
		//fprintf(stderr,"module datetime = %s\n",f_info.created().toString().data());
		if(f_info.created() > tbp_dt)
		{
				oldModuleName += (module);
		}

		// Give warning message if module is newer than profiling time
		if(oldModuleName.length() != 0)
		{
/* THIS CAUSED MULTIPLE ISSUES
			QString msg = "Module:\n\n" + oldModuleName
					+ "\nhas creation time ("+ f_info.created().toString()
					+") later than the profiling time ("+ tbp_dt.toString()
					+").\n"
					+ "Symbol information might be inaccurate.\n"
					+ "Please re-run the profile.\n\n"
					+ "Do you want to continue?\n";

			fprintf(stderr,"About to show dialog\n");
			if( QMessageBox::warning(this,"DiffAnalyst Warning", msg,
				QMessageBox::Yes, QMessageBox::No) != QMessageBox::Yes)
			{
				return false;
			}
*/
			QString msg = "Module: " + oldModuleName
					+ " has creation time ("+ f_info.created().toString()
					+") later than the profiling time ("+ tbp_dt.toString() +")."
					+ " Symbol information might be inaccurate.\n";

			fprintf(stderr,"DiffAnalyst Warrning: %s",msg.data());

		}

	}
	//------------------------------------------------------------
	//Get TaskID
	ret = m_pTbsReader[diffIndex]->readProcInfo(m_procIdList[diffIndex]);
	PROC_ID_LIST::iterator it = m_procIdList[diffIndex].begin();	
	PROC_ID_LIST::iterator it_end = m_procIdList[diffIndex].end();	
	for(; it != it_end ; it++)
	{
		if(task == (*it).ModName)
		{
			m_taskId[diffIndex] = (*it).taskId;
			break;
		}
	}

	// Get ModuleInfo
	ret = m_pTbsReader[diffIndex]->readInstSampleInfo(
				module, pTaskSampleMap, NULL , &attr, NULL);

	return ret;	
}

void DiffSession::closeEvent(QCloseEvent *e)
{
	emit updateDasmDockView(NULL);		
	QWidget::closeEvent(e);
}


bool DiffSession::isSameModule()
{ 
	bool ret = false;
	for (int i = 1 ; i < m_numDiff ; i++)
	{
		ret = ( 0 == m_diffInfoVec[0].module.compare(m_diffInfoVec[i].module));
	}
	return ret;
}

void DiffSession::sumAllCpusInSampleDataMap(SampleDataMap* pSdm) 
{
	if(pSdm == NULL)
		return;

	SampleDataMap::iterator sit  = pSdm->begin();
	SampleDataMap::iterator send = pSdm->end();
	for(; sit != send ; sit++)
	{
		SampleKey key(-1,sit->first.event);
		SampleDataMap::iterator cIt = pSdm->find(key);
		if( cIt == pSdm->end())
		{
			pSdm->insert(SamplePercentMap::value_type(key,sit->second));
		}else{
			cIt->second = cIt->second + sit->second;	
		}
	}
#if DA_DEBUG
// DA_DEBUG MAP
	SampleDataMap::iterator sdmIt  = pSdm->begin();	
	SampleDataMap::iterator sdmEnd = pSdm->end();	
	for(; sdmIt != sdmEnd ; sdmIt++)
	{
		fprintf(stderr,"DA_DEBUG: sumAllCpusInSampleDataMap: cpu = %u, event = %lx, count = %u\n",
				sdmIt->first.cpu, sdmIt->first.event, sdmIt->second);
	}
#endif
}

void DiffSession::onRightClicked(QListViewItem * item,
				const QPoint &pt,
				int col)
{
	Q_UNUSED(col);
	if ( NULL == item ) return;

	// Popup Menu
	QPopupMenu *pRightClickMenu = new QPopupMenu( m_pSymbolLV);
	if(!pRightClickMenu)
		return;

	pRightClickMenu->insertItem("Merge symbol data",this,
			SLOT(onMergeRow()));

	pRightClickMenu->popup(pt);
}

void DiffSession::onMergeRow()
{
	DiffDataListItem *pLeft = NULL;
	DiffDataListItem *pRight = NULL;

	DiffDataListItem *pItem = (DiffDataListItem*)m_pSymbolLV->firstChild();
	for(int i = 0 ; i < m_pSymbolLV->childCount() ; i++, pItem = (DiffDataListItem*)pItem->nextSibling())
	{
		if(pItem->isSelected())
		{
			if(pLeft == NULL)
			{
				pLeft = pItem;
			}
			else if(pRight == NULL)
			{
				pRight = pItem;
			}else{
				QMessageBox::critical(this,"DiffAnalyst Error"
					,"Cannot merge more than two rows\n");
				return;
			}
		}
	}	

	if(!pLeft || !pRight)
		return;

	// Check if can Merge pRight into pLeft
	for(int i = 1 ; i < m_pSymbolLV->columns(); i++)
	{
		bool isLEmpty = pLeft->text(i).isEmpty();
		bool isREmpty = pRight->text(i).isEmpty();
		if(!isLEmpty && !isREmpty)
		{
			// Cannot merge
			QMessageBox::critical(this,"DiffAnalyst Error",
			"Cannot merge symbols with overlap data.\n");
			return;	
		}
	}
	
	// Merge Name
	pLeft->setText(0,
			pLeft->text(0) + " / " +
			pRight->text(0));
	
	// Merge pRight into pLeft
	for(int i = 1 ; i < m_pSymbolLV->columns(); i++)
	{
		QString tmp = pRight->text(i);
		if(!tmp.isEmpty())
		{
			pLeft->setText(i,tmp);
		}
	}

	// Merge SampleDataMap, startAddr, and stopAddr
	if(pLeft->getSymbolViewInfo()->stopAddr[0] == 0)
	{
		aggregateSampleDataMap(&(pLeft->getSymbolViewInfo()->sampleDataMap[0]),
				&(pRight->getSymbolViewInfo()->sampleDataMap[0]));	
		pLeft->getSymbolViewInfo()->startAddr[0] = pRight->getSymbolViewInfo()->startAddr[0];
		pLeft->getSymbolViewInfo()->stopAddr[0] = pRight->getSymbolViewInfo()->stopAddr[0];
	} else if(pLeft->getSymbolViewInfo()->stopAddr[1] == 0){
		aggregateSampleDataMap(&(pLeft->getSymbolViewInfo()->sampleDataMap[1]),
				&(pRight->getSymbolViewInfo()->sampleDataMap[1]));	
		pLeft->getSymbolViewInfo()->startAddr[1] = pRight->getSymbolViewInfo()->startAddr[1];
		pLeft->getSymbolViewInfo()->stopAddr[1] = pRight->getSymbolViewInfo()->stopAddr[1];
	}

	// Repaint 	
	pLeft->repaint();

	m_pSymbolLV->takeItem(pRight);
}

void DiffSession::buildInlineBlockMap(int diffIndex, bfd_vma funcStartAddr)
{
	sym_info symInfo;
	sym_info inlineInfo;
	SYM_INFO_VECTOR inlinesVec;

	// If already the same functionStartAddress, just return;
	if(funcStartAddr != (m_inlineBlockMap[diffIndex].begin())->first)
		m_inlineBlockMap[diffIndex].clear();	
	else{
		return;
	}

	
	m_symEng[diffIndex].getSymbolForAddr(funcStartAddr,&symInfo,&inlineInfo);	

	//fprintf(stderr,"DEBUG: buildInlineBlockmap: func = %s, start = %lx\n",
	//				symInfo.name.data(),funcStartAddr);

	m_inlineBlockMap[diffIndex].insert(INLINE_BLOCK_MAP::value_type(
						symInfo.sym_start,
						INLINE_BLOCK(symInfo.name,false)));
	m_inlineBlockMap[diffIndex].insert(INLINE_BLOCK_MAP::value_type(
						symInfo.possible_end,
						INLINE_BLOCK(symInfo.name,false)));

	m_symEng[diffIndex].getInlinesForFunctionDwarf(funcStartAddr,inlinesVec);
	SYM_INFO_VECTOR::iterator it = inlinesVec.begin();
	SYM_INFO_VECTOR::iterator it_end = inlinesVec.end();
	for(; it != it_end ; it++)
	{
		QString oldName;
		bool oldFlag;
		bfd_vma beg, end;
		getInlineBlockMap(diffIndex, (*it)->sym_start, oldName, oldFlag, beg, end );	

		INLINE_BLOCK_MAP::iterator ib_it = m_inlineBlockMap[diffIndex].find((*it)->sym_start);
		if( ib_it == m_inlineBlockMap[diffIndex].end())
		{
			// Block start not found, insert new block start
			m_inlineBlockMap[diffIndex].insert( INLINE_BLOCK_MAP::value_type(
								(*it)->sym_start, 
								INLINE_BLOCK((*it)->name,true)));
		}else{
			// Block start already exist, we need to update block info
			(*ib_it).second.name = (*it)->name;
			(*ib_it).second.isInline = true;
		}

		// Block start already exist, we need to update block info
		ib_it = m_inlineBlockMap[diffIndex].find((*it)->possible_end);
		if( ib_it == m_inlineBlockMap[diffIndex].end())
		{
			// Block end not found, insert new block end 
			m_inlineBlockMap[diffIndex].insert( INLINE_BLOCK_MAP::value_type(
								(*it)->possible_end,
								INLINE_BLOCK(oldName, oldFlag)));
		}
	}

#if DA_DEBUG
{
	INLINE_BLOCK_MAP::iterator it  = m_inlineBlockMap[diffIndex].begin();	
	INLINE_BLOCK_MAP::iterator end = m_inlineBlockMap[diffIndex].end();	
	for(; it != end ; it++)
	{
		fprintf(stderr,"DA_DEBUG: block %llx, name = %s, isInline = %s\n", it->first, it->second.name.data(), (it->second.isInline)?"yes":"no");
	}
}
#endif
}

void DiffSession::getInlineBlockMap(int diffIndex,bfd_vma addr,QString &name, 
				bool &flag, bfd_vma &prev, bfd_vma &next)
{

	INLINE_BLOCK_MAP::reverse_iterator prev_rit;
	INLINE_BLOCK_MAP::reverse_iterator rit = 
				m_inlineBlockMap[diffIndex].rbegin();
	INLINE_BLOCK_MAP::reverse_iterator rit_end = 
			m_inlineBlockMap[diffIndex].rend();
	prev_rit = rit_end;

	for(; rit != rit_end ;)
	{
		if(addr >= rit->first)
		{
			name = rit->second.name.data();
			flag = rit->second.isInline;
			prev = rit->first;
			if (prev_rit != rit_end)
				next = prev_rit->first;

			break;
		}else{
			prev_rit = rit ;
			rit++;
		}
	}
}

QString DiffSession::getSessionStr(unsigned int index)
{
	bool isOk;
	m_diffInfoVec.at(index,&isOk);
	if(isOk)
	{
		return QString(
			m_diffInfoVec.at(index).sessionFile + ":" +
			m_diffInfoVec.at(index).task + ":" +
			m_diffInfoVec.at(index).module);
	}else{
		return QString();
	}
}

void DiffSession::onTogglePercent(bool b)
{
	m_diffViewOptions.showPercentage = b;	
	populateDataToSymbolView();
}

void DiffSession::onSeparateCpu(bool b)
{
	m_diffViewOptions.separateCpus   = b;
	populateDataToSymbolView();
	
	// Clear DasmView	
	emit updateDasmDockView(NULL);		
}

void DiffSession::onAggregateInline(bool b)
{
	m_aggregateInline = b;
	m_symViewInfoMap.clear();
	
	// For each profile to diff,
	for(unsigned int i=0 ; i<m_numDiff ; i++)
	{
		m_taskSampleMap[i].clear();
		m_moduleTotalMap[i].clear();

		// Get samples and store them in TaskSampleMap
		if (!getInfoFromEbpFile( &(m_taskSampleMap[i]), 
					m_diffInfoVec[i].sessionFile,
					m_diffInfoVec[i].task,
					m_diffInfoVec[i].module, i)) 
		{
			return ;
		}

		// By this time we need to have the column list ready
		if (!aggregateSamplesForModule( i,
					&(m_taskSampleMap[i]),
					m_diffInfoVec[i].module))
		{
			return ;
		}
	}

	// Populate Symbol View
	populateDataToSymbolView();
	
	// Clear DasmView	
	emit updateDasmDockView(NULL);		
}

void DiffSession::onClickedColumnArrangement()
{
	m_pToolId [DiffSession::TM_LEFTRIGHT]->setOn(m_diffViewOptions.showLeftRight);
	m_pToolId [DiffSession::TM_SIDEBYSIDE]->setOn(m_diffViewOptions.showSideBySide);
	m_pToolId [DiffSession::TM_DELTA]->setOn(m_diffViewOptions.showDelta);

	populateDataToSymbolView();
}

void DiffSession::onClickedLeftRight()
{
	m_diffViewOptions.showLeftRight  = true;
	m_diffViewOptions.showSideBySide = false;
	m_diffViewOptions.showDelta      = false;
	
	m_pToolId [DiffSession::TM_PERCENT]->setEnabled(true);
	if( m_pToolId [DiffSession::TM_PERCENT]->isOn())
	{
		m_diffViewOptions.showPercentage = true;	
	}
	onClickedColumnArrangement();
}

void DiffSession::onClickedSideBySide()
{
	// Check to see if the view are the same
	if(QString::compare( m_diffInfoVec[0].currentViewName.stripWhiteSpace() ,
			m_diffInfoVec[1].currentViewName.stripWhiteSpace()) != 0)
	{
		QMessageBox::critical(this,"DiffAnalyst Erorr", 
			QString("Cannot create Side-by-side view.\n") +
			"Please select the same view name for both sessions\n");
		m_pToolId [DiffSession::TM_SIDEBYSIDE]->setOn(m_diffViewOptions.showSideBySide);
		return;
	}

	m_diffViewOptions.showLeftRight  = false;
	m_diffViewOptions.showSideBySide = true;
	m_diffViewOptions.showDelta      = false;

	m_pToolId [DiffSession::TM_PERCENT]->setEnabled(true);
	if( m_pToolId [DiffSession::TM_PERCENT]->isOn())
	{
		m_diffViewOptions.showPercentage = true;	
	}
	onClickedColumnArrangement();
}

void DiffSession::onClickedDelta()
{
	// Check to see if the view are the same
	if(QString::compare( m_diffInfoVec[0].currentViewName.stripWhiteSpace(),
			m_diffInfoVec[1].currentViewName.stripWhiteSpace()) != 0)
	{
		QMessageBox::critical(this,"DiffAnalyst Erorr", 
			QString("Cannot create Delta view.\n") +
			"Please select the same view name for both sessions\n");
		m_pToolId [DiffSession::TM_DELTA]->setOn(m_diffViewOptions.showDelta);
		return;
	}

	m_diffViewOptions.showLeftRight  = false;
	m_diffViewOptions.showSideBySide = false;
	m_diffViewOptions.showDelta      = true;

	m_diffViewOptions.showPercentage = false;	
	m_pToolId [DiffSession::TM_PERCENT]->setEnabled(false);

	onClickedColumnArrangement();
}

void DiffSession::calculateSamplePercentMap(SamplePercentMap* percent, 
				SampleDataMap* samples,
				SampleDataMap* total)
{
	if(percent == NULL || samples == NULL || total == NULL)
		return;

#if DA_DEBUG
	fprintf(stderr,"--------INSTR---------\n");
#endif
	SampleDataMap::iterator sit  = samples->begin();
	SampleDataMap::iterator send = samples->end();
	for(; sit != send ; sit++)
	{
		SampleKey key(-1,sit->first.event);
		SampleDataMap::iterator tit  = total->find(key);
		if( tit != total->end())
		{
			float result = ((sit->second) * 100);
			result = result / (tit->second);
			percent->insert(SamplePercentMap::value_type(sit->first,result));
#if DA_DEBUG
			fprintf(stderr,"cpu = %llx, event = %llx\t\t",
					sit->first.cpu, sit->first.event);
			fprintf(stderr,"result = %f, total = %d, samples = %d\n",
					result, (tit->second), (sit->second));
#endif
		}
	}
}


