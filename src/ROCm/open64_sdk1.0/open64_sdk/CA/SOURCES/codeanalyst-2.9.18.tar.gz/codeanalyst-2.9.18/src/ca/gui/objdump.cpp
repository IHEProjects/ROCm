//$Id: objdump.cpp,v 1.2 2005/02/14 16:52:29 jyeh Exp $
// Parse and return needed information from spawned objdump process 

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include <qobject.h>
#include <qprocess.h>
#include <qprogressdialog.h>
#include <qmessagebox.h>

#include "objdump.h"

using namespace std;

objdump::objdump(QStringList & args)
{
	m_objdumpProcess = new QProcess(this);
	if (NULL == m_objdumpProcess) {
		QMessageBox::critical (NULL, "Memory error", "Insufficient memory");
		return;
	}

	connect(m_objdumpProcess, SIGNAL(readyReadStdout()),
		this, SLOT(readSTDOut()));

	connect(m_objdumpProcess, SIGNAL(processExited()),
		this, SLOT(displayBuffer()));

	m_objdumpProcess->setArguments(args);
	m_objdumpProcess->start();
}


objdump::~objdump()
{
	if (NULL != m_objdumpProcess) {
		delete m_objdumpProcess;
		m_objdumpProcess = NULL;
	}
}


bool objdump::stillRunning()
{
	return m_objdumpProcess->isRunning();
}

QString objdump::getKernelRange()
{
	QString buf;
	QString range = "";
	unsigned int size;
	unsigned int str_addr;
	unsigned int i = 0;
	QStringList::Iterator it;
	QProgressDialog progress;

	progress.setLabelText (QString("Reading kernel range"));
	progress.setTotalSteps ( m_stdoutLst.size());

	//todo test on x86-64
	for (it = m_stdoutLst.begin(); it != m_stdoutLst.end();
		it++) {
			QString line = *it;
			progress.setProgress (++i);

			if (line.contains(" .text ")) {
				// line format = "  %s %s         %x  %x  %s  %s  %s",
				line = line.section("         ", 1, 1);
				sscanf (line.data(), "%x", &size);
				sscanf (line.section("  ", 1, 1).data(), "%x", &str_addr);
				break;
			}

	}
	unsigned int end_addr = size + str_addr;

	range.sprintf("%x,%x", str_addr, end_addr);

	return range;
}


void objdump::displayBuffer()
{
}

void objdump::readSTDOut()
{
	QString tmp = "";

	while(QString::null !=(tmp = m_objdumpProcess->readLineStdout())) {
		m_stdoutLst += tmp;
	}
}
