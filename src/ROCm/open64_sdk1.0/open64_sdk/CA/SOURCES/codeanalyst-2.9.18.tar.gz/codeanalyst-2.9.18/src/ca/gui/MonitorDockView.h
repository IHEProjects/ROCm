
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _MONITORDOCKVIEW_H_
#define _MONITORDOCKVIEW_H_

#include <qdockwindow.h>
#include <qtabwidget.h>
#include <qthread.h>
#include <qlayout.h>
#include <qmutex.h>

///////////////////////////////////////////////////////////////////////////
class MonitorSnapshot
{
public:
	MonitorSnapshot() {};

	virtual ~MonitorSnapshot() {};
	
	virtual bool takeSnapshot() = 0;

	virtual void signalSnapshotReady(QObject * obj) = 0;
};

///////////////////////////////////////////////////////////////////////////
class MonitorUpdater : public QThread
{
public:
	MonitorUpdater(QObject * parent, 
				QMutex * mutex,
				MonitorSnapshot * snap,
				bool * isStop,
				unsigned long msec = 500) {
		m_pApp		= parent;
		m_pSnapMutex	= mutex;
		m_pSnapshot	= snap;
		m_isStop	= isStop;
		m_msecSleep	= msec;
	};	

	virtual void run();
	void setMsecSleep(unsigned long msec) { m_msecSleep = msec;};

protected:	
	QObject			* m_pApp;
	QMutex			* m_pSnapMutex;
	MonitorSnapshot		* m_pSnapshot;
	unsigned long		m_msecSleep;
	bool			* m_isStop;
};


///////////////////////////////////////////////////////////////////////////
class MonitorDockView : public QDockWindow
{
	Q_OBJECT;
public:
	MonitorDockView(QWidget * parent, const char * name = 0, WFlags f = 0);
	virtual ~MonitorDockView();
	virtual void updateWithSnapshot() = 0;

signals:
	void oprofileDockViewNoShow();

public slots:
	virtual void undock();
	virtual void show();	
	virtual void hide();	

protected:
	virtual bool init();

	QObject			* m_pApp;
	MonitorSnapshot 	* m_pSnap;	// Abstract
	QMutex			m_snapMutex;
	MonitorUpdater		* m_pMonitorUpdater;
	bool			m_isStop;
	
};

#endif //_MONITORDOCKVIEW_H_


