/**
 * @file slock.h
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#include <limits.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/stat.h>

#include "slock.h"
#include "smm.h"
#include "config.h"

using namespace std;

/// Create semaphore using the key set in the constructor
int shared_lock::create_semaphore(pid_t tgid)
{
	int ret = -1;
	key_t key;
	char buf[NAME_MAX];
		
	snprintf(buf, sizeof(buf), "%s%u", CA_JIT_DIR, tgid);
	key = ftok(buf, CA_SM_VERSION);
	held_key = key;
	
	/// Create a smaphore array with 1 semaphore
	if((semid = semget(key, 1, IPC_CREAT|0666)) < 0)
		goto out;
    
	/// Set the initial value of the semaphore to 1.
    if (semctl(semid, 0, SETVAL, 1) < 0) 
    	goto out;	

	ret = 0;

out:
  	return ret;  
}


void shared_lock::delete_lock(pid_t tgid)
{
	key_t key;
	char buf[NAME_MAX];
	snprintf(buf, sizeof(buf), "%s%u", CA_JIT_DIR, tgid);
	if(stat(buf,NULL) == 0)
	{
		key = ftok(buf, CA_SM_VERSION);
		if((semid = semget(key, 1, 0666)) > 0)
			semctl(semid, 0, IPC_RMID);
	}
}


/// Create semaphore using the key set in the constructor
int shared_lock::get_semaphore(pid_t tgid)
{
	int ret = 0;
	char buf[NAME_MAX];

	if (held_key < 0) {
		snprintf(buf, sizeof(buf), "%s%u", CA_JIT_DIR, tgid);
		held_key = ftok(buf, CA_SM_VERSION);
	}

	/// Create a smaphore array with 1 semaphore
	if((semid = semget(held_key, 1, 0666)) < 0) 
		goto out;
    
	/// Set the initial value of the semaphore to 1.
    if (semctl(semid, 0, SETVAL, 1) < 0)
		goto out;

	return ret;

out:
	ret = -1;
  	return ret;  
}

/// Semaphore p/down operation
int shared_lock::lock()
{
	struct sembuf operations[1];
	int retval;

	/// Attempt to lock semaphore #0 in the semaphore array
	operations[0].sem_num = 0;
	/// Subtract one from the semaphore
	operations[0].sem_op = -1;
	/// Set the flag so that the caller is blocked waiting for the lock
	operations[0].sem_flg = 0;

	for (int i=0; i<5; i++) {
		retval = semop(semid, operations, 1);
	
	    if(0 == retval)
			break;

		sleep(1);
	}
	return retval;
}


/// Semaphore v/up operation
int shared_lock::unlock()
{
	struct sembuf operations[1];
	int retval;

	/// Attempt to lock semaphore #0 in the semaphore array
	operations[0].sem_num = 0;
	/// Add 1 to the semaphore
	operations[0].sem_op = 1;
	/// Set the flag so that the caller is blocked waiting for the lock 
	operations[0].sem_flg = 0;

	retval = semop(semid, operations, 1);

	return retval;	
}


