#ifndef _CATRANSLATECONSOLE_H_
#define _CATRANSLATECONSOLE_H_

#include "catranslate.h"

class ca_translate_console:public CATranslate
{
public:
	ca_translate_console();

	~ca_translate_console();

	void display_oprofile_log();

	void init(vector < string > &events, 
		op_event_property * event_properties, 
		QString & session,
		unsigned int activeCounterMask,
		unsigned int ncpu,
		QString & jncPath,
		QString & caSession,
		EventMaskEncodeMap & events_map);
};



#endif
