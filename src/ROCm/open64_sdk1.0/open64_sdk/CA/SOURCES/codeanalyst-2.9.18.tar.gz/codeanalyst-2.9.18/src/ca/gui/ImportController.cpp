/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <stdlib.h>
#include <qmessagebox.h>

#include "helperAPI.h"
#include "ImportController.h"
#include "helperAPI.h"
#include "opxmldata_handler.h"
#include "tbsreader.h"
#include "EventMaskEncoding.h"
#include "catranslate_gui_display.h"


///////////////////////////////////
// OP_FILE_NAME_FIELD
//
enum OP_FILE_NAME_FIELD
{
	op_field_name = 0,
	op_field_count,
	op_field_unitmask,
};

#define NO_SAMPLE_MSG "Oprofile collected no samples.\n" \
		"Suggestion:\n" \
		"- Check the profiling duration\n" \
		"- Check number of counts for events\n" \
		"- Check \"Start delay period\" and \"Start with the profiling paused\" options.\n" 

const QString DLG_ALLOC_ERROR_MSG = "Could not allocate memory for the dialog box";

ImportController::ImportController(bool isGui)
{
	m_isGui = isGui;
	m_pCATranslateDisplay = NULL;
	m_pCawFile = NULL;
	m_pSession   = NULL;
	m_pCATranslate  = NULL;
}

ImportController::~ImportController()
{

}

bool ImportController::onImportXmlFile(QString import_xml_path,
				QString import_xml_cpuinfo_path)
{
	bool ret = false;
	unsigned int numCpu;
	unsigned long cpuModel;
	unsigned long cpuFamily;
	EventMaskEncodeMap events_map;
	OP_EVENT_PROPERTY_MAP ebp_events_name_map;

	if(!QFile::exists(import_xml_path))
	{
		m_importErrorMsg = QString("XML File ") 
				+ import_xml_path
				+ " does not exist.";
		return false;
	}
	
	// Get system info
	if(!QFile::exists(import_xml_cpuinfo_path))
	{
		m_importErrorMsg = QString("cpuinfo File ") 
				+ import_xml_cpuinfo_path 
				+ " does not exist.";
		return false;
	}
	
	numCpu    = XpFileContains(import_xml_cpuinfo_path, "processor");
	cpuFamily = getFamilyFromCpuInfo(import_xml_cpuinfo_path);
	cpuModel  = getModelFromCpuInfo(import_xml_cpuinfo_path);
	QString file = helpGetEventFile(cpuFamily, cpuModel);

	CEventsFile * eventFileForImport = new CEventsFile();
	if(!eventFileForImport)
	{
		m_importErrorMsg = QString("Error getting CA Eventfile.");
		return false;
	}

	eventFileForImport->open(file);

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++=
//TODO: This part should really be in libca/catranslate.cpp
	// - Read XML file 
	opxmldata_handler opXmlDataHandler;

	// Opdata_handler initialization:
	opXmlDataHandler.init();

	// Initialize Translattion Dialog
	opXmlDataHandler.set_display(m_pCATranslateDisplay);

	// Read XML file
	if(!opXmlDataHandler.readXML(import_xml_path.ascii()))	
	{
		m_importErrorMsg = QString("Error reading XML file: ") 
						+ import_xml_path + "."; 
		goto closeReader;
	}

	// Handle EBP Events
	if(opXmlDataHandler.getEvents(ebp_events_name_map) < 0)
	{
		m_importErrorMsg = QString("Error getting EBS sample."); 
		goto closeReader;
	}

	// Sanity check
	if( ebp_events_name_map.size() == 0)
	{
		m_importErrorMsg = 
			QString("The imported XML file contains insufficient information.\n") +
			"Please make sure to use option \"opcontrol --separate=lib,cpu\"\n" +
			"when running profile.\n";
		goto closeReader;
	}

	if( ebp_events_name_map.size() > 0 )
	{
		//***********************************************************
		// Create EBP Profile
		EBP_OPTIONS *pEbp = new EBP_OPTIONS ();
		RETURN_FALSE_IF_NULL (pEbp, NULL);
	
		PopulateEbpSettingsForImportSession(pEbp, 
					ebp_events_name_map, 
					eventFileForImport, 
					events_map);
		//***********************************************************
		// Process XML file
		opXmlDataHandler.setEventEncodeMap(events_map);

		if(m_pCATranslateDisplay)
			m_pCATranslateDisplay->translationInProgress(true);

		if(!opXmlDataHandler.processXMLData())
		{
			m_importErrorMsg = QString("Error processing EBP XML file: ") 
					+ import_xml_path + ".\n" 
					+ "Please make sure the XML file was created using:\n"
					+ "    opreport -Xwdl -o <output.file>";
			goto closeReader;
		}

		//***********************************************************
		// Create Directory inside the project directory
		pEbp->sessionName = getNextImportSessionName(EVENT_TRIGGER);
		pEbp->sessionNote = getSessionNote();
		pEbp->sessionFile = pEbp->sessionName + EBS_FILE_EXT;

		//  Create Directory inside the project directory
		QString dir_name;
		dir_name = QString(m_pCawFile->getDir() 
				+ pEbp->sessionFile) + ".dir";

		QDir ebs_dir;
		ebs_dir.mkdir(dir_name);

		QString caSession;
		caSession = dir_name 
			+ QString("/") 
			+ QString(pEbp->sessionFile);
		
		//***********************************************************
		// Generate EBP file
		opXmlDataHandler.write_ebp_output(caSession.data(), numCpu,
					cpuFamily, cpuModel);
		
		// - Copy jo file over for java
		opXmlDataHandler.copyJoFile(caSession.section("/",0,-2));
	
		// - Adding EBP section to .caw file
		m_pCawFile->addSession(pEbp);
		m_pCawFile->saveCawFile ();
		
		m_curSessionName = pEbp->sessionName;
		m_curTrigger     = EVENT_TRIGGER;
	}

	events_map.clear();

	ret = true;
closeReader:

	if(m_pCATranslateDisplay)
		m_pCATranslateDisplay->translationInProgress(false);

	// Closing
	eventFileForImport->close();
	if(eventFileForImport)
	{
		delete eventFileForImport;
		eventFileForImport = NULL;
	}

	return ret;
} //bool ImportController::onImportXmlFile

bool ImportController::onImportEbpFile(QString import_ebp_path,
				QString import_jit_dir_path)
{
	QString caSession = "";
	EBP_OPTIONS *pEbs = NULL;
	TBP_OPTIONS *pTbs = NULL;
	QString dir_name = "";

	// - Read TBS file 
        TbsReader *ebp_reader = new TbsReader ();
        RETURN_FALSE_IF_NULL (ebp_reader, NULL);
        if(!ebp_reader->OpenTbsFile(import_ebp_path.data()))
	{
		m_importErrorMsg = QString("Error opening TBP/EBP file: ") 
				+ import_ebp_path + "." ;
		return FALSE;
	}
        
	// - Determine what type of EBP file (TBS or EBS)
	QValueList<unsigned long long> eventList = ebp_reader->getEventList();
	if(import_ebp_path.section('.',-1).lower() == QString("tbp")) 
	{
		pTbs = new TBP_OPTIONS ();
		RETURN_FALSE_IF_NULL (pTbs, NULL);
	} else{
		pEbs = new EBP_OPTIONS ();
		RETURN_FALSE_IF_NULL (pEbs, NULL);
	}

	// ---------------------------------------------------------------
	// Handle different type of EBP file
	// * TBP
	// * EBP
	if(pTbs != NULL)
	{
		// HANDLE TBP FILE
		pTbs->sessionName = getNextImportSessionName(TIMER_TRIGGER);
		pTbs->sessionNote = getSessionNote();
		pTbs->sessionFile = pTbs->sessionName + TBS_FILE_EXT;

		// - Create Directory inside the project directory
		dir_name = QString(m_pCawFile->getDir() 
				+ pTbs->sessionFile) + ".dir";
		
		QDir tbs_dir;
		tbs_dir.mkdir(dir_name);

		caSession = dir_name 
			+ QString("/") 
			+ QString(pTbs->sessionFile);
 	
		// - Copy EBP file over.
		QString cmd;	
		cmd = "/bin/cp -f \"" + import_ebp_path + "\" \"" + caSession +"\"";  
		//fprintf(stderr,"DEBUG: Copy file : %s\n",cmd.data());
		if(system(cmd.data()) != 0)
		{
			m_importErrorMsg = QString("Error: Cannot copy ") 
					+ import_ebp_path
					+ " to "+caSession+".\n";
			return false;
		}

		// - Copy jit dir for java.
		if(!import_jit_dir_path.isEmpty())
		{
			cmd = "/bin/cp -rf \"" + import_jit_dir_path + "\" \"" + dir_name +"\"";  
			//fprintf(stderr,"DEBUG: Copy dir : %s\n",cmd.data());
			if(system(cmd.data()) != 0)
			{
				m_importErrorMsg = QString("Error: Cannot copy ") 
					+ import_jit_dir_path
					+ " to "+dir_name+".\n";
				return false;
			}
		}
		
		// - Adding EBP section to .caw file
		m_pCawFile->addSession(pTbs);
		m_pCawFile->saveCawFile ();
	
		m_curSessionName = pTbs->sessionName;
		m_curTrigger     = TIMER_TRIGGER;
	
	}else if(pEbs != NULL){
		// HANDLE EBP EVENT FILE
		RETURN_FALSE_IF_NULL (pEbs, NULL);

		pEbs->sessionName = getNextImportSessionName(EVENT_TRIGGER);
		pEbs->sessionNote = getSessionNote();
		pEbs->sessionFile = pEbs->sessionName + EBS_FILE_EXT;

		// - Create Directory inside the project directory
		dir_name = QString(m_pCawFile->getDir() 
				+ pEbs->sessionFile) + ".dir";
		
		QDir ebs_dir;
		ebs_dir.mkdir(dir_name);

		caSession = dir_name 
			+ QString("/") 
			+ QString(pEbs->sessionFile);
 	
		// - Copy EBP file over.
		QString cmd;	
		cmd = "/bin/cp -f \"" + import_ebp_path + "\" \"" + caSession +"\"";  
		//fprintf(stderr,"DEBUG: Copy file : %s\n",cmd.data());
		if(system(cmd.data()) != 0)
		{
			m_importErrorMsg = QString("Error: Cannot copy ") 
					+ import_ebp_path
					+ " to "+caSession+".\n";
			return false;
		}

		// - Copy jit dir for java.
		if(!import_jit_dir_path.isEmpty())
		{
			cmd = "/bin/cp -rf \"" + import_jit_dir_path + "\" \"" + dir_name +"\"";  
			//fprintf(stderr,"DEBUG: Copy dir : %s\n",cmd.data());
			if(system(cmd.data()) != 0)
			{
				m_importErrorMsg = QString("Error: Cannot copy ") 
					+ import_jit_dir_path
					+ " to "+dir_name+".\n";
				return false;
			}
		}
	
		// - Adding EBP section to .caw file
		m_pCawFile->addSession(pEbs);
		m_pCawFile->saveCawFile ();
		
		m_curSessionName = pEbs->sessionName;
		m_curTrigger     = EVENT_TRIGGER;
	}


	return true;
} //bool ImportController::onImportEbpFile


void ImportController::PopulateEbpSettingsForImportSession( EBP_OPTIONS *pEbs,
			OP_EVENT_PROPERTY_MAP &pmc_events_name_map,
			CEventsFile * eventFile,
			EventMaskEncodeMap &events_map)
{
	OP_EVENT_PROPERTY_MAP::iterator it  = pmc_events_name_map.begin ();
	OP_EVENT_PROPERTY_MAP::iterator end = pmc_events_name_map.end ();
	for (; it != end; it++) 
	{
		CpuEvent cpu_event;
		string name = it->first.data ();
		eventFile->findEventByOpStr(name.data(), cpu_event);

		/* Fill the EBP_Options */
		PerfEvent pe;
		pe.select 	= cpu_event.value;
		pe.umask  	= it->second.unitmask;
		pe.count 	= it->second.count;
		pe.setOs(it->second.os);
		pe.setUsr(it->second.usr);
		pe.setEdge(false);
		pEbs->getEventContainer()->add(pe);

		// NOTE: Instead of calling enumerateAllOPEvent,
		// we can just simply do this here.
		if (events_map.find(name) == events_map.end()) {
			EventEncodeType eet;
			eet.sortedIndex	= events_map.size();
			eet.weight 	= 1;
			eet.eventCount	= it->second.count; 
			eet.eventMask	= EncodeEventMask(cpu_event.value,
							it->second.unitmask);

			events_map.insert(EventMaskEncodeMap::value_type(name, eet));
		}
	}

} //void ImportController::PopulateEbpSettingsForImportSession

bool ImportController::onImportEbpData ( 
	OP_EVENT_PROPERTY_MAP events_name_map,
	QString sessionName,
	QString sessionNote,
	CEventsFile * eventFile,
	QString import_cpuinfo_path,
	QString op_sample_dir,
	bool isApplyProcessFilter,
	QStringList processFilter)
{
	bool ret = false;

	EventMaskEncodeMap events_map;
	QString caSession = "";
	QString caSessionDir = "";
	vector < string > events_name;

	EBP_OPTIONS *pEbs = new EBP_OPTIONS ();
	if(!pEbs)
	{
		m_importErrorMsg = QString("Error importing profile data into EBP session.") ;
		return ret;
	}

	pEbs->sessionName = sessionName;
	pEbs->sessionNote = sessionNote;
	pEbs->sessionFile = pEbs->sessionName + EBS_FILE_EXT;
	pEbs->msMpxInterval = 0;

	QDir ebs_dir;
	QString ebs_dir_name = QString(m_pCawFile->getDir() + pEbs->sessionFile);
	ebs_dir_name += ".dir";
	ebs_dir.mkdir(ebs_dir_name);

	caSession = ebs_dir_name;
	caSessionDir = caSession;
	caSession += QString("/");
	caSession += QString(pEbs->sessionFile);

	//***********************************************************
	PopulateEbpSettingsForImportSession(pEbs, events_name_map, eventFile, events_map);
	
	//***********************************************************
	// Initialize EBP Session setting

	m_pSession = static_cast<SESSION_OPTIONS *>(new EBP_OPTIONS ());

	EBP_OPTIONS *pEventSession = static_cast <EBP_OPTIONS *> (m_pSession);
	*pEventSession = *pEbs;

	/*****************************************************************
	* Translating Oprofile Samples Phase
	*/	
	m_pCATranslate = new CATranslate();
	if (!m_pCATranslate) {
		m_importErrorMsg = QString("Translate Error: ") 
				+ "failed to create translate object.";
		return ret;
	}

	m_pCATranslate->init( op_sample_dir,
				XpFileContains(import_cpuinfo_path.data(), "processor"),
				ebs_dir_name, events_map, m_pCATranslateDisplay);
	
	/*****************************************************************
 	 * Initialize the process filter for import
 	 */
	QStringList tmpList;
	if(isApplyProcessFilter) {
		pEbs->filterList = processFilter.join(QString(","));
		tmpList = processFilter;
	}
	
	bool rt = m_pCATranslate->translate_op_to_ca(
				getFamilyFromCpuInfo(import_cpuinfo_path.data()),
					getModelFromCpuInfo(import_cpuinfo_path.data()),
					tmpList, caSession);

	/*****************************************************************
	* Adding imported session and open the session window  
	*/
	if (rt) 
	{
		// CSS conversion
		if (QFile::exists(op_sample_dir.section("/", 0, -3) + "/ca_oprofile.cg")
		&& !cssConversion(caSessionDir)) {
			showError(QString("Failed to convert CSS data to") +
			"kcachegrind format.\n");
		}

		m_pCawFile->addSession(pEbs);
		m_pCawFile->saveCawFile ();
		
		m_curSessionName = pEbs->sessionName;
		m_curTrigger     = EVENT_TRIGGER;
	} else {
		folderRemove(ebs_dir_name);
		m_importErrorMsg = QString(NO_SAMPLE_MSG);
		return ret;
	}
	ret = true;
	return ret;
} //bool ImportController::onImportEbpData

bool ImportController::onImportLocalRemoteFile (QString op_sample_dir,
				QString import_cpuinfo_path,		
				bool isApplyProcessFilter,
				QStringList processFilter,
				bool is_remote_import)
{
	QString project_path;
	QStringList path_list;
	OP_EVENT_PROPERTY_MAP events_name_map;
	QString sessionName;
	QString sessionNote;
	CEventsFile * eventFileForImport = new CEventsFile();

	/***********************************************************
	* Sanity check for blank importing path
	*/ 
	if (op_sample_dir.isEmpty())
	{
		m_importErrorMsg = QString("Error: Please specify Oprofile sample dir.\n") 
				+ "( i.e. /var/lib/oprofile/samples/current )" ;
		return false;
	}

	path_list = QStringList::split ("/", op_sample_dir);
	project_path = m_pCawFile->getPath ();
	project_path.truncate (project_path.findRev (XPS_PATH_SLASH) + 1);

	/***********************************************************
	* Acquiring a list of events from the oprofile samples
	*/
	QDir d (op_sample_dir);

	// Sanity check to see if this directory really contains oprofile samples
	// by checking for directory {root} or {kern}
	if ( !d.exists()
	|| ( !d.exists("{root}") && !d.exists("{kern}")))
	{
		m_importErrorMsg = QString("Error: Please specify Oprofile sample dir.\n") 
				+ "( i.e. /var/lib/oprofile/samples/current )\n" 
				+ " or check if directory " 
				+ op_sample_dir + "/{root} or {kern} exists.";
		return false;	
	}

	/***********************************************************
	* If this is a remote import, we have to make sure that
	* we using the event files corresponded to the platform
	*/
	if(is_remote_import)
	{
		QString file; 

		if(QFile::exists(import_cpuinfo_path))
		{
			unsigned long cpuFamily = getFamilyFromCpuInfo(import_cpuinfo_path.data());
			unsigned long cpuModel  = getModelFromCpuInfo(import_cpuinfo_path.data());
			file = helpGetEventFile(cpuFamily, cpuModel);
		}

		eventFileForImport->open(file);
	}else{
		// Check CPU family for the current running platform
		unsigned long cpuFamily = 0;
		unsigned long cpuModel  = 0;
		char VenderId[15];
		unsigned long stepping;
		CpuId(VenderId, &cpuFamily, &cpuModel, &stepping);

		// Get oprofile events directory 
		QString file = helpGetEventFile(cpuFamily, cpuModel);

		eventFileForImport->open(file);
	}
	// ***********************************************************

	if (!validateDirContainsOPSamples (d, *eventFileForImport))
	{
		m_importErrorMsg = QString(NO_SAMPLE_MSG) ;
		return false;
	}

	findOprofileEvents (d, events_name_map);

	bool ret = false;
	// Get session note
	sessionNote = getSessionNote();

	// Handling session name
	sessionName = getNextImportSessionName(EVENT_TRIGGER);

	// Import EBP data
	ret = onImportEbpData ( events_name_map,
		sessionName,
		sessionNote,
		eventFileForImport,
		import_cpuinfo_path,
		op_sample_dir,
		isApplyProcessFilter,
		processFilter);
	if(!ret)
		goto out;

	/*
	* NOTE: If this is a remote import, we also copy the /proc/cpuid
	*	 file in the session directory which will be used 
	* 	 for viewing session property 
	*/ 
	if(ret && is_remote_import)
	{
		if(QFile::exists(import_cpuinfo_path))
		{
			QString session_cpuinfo = QString("\"") 
				+ m_pCawFile->getDir() 
				+ sessionName 
				+ ".ebp"
				+ DIR_FILE_EXT 
				+ "/cpuinfo\"";

			QString command = "cp " + import_cpuinfo_path
				+ " " + session_cpuinfo;
			system(command.data());
		}

		//Also, close the event file.
		eventFileForImport->close();
		if(NULL != eventFileForImport){
			delete eventFileForImport;
			eventFileForImport = NULL;	
		}
	}

out:
	return ret;
} //void ImportController::onImportLocalRemoteFile


/**
* Given a directory, parse the file names in the directory
* to find the events Oprofile profiled.
*/
bool ImportController::findOprofileEvents (const QDir & _d,
			OP_EVENT_PROPERTY_MAP &events_name_map)
{
	QDir d = _d;

	QStringList entries = d.entryList ();
	QStringList::Iterator it     = entries.begin ();
	QStringList::Iterator it_end = entries.end ();
	for (; it != it_end ; ++it)
	{
		if (*it == "." || *it == "..")
			continue;
		QFileInfo info (d, *it);
		if (info.isDir ())
		{
			if (!findOprofileEvents (QDir (info.filePath ()), events_name_map))
				return false;
		}
		else
		{
			parseOPSampleFileName (info.fileName (), events_name_map);
		}
	}

	QString name = d.dirName ();

	if (!d.cdUp ())
		return false;

	return true;
}

bool ImportController::validateDirContainsOPSamples (const QDir & _d, CEventsFile & _e)
{
	QDir d = _d;
	return (findOPSamplesFile (d, _e));
}


bool ImportController::findOPSamplesFile (const QDir & _d, CEventsFile & _e)
{
	QDir d = _d;
	QStringList entries = d.entryList ();
	bool ret = false;

	for (QStringList::Iterator it = entries.begin ();
		it != entries.end (); ++it)
	{
		if (*it == "." || *it == "..")
			continue;
		QFileInfo info (d, *it);
		if (info.isDir ())
		{
			if (!(ret = findOPSamplesFile (QDir (info.filePath ()), _e)))
				continue;
			else
			{
				return ret;
			}
		}
		else
		{
			QString event_name = parseOPSampleFileForEventName (info.fileName ());
			if (_e.isEventExist(event_name))
			{
				return true;
			}
		}
		ret = false;
	}
	return ret;
}

QString ImportController::parseOPSampleFileForEventName (const QString & fname)
{
	QStringList strlist = QStringList::split (".", fname);

	if (1 < strlist.size ())
	{
		return strlist[op_field_name];
	} else {
		return QString ("");
	}
}


void ImportController::parseOPSampleFileName (const QString & fname,
		   OP_EVENT_PROPERTY_MAP &events_name_map)
{
	bool ok;
		
	QStringList strlist = QStringList::split (".", fname);

	if (1 < strlist.size ())
	{

		QString key = "event:" + strlist[op_field_name] + " "
			+ "count:" + strlist[op_field_count] + " "
			+ "unit-mask:" + strlist[op_field_unitmask];

		string parsed_name 			= string (key.data ());
		events_name_map[parsed_name].count 	= strlist[op_field_count].toUInt (&ok);
		events_name_map[parsed_name].unitmask 	= strlist[op_field_unitmask].toUInt (&ok);
		events_name_map[parsed_name].os 	= true;
		events_name_map[parsed_name].usr 	= true;
		events_name_map[parsed_name].op_name 	= parsed_name.c_str ();
	}
}

QString ImportController::getNextImportSessionName(TRIGGER trigger)
{
	RUN_SETTING * pRunSetting;
	QString importSessionName;

	pRunSetting = m_pCawFile->getRunSetting (m_pCawFile->getLastRunSettingName());
	if (pRunSetting)
		importSessionName = pRunSetting->sessionName;
	importSessionName += QString(" - Import ");

	importSessionName = m_pCawFile->getNextSessionName(trigger, importSessionName);
	return importSessionName;
}


QString ImportController::getSessionNote()
{
	RUN_SETTING * pRunSetting;

	pRunSetting = m_pCawFile->getRunSetting (m_pCawFile->getLastRunSettingName());
	if (pRunSetting)
		return pRunSetting->sessionNote;
	else
		return QString("");
}

void ImportController::showWarning(QString msg) 
{
	if (m_isGui) {
		QMessageBox::warning( NULL, "CodeAnalyst Warning", msg);
	} else { 
		fprintf (stderr, "WARNING: %s\n", msg.ascii());
	}
}

void ImportController::showError(QString msg) 
{
	if (m_isGui) {
		QMessageBox::critical( NULL, "CodeAnalyst Warning", msg);
	} else { 
		fprintf (stderr, "ERROR: %s\n", msg.ascii());
	}
}
