// ViewConfigAPI.h: API interface for view configuration class

/*
// CodeAnalyst for Open Source
// Copyright 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _VIEWCONFIGAPI_H_
#define _VIEWCONFIGAPI_H_

// Include Qt-related definitions
#include <qstring.h>
#include <qfile.h>
#include <qtextstream.h>
#include <qxml.h>

#include <list>
using namespace std ;

//
// Linux
// VIEWCONFIGAPI_EXPORTS should be defined to be empty
//
#define VIEWCONFIGURE_API

//
// Performance event configuration - must be encoded with event select,
// unit mask, etc. using the field layout of the Performance
// Counter Select register
//
typedef UINT64 EventConfig ;

//
// ColumnType specifies how column content is used and shown
//
typedef enum
{
	ColumnInvalid,     // For initialization
	ColumnValue,       // Show data as a simple umodified value
	ColumnSum,         // Compute and show sum of two data values
	ColumnDifference,  // Compute and show difference of two data values
	ColumnProduct,     // Compute and show product of two data values
	ColumnRatio        // Compute and show ratio of two data values
} ColumnType ;

//
// ColumnSorting controls how data is sorted in a column
//
typedef enum
{
	NoSort,            // Don't sort data in column
	AscendingSort,     // Sort in ascending order
	DescendingSort     // Sort in descending order
} ColumnSorting ;

//
// A ColumnSpec describes a column in a view
//
typedef struct
{
	ColumnType    type ;             // Controls data display
	ColumnSorting sorting ;          // Control data sorting
	bool          visible ;          // Shows column (T) or hides it (F)
	QString       title ;            // Column title or legend to display
	EventConfig   dataSelectLeft ;   // Selects data for left operand/value
	EventConfig   dataSelectRight ;  // Selects data for right operand
} ColumnSpec ;

//
// This type is for internal use only. It is not exportable through
// the DLL interface. It is used during XML processing to build a list
// of column specifications. Once the list is built, it is copied to
// an array of column specifications and the list is discarded. This
// lets us handle a variable number of column specs on input before
// the exact number of columns is known.
//
typedef list<ColumnSpec> ColumnSpecList ;

//
// Maintains an association between a readable ID and an event
// configuration value. The readable IDs are used in the <output>
// section of the XML file to refer to data for specific events.
//
typedef struct
{
	QString     eventId ;     // Event/data identifier
	EventConfig eventConfig ; // Event configuration value
} DataAssoc ;

//
// This type is for internal use only. It is not exportable through
// the DLL interface. It maintains the list of ID/event associations
// for the view configuration. This list determines the events that
// are needed to display the view. Thus, if data for an event are to
// to be displayed, there must be an entry for the event in this list.
//
typedef list<DataAssoc> DataAssocList ;

///////////////////////////////////////////////////////////////////////////////
// CViewConfig class declaration
///////////////////////////////////////////////////////////////////////////////

class VIEWCONFIGURE_API CViewConfig : public QXmlDefaultHandler
{
public:

	///////////////////////////////////////////////////////////////////////
	// Constructors, destructors, assignment
	///////////////////////////////////////////////////////////////////////
	CViewConfig() ;
	CViewConfig(const CViewConfig& original) ;
	~CViewConfig() ;
	const CViewConfig& operator = (const CViewConfig& rhs) ;

	///////////////////////////////////////////////////////////////////////
	// Client functions for a view configuration
	///////////////////////////////////////////////////////////////////////

	// Basic mutator and accessor methods
	void SetConfigName(const QString name) ;
	void GetConfigName(QString& name) ;
	void SetSeparateCPUs(bool flag) { m_separateCPUs = flag ; }
	bool GetSeparateCPUs() { return( m_separateCPUs ) ; }
	void SetSeparateProcesses(bool flag) { m_separateProcesses = flag ; }
	bool GetSeparateProcesses() { return( m_separateProcesses ) ; }
	void SetSeparateThreads(bool flag) { m_separateThreads = flag ; }
	bool GetSeparateThreads() { return( m_separateThreads ) ; }
	void SetDefaultView(bool flag) { m_defaultView = flag ; }
	bool GetDefaultView() { return( m_defaultView ) ; }
	void SetShowPercentage(bool flag) { m_showPercentage = flag ; }
	bool GetShowPercentage() { return( m_showPercentage ) ; }
	void SetToolTip(const QString toolTip) ;
	void GetToolTip(QString& toolTip) ;
	void SetDescription(const QString description) ;
	void GetDescription(QString& description) ;

	// Determine if this view is displayable from available events
	bool isViewDisplayable(EventConfig* pAvailable, 
		int numberOfEvents, bool testUnitMask = false) ;

	// Define column specifications for the view; Generate ID/event
	// associations when the argument generateDataSpecs is true
	void SetColumnSpecs(ColumnSpec* columnSpecArray, int numberOfColumns,
		const int generateDataAssocs = true) ;
	// Make column specifications from an array of EventConfig values
	void MakeColumnSpecs(int numberOfEvents, EventConfig* pEvents,
		QStringList titles, const int generateDataAssocs = true) ;
	// Return the number of columns in the view (number of column specs)
	int GetNumberOfColumns() { return( m_numberOfColumns ) ; }
	// Return column specifications in the array allocated by the caller
	void GetColumnSpecs(ColumnSpec* columnSpecArray) ;
	// Static class method to copy an array of ColumnSpec
	static void CopyColumnSpecs(ColumnSpec* fromArray,
		ColumnSpec* toArray, int size) ;

	// Read a view configuration in XML from the specified file
	bool ReadConfigFile(wchar_t* configFileName) ;
	// Write the current view configuration in XML to the specified file
	bool WriteConfigFile(wchar_t* configFileName) ;

	// Define a data/event configuration association
	void AddAssoc(const QString id, EventConfig config) ;
	void AddAssoc(const QString id, 
		unsigned int select, unsigned int unitMask) ;
	// Find data/event configuration association by id or value
	bool FindAssocById(const QString id, DataAssoc& assoc) ;
	bool FindAssocByConfig(EventConfig config, DataAssoc& assoc) ;
	bool FindAssocByValue(unsigned int select,
		unsigned int unitMask, DataAssoc& assoc) ;
	// Return EventConfig given an event ID
	EventConfig GetConfigById(const QString id) ;

	///////////////////////////////////////////////////////////////////////
	// Callback functions which override QXmlDefaultHandler
	///////////////////////////////////////////////////////////////////////
	bool startDocument() ;
	bool endDocument() ;
	bool startElement(
		const QString& namespaceURI, const QString& localName,
		const QString& qName, const QXmlAttributes& atts) ;
	bool endElement(
		const QString& namespaceURI, const QString& localName,
		const QString& qName) ;
	bool characters(const QString& ch) ;

	// Encode a 12-bit select and unit mask into an event configuration
	static EventConfig EncodeConfig(unsigned int select, unsigned int unitMask) ;
	// Extract a 12-bit select value from an event configuration
	static unsigned int ExtractSelect(EventConfig config) ;
	// Extract an 8-bit unit mask value from an event configuration
	static unsigned int ExtractUnitMask(EventConfig config) ;
private:
	///////////////////////////////////////////////////////////////////////
	// Private functions
	///////////////////////////////////////////////////////////////////////
	// Generate data/event configuration associations for column specs
	void GenerateDataAssocs(ColumnSpec* columnSpecArray, int numberOfColumns) ;
	// Return true if config is in the array of event configurations
	bool FindEventConfig(EventConfig config, 
		EventConfig* pArray, int numberOfEvents, bool testUnitMask) ;

	///////////////////////////////////////////////////////////////////////
	// Private functions to assist configuration writing
	///////////////////////////////////////////////////////////////////////
	// Write tool tip element to the XML stream
	void WriteTooltip(QTextStream& xmlStream, QString& text) ;
	// Write description element to the XML stream
	void WriteDescription(QTextStream& xmlStream, QString& text) ;
	// Write string-valued attribute to the XML stream
	void WriteStringAttr(QTextStream& xmlStream, const char* attr, const QString& value) ;
	// Write integer-valued attribute (decimal format) to the XML stream
	void WriteDecimalAttr(QTextStream& xmlStream, const char* attr,
		unsigned long long int value) ;
	// Write integer-valued attribute (hexadecimal format) to the XML stream
	void WriteHexAttr(QTextStream& xmlStream, const char* attr,
		unsigned long long int value) ;
	// Write float-valued attribute (decimal format) to the XML stream
	void WriteFloatAttr(QTextStream& xmlStream, const char* attr, float value) ;
	// Write Boolean-valued attribute to the XML stream
	void WriteBoolAttr(QTextStream& xmlStream, const char* attr, bool value) ;
	// Write the <data> element to the XML stream
	void WriteData(QTextStream& xmlStream) ;
	// Write an event ID to the XML stream
	void WriteEventId(QTextStream& xmlStream, const char* attr, const EventConfig& config) ;
	// Write an arithmetic relationship to the XML stream
	void WriteArith(QTextStream& xmlStream, const ColumnSpec& column) ;
	// Write a <column> element to the XML stream
	void WriteColumn(QTextStream& xmlStream, const ColumnSpec& column) ;
	// Write the <output> element to the XML stream
	void WriteOutput(QTextStream& xmlStream) ;
	// Write the <view> element to the XML stream
	void WriteView(QTextStream& xmlStream) ;


private:
	// Configuration attributes
	QString m_configName ;        // Configuration name
	QString m_toolTip ;           // Tooltip for the configuration
	QString m_description ;       // Short description of the configuration
	bool m_separateCPUs ;         // Separate CPUs (T) or aggregated (F)
	bool m_separateProcesses ;    // Separate processors (T) or aggregated (F)
	bool m_separateThreads ;      // Separate threads (T) or aggregated (F)
	bool m_defaultView ;          // Candidate default view (T) or not (F)
	bool m_showPercentage ;       // Show %'tage column in view (T) or not (F)
	DataAssocList m_assocList ;   // List of ID/event select associations
	int m_numberOfColumns ;       // Number of columns / columns specs
	ColumnSpec* m_columnSpecs ;   // Column specifications (1D array)

	// Private data members for XML handling
	bool m_viewIsOpen ;           // <view> element is open
	bool m_dataIsOpen ;           // <data> element is open
	bool m_columnIsOpen ;         // <column> element is open
	bool m_outputIsOpen ;         // <output> element is open
	bool m_toolTipIsOpen ;        // <tool_tip> element is open
	bool m_descriptionIsOpen ;    // <dscription> element is open
	bool m_xmlSemanticError ;     // Is true on XML semantic error
	ColumnSpecList m_columnList ; // Temporary list of column specs
} ;

#endif  // _VIEWCONFIGAPI_H_
