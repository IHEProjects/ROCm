//$Id: atuneoptions.h,v 1.4 2006/05/15 22:09:22 jyeh Exp $
// Interface for CATuneOptions class, which encapsulates dealings with the
//  application settings.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _ATUNEOPTIONS_H
#define _ATUNEOPTIONS_H

#include <qsettings.h>
#include <qvaluevector.h>

#include "typedefs.h"
#include "config.h"

#define CODEANALYSTRC_VERSION "version3"

#define OPT_DATA_PREFIX "/CodeAnalyst/" CODEANALYSTRC_VERSION  

#define OPT_DATA_AGGREGATION OPT_DATA_PREFIX "/DataAgg"
enum DataAggregationType 
{
	AGG_INLINEINSTANCE = 0,
	AGG_INLINEFUNCTION,
	AGG_BASICBLOCK	
};

#define OPT_BYPASS_SOURCE OPT_DATA_PREFIX "/BypassSource"
enum BypassSourceType
{
	NO_BYPASS_SOURCE = 0,
	BYPASS_SOURCE
};

#define OPT_SOURCE_ALERT OPT_DATA_PREFIX "/AlertNoSource"
enum SourceAlertType
{
	NO_SOURCE_ALERT = 0,
	SOURCE_ALERT
};

#define OPT_USE_HOTKEYS OPT_DATA_PREFIX "/UseHotKeys"
enum UseHotkeysType
{
	NO_HK_USE = 0,
	HK_USE
};

#define OPT_REPLACESYSDIR OPT_DATA_PREFIX "/ReplaceSysDir"
enum ReplaceSysDirType
{
	REPLACE_SYSDIR = 0,
	NO_REPLACE_SYSDIR
};

#define OPT_PROJDIR OPT_DATA_PREFIX "/DefaultProjectDir"
#define OPT_SEARCH_PATHS OPT_DATA_PREFIX "/DebugSearchPaths"

#define OPT_MRUCAWLIST OPT_DATA_PREFIX "/MruCawList"
#define OPT_COLUMN_MASK OPT_DATA_PREFIX "/MColumnsShown"

#define OPT_FONT_SIZE OPT_DATA_PREFIX "/FontSize"
enum CaFontSizes
{
	FONT_CMB_SMALL = 0,
	FONT_CMB_DEFAULT,
	FONT_CMB_LARGE,
	FONT_SIZE_SMALL = 8,
	FONT_SIZE_DEFAULT = 10,
	FONT_SIZE_LARGE = 14
};

#define OPT_EVENT_SORT OPT_DATA_PREFIX "/EventSort"
enum EventSortType
{
	NO_SORT_BY_INDEX = 1
};

#define OPT_CHART_DENSITY OPT_DATA_PREFIX "/ChartDensity"
enum ChartDensityShownType
{
	NO_SHOW_CHART_DENSITY = 0,
	SHOW_CHART_DENSITY
};

enum BuffDefaultSizeType
{
	OP_DEFAULT_BUFFER_SIZE 		= 4194304,
	OP_DEFAULT_WATERSHED_SIZE 	= 131072, 
	OP_DEFAULT_CPU_BUFFER_SIZE 	= 32768 
};

#define OPT_IMPORT_TYPE OPT_DATA_PREFIX "/ImportType"
enum ImportType
{
	REMOTE_PROFILE = 0,
        LOCAL_PROFILE,
        EBP_PROFILE,
        XML_PROFILE
};

#define OPT_JAVA_JPA OPT_DATA_PREFIX "/JPA"
enum JPAType
{
	JVMPI = 0,
	JVMTI
};

#define OPT_OP_MERGE_LIB OPT_DATA_PREFIX "/OPMergeLib"
enum OPMergeLib
{
	NO_MERGE_LIB = 0,
	MERGE_LIB
}; 

#define OPT_OP_EXCLUDE_DEP OPT_DATA_PREFIX "/OPExcludeDep"
enum OPExcludeDep
{
	NO_EXCLUDE_DEP = 0,
	EXCLUDE_DEP
};

#define OPT_SHOW_AGG_CONTROLLER OPT_DATA_PREFIX "/ShowAggController"
enum AggControllerType
{
	NO_SHOW_AGG_CONTROLLER = 0,
	SHOW_AGG_CONTROLLER
};


#define OPT_IMPORT_OPDIR OPT_DATA_PREFIX "/ImportOPDir" 
#define OPT_IMPORT_TAR  OPT_DATA_PREFIX "/ImportTAR"
#define OPT_PLUG_IN OPT_DATA_PREFIX "/OPPlugIn"

#define OPT_COLOR_LIST  OPT_DATA_PREFIX "/CpuColorList"
#define CA_PRECISION_KEY  OPT_DATA_PREFIX "/Precision"
typedef QValueVector<QColor> ColorList;
//depreciated defines
#define COLOR_LIST_SIZE 32

class CATuneOptions
{
private:
	QSettings m_qsetting;
	QSettings m_user;
public:
	CATuneOptions();
	~CATuneOptions();

	bool getShowAggregationController(uint * show);
	bool setShowAggregationController(uint show);

	bool getDataAggregation(uint * data_agg);
	bool setDataAggregation(uint data_agg);

	bool getBypassSource (uint * bypass_source);
	bool setBypassSource (uint bypass_source);

	bool getAlertNoSource (uint * alert_no_source);
	bool setAlertNoSource (uint alert_no_source);

	bool getReplaceSysDir (uint * replace);
	bool setReplaceSysDir (uint  replace);

	bool getUseHotKeys (uint * use_hot_keys);
	bool setUseHotKeys (uint  use_hot_keys);

	bool getDefaultProjectDir (QString & pro_dir);
	bool setDefaultProjectDir (QString & pro_dir);

	bool getDebugSearchPaths (QString & search_path);
	bool setDebugSearchPaths (QString & search_path);

	bool getMruFileList (QString & mru);
	bool setMruFileList (QString & mru);

	bool getNoVmlinux (uint * no_vmlinux);
	bool setNoVmlinux (uint  no_vmlinux);

	bool getVmlinuxDir (QString & vmlinux_dir);
	bool setVmlinuxDir (QString & vmlinux_dir);
	
	bool getBufferSize (uint * buffer_size);
	bool setBufferSize (uint buffer_size);

	bool getWatershedSize (uint * watershed_size);
	bool setWatershedSize (uint watershed_size);

	bool getCpuBufSize (uint * cpu_buf_size);
	bool setCpuBufSize (uint cpu_buf_size);

	bool getFontSize (uint * buffer_size);
	bool setFontSize (uint buffer_size);

	bool getSortEventByIndex (uint * sort_by_index);
	bool setSortEventByIndex (uint sort_by_index);

	bool getShowChartDensity (uint *show_chart_density);
	bool setShowChartDensity (uint show_chart_density);

	bool getImportType(uint * import_type);
	bool setImportType(uint import_type);

	bool setImportOpdir(QString & pro_dir);
	bool getImportOpdir(QString & prd_path);

	bool setImportTAR(QString & jnc);
	bool getImportTAR(QString & jnc);

	bool getImportMergeByLib(uint * merge_by_lib);
	bool setImportMergeByLib(uint merge_by_lib);

	bool getImportExcludeDep(uint * exclude_dep);
	bool setImportExcludeDep(uint exclude_dep);


	bool getOPPlugIn(QString & name);
	bool setOPPlugIn(QString & name);

	bool getJPA(uint * jpa_type);
	bool setJPA(uint jpa_type);

	bool getCpuColorList ( ColorList *pColorList);
	bool setCpuColorList ( const ColorList *pColorList);

	bool getShowRunOptions ();
	bool setShowRunOptions (bool showRunOptions);

	bool getPrecision (int *pPrecision);
	bool setPrecision (int precision);
	//depreciated
	bool getCpuColorList ( QColor color_list[COLOR_LIST_SIZE]);
	bool setCpuColorList ( QColor color_list[COLOR_LIST_SIZE]);
};

#endif // #ifndef _ATUNEOPTIONS_H
