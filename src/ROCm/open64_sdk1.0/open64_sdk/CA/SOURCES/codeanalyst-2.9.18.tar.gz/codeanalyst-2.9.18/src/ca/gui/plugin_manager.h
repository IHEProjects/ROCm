#ifndef _PLUGIN_MANAGER_CPP_
#define _PLUGIN_MANAGER_CPP_

#include <dlfcn.h>
#include <string>

#include "opdata_handler.h"
#include "output.h"

#define OP_072_PLUGIN "libopdata072.so"
#define OP_081_PLUGIN "libopdata081.so"
#define OP_091_PLUGIN "libopdata091.so"

class PlugInManager
{

public:
	PlugInManager();
	~PlugInManager();
	bool load_opdata_plugin();
	bool load_output_plugin();
	void unload_opoutput_plugin(output * output);
	void unload_opdata_plugin(opdata_handler * opdata);
	create_opdata_t * create_opdata;
	delete_opdata_t * delete_opdata;

protected:
	void show_error(const char * so_name);
	void * opdata_handle;
	void * ca_output_handle; 


};

#endif
