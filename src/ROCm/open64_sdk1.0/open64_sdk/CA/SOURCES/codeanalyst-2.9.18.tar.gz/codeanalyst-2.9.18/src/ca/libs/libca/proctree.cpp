//$Id: proctree.cpp,v 1.2 2006/05/15 22:09:45 jyeh Exp $

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include <stdio.h>

#include "proctree.h"


//////////////////////////////////////////////////////////////////////////
// Module::Module()
// ----------------
//
Module::Module()
{
	Name	  = NULL;
	Path	  = NULL;
	size	  = 0;
	Base	  = 0;
	total	  = 0;
	long_mode = false;
	m_ModType = UNMANAGEDPE;
	taskId	  = 0;
}

/////////////////////////////////////////////////////////////////////////
// Module::~Module()
// -----------------
//
Module::~Module()
{
	if( Path != NULL )
	{
		delete Path;
		Path = NULL;
	}

	if( Name != NULL ) 
	{
		delete Name;
		Name = NULL;
	}
	
	Functions.clear();
}

//////////////////////////////////////////////////////////////////////////
// Module::SetName()
// -----------------
//
void
Module::SetName( const char *pString )
{
	if( Name != NULL )
	{
		delete Name;
		Name = NULL;
	}
	
	size_t malloc_size = strlen(pString) + 1;
	Name = new char[malloc_size];
	strcpy( Name, pString );
}

char * Module::GetName() const
{
	return Name;
}

char * Module::GetPath() const
{
    return Path;
}


//////////////////////////////////////////////////////////////////////////
// Module::SetPath()
// -----------------
//
void
Module::SetPath( const char *pString )
{
	if( Path != NULL )
	{
		delete Path;
		Name = NULL;
	}

	size_t malloc_size = strlen(pString) + 1;
	Path = (char*)new char[malloc_size]; 
	strcpy( Path, pString );
}


//////////////////////////////////////////////////////////////////////////
// Function::SetName()
// -----------------
//
void
Function::SetName( const char *pString )
{
	if( Name != NULL ) {
		delete Name;
		Name = NULL;
	}

	size_t malloc_size;
	if (NULL != pString)
		malloc_size = strlen(pString) + 1;
	else
		malloc_size = 1;

#ifdef _DEBUG
	if( malloc_size >= 0x7ffdefff )
	{
		assert( false );
	}
#endif

	Name =  new char[malloc_size];
	if ((Name) && (malloc_size > 1))
		strcpy( Name, pString );
	else
		Name[0] = '\0';
}

///////////////////////////////////////////////////////////////////////////////
// Function::GetName()
// -------------------
//
char *
Function::GetName()
{
	return Name;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// Function::Function()
// --------------------
//
Function::Function()
{
	Name    = NULL;
	Address = 0;
	total   = 0;
	taskId  = 0;
}

//////////////////////////////////////////////////////////////////////
// Function::~Function()
// ---------------------
//
Function::~Function()
{
	if( Name != NULL )
	{
		delete Name;
		Name = NULL;
	}
}
