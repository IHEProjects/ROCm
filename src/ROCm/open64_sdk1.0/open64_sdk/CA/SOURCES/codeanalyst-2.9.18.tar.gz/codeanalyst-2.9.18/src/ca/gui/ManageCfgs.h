//$Id: ManageCfgs.h 17169 2009-10-14 18:11:41Z ssuthiku $
//  This is our derivative of the IManageCfgs.ui

/**
*   (c) 2006 Advanced Micro Devices, Inc.
*  YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
*  AND CONDITIONS OF THE GNU GENERAL PUBLIC
*  LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS
*  INCLUDED WITH THIS FILE AND POSTED AT
*  <http://www.gnu.org/licenses/gpl.html>
*  Support: codeanalyst@amd.com
*/
#ifndef MANAGE_CFGS_H
#define MANAGE_CFGS_H

#include "iManageCfgs.h"
#include "ProfileCollection.h"


class ManageCfgsDlg : public IManageCfgs
{ 
	Q_OBJECT
public:
	ManageCfgsDlg ( ProfileCollection *pProfiles, 
			QWidget* parent = 0,
			bool showEdit = true, 
			const char* name = 0, 
			bool modal = true, 
			WFlags fl = WStyle_Customize 
				| WStyle_DialogBorder 
				| WStyle_Title 
				| WDestructiveClose );

	~ManageCfgsDlg ();

public slots:
	void onRemove ();
	void onEdit ();
	void onExport ();
	void onImport ();
	void onRename();

private:
	void refreshList ();

private:
	ProfileCollection 	*m_pCollection;
};

#endif
