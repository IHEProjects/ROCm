//$Id: javasourceview.cpp,v 1.8 2006/05/15 22:09:22 jyeh Exp $
//  implementation of the CJavaSourceView class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/
#include "javasourceview.h"
#include "assert.h"
#include "elfreader.h"
#include "EventMaskEncoding.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CJavaSourceView::CJavaSourceView( ViewShownData *pViewShown, VADDR Address, 
								 SampleMap SampMap,  QWidget* parent,
								 QString jncDir,	  const char* name, 
								 ProfileAttribute profInfo, 
								 JitBlockMap jitBlockMap,
								 int wflags ) 
								 : DataTab (pViewShown, parent, name, wflags)
{
	m_indexOffset = SRC_OFFSET_INDEX;
	m_exportString = "&Export source data...";
	setDockMenuEnabled (false);

	m_pItemOfInterest = NULL;
	m_pSrcInfo = NULL;
	m_dataSecOffset = 0;
	m_Address    = Address;
	m_SampleMap  = SampMap;
	m_jncDir = jncDir;
	m_jitBlockMap = jitBlockMap;

	m_progressDlg.setFont( STD_FONT );
	m_progressDlg.setCancelButtonText( 0 );

	setFont( QFont( "Lucida Console", 8 ) );
	setGeometry( QRect(100, 100, 640, 480) );

	m_profInfo.modPatchLoadAddr = profInfo.modPatchLoadAddr;
	m_profInfo.modPath = profInfo.modPath;
	m_profInfo.modType = profInfo.modType;
	m_profInfo.totalSamples = profInfo.totalSamples;

	// create our source list view
	m_pSourceList	= new ChartListView( this );
	m_pList = m_pSourceList;

	m_pList->addColumn ( "Location", 80 );
	m_pList->setColumnAlignment( SRC_ADDRESS_COLUMN, AlignLeft );
#ifdef __x86_64__
	m_pSourceList->addColumn( "Address",	160 );
#else
	m_pSourceList->addColumn( "Address",	80 );
#endif

	m_pList->addColumn ( "Line", 30 );
	m_pList->setColumnAlignment( SRC_LINE_COLUMN, AlignRight );
	m_pList->addColumn ( "Source",	500 );
	m_pList->setColumnAlignment( SRC_SOURCE_COLUMN, AlignLeft );

	// Enable sorting for the source list
	m_pSourceList->setSorting(SRC_LINE_COLUMN, TRUE);
	m_pSourceList->setShowSortIndicator( TRUE );

	// + mark on the root
	m_pSourceList->setRootIsDecorated( TRUE );

	// full row select
	m_pSourceList->setAllColumnsShowFocus( TRUE );

	// Disable clicking on Source column
	m_pSourceList->header()->setClickEnabled( FALSE, SRC_SOURCE_COLUMN );

	setFocusProxy   ( m_pSourceList );
	setCentralWidget( m_pSourceList );

	m_pMenu = new QPopupMenu( this );

	// enable multiple selection and connect selectionChanged()
	m_pSourceList->setSelectionMode (QListView::Extended);
	QObject::connect(m_pSourceList, SIGNAL(selectionChanged ( )), this, 
		SLOT(OnSelectionChange( )));
	QObject::connect( m_pSourceList, SIGNAL( rightButtonClicked ( 
		QListViewItem *, const QPoint &, int ) ), 
		SLOT( OnRightClick( QListViewItem *, const QPoint &,
		int ) ) );
	QObject::connect (m_pSourceList, SIGNAL (contextMenuRequested (
		QListViewItem *, const QPoint &, int)),
		SLOT (OnRightClick (QListViewItem *, const QPoint &,
		int)));

	QObject::connect (m_pSourceList, SIGNAL(contentsRedrawn()),
		this, SLOT (OnListRedrawn()));

	QObject::connect (m_pSourceList->header(), SIGNAL(clicked(int)),
		this, SLOT (OnHeaderClicked (int)));

	m_pMenu->insertItem( "Copy selection to buffer", this, 
		SLOT(onCopySelection()), CTRL+Key_C );

	SampleMap::iterator sampleIter = m_SampleMap.begin();
	m_moduleSamples = 0;
	for (; sampleIter != m_SampleMap.end(); sampleIter++) {
		UINT tNum;
		//sscanf( sampleIter.data().Samples.data(), "%u", &tNum );
		m_moduleSamples += tNum;
	}
	setDockMenuEnabled (false);
}


CJavaSourceView::~CJavaSourceView()
{
	if (m_pSourceList)
		delete m_pSourceList;

	if (m_pMenu)
		delete m_pMenu;

	if (m_pSrcInfo)
		delete m_pSrcInfo;
}


void CJavaSourceView::ReadSourceFileMap()
{
	QString srcMapFileName;
	srcMapFileName = m_jncDir + JAVASRCFILEMAP;

	QFile MapFile(srcMapFileName);
	QTextStream stream(&MapFile);
	QString    line;

	// open the file, creating if necessary
	if( !MapFile.open( IO_ReadOnly ) ) return ;

	// clear the previous map
	m_SrcFileMap.clear();

	while( !stream.eof() )
	{
		QString javaSrc;
		QString  javaSrcFilePath;

		// read the next line, which contains SRC.java=path src.java
		line = stream.readLine();

		javaSrcFilePath  = line.section ("=",1);
		javaSrc	= line.section ("=",0,0);

		m_SrcFileMap[javaSrc] = javaSrcFilePath;
	}

	MapFile.close();

}


void CJavaSourceView::WriteSourceFileMap()
{
	QString srcMapFileName;
	srcMapFileName = m_jncDir + JAVASRCFILEMAP;

	QFile MapFile(srcMapFileName);
	QTextStream stream(&MapFile);
	QCString line;

	if( !MapFile.open( IO_ReadWrite | IO_Translate | IO_Truncate ) ) return;

	JavaSrcFileMap::Iterator srcIter;

	for( srcIter = m_SrcFileMap.begin(); srcIter != m_SrcFileMap.end(); 
		++srcIter )
	{
		stream << srcIter.key().data() << "=" << srcIter.data().data() << endl;
	}

	MapFile.close();
}

void
CJavaSourceView::Tag( QString caption )
{
	m_Caption = caption;
	m_densityChart->setCaption (caption);

}


//////////////////////////////////////////////////////////////////////////
// CSourceView::Initialize()
// -------------------------
//
bool
CJavaSourceView::Initialize()
{
	bool bRet = false;
	QString tJavaSrc = "";
	QString tJavaSrcPath = "";

	//add view submenu
	if (!initMenu ())
		return false;

	m_pMenu->insertItem ("&Show", m_pColumnMenu);

	// find java src file (which is myexample.java, Note: no path.
	JitBlockMap::iterator jitIter = m_jitBlockMap.find(m_Address);
	if (jitIter != m_jitBlockMap.end())
	{	
		tJavaSrc = jitIter->second.javaSrcFile;
	} else {
		return bRet;
	}

	m_densityChart = new SrcDensityView (this);
	RETURN_FALSE_IF_NULL (m_densityChart, this);
	if (! m_densityChart->initialize (m_pViewShown, m_profInfo))
		return false;

	//If the chart is double clicked, go to that address
	QObject::connect(m_densityChart, SIGNAL (newHotSpot (VADDR, 
						QString, SampleMap *)),
		this, SLOT (OnNewJavaHotspot (VADDR, QString, SampleMap* )));

	// read src file map from SessionJitDir\javasrc.map
	ReadSourceFileMap();

	JavaSrcFileMap::Iterator srcIter = m_SrcFileMap.find(tJavaSrc);
	if (srcIter != m_SrcFileMap.end())
		tJavaSrcPath = srcIter.data();

	if (!QFile::exists(tJavaSrcPath))
	{
		// We did not find the file, ask user where they are.
		// Save the path of the user selected and use it next time.
		QString fn = QFileDialog::getOpenFileName( tJavaSrc, 
			"Java Source File (*.java)" , this );

		if ( !fn.isEmpty() ) 
			tJavaSrcPath = fn;
	}

	if (QFile::exists(tJavaSrcPath))
	{
		m_SourceFilePath = tJavaSrcPath;
		m_SrcFileMap[tJavaSrc] = m_SourceFilePath;
		WriteSourceFileMap();
		bRet = true;
	}

	return bRet;
}


void
CJavaSourceView::ReorderInstNumbers(QListViewItem *plistviewItem)
{
	QListViewItem *pInstItem = NULL;

	if (plistviewItem != NULL)
	{
		int itemCount = 0;

		QString buff;
		for (; pInstItem != NULL; pInstItem = pInstItem->nextSibling())
		{
			buff.sprintf( "%u", ++itemCount );
			pInstItem->setText(SRC_LINE_COLUMN, buff);
		}
	}
}


void
CJavaSourceView::SwapFrist2Items(QListViewItem *plistviewItem)
{
	QListViewItem *pFirstItem = NULL;
	QListViewItem *pSecondItem = NULL;

	do {
		if(plistviewItem == NULL)
			break;

		pFirstItem = plistviewItem->firstChild();
		if (NULL == pFirstItem)
			break;

		pSecondItem = pFirstItem->nextSibling();
		if (pSecondItem == NULL)
			break;

		QString addrStr;
		QString sourceStr;
		QString lineNumStr;

		addrStr = pFirstItem->text(SRC_ADDRESS_COLUMN);

		sourceStr = pFirstItem->text(SRC_SOURCE_COLUMN);

		lineNumStr = pFirstItem->text(SRC_LINE_COLUMN);

		pFirstItem->setText(SRC_ADDRESS_COLUMN, pSecondItem->text(SRC_ADDRESS_COLUMN));
		pFirstItem->setText(SRC_SOURCE_COLUMN, pSecondItem->text(SRC_SOURCE_COLUMN));
		pFirstItem->setText(SRC_LINE_COLUMN, pSecondItem->text(SRC_LINE_COLUMN));

		pSecondItem->setText(SRC_ADDRESS_COLUMN, addrStr);
		pSecondItem->setText(SRC_SOURCE_COLUMN, sourceStr);
		pSecondItem->setText(SRC_LINE_COLUMN, lineNumStr);
	} while (0);
}


QListViewItem*
CJavaSourceView::GetPrecedingChildItem(QListViewItem *plistviewItem, VADDR addr )
{
	QListViewItem *pRetInstItem = NULL;

	QListViewItem *pInstItem = NULL;

	if (plistviewItem != NULL)
	{
		pInstItem = plistviewItem->firstChild();
		for (; pInstItem != NULL; pInstItem = pInstItem->nextSibling())
		{
			VADDR itemAddr;
#ifdef __x86_64__
			itemAddr = pInstItem->text(SRC_ADDRESS_COLUMN).toULongLong (NULL, HEX_BASE);
#else
			itemAddr = pInstItem->text(SRC_ADDRESS_COLUMN).toULong (NULL, HEX_BASE);
#endif
			if (itemAddr < addr)
				pRetInstItem = pInstItem;
			else
				break;
		}
	}

	return pRetInstItem;
}


/*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* CSourceView::OnNewJavaHotspot()
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
void CJavaSourceView::OnNewJavaHotspot( VADDR addr, QString caption )
{
	bool found = false;

	if( caption != m_Caption )
		return;

	for( QListViewItem *pItem=m_pSourceList->firstChild();
		pItem!=NULL; pItem=pItem->nextSibling() ) {
			QListViewItem	*pChild;
			UINT64			itemAddr = 0;

			for( pChild = pItem->firstChild(); pChild != NULL; 
				pChild = pChild->nextSibling() ) {

#ifdef __x86_64__
					itemAddr = pChild->text(SRC_ADDRESS_COLUMN).toULongLong (NULL, HEX_BASE);
#else
					itemAddr = pChild->text(SRC_ADDRESS_COLUMN).toULong (NULL, HEX_BASE);
#endif

					if ( itemAddr == addr ) {
						m_pSourceList->ensureItemVisible ( pChild );
						pChild->setSelected ( true );

						QListViewItem * line_item = pChild->parent();
						unsigned int line = 1;
						if (NULL != line_item)
							line = line_item->text(SRC_LINE_COLUMN).toUInt();
						else
							line = pChild->text (SRC_LINE_COLUMN).toUInt();

						m_densityChart->setInterestPoint (line);
						found = true;
						break;
					}

			}
			//break at the first found line, don't keep looking inside other lines
			if (found) break;
	}
}


//////////////////////////////////////////////////////////////////////////
// CSourceView::DispalyCCode()
// ---------------------------
//
void CJavaSourceView::DisplayJavaSource()
{
	QFile			*pFile = new QFile(m_SourceFilePath);
	RETURN_IF_NULL (pFile, this);
	QTextStream		stream;
	QString			srcstring;

	CSourceTabItem *pItem;
	DWORD			lineno;
	SRC_LV_ITEM		srcline;

	pFile->open( IO_ReadOnly );
	stream.setDevice( pFile );

	// initialize progress dialog
	m_progressDlg.setLabelText( "Displaying Java source code..." );
	m_progressDlg.setTotalSteps( pFile->size() );
	m_progressDlg.setProgress( 0 );
	m_progressDlg.show();

	// Insert a blank line to get the ball rolling
	srcline.address = 0;
	srcline.lineNumber = 0;
	srcline.SourceLine = "";

	//at this point, we don't have sample info for line yet, set them to 0,
	// we will update them when we update assembly.

	pItem = new CSourceTabItem (m_pViewShown, SRC_OFFSET_INDEX,
		m_pList, srcline);
	if (NULL == pItem) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		return;
	}

	lineno = 1;
	do
	{
		srcstring = stream.readLine();
		srcline.lineNumber = lineno;
		srcline.SourceLine = srcstring;

		pItem = new CSourceTabItem(m_pViewShown, SRC_OFFSET_INDEX,
			m_pSourceList, pItem, srcline);
		if (NULL == pItem) {
			QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
			break;
		}
		++lineno;

		m_progressDlg.setProgress( m_progressDlg.progress() + srcstring.length() );

	} while( !stream.eof() );

	m_progressDlg.hide();

	m_nSourceLines = lineno;
	m_densityChart->setMaxLine (lineno);

	// cleanup
	pFile->close();
	delete pFile;

	DisplayNativeCode();

	if( m_pItemOfInterest ) 
	{
		m_pSourceList->setSelected ( m_pItemOfInterest, true );
		m_pSourceList->setCurrentItem( m_pItemOfInterest );
		m_pSourceList->ensureItemVisible( m_pItemOfInterest );
	}
} //CJavaSourceView::DisplayJavaSource


void CJavaSourceView::PrintSrcInfo()
{
#ifdef _DEBUG_
	for (unsigned int i=0; i<m_srcEntryCnt; i++) {
		qDebug("addrOffset 0x%x", m_pSrcInfo[i].addrOffset);
		qDebug("lineNum %d", m_pSrcInfo[i].lineNum);
	}
#endif
}


bool CJavaSourceView::ReadJNCDataSec(const char * pJncFileName)
{
	FILE *  jnc_file_stream;

	jnc_file_stream = fopen(pJncFileName, "r+b");
	RETURN_FALSE_IF_NULL (jnc_file_stream, this);

	unsigned int strLength = 0;
	char * pJavaSrcName = NULL;
	char * pJavaFunctionName = NULL;
	char * pClassName = NULL;

	fseek(jnc_file_stream, m_dataSecOffset, SEEK_SET); 

	fread((char *)&strLength, sizeof(unsigned int), 1, jnc_file_stream);  
	pJavaSrcName = new char[strLength];
	if (NULL == pJavaSrcName) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		fclose (jnc_file_stream);
		return false;
	}
	memset(pJavaSrcName, 0, strLength);
	fread(pJavaSrcName, strLength, 1, jnc_file_stream); 

	fread((char *)&strLength, sizeof(unsigned int), 1, jnc_file_stream);  
	pClassName = new char[strLength];
	if (NULL == pClassName) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		fclose (jnc_file_stream);
		return false;
	}
	fread(pClassName, strLength, 1, jnc_file_stream); 

	fread((char *)&strLength, sizeof(unsigned int), 1, jnc_file_stream);
	pJavaFunctionName = new char[strLength];
	if (NULL == pJavaFunctionName) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		fclose (jnc_file_stream);
		return false;
	}
	fread(pJavaFunctionName, strLength, 1, jnc_file_stream);

	fread((char *)&m_jnc_load_addr, sizeof(unsigned long long), 1, 
		jnc_file_stream);

	fread((char *)&m_srcEntryCnt, sizeof(unsigned int), 1, jnc_file_stream);
	if (m_srcEntryCnt > 0) {
		m_pSrcInfo = new JavaSrcLineInfo[m_srcEntryCnt];
		if (NULL == m_pSrcInfo) {
			QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
			fclose (jnc_file_stream);
			return false;
		}
		fread((char *)m_pSrcInfo, m_srcEntryCnt * sizeof(JavaSrcLineInfo), 1,
			jnc_file_stream);
	}

	//    PrintSrcInfo();

	if (NULL != pJavaSrcName) {
		delete pJavaSrcName;
		pJavaSrcName = NULL;
	}

	if (NULL != pJavaFunctionName) {
		delete pJavaFunctionName;
		pJavaFunctionName = NULL;
	}

	fclose(jnc_file_stream);
	jnc_file_stream = NULL;
	return true;
}


void CJavaSourceView::DisplayNativeCode()
{
	QString tJavaSrc;

	// find java src file (which is myexample.java, Note: no path.
	JitBlockMap::iterator jitIter = m_jitBlockMap.find(m_Address);
	if (jitIter != m_jitBlockMap.end())
	{	
		tJavaSrc = jitIter->second.javaSrcFile;
	}

	typedef QMap<QString, int> TempMap;
	TempMap tMap;
	TempMap::Iterator tMapIter;
	SrcFunctionMap fun_map;
	SrcChartSampMap chart_map;

	for (jitIter = m_jitBlockMap.begin(); jitIter != m_jitBlockMap.end(); 
		jitIter++)
	{
		if (tJavaSrc != jitIter->second.javaSrcFile)
			continue;

		tMapIter = tMap.find(jitIter->second.jit_fun_name);
		if (tMapIter != tMap.end())
			continue;

		tMap[jitIter->second.jit_fun_name] = 1;

		CELFReader elfreader;
		elfreader.setELFFileName(jitIter->second.jnc_file_path.data());
		elfreader.readELFHeader();
		elfreader.readStrSectionHeader();
		elfreader.processSectionHeaders();
		m_dataSecOffset = elfreader.getDataSecOffset();

		// Make sure data section exists before reading the section
		if (0 != m_dataSecOffset)
		{
			ReadJNCDataSec(jitIter->second.jnc_file_path.data());
			AddJncNativeCode(jitIter->second, &fun_map, &chart_map);
		}
	}
	m_densityChart->setFunctions (fun_map);
	m_densityChart->setSamples (chart_map);
} //CJavaSourceView::DisplayNativeCode


void
CJavaSourceView::AddJncNativeCode(JIT_BLOCK_INFO jitBlock, 
								  SrcFunctionMap *pfunMap, 
								  SrcChartSampMap *psampMap)
{
	CSourceTabItem		*pNewItem;
	SymbolEngine symbolEngine;
	line_list_type dasmlineList;
	VADDR EndAddr = 0;  //JAVA, unknown end
	VADDR StartAddr = 0x80;
	JavaOffsetDsmMap jOffsetMap;
	// All .jnc files start at address 0x80.  
	// This will provide the starting value as the first byte of the jnc .text

	// Get the disassembly from symbol engine
	int symRetValue = symbolEngine.open(jitBlock.jnc_file_path);
	if (SymbolEngine::OKAY == symRetValue || 
		SymbolEngine::NO_SYMBOLS == symRetValue ||
		SymbolEngine::NO_SYMBOL_TABLE == symRetValue) 
	{

		dasmlineList.clear();

		if (SymbolEngine::OKAY != symbolEngine.disassembleRange (
			(bfd_vma) StartAddr, (bfd_vma) EndAddr, &dasmlineList)) 
			return;
		VADDR first_offset = 0xffffffff;
		unsigned int first_line = 0xffffffff;

		//the line number/offset table is in offset order
		if (m_srcEntryCnt > 0)
			first_offset = m_pSrcInfo[0].addrOffset;

		for (unsigned int i=0; i < m_srcEntryCnt; i++) 
		{
			if (m_pSrcInfo[i].lineNum < first_line)
				first_line = m_pSrcInfo[i].lineNum;
		}

		line_list_type::iterator dasmIter;
		dasmIter = dasmlineList.begin();
		while (dasmIter != dasmlineList.end()) {
			unsigned int lineno;
			SRC_LV_ITEM tSrcItem;
			VADDR address =  (*dasmIter).address - 0x80;

			if (address < first_offset)
				lineno = first_line;
			else {
				unsigned int j;
				//search line table for the closest offset
				for (j = 1; j < m_srcEntryCnt; j ++) 
				{
					if (m_pSrcInfo[j].addrOffset > address)
						break;
				}

				lineno = m_pSrcInfo[j - 1].lineNum;
			}

			//align with eip
			//address += m_jnc_load_addr;//m_profInfo.modPatchLoadAddr;
			address += m_profInfo.modPatchLoadAddr;

			QListViewItem * pSourceLineItem = GetSourceLineItem (lineno);

			if (!jitBlock.jit_fun_name.isEmpty()) 
			{
				SrcFunctionLineRange & function = 
					(*pfunMap)[jitBlock.jit_fun_name];
				if (function.start > lineno)
					function.start = lineno;
				if (function.end < lineno)
					function.end = lineno;
			}    

			SampleMap::iterator smit = m_SampleMap.find(address);
			//todo what if source line is not found?
			int instrCount = pSourceLineItem->childCount();

			tSrcItem.address = address; 
			if( smit != m_SampleMap.end() ) 
			{
				SrcChartSample &temp_sample = (*psampMap)[lineno];
				if (temp_sample.function.isEmpty())
					temp_sample.function = jitBlock.jit_fun_name;

				if ((0 == temp_sample.first_addr) || 
					(address < temp_sample.first_addr)) 
				{
					temp_sample.first_addr = address;
				}

			}

			tSrcItem.SourceLine = (*dasmIter).disassembly;
			tSrcItem.lineNumber = instrCount + 1;
			if( instrCount == 0 ) 
			{
				// the first disassembly item under the source line item.
				pNewItem = new CSourceTabItem(m_pViewShown, SRC_OFFSET_INDEX,
					pSourceLineItem, tSrcItem);
			} else {
				// find the last disassembly item for the source line item.
				//QListViewItem *pLastInstItem =
				//   GetLastChildItem(pSourceLineItem);

				// find the preceding disassembly item for the source line item;
				QListViewItem *pPrecedingItem = 
					GetPrecedingChildItem(pSourceLineItem, tSrcItem.address);

				if (pPrecedingItem != NULL) {
					pNewItem = new CSourceTabItem(m_pViewShown, SRC_OFFSET_INDEX,
						pSourceLineItem, pPrecedingItem, 
						tSrcItem);
				} else {
					// Stpuid QT QListViewItem does not allow to insert an item precede the first child item.
					// I'm insert after the first child item, then swap the contents of them.
					// --Lei
					QListViewItem *pFirstChildItem = pSourceLineItem->firstChild();
					pNewItem = new CSourceTabItem (m_pViewShown, SRC_OFFSET_INDEX,
						pSourceLineItem, pFirstChildItem, 
						tSrcItem );

					SwapFrist2Items(pSourceLineItem);
				}

				ReorderInstNumbers(pSourceLineItem);

				if (m_Address == address) {
					m_pItemOfInterest  = pNewItem;
				}
			}
			dasmIter++;
		} //for each disassembled instruction from the jnc file
	} //if the symbol engine opened the jnc okay
}

void CJavaSourceView::addDataToList ()
{
	SampleMap::iterator it;
	CSourceTabItem *item = NULL;

	for (it = m_SampleMap.begin (); it != m_SampleMap.end (); it++) 
	{
		SRC_LV_ITEM source_line;
		sym_info sym;
		UINT64 address = it->first;

		QString tempSearch = "0x" + QString::number (address, HEX_BASE);
		item = (CSourceTabItem *) m_pList->findItem (tempSearch, SRC_ADDRESS_COLUMN);
		if (NULL == item)
			continue;

		//get line number from parent
		CSourceTabItem *line_item = (CSourceTabItem *) item->parent ();
		unsigned int line = 0;
		if (NULL != line_item)
			line = line_item->text (SRC_LINE_COLUMN).toUInt ();

		DataArray tempParent;
		line_item->fillData (&tempParent);
		DataArray tempAsm;
		tempAsm.resize (m_pViewShown->available.count(), 0);

		SampleDataMap::iterator sample_it = it->second.begin();
		SampleDataMap::iterator sample_end = it->second.end();
		for (; sample_it != sample_end; sample_it++) 
		{
			unsigned long long deEvent;
			unsigned char deUMask;
			DecodeEventMask(sample_it->first.event, &deEvent, &deUMask);
			CpuEventType key(sample_it->first.cpu, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			int index = m_pViewShown->indexes[key];

			//aggregate
			tempParent[index] += sample_it->second;
			line_item->addItemTotal(sample_it->second);
			tempAsm[index] += sample_it->second;
			item->addItemTotal(sample_it->second);

			//if part of complex column, re-calculate
			ComplexDependentMap::Iterator complex = 
					m_pViewShown->calculated.find (index);

			if (complex != m_pViewShown->calculated.end())
			{
				ListOfComplex::Iterator cpxIt = (*complex).begin();
				for (; cpxIt != (*complex).end(); ++cpxIt)
				{
					float calc = m_pViewShown->setComplex (&(*cpxIt), &tempParent);
					int complexIndex = (*cpxIt).columnIndex;
					tempParent[complexIndex] = calc;

					calc = m_pViewShown->setComplex (&(*cpxIt), &tempAsm);
					tempAsm[complexIndex] = calc;
				}
			}
		}

		line_item->addData (tempParent, m_precision);
		item->addData (tempAsm, m_precision);
	}
}   // CJavaSourceView::addDataToList


void CJavaSourceView::onViewChanged (ViewShownData* pShownData)
{
	QListViewItem *pCurrent = m_pList->currentItem ();
	UINT64 saveAddr = 0;
	if (NULL != pCurrent)
	{
		saveAddr = pCurrent->text (SRC_ADDRESS_COLUMN).toULongLong (NULL, 16);
	}

	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}

	//remove all columns
	clearShownColumns ();

	//update shown columns
	if (NULL != m_pColumnMenu)
		m_pColumnMenu->clear();

	//add data columns
	if (!initMenu ())
	{
		m_pList->setUpdatesEnabled (true);
		return;
	}

	if(m_pMenu != NULL)
	{
		if (-1 == m_pMenu->idAt (SRC_POP_SHOWN))
			m_pMenu->insertItem ("&Show", m_pColumnMenu);
	}

	//redo data here
	addDataToList ();

	m_pList->triggerUpdate();
	if (0 != saveAddr)
	{
		OnNewJavaHotspot (saveAddr, caption ());
	}
}


void 
CJavaSourceView::OnSelectionChange()
{
	CSourceTabItem *pItem = (CSourceTabItem *) m_pSourceList->firstChild();

	unsigned int srcLineCount = 0;
	unsigned int instCount = 0;
	unsigned sampleCount = 0;

	while (pItem) 
	{
		if (pItem->isSelected())
		{
			srcLineCount++;
			instCount += pItem->childCount();
			sampleCount += pItem->getItemTotal();
		} else {
			CSourceTabItem *pChildItem = (CSourceTabItem*) pItem->firstChild ();

			BOOL bAddSource = FALSE;
			while (pChildItem)
			{
				if (pChildItem->isSelected())
				{
					bAddSource = TRUE;
					instCount++;

					sampleCount += pChildItem->getItemTotal();

				}

				pChildItem = (CSourceTabItem *) pChildItem->nextSibling();
			}
			if (bAddSource)
				srcLineCount++;
		}

		pItem = (CSourceTabItem *) pItem->nextSibling();
	}

	QString tStr;
	float mod_pct = 0.0 , pct = 0.0;

	if (m_moduleSamples != 0)
		mod_pct = (float) sampleCount * 100 / (float) m_moduleSamples;

	if (m_profInfo.totalSamples != 0)
		pct = (float) sampleCount * 100 / (float) m_profInfo.totalSamples;

	tStr.sprintf("%u source lines, %u instructions, Total: %u samples, %.2f%% of samples in Java app, %.2f%% of total session samples", 
		srcLineCount, instCount, sampleCount, mod_pct, pct);

	statusBar()->message (tStr);
}


///////////////////////////////////////////////////////////////////////////////
// DasmView::OnRightClick()
// ------------------------
//
void
CJavaSourceView::OnRightClick( QListViewItem *pItem, const QPoint &pt, int i )
{
	Q_UNUSED (pItem);
	Q_UNUSED (i);
	m_pMenu->popup( pt );
}



void CJavaSourceView::OnDensityVisibilty ()
{
	m_densityChart->checkVisibility ();
}


void CJavaSourceView::showEvent (QShowEvent * e)
{
	Q_UNUSED (e);
	m_densityChart->checkVisibility ();
}


//check for whether the currently shown list changed.
void CJavaSourceView::OnListRedrawn ()
{
	UINT64 start = 1;
	UINT64 end = m_nSourceLines;

	static QListViewItem * last_top = NULL;
	static QListViewItem * last_bottom = NULL;
	QListViewItem * line_item;

	//instead of checking items at these points, I could start at the first
	//item and scroll through all visible items
	QPoint top_point = QPoint (0,0);
	QPoint bottom_point = QPoint (0,(m_pSourceList->visibleHeight() - 1));

	QListViewItem * top = m_pSourceList->itemAt (top_point);
	QListViewItem *bottom = m_pSourceList->itemAt (bottom_point);
	if (NULL != bottom) {
		if (NULL != bottom->itemBelow())
			bottom = bottom->itemBelow();
	}
	//If the visible items really didn't change...
	if ((last_top == top) && (last_bottom == bottom))
		return;

	last_top = top;
	last_bottom = bottom;

	if (NULL != bottom) {
		//if the bottom line is disassembly
		line_item = bottom->parent();
		if (NULL != line_item)
			end = line_item->text(SRC_LINE_COLUMN).toUInt();
		else
			end = bottom->text(SRC_LINE_COLUMN).toUInt();
	}

	if (NULL != top) {
		//if the top line is disassembly
		line_item = top->parent();
		if (NULL != line_item)
			start = line_item->text(SRC_LINE_COLUMN).toUInt();
		else
			start = top->text(SRC_LINE_COLUMN).toUInt();
	}

	if (NULL != m_densityChart)
		m_densityChart->shownDataChanged (start, end);
} //CJavaSourceView::OnListRedrawn


//We are paying attention to this because the header click affects the sorting
void CJavaSourceView::OnHeaderClicked (int column)
{
	//if sorted by samples, don't shown range in chart.
	m_densityChart->setShowCurrentData (SRC_LINE_COLUMN == column);
}


/////////////////////////////////////////////////////////
// Find the Source line item for a given line nubmer.
//
// Note: DisplayCCode() function adds an extra blank line 
//	at the begin of source file.
//
QListViewItem * CJavaSourceView::GetSourceLineItem(int lineNum)
{
	CSourceTabItem * pItem = NULL;
	int i = 0;

	pItem = (CSourceTabItem *)m_pSourceList->firstChild();
	for( ; pItem!=NULL; pItem=(CSourceTabItem *)pItem->nextSibling() )
	{
		if (i == lineNum)
			break;
		i++;
	}

	return pItem;
}
