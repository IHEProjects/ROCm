
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _DASMDOCKVIEW_H_
#define _DASMDOCKVIEW_H_

#include <qdockwindow.h>
#include <qlayout.h>
#include <qlistview.h>
#include <qsplitter.h>
#include <qhbox.h>
#include <qmainwindow.h>
#include <qcheckbox.h>
#include <qtoolbutton.h>
#include <qpushbutton.h>
#include <qcombobox.h>
#include "diffStruct.h"
#include "DiffSession.h"
#include "bbanalysis.h"

#include "BBDataListItem.h"

class DasmDockView : public QDockWindow
{

	Q_OBJECT;
public:
	DasmDockView(QWidget * parent, const char * name = 0, WFlags f = 0);
	~DasmDockView();
	bool init();

signals:
	void dasmDockViewNoShow();

public slots:
	virtual void undock()
	{ 	setMinimumWidth(500);
		setMinimumHeight(600);
		QDockWindow::undock();
	};
	virtual bool close(bool alsoDelete);	
	virtual void onDasmDockViewShowChanged(bool b);	
	virtual void onUpdateDasmSymbol(QListViewItem* i);
	virtual void onChangeSession(DiffSession *s);

private slots:
	void onCodeByteToggled(bool b);
	void onLoadStoreToggled(bool b);
	void onInlineToggled(bool b);
	void onExpandCollapseToggled(bool b);
	void onBBDiffToggled(bool b);
	void onPercentChanged(int i);
	void onSyncDasmViewToggled(bool b);

	
	// SYNC
	void onSelectionChanged(QListViewItem* i);	
	void onExpanded(QListViewItem *i);	
	void onCollapsed(QListViewItem *i);	
	void onContentsRightMoving(int x ,int y);
	void onContentsLeftMoving(int x ,int y);

private:
	bool initDasmToolbar();
	void resetToolbar();
	void addColumn(int diffIndex);
	void setHiddenColumn();
	void calculateSamplePercentMap(SamplePercentMap* percent, 
				SampleDataMap* samples,
				SampleDataMap* total);
	void updateListViews();
	void updateListViewsWithRawData();
	void updateListViewsWithFunctionPercent();
	void updateListViewsWithBBPercent();
	


	DiffSession	*m_pDiffSession;
	QBoxLayout	*m_pBLayout;
	QSplitter	*m_pSplitter;
	QListView	*m_pView[MAX_NUM_DIFF];
	BBAnalysis	m_bba[MAX_NUM_DIFF];	
	BLOCKMAP 	*m_pBBMap[MAX_NUM_DIFF];
	MEMACCESSMAP 	*m_pMemMap[MAX_NUM_DIFF];
	DASM_VIEW_INFO_MAP m_bbViewInfoMap[MAX_NUM_DIFF];
	DASM_VIEW_INFO_MAP m_dasmViewInfoMap[MAX_NUM_DIFF];
	QToolBar	*m_pDasmToolbar;
	QMainWindow	*m_pMainWindow;
	SYM_INFO_VECTOR m_inlineInfoVec[MAX_NUM_DIFF];
	bool 		m_syncDasmView;
	bool		m_isMoving;
	SampleDataMap	*m_pTotalSampleDataMap[MAX_NUM_DIFF];
	BBDataListItem	*m_pCurHighlightedBB[MAX_NUM_DIFF];

	//Dasm ToolButtons
	QPushButton	*m_pCodeByte;
	QPushButton	*m_pLoadStore;
	QPushButton	*m_pInline;
	QPushButton	*m_pExpandCollapse;
	QPushButton	*m_pSyncDasmView;
	QPushButton	*m_pBBDiff;
	QComboBox	*m_pPercentCombo;

	//QPoint		m_curView[MAX_NUM_DIFF];
	int		m_xDiff;
	int		m_yDiff;
	
};

#endif //_DASMDOCKVIEW_H_


