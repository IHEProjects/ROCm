/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef _PROCTREE_H
#define _PROCTREE_H

#include <qmap.h>
#include <qsortedlist.h>

#include "stdafx.h"
#include "libprofile_ctrl.h"

class Function;
class Sample;
class Module;

typedef QMap<VADDR, Function *> FunctionMapList;
typedef QSortedList<Module> ModuleList;


typedef struct {
	VADDR address;
	VADDR baseAddr;
	unsigned int cpu;
	unsigned int eventIndex;
	QString jncName;
	QString funName;
    QString transjavaSrcName;
} ADDR_TRANSLATE;


//////////////////////////////////////////////////////////////////////////
// Function Class
//
//////////////////////////////////////////////////////////////////////////
class Function
{
public:
    Function();
    ~Function();

    inline bool operator< (Function& f)
        { return !(total < f.total); }

    bool operator == (Function& f)
    {
	Q_UNUSED (f);
        int result = 0;
        // todo: define this operator

        return result;
    }

    void SetName(const char * pString);      
    char * GetName();

public:
    VADDR Address;
    unsigned long long total;
    char * Name;
    unsigned int taskId;
    VADDR funcBaseAddr;
    QString jncFileName;
    QString javaSrcFile;
    SampleDataMap func_CpuSamples;
};


class Module
{
private:
    char*	Path;
    char*	Name;
    QString	m_SymbolFile;
    bool	DoesSampleBelongToModule( VADDR sample_address );

public:
	VADDR   Base;
	unsigned int size;

	SampleDataMap mod_CpuSamples;

	unsigned long long     total;
	bool	long_mode;
	bool	root;
	unsigned int taskId;

	FunctionMapList  Functions;
	unsigned int m_ModType;

	Module();
	~Module();

	void	SetName( const char *pString );
	void	SetPath( const char *pString );
	void	SetSymbolFile( QString sym_file );
	char*	GetName() const;
	char*	GetPath() const;
	QString GetSymbolFile();

};


struct module_compare
{
	bool operator()(Module const & m1, Module const & m2) const {
    	return m1.total <= m2.total;
  	}
};


class ProcessTree
{
};

#endif
