//$Id: sourceview.h,v 1.8 2005/02/14 16:52:40 jyeh Exp $
// interface for the SourceDataView class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef _SOURCEDATAVIEW_H
#define _SOURCEDATAVIEW_H

#include <qevent.h>

#include "stdafx.h"
#include "tbsreader.h"
#include "symbolengine.h"
#include "codeDensity.h"
#include "sessionnav.h"

#define INVALID_SOURCE_LINE	"--------"
#define MAX_DASM_LINES		100
#define MAX_CHARS 10

typedef map<unsigned long, SampleDataMap> LineSampleMap;

enum SRC_CODE_DENSITY_Enum {
	SRC_ZOOM_FILE = 0,
	SRC_ZOOM_SECTION,
	SRC_ZOOM_USER,
	SRC_ZOOM_SHOWN
};

enum SOURCE_COLUMNS {
	SRC_ADDRESS_COLUMN = 0,
	SRC_LINE_COLUMN,
	SRC_SOURCE_COLUMN,
	SRC_CODE_BYTES_COLUMN,
	SRC_OFFSET_INDEX,
	SRC_INVALID
};

enum SOURCE_ITEM_DEPTH {
	SRC_FUNCTION_DEPTH = 0,
	SRC_LINE_DEPTH
};

enum SOURCE_POPUPS {
	SRC_POP_COPY = 0,
	SRC_POP_SHOWN
};

enum SOURCE_SEARCH
{
	SEARCH_ALL = 0,
	SEARCH_LINE,
	SEARCH_ADDRESS,
	SEARCH_SOURCE
};

typedef struct _SrcChartSample{
	VADDR first_addr;
	DataArray samples;
	QString function;
	_SrcChartSample () {
		first_addr = 0;
	};
} SrcChartSample ;

//maps line number to samples
typedef QMap < unsigned int, SrcChartSample > SrcChartSampMap;

typedef struct _SrcFunctionLineRange{
	unsigned int start; //first line of function with instructions
	unsigned int end; //last line of function with instructions
	_SrcFunctionLineRange () {
		start = (unsigned int) -1;
		end = 0;
	};
} SrcFunctionLineRange ;

//maps function name to line number range
typedef QMap < QString, SrcFunctionLineRange > SrcFunctionMap;

//////////////////////////////////////////////////////////////////////////////
enum {
	SOURCE_EVENT_MULTISELECT = QEvent::User
};

// ----------------------------------------------------------------------------
//
// We have to override QListViewItem to get around Qt's stupid ListView sorting
// limitation
//
class CSourceTabItem : public DataListItem 
{
	enum { MARGIN = 10 };
public:
	CSourceTabItem (ViewShownData *pViewShown, int indexOffset, 
		QListView * parent, QListViewItem * after,
		SRC_LV_ITEM source_item);

	CSourceTabItem (ViewShownData *pViewShown, int indexOffset, 
		QListViewItem * pItem, QListViewItem * pAfter,
		SRC_LV_ITEM source_item);

	CSourceTabItem (ViewShownData *pViewShown, int indexOffset, 
		QListViewItem * pItem, SRC_LV_ITEM source_item);

	CSourceTabItem (ViewShownData *pViewShown, int indexOffset, 
		QListView * parent, SRC_LV_ITEM source_item);

	void addData (DataArray data, int precision);
	int width (const QFontMetrics & fm, const QListView * lv, int col) const;
	void fillData (DataArray *pData);

protected:
	QString key (int column, bool ascending) const;
	void paintCell (QPainter * p, const QColorGroup & cg, int column,
		int width, int align);

public:
	QListViewItem * m_last_child;
}; //class CSourceTabItem 


//DensityChartArea defined in codeDensity.h
class SrcDensityChart : public DensityChartArea 
{
	Q_OBJECT
public:
	SrcDensityChart (ViewShownData *pViewShown, QWidget * parent, 
		ProfileAttribute profile);
	virtual ~SrcDensityChart ();

	void setSamples (SrcChartSampMap samp_map);
	void setFunctions (SrcFunctionMap function_map);
	bool initialize ();
	void showCurrent (unsigned int start, unsigned int end);
	void setInterestLine (unsigned int interesting);
	void setMaxLine (unsigned int max);

	//overwriting pure virtual function
	virtual void zoomChanged (int zoom_level);
	void setCurrentFunction(QString name)
	{ m_currentFunction = name; };

protected:
	//overwriting pure virtual functions!
	virtual bool groupData ();
	virtual void tipGroups ();

	private slots:
		void onGroupDoubleClicked (UINT64 group_data);

signals:
		void doubleClicked (UINT64 interesting);

private:
	unsigned int m_total_src_lines;
	QString m_currentFunction;

	ProfileAttribute m_profile;
	SrcChartSampMap m_sample_map;
	SrcFunctionMap m_function_map;
}; //class SrcDensityChart


//ZoomDock defined in codeDensity.h
class SrcDensityView : public ZoomDock {
	Q_OBJECT
public:
	SrcDensityView (QWidget * parent);
	~SrcDensityView ();

	bool initialize (ViewShownData *pViewShown, ProfileAttribute profile, QString curFuncName= "");
	void shownDataChanged (unsigned int start, unsigned int end);
	void setInterestPoint (unsigned int interesting);
	void setShowCurrentData (bool show_current);
	void setSamples (SrcChartSampMap samp_map);
	void setFunctions (SrcFunctionMap function_map);
	void setMaxLine (unsigned int max);

	public slots:
		void onDoubleClicked (UINT64 hot_spot);

signals:
		void newHotSpot (VADDR hot_spot, QString caption, SampleMap*);

private:
	SrcDensityChart * m_pSrcChart;
	QString	m_currentFunction;
};


//////////////////////////////////////////////////////////////////////////////
// SourceDataTab Class
//

class SourceDataTab : public DataTab 
{
	Q_OBJECT
public:
	SourceDataTab (ViewShownData *pViewShown, QString module_name, 
		VADDR address, TbsReader* tbp_file,
		SampleMap *sample_map, QWidget * parent, const char *name,
		int wflags);
	virtual ~SourceDataTab ();

	QString getSourceFileName ();
	bool displaySource (ProfileAttribute prof_att);
	sym_info* getCurrentSymInfo(){ return &m_currentSym;};

signals:
	void disassembledDone ();

protected:
	void showEvent (QShowEvent * e);

public slots:
	void onDensityVisibilty ();
	virtual void onViewChanged (ViewShownData* pShownData);

private slots:
	void onSelectionChange ();
	void onListRedrawn ();
	void onNewHotSpot (VADDR addr, QString caption, SampleMap *);
	void onHeaderClicked (int column);
	void onHeaderSizeChanged(int section,int oldSize, int newSize);
	void OnRightClick( QListViewItem *pItem, const QPoint &pt, int i );
	void onSearch();
	void onExpandCollapseToggled(bool b);


private:
	bool openSource (QFile * file, QString & filename);
	bool checkFileStamp (QString filename);
	bool addSourceToList ();
	bool addInstToList (bool use_lines);
	void moveSelectItem (QListViewItem * pItem);
	bool addDataToInst(CSourceTabItem * dasmItem, 
			SampleMap::iterator & itsample, 
			line_list_type::const_iterator & it,
			QString & functionName,
			SrcChartSampMap & chartMap);

	void calculateTotalData();
	
private:
	sym_info  m_currentSym;
	ProfileAttribute m_profile;
	SrcFunctionMap m_func_map;
	QString m_module_name;
	QString m_file_name;
	ChartListView *m_list;
	QPopupMenu	*m_pMenu;

	QPushButton	*m_pExpandCollapse;
	QToolBar * m_pSearchToolbar;
	QToolBar * m_pSourceToolbar;
	QLineEdit *m_pSearchBox;
	QComboBox * m_pSearchType;

	TbsReader* m_tbp_file;
	SymbolEngine m_symbol_engine;
	VADDR m_addr;
	unsigned int m_max_lines;
	SampleMap *m_sample_map;

	SrcDensityView *m_density_view;
	LineSampleMap m_lineSampleMap;	
}; //class SourceDataTab 

#endif // #ifndef _SOURCEDATAVIEW_H
