#include "stdafx.h"

unsigned long AggregateSamples(SampleDataMap &destMap, SampleDataMap &sourceMap)
{
	unsigned long total = 0;

	SampleDataMap::iterator srcIter, srcIterEnd, destIter;

	srcIterEnd = sourceMap.end();
	for (srcIter = sourceMap.begin(); srcIter!= srcIterEnd; srcIter++) {
		if (!srcIter->second)
			continue;

		SampleKey key;
		key.cpu = srcIter->first.cpu;
		key.event = srcIter->first.event;

		destIter = destMap.find(key);
		if (destIter != destMap.end()) {
			destIter->second += srcIter->second;
		} else {
			destMap.insert(SampleDataMap::value_type(key, srcIter->second));
		}
		total += srcIter->second;
	}
	return total;
}

