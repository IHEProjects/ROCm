//$Id: dasmview.cpp,v 1.18 2005/03/27 23:11:01 jyeh Exp $
// implementation of the Dasmview class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "stdafx.h"
#include <assert.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <vector>

#include "dasmview.h"
#include "auxil.h"
#include "EventMaskEncoding.h"
#include "dataagg.h"

DasmTabItem::DasmTabItem (QListView * pParent, DASM_LV_ITEM item,
						  ViewShownData *pViewShown, int indexOffset)
						  : DataListItem (pViewShown, indexOffset, pParent)
{
	m_pPrecision = NULL;

	setText (ASM_ADDRESS_COLUMN, item.CsEip);
	setText (ASM_CODE_BYTES_COLUMN, item.CodeBytes);
	setText (ASM_INSTRUCTION_COLUMN, item.Instruction);
	if (item.Symbol != "NO SYMBOL" ) {
		setText (ASM_SYMBOL_COLUMN, item.Symbol);
	}
}

QString DasmTabItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	static int updateCounter = 0;
	QString retString;

	// Every 100 sorts, tell the app to handle gui stuff, 
	// for a max of 1 milisecond
	if (0 == (updateCounter++ % 100)) {
		qApp->processEvents (1);
	}
	if ((column < ASM_CODE_BYTES_COLUMN) || (column >  ASM_SYMBOL_COLUMN)) {
		retString.fill ('0', (20 - text (column).length()));
		retString += text (column);
	}
	else {
		retString = text (column);
	}
	return retString;
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DasmTab::DasmTab (VADDR Address, SampleMap *SampMap, 
		ViewShownData *pViewShown, ProfileAttribute profAtt, 
		QWidget * parent,  const char * name, int wflags)
		:  DataTab (pViewShown, parent, name, wflags )
{
	m_oneAtATime = false;
	m_dasmtab_symengine = NULL;
	m_prog_dlg = NULL;
	m_densityView = NULL;
	m_Address = Address;

	m_SampMap = SampMap;
	m_vaImageBase = 0;
	m_pItemOfInterest = 0;

	m_exportString = "&Export Asm Data...";
	m_indexOffset = ASM_OFFSET_INDEX;

	setGeometry (QRect (100, 100, 640, 480));

	m_SectionMap.clear ();

	m_ProfAtt.modName = profAtt.modName;
	m_ProfAtt.cpuNum = profAtt.cpuNum;

	m_ProfAtt.eventNum = profAtt.eventNum;
	m_ProfAtt.totalSamples = profAtt.totalSamples;
	m_ProfAtt.modPatchLoadAddr = profAtt.modPatchLoadAddr;
	m_ProfAtt.modType = profAtt.modType;
	m_ProfAtt.modPath = profAtt.modPath;
	m_ProfAtt.sessionPath= profAtt.sessionPath;
	m_ProfAtt.modTotal = profAtt.modTotal;

	
	// at this point, the sample map and jit map had been built from
	// previous module dat view or graph view.
	// Just register the maps.	
	AddModGlobalMap(m_ProfAtt.sessionPath, m_ProfAtt.modPath, NULL, NULL);

	setDockMenuEnabled (false);
}


DasmTab::~DasmTab ()
{
	m_SectionMap.clear ();

	if (m_pMenu) {
		delete m_pMenu;
		m_pMenu = NULL;
	}

	if (NULL != m_dasmtab_symengine)  {
		m_dasmtab_symengine->closeEngine();
		delete m_dasmtab_symengine;
		m_dasmtab_symengine= NULL;
	}

	m_SampMap = NULL;

	// un-register the usage of the maps
	//RemoveModGlobalMap(m_ProfAtt.sessionPath, m_ProfAtt.modPath);

	m_bba.bba_cleanup();
}


void
DasmTab::Tag (QString caption)
{
	m_Caption = caption;
	setCaption (caption);
	m_densityView->setClickedCaption (caption);
	m_densityView->checkVisibility ();
}


void DasmTab::OnNewHotspot (VADDR addr, QString caption, SampleMap *pMap)
{
	if (caption != m_Caption)  
		return;

	// verfiy if address is in .text section
	//VADDR sectionStart = 0;
	//VADDR sectionEnd = 0;

	bfd_vma address = addr;
	section_map_type::iterator sectionIter;

	bool bContinue = false;
	sectionIter = m_SectionMap.lower_bound (address);
	if (sectionIter != m_SectionMap.end ()) {
		section_map_type::value_type & sectionData = *sectionIter;
		section_info temp_sec = (section_info) sectionData.second;

		if ((VADDR) sectionData.first <= address && 
			(VADDR) temp_sec.end > address) {
			if (temp_sec.is_code)
				bContinue = true;
		}
	}

	if (!bContinue)
		return;

	bool bDasm = false;
		
	if (addr < m_FirstInstVAddr || addr > m_LastInstVAddr)
		bDasm = true;	

	if (pMap) {
		m_SampMap = pMap;
		bDasm = true;
	}

	if (bDasm) {
		m_Address = addr;
		m_pAsmList->clear ();
		m_densityView->setInterestPoint (m_Address);
		Dasm ();
	} else {
		ChangeInterestItem(addr);
	}
}


//////////////////////////////////////////////////////////////////////////
// Init()
// ------
// Attempts to find the specified base module name in the list of
// module paths in the sym.map file
//
bool DasmTab::Init()
{
	if (!m_SampMap)
		return false;

	m_pAsmList = new ChartListView (this);
	RETURN_FALSE_IF_NULL (m_pAsmList, this);
	m_pList = m_pAsmList;

#ifdef __x86_64__
	m_pAsmList->addColumn ("Address", 160);
#else
	m_pAsmList->addColumn ("Address", -1);
#endif

	m_pAsmList->addColumn ("Code Bytes", 200);
	m_pAsmList->addColumn ("Instruction", 200);
	m_pAsmList->addColumn ("Symbol", 200);

	m_pAsmList->setColumnAlignment (ASM_INSTRUCTION_COLUMN, AlignLeft);
	m_pAsmList->setColumnAlignment (ASM_ADDRESS_COLUMN, AlignLeft);
	m_pAsmList->setColumnAlignment (ASM_SYMBOL_COLUMN, AlignLeft);

	m_pAsmList->setSelectionMode (QListView::Extended);
	m_pAsmList->setSorting (ASM_ADDRESS_COLUMN, true);

	//add data columns
	if (!initMenu ())
		return false;

	m_pAsmList->setAllColumnsShowFocus (TRUE);
	setFocusProxy (m_pAsmList);
	setCentralWidget (m_pAsmList);
	statusBar ()->setSizeGripEnabled (false);

	// Init popup menu
	m_pMenu = new QPopupMenu (this);
	RETURN_FALSE_IF_NULL (m_pMenu, this);

	m_pMenu->insertItem ("Copy Selection", this, SLOT (onCopySelection ()),
		CTRL + Key_C);
	m_pMenu->insertItem ("Page up...",
		this, SLOT (OnPageUp ()), Key_PageUp);
	m_pMenu->insertItem ("Page down...",
		this, SLOT (OnPageDown ()), Key_PageDown);
	m_pMenu->insertItem ("&Show", m_pColumnMenu);

	QObject::connect (m_pMenu, SIGNAL (activated (int)),
					this, SLOT (OnMenuItemClick (int)));
	QObject::connect (m_pAsmList,
		SIGNAL (rightButtonClicked (QListViewItem *, const QPoint &, int)),
		SLOT (OnRightClick (QListViewItem *, const QPoint &, int)));

/*
	QObject::connect (m_pAsmList,
		SIGNAL (doubleClicked (QListViewItem *, const QPoint &, int)),
		SLOT (OnDoubleClick (QListViewItem *, const QPoint &, int)));
*/
	QObject::connect (m_pAsmList,
		SIGNAL (contextMenuRequested (QListViewItem *, const QPoint &, int)),
		SLOT (OnRightClick (QListViewItem *, const QPoint &, int)));

	m_pScrollBar = m_pAsmList->verticalScrollBar ();
	QObject::connect (m_pAsmList, SIGNAL (selectionChanged ()),
		this, SLOT (OnSelectionChange ()));

	QObject::connect (m_pAsmList, SIGNAL (contentsRedrawn ()),
		this, SLOT (OnListRedrawn ()));

	QString msg = QString::null;

	m_file_path = m_ProfAtt.modPath;


	// validate the file path
	if (!QFile::exists (m_file_path)) {
		msg = "Could not find " + m_file_path + ".\nBrowse for File?";

		// the image does not exist on the hard disk
		if (QMessageBox::information (this, "Error", msg,
			QMessageBox::Yes, QMessageBox::No) != QMessageBox::Yes) 
		{
				return false;
		} 	else {
			QString tempFilePath;
			tempFilePath = QFileDialog::getOpenFileName ();
			if (tempFilePath.isEmpty ())
				return FALSE;
			m_ProfAtt.modName = tempFilePath;
			m_file_path = tempFilePath;
			m_ProfAtt.modPath = tempFilePath;
		}
	}

	if (!initialize_symbolengine())
		return false;

	if (m_bba.bba_init(m_file_path.ascii()) != OK ) 
		return false;
	else
		if (m_bba.bba_analyze_all() != OK)
			return false;

	m_vaImageBase = m_bba.bba_get_image_base();
	if(m_ProfAtt.modType == JAVAMODULE) {
		m_vaImageBase -= m_bba.bba_get_first_section_offset();
	}

	m_densityView = new DasmDensityView (this);
	RETURN_FALSE_IF_NULL (m_densityView, this);

	if (!m_densityView->initialize (m_pViewShown, m_ProfAtt, 
					m_SampMap, m_Address)) {
		return false;
	}

	//If the chart is double clicked, go to that address
	QObject::connect (m_densityView,
		SIGNAL(newHotSpot (VADDR, QString, SampleMap*)),
		this, SLOT (OnNewHotspot (VADDR, QString, SampleMap*)));

	if (!GetSectionMap()) {
		QMessageBox::information (this, "Error", 
			"Failed to Querying section info in the module.");
		return false;
	}
	
	// validation succeeded
	setCaption ("Found " + QString (m_ProfAtt.modName.data ()));
	return TRUE;
}


void DasmTab::showEvent (QShowEvent * e)
{
	Q_UNUSED (e);
	m_densityView->checkVisibility ();
}

bool DasmTab::GetSectionAddress (VADDR address, VADDR * pStartVAddr, VADDR * pEndVAddr)
{
	bool bRet = false;

	bfd_vma addr = address;
	section_map_type::iterator sectionIter = m_SectionMap.lower_bound (addr);
	if (sectionIter != m_SectionMap.end ()) {
		section_map_type::value_type & sectionData = *sectionIter;
		*pStartVAddr = (VADDR) sectionData.first;
		section_info temp = (section_info) sectionData.second;
		*pEndVAddr = (VADDR) temp.end;
		bRet = true;
	}

	return bRet;
}

///////////////////////////////////////////////////////////////
// Dasm()
// ------
// Open the file, begin disassembly
//
bool DasmTab::Dasm()
{
	bool bRet = true;
	DasmTabItem *pItem = NULL;
	DasmTabItem *pBlockStartItem = NULL;

	UINT32 closest = 0xFFFFFFFF;

	VADDR start = 0, end = 0;
	VADDR sectionStart = 0;
	VADDR sectionEnd = 0;

	m_pAsmList->clear();


	start = FindBlockStartAddr(m_Address);
	GetSectionAddress(m_Address, &sectionStart, &sectionEnd);

	if (start < sectionStart)
		start = sectionStart;

	end = m_Address + HALFPAGE;
	end = (end < sectionEnd)? end : sectionEnd;
	
	line_list_type dasmlineList;

	int symRetValue;
	dasmlineList.clear();

	symRetValue = m_dasmtab_symengine->disassembleRange((bfd_vma) start, 
					(bfd_vma) end, &dasmlineList);
	
	if (SymbolEngine::OKAY != symRetValue || dasmlineList.count() == 0) {
		//May have failed because of cancel
		QString temp;
		char num_start[LONG_STR_MAX];
		char num_end[LONG_STR_MAX];
		snprintf (num_start, (LONG_STR_MAX - 1), LONG_FORMAT, start);
		snprintf (num_end, (LONG_STR_MAX - 1), LONG_FORMAT, end);
		temp.sprintf ("Failed to disassemble range %s to %s",
						num_start, num_end);
		QMessageBox::information (this, "Disassembly error", temp);

		m_FirstInstVAddr = -1;

		return false;
	}
	      
	line_list_type::iterator dasmIter, dasmIterPrev;
	line_list_type::iterator dasmEnd;
	dasmIter = dasmlineList.begin();
	dasmEnd = dasmlineList.end();

	m_FirstInstVAddr = (VADDR) (*dasmIter).address;;

	bool bBackground = false;
	bool bNewBlock = true;
	unsigned int loadCnt = 0;
	unsigned int storeCnt = 0;

	// block iterator	
	BASIC_BLOCK_KEY bbKey;
	bbKey.bb_start = (unsigned int) m_FirstInstVAddr - m_vaImageBase;

	// no need to check pBBMap --since it always exists;
	BLOCKMAP *pBBMap = m_bba.bba_get_block_map();
	BLOCKMAP::iterator bbIter = pBBMap->lower_bound(bbKey);
	BLOCKMAP::iterator bbEnd = pBBMap->end();

	// Memory Access
	MEMACCESSMAP *pMemMap = NULL;
	MEMACCESSMAP::iterator memAccIter;
	MEMACCESSMAP::iterator memAccEnd;
	pMemMap = m_bba.bba_get_mem_map();
	memAccIter = pMemMap->begin();
	memAccEnd = pMemMap->end();
	VADDR tAddr = 0;

	// iterate block 
	while (bbIter != pBBMap->end()) {
		VADDR blockEndAddr = m_vaImageBase + 
			bbIter->second.bb_start_offset + bbIter->second.bb_size;

		if (blockEndAddr <= m_FirstInstVAddr) {
			bbIter--;
		}
		else
			break;
	};

	// iterate memory access
	while (memAccIter != memAccEnd) {
		tAddr = m_vaImageBase + memAccIter->first;
		if (tAddr >=  m_FirstInstVAddr)
			break;

		memAccIter++;
	}	

	// Sample iterator and iterate sample map to the first instruction
	SampleMap::iterator sampIter = m_SampMap->begin();
	SampleMap::iterator sampEnd = m_SampMap->end();
	SampleDataMap itemSamples;	// samples for one view item;
	m_ViewSampMap.clear();	// clear the previous view sample Map
	while ( sampIter != sampEnd
	&&      sampIter->first < m_FirstInstVAddr)
	{
		sampIter++;
	}

	while (dasmIter != dasmEnd) {
		tAddr = (VADDR) (*dasmIter).address;

		if (bbIter != bbEnd) {
			VADDR blockEndAddr = m_vaImageBase + 
				bbIter->second.bb_start_offset +
				bbIter->second.bb_size;
			
			if (tAddr >= blockEndAddr) {
				bBackground = !bBackground;
				bNewBlock = true;
				bbIter--;
			}
		} 

		DASM_LV_ITEM dv_item;
		dv_item.Instruction = (*dasmIter).disassembly;
		char buff[LONG_STR_MAX];
		snprintf (buff, LONG_STR_MAX - 1, LONG_FORMAT, (unsigned long)tAddr);
		dv_item.CsEip = buff;
		dv_item.CodeBytes = (*dasmIter).codebytes;
		
		pItem = new DasmTabItem (m_pAsmList, dv_item,
						m_pViewShown, ASM_OFFSET_INDEX);
		if (!pItem)
			goto FUNC_EXIT;

		if (bBackground)
			pItem->setBackgroundColor(Qt::lightGray);

		if (bNewBlock) {
			QString symName;	

			// update Load/store info for previous block;
			if (pBlockStartItem) {
				symName = pBlockStartItem->text(ASM_SYMBOL_COLUMN);
				symName += " (" + QString::number(loadCnt, 10) + " / " + 
						QString::number(storeCnt, 10) + ")";

				pBlockStartItem->setText(ASM_SYMBOL_COLUMN,symName); 
			}

			// Look up symbol information from symbol engine
			// to fill in the Symbol column
			sym_info funcSym;
			funcSym.clear();

			if (SymbolEngine::OKAY == m_dasmtab_symengine->getSymbolForAddr(
							tAddr,&funcSym)) {
				symName = funcSym.name;
			}

			VADDR offset = tAddr - funcSym.sym_start;

			// Append offset value
			if (offset > 0)	{
				symName = funcSym.name+ " + 0x" + QString::number(offset,16);
			}
			pItem->setText(ASM_SYMBOL_COLUMN,symName); 
			
			pBlockStartItem = pItem;
			loadCnt = 0;
			storeCnt = 0;
			bNewBlock = false;

		}

		UINT32 delta = m_Address - tAddr;
		if (delta < closest) {
			m_pItemOfInterest = pItem;
			closest = delta;
		}

		// accumulate memory access info		
		while (memAccIter != memAccEnd) {
			VADDR memAccAddr = m_vaImageBase + memAccIter->first;
			if (tAddr < memAccAddr )
				break;

			if (tAddr ==  memAccAddr) {
				switch(memAccIter->second) {
					case MA_READ:
						loadCnt++;
						break;
					case MA_WRITE:
						storeCnt++;
						break;
					case MA_READWRITE:
						loadCnt++;
						storeCnt++;
						break;
					default:
						break;
				}
				memAccIter++;
				break;
			}

			memAccIter++;
		}

		// Accumulate samples for view items
		while (sampIter != sampEnd) {
			if (sampIter->first >= tAddr) {
				break;
			} else {
				if (sampIter->first >= m_LastInstVAddr) {
					AggregateSamples(itemSamples, sampIter->second);
				}
				sampIter++;
			}
		};
		
		if (m_LastInstVAddr != 0) {
			if (itemSamples.size()) 
				m_ViewSampMap.insert(SampleMap::value_type(
							m_LastInstVAddr, itemSamples));

			itemSamples.clear();
		}

		m_LastInstVAddr = tAddr; 

		dasmIter++;	
	}
	BuildUpWorkflowMap();

	onViewChanged (m_pViewShown);

	/* go to address the user clicked on */
	if (m_pItemOfInterest) {
		m_pAsmList->setSelected (m_pItemOfInterest, true);
		m_pAsmList->setCurrentItem (m_pItemOfInterest);
		m_pAsmList->ensureItemVisible (m_pItemOfInterest);
	}

FUNC_EXIT:
	if (!bRet) {
		QMessageBox::information(NULL, "Disassembly Error",
				"There was no enough memory to create disassembly item.");
	}


	return bRet;
}

void DasmTab::BuildUpWorkflowMap()
{
	m_ViewBrDestMap.clear();
	m_ViewBrSrcMap.clear();

	unsigned int viewStartOffset = m_FirstInstVAddr - m_vaImageBase;
	unsigned int viewEndOffset = m_LastInstVAddr - m_vaImageBase;

	BRANCHINSTRMAP *pBrMap = m_bba.bba_get_jump_map();
	BRANCHINSTRMAP::iterator brIter = pBrMap->lower_bound(viewStartOffset);
	BRANCHINSTRMAP::iterator brEnd = pBrMap->end();

	while(brIter != brEnd) {
		if (brIter->second.instr_offset < viewStartOffset) {
			brIter++;
			continue;
		}

		if (brIter->second.instr_offset > viewEndOffset)
			break;

		// branch instruction is in the display range;
		if (brIter->second.destination_offset != 0) {
			m_ViewBrDestMap.insert(BR_DEST_MAP::value_type(
					brIter->second.instr_offset + m_vaImageBase,
					brIter->second.destination_offset + m_vaImageBase));

		}

		brIter++;
	}

	pBrMap = m_bba.bba_get_call_map();
	brIter = pBrMap->lower_bound(viewStartOffset);
	brEnd = pBrMap->end();
	while(brIter != brEnd) {
		if (brIter->second.instr_offset < viewStartOffset) {
			brIter++;
			continue;
		}

		if (brIter->second.instr_offset > viewEndOffset)
			break;

		// branch instruction is in the display range;
		if (brIter->second.destination_offset != 0) {
			m_ViewBrDestMap.insert(BR_DEST_MAP::value_type(
					brIter->second.instr_offset + m_vaImageBase,
					brIter->second.destination_offset + m_vaImageBase));

		}

		brIter++;
	}

	MULTIMAP *pBrDestMap = m_bba.bba_get_br_dest_map();
	MULTIMAP::iterator brDestIter = pBrDestMap->lower_bound(viewStartOffset);
	MULTIMAP::iterator brDestEnd = pBrDestMap->end();;
	while(brDestIter != brDestEnd) { 
		if (brDestIter->first < viewStartOffset) {
			brDestIter++;
			continue;
		}

		if (brDestIter->first > viewEndOffset)
			break;

		m_ViewBrSrcMap.insert(BR_DEST_MAP::value_type(
					brDestIter->first + m_vaImageBase,
					brDestIter->second + m_vaImageBase));

		brDestIter++;
	}
}

void DasmTab::OnPageUp ()
{
	if (m_oneAtATime) {
		//ignore the scroll event if we're currently processing one
		return;
	}
	m_oneAtATime = true;

	if (m_pScrollBar->value () == m_pScrollBar->minValue ()) {
		m_Address = m_FirstInstVAddr;
		m_pAsmList->clear ();
		Dasm ();
	}
	else {
		int visibleheight = m_pAsmList->visibleHeight ();
		m_pAsmList->scrollBy (0, -visibleheight);
	}
	m_oneAtATime = false;
}


void DasmTab::OnPageDown ()
{
	if (m_oneAtATime) {
		return;
	}
	m_oneAtATime = true;

	if (m_pScrollBar->value () == m_pScrollBar->maxValue ()) {
		m_Address = m_LastInstVAddr;
		m_pAsmList->clear ();
		Dasm ();
	}
	else {
		int visibleheight = m_pAsmList->visibleHeight ();
		m_pAsmList->scrollBy (0, visibleheight);
	}
	m_oneAtATime = false;
}

//
bool DasmTab::GetSectionMap()
{
	bool bRet = true;
	label_info t_label;
	section_map_type::iterator it;
	if (NULL == m_dasmtab_symengine) {
		bRet = false;
		goto FUNC_EXIT;
	}

	if (SymbolEngine::OKAY != m_dasmtab_symengine->getAllSections (
							&m_SectionMap)) {
		bRet = false;
		goto FUNC_EXIT;
	}

FUNC_EXIT:
	return bRet;
}

void DasmTab::OnRightClick (QListViewItem * pItem, const QPoint & pt, int i)
{
	Q_UNUSED (i);

	if(!pItem)
		return;	

	// remove previous dynamic pop-up menu;
	POPUPMENU_MAP::iterator it = m_PopMenuMap.begin();
	POPUPMENU_MAP::iterator itEnd = m_PopMenuMap.end();
	while (it != itEnd) {
		m_pMenu->removeItem(it->first);
		it++;
	}
	m_PopMenuMap.clear();

	QString tstr;
	VADDR itemAddr = 0;
	int menuid = 0;
	itemAddr = (VADDR)pItem->text(ASM_ADDRESS_COLUMN).toULongLong(NULL, 16);

	BR_DEST_MAP::iterator brDestIt;
	brDestIt = m_ViewBrDestMap.find(itemAddr);
	if (brDestIt != m_ViewBrDestMap.end()) {
		// insert separator
		menuid = m_pMenu->insertSeparator();
		m_PopMenuMap.insert(POPUPMENU_MAP::value_type(menuid, 0));
	
		// insert destination address pop-up menu	
		tstr.sprintf("Dest: 0x%lx", brDestIt->second);	
		menuid = m_pMenu->insertItem (tstr, this, 
					SLOT(OnMenuItemClick(int)), Key_D);

		m_PopMenuMap.insert(POPUPMENU_MAP::value_type(menuid, 
					brDestIt->second));
	}

	brDestIt = m_ViewBrSrcMap.find(itemAddr);
	BR_DEST_MAP::iterator brDestItEnd = m_ViewBrSrcMap.end();
	if (brDestIt != brDestItEnd) {
		// insert separator
		menuid = m_pMenu->insertSeparator();
		m_PopMenuMap.insert(POPUPMENU_MAP::value_type(menuid, 0));
	}

	while (brDestIt != brDestItEnd) {
		if (itemAddr != brDestIt->first) {
			break;
		}

		// insert destination address pop-up menu	
		tstr.sprintf("Prev: 0x%lx", brDestIt->second);	
		menuid = m_pMenu->insertItem (tstr, 
					this, SLOT(OnMenuItemClick(int)) , Key_D);

		m_PopMenuMap.insert(POPUPMENU_MAP::value_type(menuid, 
							brDestIt->second));
		brDestIt++;
	};
	
	m_pMenu->popup (pt);
} //void DasmTab::OnRightClick 


#if 0
void DasmTab::OnDoubleClick(QListViewItem * _pItem, const QPoint & pt, int i)
{
	/* 
 	 * Getting source/destination
 	 */
	QString tstr;
	VADDR itemAddr = 0;
	int menuid = 0;
	vector<unsigned long long> prev;
	vector<unsigned long long> dest;
	DasmTabItem *pItem = (DasmTabItem*)_pItem;

	if(!pItem)
	{
		return;
	}
	itemAddr = (VADDR)pItem->text(ASM_ADDRESS_COLUMN).toULongLong(NULL, 16);

	BR_DEST_MAP::iterator brDestIt;
	brDestIt = m_ViewBrDestMap.find(itemAddr);
	if (brDestIt != m_ViewBrDestMap.end()) {
		dest.push_back(brDestIt->second);
		
	}

	brDestIt = m_ViewBrSrcMap.find(itemAddr);
	BR_DEST_MAP::iterator brDestItEnd = m_ViewBrSrcMap.end();
	while (brDestIt != brDestItEnd) {
		if (itemAddr != brDestIt->first) {
			break;
		}
		prev.push_back(brDestIt->second);
		brDestIt++;
	};

	/*
 	 * Highlight source/destination
 	 */
	vector<unsigned long long>::iterator prev_it = prev.begin();
	vector<unsigned long long>::iterator prev_end = prev.end();
	vector<unsigned long long>::iterator dest_it = dest.begin();
	vector<unsigned long long>::iterator dest_end = dest.end();
	pItem = (DasmTabItem *) m_pAsmList->firstChild ();
	while (pItem) 
	{
		itemAddr = (VADDR)pItem->text(ASM_ADDRESS_COLUMN).toULongLong(NULL, 16);
		if (prev_it != prev_end && itemAddr == *prev_it) 
		{
			pItem->setItemColor(Qt::blue);
			pItem->setVisible(true); 
			prev_it++;	
		} else if (dest_it != dest_end && itemAddr == *dest_it) { 
			pItem->setItemColor(Qt::blue); 
			pItem->setVisible(true); 
			dest_it++;	
		}else{
			// Check if this is inline instance		
			if(pItem->text(ASM_SYMBOL_COLUMN).contains(QString("->")))
			{	
				pItem->setItemColor(Qt::red); 
			}else{
				// Restore original color
				pItem->setItemColor(Qt::black); 
			}

		}

		pItem = (DasmTabItem *) pItem->nextSibling ();
	}
	m_pAsmList->triggerUpdate();

} //void DasmTab::OnDoubleClick
#endif

void DasmTab::OnMenuItemClick(int menuid)
{
	POPUPMENU_MAP::iterator it = m_PopMenuMap.find(menuid);
	if (it != m_PopMenuMap.end()) {
		if (it->second >= m_FirstInstVAddr && 
			it->second <= m_LastInstVAddr) {
			ChangeInterestItem(it->second);
		} else { 
			// Check if the address is in the module section
			VADDR secStart = 0;
			VADDR secEnd = 0;
			// If in the section range display it.
			if (GetSectionAddress (it->second, &secStart, &secEnd)) {
				m_Address = it->second;
				m_densityView->setInterestPoint (m_Address);
				Dasm();
			}
		}
	}
}


void DasmTab::ChangeInterestItem(VADDR focus)
{
	DasmTabItem *pItem = NULL;
	QListViewItemIterator viewIter(m_pList);

	VADDR tAddr = 0;	
	for (; viewIter.current(); ++viewIter) {
		pItem = (DasmTabItem *) *viewIter;

		tAddr =(VADDR)pItem->text(ASM_ADDRESS_COLUMN).toULongLong(NULL, 16);
		
		if (tAddr == focus) {
			m_pItemOfInterest = pItem;
			m_pAsmList->clearSelection();
			m_pAsmList->setSelected (m_pItemOfInterest, true);
			m_pAsmList->setCurrentItem (m_pItemOfInterest);
			m_pAsmList->ensureItemVisible (m_pItemOfInterest);
		}
	}	
}

VADDR DasmTab::FindBlockStartAddr (VADDR centerVAddr)
{

	VADDR retAddr = 0;

	VADDR sectionStart = 0;
	VADDR sectionEnd = 0;
	GetSectionAddress (centerVAddr, &sectionStart, &sectionEnd);
	retAddr = sectionStart;

	BLOCKMAP *pBBMap = NULL;
	pBBMap = m_bba.bba_get_block_map();
	if (!pBBMap)
		return retAddr;

	if (sectionStart + HALFPAGE > centerVAddr)
		return sectionStart;

	unsigned int blockoffset = 0;
	blockoffset = centerVAddr - m_vaImageBase - HALFPAGE;

	BASIC_BLOCK_KEY bbKey;
	bbKey.bb_start = blockoffset;

	BLOCKMAP::iterator bbIter = pBBMap->lower_bound(bbKey);
	if (bbIter != pBBMap->end()) {
		retAddr = bbIter->first.bb_start + m_vaImageBase;
	} else  {
		retAddr = sectionStart;
	}

	return retAddr;
}


VADDR DasmTab::FindStartShowAddress ()
{
	VADDR retAddr = 0;

	return retAddr;

}


void DasmTab::OnSelectionChange ()
{
	DasmTabItem *pItem = (DasmTabItem *) m_pAsmList->firstChild ();

	unsigned int itemCount = 0;

	while (pItem) {
		if (pItem->isSelected ()) {
			itemCount++;
		}
		pItem = (DasmTabItem *) pItem->nextSibling ();
	}

	QString tStr;
	//float mod_pct = 0.0, pct = 0.0;

	tStr.sprintf ("%u instructions, Total" ,itemCount );

	statusBar ()->message (tStr);


}//DasmTab::OnSelectionChange


//This is called when the CodeAnalyst Options are changed
void DasmTab::onViewChanged(ViewShownData* pShownData)
{
	m_pList->setUpdatesEnabled(false);

	CATuneOptions ao;
	ao.getPrecision(&m_precision);

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}
	
	//remove all columns
	clearShownColumns();

	//update shown columns
	if (NULL != m_pColumnMenu)
		m_pColumnMenu->clear();

	if (NULL != m_pColumnIndex) {
		delete [] m_pColumnIndex;
		m_pColumnIndex = NULL;
	}

	/* add data columns */
	if (!initMenu())
		return;

	if(m_pMenu != NULL) {
		if (-1 == m_pMenu->idAt(ASM_POP_SHOWN))
			m_pMenu->insertItem("&Show", m_pColumnMenu);
	}

	// calculate total
	m_TotalSampleDataMap.clear();

	SampleDataMap::iterator it = m_ProfAtt.modTotal.begin();
	SampleDataMap::iterator end = m_ProfAtt.modTotal.end();
	for (; it != end; ++it) {
		// We use -1 to denote "ALL CPU"
                SampleKey key(-1,it->first.event);
                SampleDataMap::iterator tit  = m_TotalSampleDataMap.find(key);
                SampleDataMap::iterator tend  = m_TotalSampleDataMap.end();
                if( tit != tend)
                {
                        tit->second += it->second;
                }else{
                        m_TotalSampleDataMap.insert(SampleDataMap::value_type(key,it->second));
                        
                }
	}

	/* Replace data from dasm items */
	QListViewItemIterator viewItemIt(m_pList);
	QListViewItemIterator viewItemItPrev;
	DasmTabItem * pItem = (DasmTabItem *) *viewItemIt;

	VADDR addr;
	SampleMap::iterator sampIter;
	SampleMap::iterator sampEnd = m_ViewSampMap.end();

	for ( ;viewItemIt.current(); ++viewItemIt) {
		pItem = (DasmTabItem *) *viewItemIt;
		addr = (VADDR)pItem->text(ASM_ADDRESS_COLUMN).toULongLong(NULL, 16);
		pItem->setTotal(&m_TotalSampleDataMap);

		sampIter = m_ViewSampMap.find(addr);
		if (sampIter != sampEnd) {
			pItem->drawData(&(sampIter->second), m_totalModSamples);
		} else {
			pItem->drawData(NULL, m_totalModSamples);
		}

		pItem->updateShown ();
	}

	emit viewChange(m_SampMap);
	m_pList->setUpdatesEnabled(true);
	m_pList->triggerUpdate();
} //DasmTab::onViewChanged



//check for whether the currently shown list changed.
void DasmTab::OnListRedrawn ()
{
	static DasmTabItem *last_top = NULL;
	static DasmTabItem *last_bottom = NULL;

	//instead of checking items at these points, I could start at the first
	//item and scroll through all visible items
	QPoint top_point = QPoint (0, 0);
	QPoint bottom_point = QPoint (0, (m_pAsmList->visibleHeight () - 1));

	DasmTabItem *top = (DasmTabItem *) m_pAsmList->itemAt (top_point);
	DasmTabItem *bottom = (DasmTabItem *) m_pAsmList->itemAt (bottom_point);
	if (NULL != bottom)
		bottom = (DasmTabItem *) bottom->itemBelow ();
	//If the visible items really didn't change...
	if ((last_top == top) && (last_bottom == bottom))
		return;

	last_top = top;
	last_bottom = bottom;

	if ((NULL != top) && (NULL != bottom)) {
		UINT64 start = top->text (ASM_ADDRESS_COLUMN).toULongLong (NULL, HEX_BASE);
		UINT64 end = bottom->text (ASM_ADDRESS_COLUMN).toULongLong (NULL, HEX_BASE);
		if (start < end)
			m_densityView->shownDataChanged (start, end);
		else//in case it's sorted in reverse order...
			m_densityView->shownDataChanged (end, start);
	}
}


void DasmTab::OnDensityVisibilty ()
{
	m_densityView->checkVisibility ();
}


bool DasmTab::displayProgress_callback()
{
	bool ret = true;

	if (NULL == m_prog_dlg)
		return true;

	if (m_display_progress_calls > m_display_progress_threshold) {
		m_prog_dlg->setProgress (m_prog_dlg->progress () + 10);
		qApp->processEvents();
	}

	if (m_prog_dlg->wasCancelled())
		ret = false;

	return ret;
}

bool DasmTab::initialize_symbolengine ()
{
	bool ret = false;

	if (NULL == m_dasmtab_symengine) {
		m_dasmtab_symengine = new SymbolEngine();
		if (NULL == m_dasmtab_symengine)
			goto init_sym_out;
		int temp = m_dasmtab_symengine->open(m_file_path.data(),true);
		if ((SymbolEngine::OKAY != temp)
			&& (SymbolEngine::NO_SYMBOL_TABLE != temp)
			&& (SymbolEngine::NO_SYMBOLS != temp)) {
				QMessageBox::critical (NULL, "Disassembly error", 
					"Could not open symbol engine for file " + m_file_path);
				goto init_sym_out;
		}
		ret = true;
	}
init_sym_out:
	return ret;
}

/////////////////////////////////////////////////////////////////////

DasmDensityView::DasmDensityView (QWidget * parent)
:  ZoomDock (parent)
{
}


DasmDensityView::~DasmDensityView ()
{
}


bool DasmDensityView::initialize (ViewShownData *pViewShown, 
		ProfileAttribute profile, SampleMap * samp_map, VADDR hot_spot)
{
	if (!ZoomDock::initialize ())
		return false;

	addZoomLevel ("Module", DASM_ZOOM_MODULE);
	addZoomLevel ("Function", DASM_ZOOM_SECTION);
	addZoomLevel ("Partial", DASM_ZOOM_USER);
	addZoomLevel ("Current", DASM_ZOOM_SHOWN);

	//create the density chart  and hook it up
	m_dasm_chart = new DasmDensityChart (pViewShown, widget (), profile);
	RETURN_FALSE_IF_NULL (m_dasm_chart, this);

	m_dasm_chart->setInterestAddr (hot_spot);
	if (!m_dasm_chart->initialize (samp_map))
		return false;

	setChartArea (m_dasm_chart);
	connect (m_dasm_chart, SIGNAL (doubleClicked (VADDR)), this,
		SLOT (onDoubleClicked (VADDR)));

	connect (parent()->parent(), SIGNAL (viewChange (SampleMap *)),
		m_dasm_chart, SLOT (onViewChanged (SampleMap *)));
	setZoomLevel (DASM_ZOOM_SECTION);

	return true;
}//DasmDensityView::initialize


//If the shown data is non-contingous (like source view), the start and end
// might be found by searching all shown items for the min and max addresses
void DasmDensityView::shownDataChanged (VADDR start, VADDR end)
{
	m_dasm_chart->markRange (start, end);
	//if we are at the currently shown level of zoom, move chart with scrolling
	if (DASM_ZOOM_SHOWN == m_zoom_level)
		m_dasm_chart->zoomChanged (m_zoom_level);
}


//Called when a new hot spot is given to the dasm view
void DasmDensityView::setInterestPoint (VADDR interesting)
{
	m_dasm_chart->setInterestAddr (interesting);
	//force it to set current reference points
	m_dasm_chart->zoomChanged (m_zoom_level);
}


//Take the chart's double clicked address as the new hot spot
void DasmDensityView::onDoubleClicked (VADDR hot_spot)
{
	if (!hot_spot)
		return;

	emit newHotSpot (hot_spot, m_parent_caption, NULL);
}


void DasmDensityView::setShowCurrentData (bool show_current)
{
	//If the currently shown data doesn't make sense, 
	// disable that level of the zoom
	if (!show_current) {
		if (DASM_ZOOM_SHOWN == m_zoom_level) {
			setZoomLevel (DASM_ZOOM_SECTION);
		}
		//if not just swapping ascending/descending order of samples
		if (DASM_ZOOM_USER != zoomLevelMinimum ()) {
			removeZoomLevel (DASM_ZOOM_SHOWN);
		}
	}
	else {
		addZoomLevel ("Current", DASM_ZOOM_SHOWN);
		//make sure the correct buttons are enabled/disabled.
		setZoomLevel (m_zoom_level);
	}
	setShowMarkedData (show_current);
}


//because we tag it after it's created, when the caption is usually set
void DasmDensityView::setClickedCaption (QString caption)
{
	m_parent_caption = caption;
}

///////////////////////////////////////////////////////////////////////


//ProfileAttribute is defined in tbsfile.h
DasmDensityChart::DasmDensityChart (ViewShownData *pViewShown, QWidget * parent,
					ProfileAttribute profile)
:  DensityChartArea (pViewShown, parent)
{
	m_profile = profile;
	m_symbols_engine = NULL;
}


DasmDensityChart::~DasmDensityChart ()
{
	m_sample_list.clear ();
	if (NULL != m_symbols_engine)  {
		m_symbols_engine->closeEngine();
		delete m_symbols_engine;
		m_symbols_engine = NULL;
	}
}


//If this returns false, the initialization failed, and the chart area
// shouldn't be used.
//SampleMap is defined in stdafx.h
bool DasmDensityChart::initialize (SampleMap * samp_map)
{
	bool ret = false;
	if (!DensityChartArea::initialize (m_profile))
		return ret;

	m_module_name = m_profile.modPath;
	ret = initialize_symbolengine();
	storeSessionData (samp_map);

	connect (this, SIGNAL (groupDoubleClicked (UINT64)),
		this, SLOT (onGroupDoubleClicked (UINT64)));

	return ret;
}



bool DasmDensityChart::initialize_symbolengine ()
{
	bool ret = false;

	if (NULL == m_symbols_engine) {
		m_symbols_engine = new SymbolEngine();
		if (NULL == m_symbols_engine)
			goto init_sym_out;
	
		int temp = m_symbols_engine->open (m_module_name);
		if ((SymbolEngine::OKAY != temp)
		&&  (SymbolEngine::NO_SYMBOL_TABLE != temp)
		&&  (SymbolEngine::NO_SYMBOLS != temp)) {
			QMessageBox::critical( this, "CodeAnalyst module error", 
			QString("DasmDensityChart ERROR:\n")
			+ "Error openning symbol engine for module "
			+ m_module_name + ".");
			goto init_sym_out;
		}

		if (!readModuleData ()) {
			QString message = "Unable to open " + m_module_name;
			message += " to read the symbolic information.";
			QMessageBox::critical (this, "CodeAnalyst module error", message);
			goto init_sym_out;
		}
		ret = true;
	}

init_sym_out:
	return ret;
}

void DasmDensityChart::onViewChanged (SampleMap *pSamples)
{
	storeSessionData (pSamples);
	onShownChanged ();
}


//Translates the sample data for the module into a more appropriate form
//SampleMap is defined in stdafx.h
void DasmDensityChart::storeSessionData (SampleMap * samp_map)
{
	m_sample_list.clear ();
	SampleMap::iterator it;
	
	for (it = samp_map->begin (); it != samp_map->end (); it++) {
		DasmChartSample temp;

		temp.addr = it->first;
		//temp.function = it->second.Symbol;

		//remove offsets, if present, from the function string
		//int offset = temp.function.findRev ('+');
		//if (offset > 0)
		//	temp.function.truncate (offset);

		//we aggregate accross all cpus per event
		temp.samples.resize (m_pViewShown->available.size(), 0);

		SampleDataMap::iterator sample_it = it->second.begin();
		SampleDataMap::iterator sample_end = it->second.end();
		for (; sample_it != sample_end; sample_it++) {
			unsigned long long deEvent;
			unsigned char deUMask;
			DecodeEventMask(sample_it->first.event, &deEvent, &deUMask);
			CpuEventType key(sample_it->first.cpu, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			int index = m_pViewShown->indexes[key];

			//aggregate
			temp.samples[index] += sample_it->second;

			//if part of complex column, re-calculate
			ComplexDependentMap::Iterator complex = 
					m_pViewShown->calculated.find (index);

			if (complex != m_pViewShown->calculated.end()) {
				ListOfComplex::Iterator cpxIt = (*complex).begin();
				for (; cpxIt != (*complex).end(); ++cpxIt) {
					float calc = m_pViewShown->setComplex (&(*cpxIt),
						&(temp.samples));
					int complexIndex = (*cpxIt).columnIndex;
					temp.samples[complexIndex] = calc;
				}
			}
		}

		m_sample_list.push_back (temp);
	}
}


//Lei:TODO: why mdoule_name is not used? 
// 
//Note that we leave the symbol engine open, to be able to take clicks &
// zooms to function level.
bool DasmDensityChart::readModuleData ()
{
	bfd_vma temp_vma = 0;

	if (NULL == m_symbols_engine ) 
		return false;

	if (SymbolEngine::OKAY != m_symbols_engine->getImageBaseAddr (&temp_vma))
		return false;

	m_mod_start = temp_vma;

	if (SymbolEngine::OKAY != m_symbols_engine->getImageSize (&temp_vma)) 
		return false;

	m_mod_end = temp_vma + m_mod_start;

	section_map_type section_map;
	if (SymbolEngine::OKAY != m_symbols_engine->getAllSections (&section_map))
		return true;

	/// we got enough information, just not the data sections...
	section_map_type::iterator it;
	for (it = section_map.begin (); it != section_map.end (); it++) {
		section_map_type::value_type & t_section_value = *it;
		section_info temp_section = t_section_value.second;



		if (temp_section.is_code)
		{
			// Sanity check if we cannot get module start/end address,
			// just use the beginning of the first section and the end of
			// the last section.
			if(m_mod_start > t_section_value.first)
				m_mod_start = t_section_value.first;

			if(m_mod_end < temp_section.end)
				m_mod_end = temp_section.end;
		
			//only keep track of data sections.  Assume everything else is code
			continue;
		}	

		ChartSectionType test;
		test.start = t_section_value.first;
		test.end = temp_section.end;

		m_sections.push_back (test);

	}

	return true;
} //DasmDensityChart::readModuleData


//recalculates shown stuff from current center, and current start/end
void DasmDensityChart::zoomChanged (int zoom_level)
{
	QString label;
	char num[LONG_STR_MAX];
	sym_info temp_sym;

	if (!m_initialized || NULL == m_symbols_engine )
		return;

	switch (zoom_level) {
		case DASM_ZOOM_MODULE:
			m_cur_start = m_mod_start;
			m_cur_end = m_mod_end;
			break;

		case DASM_ZOOM_SECTION:
			{
				//if m_start_interest is in a function, show function!
				//otherwise a 4K region centering on it
				//SymbolEngine symbols;
				//int temp = symbols.open (m_module_name);

				int ret = m_symbols_engine->getSymbolForAddr(
							m_start_interest, &temp_sym);

				if (SymbolEngine::OKAY == ret) {
					m_cur_start = temp_sym.sym_start;
					m_cur_end = temp_sym.possible_end;
					
					if (0 == m_cur_end)
						m_cur_end = m_start_interest + 2048;
				} else {
					//otherwise a 4K-byte region around interest
					m_cur_start = m_start_interest - 2048;
					m_cur_end = m_start_interest + 2048;
				}

				/* Note: In some newer Linux distribution
				 * (i.e. OpenSuSE11 w/ binutils-2.18.50)
				 * the created jit module does not have the
				 * program header section. Therefore, it failed
				 * to locate imagebase. A work around for this case
				 * is to use function start/stop address instead. 
				 */
				if(m_mod_start == ~0UL)
				{
					m_mod_start = m_cur_start;
					m_mod_end   = m_cur_end;
				}


				break;
			}
		case DASM_ZOOM_USER:
			//if user specified region
			if (0 != m_end_interest) {
				m_cur_start = m_start_interest;
				m_cur_end = m_end_interest + 1;
			}
			else {
				//otherwise a 400-byte region around interest
				m_cur_start = m_start_interest - 200;
				m_cur_end = m_start_interest + 200;
			}
			break;

		case DASM_ZOOM_SHOWN:
			m_cur_start = m_mark_start;
			m_cur_end = m_mark_end;
			break;
	}

	//just in case...
	if (m_cur_start > m_cur_end)
		m_cur_start = 0;
	if (m_cur_end > m_mod_end)
		m_cur_end = m_mod_end;

	sprintf (num, LONG_FORMAT, (unsigned long)m_cur_start);
	label = num;
	sprintf (num, LONG_FORMAT, (unsigned long)m_cur_end);
	setCurrentRange (m_cur_start, m_cur_end, label, QString (num));

	calculateScale ();
}//DasmDensityChart::zoomChanged


//update section info with group data, for easy display
void DasmDensityChart::groupSections ()
{
	ChartSectionList::iterator section;
	ChartSectionList::iterator sectionEnd = m_sections.end();

	for (section = m_sections.begin (); section != sectionEnd; ++section) {
		//if the section is off the currently shown area of the chart, skip
		if ((m_cur_start > (*section).end) || 
				(m_cur_end <= (*section).start)) {
			(*section).shown = false;
			continue;
		}

		(*section).shown = true;
		(*section).group_start = ((*section).start - m_cur_start)
			/ m_group_range;

		//don't start before shown group 0
		if (0 > (*section).group_start)
			(*section).group_start = 0;

		(*section).group_end = ((*section).end - m_cur_start)
			/ m_group_range;

		//don't keep drawing beyond shown
		if ((*section).group_end > m_group_count)
			(*section).group_end = m_group_count;
	}
}


// Given the current space, partitions the shown region into groups
// these groups aggregate all samples within them, so the max sample changes
// Note that we do this once per resizing/recalculation/zoom
bool DasmDensityChart::groupData ()
{
	int group;
	m_max_group_sample = 0;

	//allocate new groups
	m_groups = new ChartGroupType[m_group_count];
	RETURN_FALSE_IF_NULL (m_groups, this);

	groupSections ();

	//sort raw data into groups
	for (group = 0; group < m_group_count; group++) {
		m_groups[group].samples.resize (m_pViewShown->available.size(), 0);

		//saves from recalculating this every time.
		m_groups[group].start = m_group_range * (group) + m_cur_start;
		m_groups[group].end = m_group_range * (group + 1) + m_cur_start - 1;

		//The DasmDensityChart saves the first address with samples within the
		//  range in the group.data member
		m_groups[group].data = m_groups[group].end;
		m_groups[group].label = QString::null;
	}

	//For each sample
	DasmChartSampleList::iterator it;
	for (it = m_sample_list.begin (); it != m_sample_list.end (); ++it) {
		//if the sample is outside the current range, don't add it to a shown
		// group
		if ((m_cur_start > (*it).addr) || (m_cur_end <= (*it).addr)) {
			continue;
		}

		group = ((*it).addr - m_cur_start) / m_group_range;
		if (group > m_group_count)
			continue;

		//save first sample address in the group as data
		if ((m_groups[group].data > (*it).addr)
			|| (m_groups[group].label.isEmpty ())) {
				m_groups[group].data = (*it).addr;

				//save the function of the address as the label
				m_groups[group].label = (*it).function;
		}

		for (UINT ev = 0; ev < m_pViewShown->shown.size(); ev++) {
			int index = m_pViewShown->shown[ev];
			m_groups[group].samples[index] += (*it).samples[index];

			//The max group sample sets the y scale.
			if (m_max_group_sample < m_groups[group].samples[index]) {
				m_max_group_sample = m_groups[group].samples[index];
			}
		}
	}//for each sample
	return true;
}//DasmDensityChart::groupData


void DasmDensityChart::tipGroups ()
{
	QString tip;
	char num[LONG_STR_MAX];
	int max = 0;

	if (NULL == m_groups)
		return;

	for (int group = 0; group < m_group_count; group++) {
		//Show the range of the group in the tool tip
		sprintf (num, LONG_FORMAT, (unsigned long) m_groups[group].start);
		if (m_groups[group].start != m_groups[group].end) {
			tip = num + QString (" to ");
			sprintf (num, LONG_FORMAT, (unsigned long) m_groups[group].end);
			tip += num;
		} else
			tip = num;

		//If there was a label for the group, show it.
		if (!m_groups[group].label.isEmpty ()) {
			tip += QString ("\n") + m_groups[group].label;
		}

		for (UINT ev = 0; ev < m_pViewShown->shown.size(); ev++) {
			int index = m_pViewShown->shown[ev];

			tip += QString ("\n\t");
			tip += QString::number (m_groups[group].samples[index]);
			tip += QString (": ");
			tip += m_pViewShown->tips[index];

			if (max < m_groups[group].samples[index])
				max = m_groups[group].samples[index];
		}

		//The tool tip for the group covers all bars in the group
		m_groups[group].tip_rect = groupTipRect (group, max);

		//If there is no chart to show, don't add a tool-tip
		if (0 == m_groups[group].tip_rect.height ()) {
			continue;
		}

		QToolTip::add (this, m_groups[group].tip_rect, tip);
	}//for each group
}// DasmDensityChart::tipGroups


//When a new hotspot is set, set the point of interest in the chart
void DasmDensityChart::setInterestAddr (VADDR interesting)
{
	m_end_interest = 0;
	m_start_interest = interesting;
	update ();
}


void DasmDensityChart::onGroupDoubleClicked (UINT64 group_data)
{
	emit doubleClicked (group_data);
}
