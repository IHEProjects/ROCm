//$Id: codeDensity.cpp,v 1.20 2005/02/14 16:52:29 jyeh Exp $
// inplementation for the CodeDensityChart class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qlayout.h>
#include <qcombobox.h>
#include <stdlib.h>

#include "codeDensity.h"
#include "eventsfile.h"
#include "helperAPI.h"
#include "colorDlg.h"


enum LocalFileEnumType {
	SPACE = 1,
	MIN_BAR_WIDTH = 5,
	CHART_MIN_WIDTH = 100,
	CHART_MIN_HEIGHT = 100,
	CHART_RIGHT_BORDER = 10,
	CHART_TOP_BORDER = 20,
	GROUP_OFFSET = 3,
	PEN_PIXEL_WIDTH = 2,
	ZOOM_LAYOUT_L_COL = 0,
	ZOOM_LAYOUT_R_COL = 1,
	ZOOM_LAYOUT_T_ROW = 0,
	ZOOM_LAYOUT_M_ROW = 1,
	ZOOM_LAYOUT_B_ROW = 2
};

static QColor CODE_SECTION = Qt::black;
static QPen NOT_CODE_SECTION = QPen (Qt::red, PEN_PIXEL_WIDTH);
static QColor INTEREST_LINE = Qt::blue;
static QPen CUR_RANGE_START = QPen (Qt::green, PEN_PIXEL_WIDTH);
static QPen CUR_RANGE_END = QPen (Qt::red, PEN_PIXEL_WIDTH);

DensityChartArea::DensityChartArea (ViewShownData *pViewShown, QWidget * parent)
:  QWidget (parent)
{
	m_pViewShown = pViewShown;

	CATuneOptions ao;
	ao.getCpuColorList (&m_colorList);

	setMinimumHeight (CHART_MIN_HEIGHT);
	//need three label widths as minimum, shouldn't really be a problem
	setMinimumWidth (fontMetrics ().width ("0x08000000") * 3);

	m_groups = NULL;
	m_group_count = 0;

	m_end_interest = 0;

	m_show_marks = true;
	m_initialized = false;
	m_user_dragging = false;
}


DensityChartArea::~DensityChartArea ()
{
	if (NULL != m_groups) {
		//there is no problem removing a tooltip that wasn't added
		for (int i = 0; i < m_group_count; i++)
			QToolTip::remove (this, m_groups[i].tip_rect);
		delete [] m_groups;
	}
	m_groups = NULL;

	m_sections.clear ();
}


//If this returns false, the initialization failed, and the chart area 
// shouldn't be used.
bool DensityChartArea::initialize (ProfileAttribute profile)
{
	Q_UNUSED (profile);
	m_popup = new QPopupMenu (this);
	RETURN_FALSE_IF_NULL (m_popup, this);

	m_popup->insertItem( "Manage Colors", this, SLOT (OnManageColors()) );

	m_initialized = true;

	return true;
}


void DensityChartArea::OnManageColors ()
{
	ColorDlg *pColor = new ColorDlg (m_pViewShown->available, &m_colorList, 
		this, NULL, true, WDestructiveClose);
	RETURN_IF_NULL (pColor, this);
	pColor->exec ();
}


void DensityChartArea::setCurrentRange (UINT64 start, UINT64 end,
										QString start_label, QString end_label)
{
	m_cur_start = start;
	m_cur_end = end;
	m_start_label = start_label;
	m_end_label = end_label;
}


//change marked scope, for our purposes, you would want to set a slot for
// the contentsRedrawn signal of the listbox to check if the currently shown
// range has changed, since we're using the marked range to show the currently
// shown range from the listbox
void DensityChartArea::markRange (UINT64 start, UINT64 end)
{
	m_mark_start = start;
	m_mark_end = end;
	update ();
}


//based on current scope and section info, the axii meet at point 
// (m_yaxis_at_x, m_xaxis_at_y)
void DensityChartArea::drawAxis (QPainter * painter)
{
	if (m_user_dragging)
		return;

	//draw x axis from the y axis to the right border
	painter->setPen (CODE_SECTION);
	painter->drawLine (m_yaxis_at_x, m_xaxis_at_y,
		(width () - CHART_RIGHT_BORDER), m_xaxis_at_y);

	//Highlight each shown non-code section on the x axis...
	painter->setPen (NOT_CODE_SECTION);
	ChartSectionList::iterator it;
	for (it = m_sections.begin (); it != m_sections.end (); ++it) {
		//if a section starts before the currently shown, start is -
		if (!(*it).shown)
			continue;

		//since the section starts at one group, the line starts at the x
		// location of the start group (see drawGroups), and ends at the x 
		// location of the end group, along the x axis
		painter->drawLine (int (m_yaxis_at_x + m_one_group_width
			* (*it).group_start), m_xaxis_at_y,
			int (m_yaxis_at_x + m_one_group_width
			* (*it).group_end), m_xaxis_at_y);
	}

	//draw y axis from the x axis to the top border
	painter->setPen (CODE_SECTION);
	painter->drawLine (m_yaxis_at_x, (CHART_TOP_BORDER + SPACE), m_yaxis_at_x,
		m_xaxis_at_y);
}                               //DensityChartArea::drawAxis


//This will draw the data, in groups, with a bar for each shown event
void DensityChartArea::drawGroups (QPainter * painter)
{
	//Group to pixels explanation:
	//initial value of x, the groups begin after the y axis, with a small
	// offset to make the various indicators easier to see.
	// Group 0 is drawn here.  All following groups are drawn at index *
	// width of one group plus this start location.
	int x = m_yaxis_at_x + GROUP_OFFSET;

	if (NULL == m_groups)
		return;

	for (int group = 0; group < m_group_count; group++) 
	{
		//They might be showing the 1st and 3rd events...
		for (UINT ev = 0; ev < m_pViewShown->shown.size(); ev++)
		{
			UINT index = m_pViewShown->shown[ev];

			//scale the height appropriately to the max samples in the current
			// reange
			int height = int (m_groups[group].samples[index] / m_yscale);

			//draw each bar in the group representing one event seperately
			if (index >= m_colorList.count())
			{
				UINT maxCol = index - m_colorList.count();
				for (UINT i = 0; i <= maxCol; i++)
				{
					m_colorList.push_back (QColor (QRgb (rand())));
				}
				CATuneOptions ao;
				ao.setCpuColorList (&m_colorList);
			}

			//draw each bar in the group representing one event seperately
			painter->fillRect (x, (m_xaxis_at_y - 1 - height),
				(int) m_one_bar_width, height,
				m_colorList[index]);

			x += (int) m_one_bar_width;
		}
		//go past space between groups
		x += (int) m_one_bar_width;
	}
}                               //DensityChartArea::drawGroups


//four labels are drawn, 2 x and 2 y
//We have to adjust for the height of the text in these.
void DensityChartArea::drawTicks (QPainter * painter)
{
	if (m_user_dragging)
		return;
	int height_space = height () - 2 * SPACE;

	//x labels, just first, last
	//The start range label is drawn where the x and y axii meet, under the x 
	// axis.
	painter->drawText (m_yaxis_at_x, height_space, m_start_label);
	//The end range label is drawn under the end range group, which may not be
	// at the right edge of the chart, depending on the calculated scale
	int x = int (m_yaxis_at_x + (m_cur_end - m_cur_start + 1)
		* m_one_group_width - fontMetrics ().width (m_end_label)
		- SPACE);
	//If the label would be drawn off the chart, it is shown at the right edge
	if ((x + fontMetrics ().width (m_end_label)) > width ())
		x = width () - fontMetrics ().width (m_end_label);
	painter->drawText (x, height_space, m_end_label);

	//y labels, just first, last
	//The max samples for the current range is shown to let the user know the
	// scale.  It's drawn at the top of the chart, to the left of the y axis
	painter->drawText (SPACE, SPACE,
		(m_yaxis_at_x - SPACE), m_font_height, Qt::AlignRight,
		QString::number (m_max_group_sample));
	//The min samples is always 0, and is shown right next to where the x and y
	//axii meet
	painter->drawText (SPACE, (height_space - 2 * m_font_height),
		(m_yaxis_at_x - SPACE),
		m_font_height, Qt::AlignRight, QString ("0"));
}


//The interest lines are for the user-defined range.
void DensityChartArea::drawInterestLines (QPainter * painter)
{
	int start, end;
	//find group of start
	start = (m_start_interest - m_cur_start) / m_group_range;

	//If the start line can be shown, draw start line
	if ((start >= 0) && (start < m_group_count)) {
		painter->setPen (INTEREST_LINE);

		//The vertical line should be drawn before the start group of interest
		//see drawGroups for the group -> x pixels calculations
		int x = int (m_yaxis_at_x + 1 + start * m_one_group_width);
		//we draw this from the top of the chart to just above the x axis
		painter->drawLine (x, (CHART_TOP_BORDER + SPACE), x,
			(m_xaxis_at_y + 1));
	}

	//if the end is specified, it may not be if it was double-clicked
	if (0 != m_end_interest)
		// draw end line after specified group
		end = (m_end_interest - m_cur_start) / m_group_range;
	else
		// draw end line after start group
		end = start;
	//We want to draw the end interest line before the start of the next group
	end++;

	//If the end line can be shown, draw end line
	if ((end >= 0) && (end <= m_group_count)) {
		painter->setPen (INTEREST_LINE);
		//see drawGroups for the group -> x pixels calculations
		int x = int (m_yaxis_at_x + 1 + end * m_one_group_width);
		//we draw this vertical line from the top of the chart to just above
		// the x axis
		painter->drawLine (x, (CHART_TOP_BORDER + SPACE), x,
			(m_xaxis_at_y + 1));
	}
} //DensityChartArea::drawInterestLines


//The marked lines are currently for the range shown in the listbox
void DensityChartArea::drawCurrentMarkers (QPainter * painter)
{
	if (m_user_dragging)
		return;
	int start, end;
	//If the listbox is not sorted according to range, these aren't shown
	if (!m_show_marks)
		return;

	//find group of start
	start = (m_mark_start - m_cur_start) / m_group_range;

	//If the start line is within the currently shown, draw start line
	if ((start >= 0) && (start < m_group_count)) {
		painter->setPen (CUR_RANGE_START);
		//see drawGroups for the group -> x pixels calculations
		int x = int (m_yaxis_at_x + 1 + start * m_one_group_width);
		//This vertical line is drawn in the top border
		painter->drawLine (x, (CHART_TOP_BORDER + SPACE), x, 0);
	}

	//find group of end
	end = 1 + (m_mark_end - m_cur_start) / m_group_range;

	//If the end line can be shown, draw end line
	if ((end >= 0) && (end <= m_group_count)) {
		painter->setPen (CUR_RANGE_END);
		//see drawGroups for the group -> x pixels calculations
		int x = int (m_yaxis_at_x + 1 + end * m_one_group_width);
		//This vertical line is drawn in the top border
		painter->drawLine (x, (CHART_TOP_BORDER + SPACE), x, 0);
	} else if (m_mark_end == m_cur_end) {
		//If the end marker is off screen, but we're at the current shown
		// zoom level, just add the marker at the end of the chart.
		painter->setPen (CUR_RANGE_END);
		int x = width () - CHART_RIGHT_BORDER;
		//This vertical line is drawn in the top border
		painter->drawLine (x, (CHART_TOP_BORDER + SPACE), x, 0);
	}
}                               //DensityChartArea::drawCurrentMarkers


//Calculates the rectange for the tooltip for a given group, with a given
// maximum number of samples
QRect DensityChartArea::groupTipRect (int group, unsigned int samples)
{
	//initial value of x, see drawGroups for the group -> x pixel description
	int x = int (m_yaxis_at_x + GROUP_OFFSET + m_one_group_width * group);

	//The start of the rectangle is at the x axis, and it goes up height pixels
	int y_base = m_xaxis_at_y - 1;
	int height = int (samples / m_yscale);

	//The tool tip rectangle covers all the bars in a group
	int width = int (m_pViewShown->shown.size() * m_one_bar_width);

	return QRect (x, (y_base - height), width, height);
}


void DensityChartArea::calculateScale ()
{
	m_max_group_sample = 0;

	//in case the font changed...
	m_font_height = fontMetrics ().height ();
	//This should barely allow for the labels below the axis
	m_xaxis_at_y = height () - (2 * SPACE + m_font_height);
	//The yscale is initialized as all the pixels available between the x axis
	// and the top border
	m_yscale = m_xaxis_at_y - SPACE - CHART_TOP_BORDER;

	//guess that (100 million samples - 1) as max count,
	// we could recalculate after groups are formed, based on 
	// m_max_group_sample, but then we might have to recalculate groups...
	//we initialize the y axis at enough space for the labels to the left of
	// the y axis
	m_yaxis_at_x = 2 * SPACE + fontMetrics ().width ("99999999");

	m_one_bar_width = MIN_BAR_WIDTH;

	//we need to clear the tool tips before we change the group count
	if (NULL != m_groups) {
		//clean up old groups, if applicable
		for (int i = 0; i < m_group_count; i++)
			QToolTip::remove (this, m_groups[i].tip_rect);
		delete[]m_groups;
		m_groups = NULL;
	}

	//if the groups don't cover the entire axis, try to increase bar width
	if (!calculateGroups ()) {
		//since the group address range is <= 1, treat as 1
		//assume # of groups = address range / group address range
		int temp = m_cur_end - m_cur_start;
		if (temp <= 0)
			temp = 1;

		//width of one group = width of one bar * # of bars in group
		//# of groups = pixel range / width of one group
		//so, width of one bar = pixel range / (# of groups * # of bars)
		m_one_bar_width = (width () - m_yaxis_at_x - CHART_RIGHT_BORDER)
			/ (temp * (m_pViewShown->shown.size() + 1));

		//If we can't increase the width, oh well....
		if (m_one_bar_width < MIN_BAR_WIDTH)
			m_one_bar_width = MIN_BAR_WIDTH;

		calculateGroups ();
		m_group_range = 1;
	}
	//calculateGroups may return NULL for m_groups, if out of memory
	groupData ();

	//This is the scale of samples to pixels.  The bar with the max samples 
	// should fill all the space in the chart to the top border.
	m_yscale = (m_max_group_sample / m_yscale);

	//now that we have the y scale, add tool tips to each group.
	tipGroups ();

	//force redraw
	update ();
}                               //DensityChartArea::calculateScale


//This calculates the number of groups that can be shown, and the range of the
// x axis that each group should then cover.  Because the number of groups *
// the group range should be the minimum to cover the currently shown range,
// there may be more range covered in the groups than the currently shown range
//
//Returns false if the groups to range is 1:1, and we should possibly increase
// the group width size so we're not showing a lot of groups beyond the 
// currently shown range
bool DensityChartArea::calculateGroups ()
{
	//assume space of one bar between groups
	m_one_group_width = (m_pViewShown->shown.size() + 1) * m_one_bar_width;
	//number of groups = width of chart / width of one group
	m_group_count = int ((width () - m_yaxis_at_x - CHART_RIGHT_BORDER)
		/ m_one_group_width);

	//at least one group should be shown
	if (1 > m_group_count)
		m_group_count = 1;

	//range of each group = current range / number of groups, plus one to 
	// ensure that the m_cur_end is shown
	m_group_range = (m_cur_end - m_cur_start) / m_group_count + 1;

	return m_group_range > 1;
}


//overrides qwidget virtual function to draw the chart
void DensityChartArea::paintEvent (QPaintEvent * paint_event)
{
	if (!m_initialized)
		return;
	QPainter p (this);

	p.setClipping (TRUE);
	p.setClipRect (paint_event->rect ());

	drawAxis (&p);
	drawTicks (&p);
	drawGroups (&p);
	drawInterestLines (&p);
	drawCurrentMarkers (&p);
}


void DensityChartArea::mousePressEvent (QMouseEvent * e)
{
	//select the first group of interest
	if (LeftButton == e->button ()) 
	{
		m_user_group = -1;
		if (NULL == m_groups)
			return;

		//ignore if outside chart
		if ((e->x () <= m_yaxis_at_x) || (e->y () >= m_xaxis_at_y))
			return;

		//See drawGroups for pixel-> group description
		int group = int ((e->x () - m_yaxis_at_x - GROUP_OFFSET)
			/ m_one_group_width);
		if ((group < 0) || (group >= m_group_count)) {
			return;
		}
		m_user_group = group;
		m_end_interest = 0;
		m_start_interest = m_groups[group].start;
		m_user_dragging = true;
		update ((m_yaxis_at_x + 1), (CHART_TOP_BORDER + SPACE), 
			(width() - m_yaxis_at_x - CHART_RIGHT_BORDER - SPACE),
			(m_xaxis_at_y - CHART_TOP_BORDER - SPACE));
	} else {
		m_popup->popup (QPoint (e->globalX (), e->globalY()));
	}
}


void DensityChartArea::mouseMoveEvent (QMouseEvent * e)
{
	if (!m_user_dragging)
		return;
	if (m_user_group < 0)
		return;
	if (NULL == m_groups)
		return;

	//ignore if outside chart
	if ((e->x () <= m_yaxis_at_x) || (e->y () >= m_xaxis_at_y))
		return;

	//assign end point of interest, after the selected group
	//See drawGroups for pixel-> group description
	int group = int ((e->x () - m_yaxis_at_x - GROUP_OFFSET)
		/ m_one_group_width);
	if ((group < 0) || (group >= m_group_count)) {
		group = m_user_group;
	}

	//start and end the intrest range correctly, no matter whether the user
	// dragged from left to right or right to left
	if (group < m_user_group) {
		m_end_interest = m_groups[m_user_group].end;
		m_start_interest = m_groups[group].start;
	} else if (group == m_user_group) {
		m_end_interest = 0;
		m_start_interest = m_groups[group].start;
	} else {
		m_end_interest = m_groups[group].end;
		m_start_interest = m_groups[m_user_group].start;
	}
	update ((m_yaxis_at_x + 1), (CHART_TOP_BORDER + SPACE), 
		(width() - m_yaxis_at_x - CHART_RIGHT_BORDER),
		(m_xaxis_at_y - CHART_TOP_BORDER - SPACE));
}


void DensityChartArea::mouseReleaseEvent (QMouseEvent * e)
{
	m_user_dragging = false;
	//ignore right clicks
	if (LeftButton == e->button ()) {
		if (m_user_group < 0)
			return;
		if (NULL == m_groups)
			return;

		//ignore if outside chart
		if ((e->x () <= m_yaxis_at_x) || (e->y () >= m_xaxis_at_y))
			return;

		//assign end point of interest, after the selected group
		//See drawGroups for pixel-> group description
		int group = int ((e->x () - m_yaxis_at_x - GROUP_OFFSET)
			/ m_one_group_width);
		if ((group < 0) || (group >= m_group_count)) {
			group = m_user_group;
		}

		//start and end the intrest range correctly, no matter whether the user
		// dragged from left to right or right to left
		if (group < m_user_group) {
			m_end_interest = m_groups[m_user_group].end;
			m_start_interest = m_groups[group].start;
		} else if (group == m_user_group) {
			m_end_interest = 0;
			m_start_interest = m_groups[group].start;
		} else {
			m_end_interest = m_groups[group].end;
			m_start_interest = m_groups[m_user_group].start;
		}
		update ();
	}
}                               // DensityChartArea::mouseReleaseEvent


//If a bar was double clicked, emits a signal with whatever data was in the
// data field of the group
void DensityChartArea::mouseDoubleClickEvent (QMouseEvent * e)
{
	if (NULL == m_groups)
		return;
	//ignore if outside chart
	if ((e->x () <= m_yaxis_at_x) || (e->y () >= m_xaxis_at_y))
		return;

	//assign start point of interest here
	//See drawGroups for pixel-> group description
	int group = int ((e->x () - m_yaxis_at_x - GROUP_OFFSET)
		/ m_one_group_width);
	if ((group < 0) || (group >= m_group_count))
		return;

	//ignore if the group had no samples.
	if (0 == m_groups[group].tip_rect.height ())
		return;

	m_user_group = -1;
	emit groupDoubleClicked (m_groups[group].data);
}


void DensityChartArea::resizeEvent (QResizeEvent * e)
{
	Q_UNUSED (e);
	if (!m_initialized)
		return;
	//We might have to show more or less groups.
	calculateScale ();
}


void DensityChartArea::onShownChanged ()
{
	if (!m_initialized)
		return;

	//we'll have to recalculate the number of groups shown
	calculateScale ();
}


void DensityChartArea::showMarkedRange (bool show_current)
{
	m_show_marks = show_current;
	update ();
}


ZoomDock::ZoomDock (QWidget * parent)
:  QDockWindow (QDockWindow::InDock, parent)
{
	setResizeEnabled (true);
	m_zoom_box = NULL;
	m_zoom_in = NULL;
	m_zoom_out = NULL;
	m_area = NULL;
	m_min_zoom_level = -1;
	m_parent_caption = parent->caption();
}


ZoomDock::~ZoomDock ()
{
}


bool ZoomDock::initialize ()
{
	QWidget *temp = new QWidget (this);
	RETURN_FALSE_IF_NULL (temp, this);

	//three rows, two columns
	m_layout = new QGridLayout (temp, 3, 2);
	RETURN_FALSE_IF_NULL (m_layout, this);

	//create the Zoom combo box and hook it up
	m_zoom_box = new QComboBox (temp);
	RETURN_FALSE_IF_NULL (m_zoom_box, this);

	QToolTip::add (m_zoom_box, "Current level of zoom");
	connect (m_zoom_box, SIGNAL (activated (int)), this,
		SLOT (onZoomBox (int)));

	//top row, right column
	m_layout->addWidget (m_zoom_box, ZOOM_LAYOUT_T_ROW, ZOOM_LAYOUT_R_COL);

	//create the zoom in button and hook it up
	m_zoom_in = new QPushButton (temp);
	RETURN_FALSE_IF_NULL (m_zoom_in, this);

	//TODO use magnifying glass icon
	m_zoom_in->setText ("+");
	QToolTip::add (m_zoom_in, "Zoom in");
	connect (m_zoom_in, SIGNAL (clicked ()), this, SLOT (onZoomIn ()));

	//middle row, right column
	m_layout->addWidget (m_zoom_in, ZOOM_LAYOUT_M_ROW, ZOOM_LAYOUT_R_COL);

	//create the zoom out button and hook it up
	m_zoom_out = new QPushButton (temp);
	RETURN_FALSE_IF_NULL (m_zoom_out, this);

	//TODO use magnifying glass icon
	m_zoom_out->setText ("-");
	QToolTip::add (m_zoom_out, "Zoom out");
	connect (m_zoom_out, SIGNAL (clicked ()), this, SLOT (onZoomOut ()));

	//bottom row, right column
	m_layout->addWidget (m_zoom_out, ZOOM_LAYOUT_B_ROW, ZOOM_LAYOUT_R_COL);

	//allow resizing of the chart column
	m_layout->setColStretch (ZOOM_LAYOUT_L_COL, 100);

	setWidget (temp);
	connect (this, 
		SIGNAL (placeChanged (QDockWindow::Place)),   
		SLOT (onDockChange (QDockWindow::Place)));

	return true;
}                               //ZoomDock::initialize


void ZoomDock::onZoomIn ()
{
	m_zoom_level++;
	m_zoom_out->setEnabled (true);
	if (m_min_zoom_level == m_zoom_level)
		m_zoom_in->setEnabled (false);

	m_zoom_box->setCurrentItem (m_zoom_level);
	if (NULL != m_area)
		m_area->zoomChanged (m_zoom_level);
}


void ZoomDock::onZoomOut ()
{
	m_zoom_level--;
	m_zoom_in->setEnabled (true);
	if (0 == m_zoom_level)
		m_zoom_out->setEnabled (false);

	m_zoom_box->setCurrentItem (m_zoom_level);
	if (NULL != m_area)
		m_area->zoomChanged (m_zoom_level);
}


void ZoomDock::onZoomBox (int i)
{
	m_zoom_level = i;

	if (m_min_zoom_level == m_zoom_level)
		m_zoom_in->setEnabled (false);
	else
		m_zoom_in->setEnabled (true);
	if (0 == m_zoom_level)
		m_zoom_out->setEnabled (false);
	else
		m_zoom_out->setEnabled (true);

	if (NULL != m_area)
		m_area->zoomChanged (m_zoom_level);
}


void ZoomDock::setShowMarkedData (bool show_marks)
{
	if (NULL != m_area)
		m_area->showMarkedRange (show_marks);
}



int ZoomDock::zoomLevelMinimum ()
{
	return m_min_zoom_level;
}


//This needs to be called whenever the session navigator emits the 
//  densityVisibilityChanged() signal OR whenever the parent QMainWindow gets
//  a showEvent ()
void ZoomDock::checkVisibility ()
{
	CATuneOptions ao;
	DWORD density = SHOW_CHART_DENSITY;

	ao.getShowChartDensity (&density);

	if (SHOW_CHART_DENSITY != density) {
		hide ();
	} else {
		show ();
		onDockChange (place());
	}
}


void ZoomDock::setChartArea (DensityChartArea * area)
{
	//create the density chart and hook it up
	m_area = area;

	//left column, spanning all rows
	if (NULL != area)
		m_layout->addMultiCellWidget (m_area, ZOOM_LAYOUT_T_ROW, 
		ZOOM_LAYOUT_B_ROW, ZOOM_LAYOUT_L_COL,
		ZOOM_LAYOUT_L_COL);
}


int ZoomDock::addZoomLevel (QString description, int index)
{
	m_zoom_box->insertItem (description, index);
	m_min_zoom_level++;
	//if the index wasn't specified, the level gets appended
	if (index < 0)
		return m_zoom_box->count ();
	else
		return index;
}


void ZoomDock::removeZoomLevel (int index)
{
	m_zoom_box->removeItem (index);
	if (m_zoom_level == m_min_zoom_level) {
		m_zoom_level--;
		//make sure the correct buttons are enabled/disabled.
		setZoomLevel (m_zoom_level);
	}
	m_min_zoom_level--;
}


void ZoomDock::setZoomLevel (int index)
{
	m_zoom_level = index;
	m_zoom_box->setCurrentItem (m_zoom_level);
	//make sure the correct buttons are enabled/disabled.
	onZoomBox (m_zoom_level);
}

//When it switches from docked, we'll want to show the caption
void ZoomDock::onDockChange (QDockWindow::Place p)
{
	if (QDockWindow::InDock != p)
		setCaption (m_parent_caption);
	else
		setCaption (QString::null);
}
