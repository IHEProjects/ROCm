/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2005 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#ifndef _ELFREADER_H
#define _ELFREADER_H

#include <elf.h>
#include <memory.h>
#include <stdlib.h>
#include <stdio.h>

#include "typedefs.h"
#include "jncfile.h"


class CELFReader {
public: 
    CELFReader();

    ~CELFReader();

    bool setELFFileName(const char * pFileName);

    bool readELFHeader();

    void printELF32Header();

    bool readStrSectionHeader();

    bool processSectionHeaders();

    bool readDataSection();

    unsigned int getDataSecOffset();

    unsigned int getDataSecSize();
private:
    void close();

    //bool readELFHeader();
    //bool readELF64Header();

    bool readStrSectionHeader32();
    bool readStrSectionHeader64();

    bool processSectionHeaders32();
    bool processSectionHeaders64();
private:
	char m_elfFileName[MAXLENGTH];
    FILE * m_pFileStream;

    // Number of sections
    unsigned int m_eshnum; 

    // Section header offset read from the elf header
    unsigned int m_shoff;

    // String section table offset from the beginning
    // of the file.  Calculated
    unsigned int m_strHeaderOffset;
    
    // Section table index in the section header table
    unsigned int m_shstrndx; 

    // Size fo the the section header entry
    unsigned int m_eshentsize;

    // Pointer pointing to the string table of section header
    char * m_pshstrtab;

    // Offset of the .data section
    unsigned int m_dataSecOffset;

    // Size of the .data section
    unsigned int m_dataSecSize;
#ifndef __x86_64__
    Elf32_Ehdr m_elfhdr;
#else
	Elf64_Ehdr	m_elfhdr;
#endif

};

#endif
