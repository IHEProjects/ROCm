/**
 * @file ca_agent_bfd.cpp
 * Implementation to write JIT code to elf file
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/limits.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "ca_agent_bfd.h"
#include "config.h"


int ca_agent_bfd::write_symbol_content(const char * symbol_name, const void* code_addr,
	unsigned int code_size)
{	
	int ret = -1;	
	bfd_boolean status = 0;
	char bfdName[PATH_MAX];  
	char pidDir[PATH_MAX];  
	bfd *abfd;
	asymbol *ptrs[2];
	asymbol *new_symbol;
	PTR bdhunk = NULL;

	if (regit_map.end() == regit_map.find((bfd_vma)code_addr))
		regit_map[(bfd_vma)code_addr] = 0;		

	sprintf(pidDir,  CA_JIT_DIR "/%d", getpid());
	sprintf(bfdName, "/%s/%lx-%d", pidDir, code_addr, regit_map[(bfd_vma)code_addr]);
	abfd = bfd_openw(bfdName ,NULL);
	if (abfd==NULL)
		goto fail;

	abfd->start_address = (bfd_vma)code_addr;
	bfd_set_format(abfd, bfd_object);
	bfd_set_arch_mach(abfd, bfd_arch_i386, bfd_mach_i386_i386);
	bfd_set_file_flags(abfd, HAS_SYMS|EXEC_P);


	new_symbol = bfd_make_empty_symbol(abfd);
	new_symbol->name = symbol_name;
	new_symbol->section =  bfd_make_section_anyway(abfd, ".text");
	new_symbol->flags = BSF_GLOBAL;
	new_symbol->value = 0;

	/// Set symbol table
	ptrs[0] = new_symbol;
	ptrs[1] = (asymbol *)0;
	bfd_set_symtab(abfd, ptrs, 1);

	/// Add the content
	status = bfd_set_section_size(abfd, new_symbol->section, code_size );
	if (!status)
		goto fail;

	status = bfd_set_section_vma(abfd, new_symbol->section, (bfd_vma)code_addr);
	if (!status)
		goto fail;	

	status = bfd_set_section_alignment(abfd, new_symbol->section, 4);
	if (!status)
		goto fail;	

	status = bfd_set_section_flags(abfd, new_symbol->section, 
		SEC_ALLOC | SEC_KEEP | SEC_CODE | SEC_HAS_CONTENTS);
	if (!status)
		goto fail;	

	bdhunk = (PTR)malloc(code_size);
	if(bdhunk == NULL)
		goto fail;

	memcpy(bdhunk, code_addr, code_size);


	status = bfd_set_section_contents(abfd, new_symbol->section, 
		(PTR)bdhunk, (file_ptr)0, (bfd_size_type)code_size);
	if (!status)
		goto fail;	

	bfd_close(abfd);

	// Set up the permission for file and directory
	chmod(pidDir, S_IRUSR|S_IWUSR|S_IXUSR
		|S_IRGRP|S_IXGRP
		|S_IROTH|S_IXOTH);
	chmod(bfdName, S_IRUSR|S_IWUSR|S_IXUSR
		|S_IRGRP|S_IXGRP
		|S_IROTH|S_IXOTH);
	
	++regit_map[(bfd_vma)code_addr];
	
	ret = 0;

fail:
	if (bdhunk != NULL) {
		free(bdhunk);
		bdhunk = NULL;
	}

	return ret;
}

