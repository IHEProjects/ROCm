//$Id: ViewCollection.h 17066 2009-08-28 22:38:27Z ssuthiku $
//This file defines the ViewCollection Interface, which handles most of the
//	view file interaction

/*
// CodeAnalyst for Open Source
// Copyright 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef VIEW_COLLECTION_H
#define VIEW_COLLECTION_H

#include "stdafx.h"
#include "ViewConfigAPI.h"
#include <qmap.h>

const QString ALL_DATA_VIEW = "All Data";

class ViewElementType
{
public:
	QString path;
	bool modifiable;
	CViewConfig * pView;
	ViewElementType () 
	{
		pView = NULL;
	};
	~ViewElementType()
	{
		if (NULL != pView)
			delete pView;
	};
};

class ViewCollection 
{
public:
	ViewCollection ();
	~ViewCollection ();

	void readAvailableViews(unsigned long cpuFamily );
	void addAllDataView (EventConfig* pAvailable, int numberOfEvents, unsigned long cpuFamily, unsigned long model);
	QStringList getListOfViews (EventConfig* pAvailable = NULL, 
		int numberOfEvents = 0, int *pDefault = NULL);

	bool viewExists (QString name);
	bool getViewTexts (QString name, QString *pToolTip, QString *pDescrip);

	bool getViewConfig (QString name, ViewShownData *pViewShown, int cpuCount,
			    unsigned long cpuFamily, unsigned long model, 
			    EventNormValueMap *pNorms = NULL);
	bool setViewConfig (QString name, ViewShownData *pViewShown, bool saveToFile=false);

	bool exportView (QString name, QString fileName);
	bool importView (QString fileName);
	bool removeView (QString name);
	void removeAllView(){ m_configs.clear();};
	
	void setSeparateCpu(QString name, bool b)
	{	
		if(m_configs.find(name) != m_configs.end())
			m_configs[name].pView->SetSeparateCPUs(b); 
	};
	
	void setSeparateTask(QString name, bool b)
	{ 
		if(m_configs.find(name) != m_configs.end())
			m_configs[name].pView->SetSeparateProcesses(b); 
	};
	
	void setSeparateThread(QString name, bool b)
	{ 
		if(m_configs.find(name) != m_configs.end())
			m_configs[name].pView->SetSeparateThreads(b); 
	};
	
	void setShowPercentage(QString name, bool b)
	{ 
		if(m_configs.find(name) != m_configs.end())
			m_configs[name].pView->SetShowPercentage(b); 
	};

	void resetView(QString name, unsigned long cpuFamily);
	
	void updateView(QString name, unsigned long cpuFamily);

private:
	void helpReadXmlFile(QString path);
	typedef QMap<QString, ViewElementType> ConfigMap;
	ConfigMap m_configs;
};
#endif
