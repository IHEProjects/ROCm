
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _DIFFVIEWSHOWNDATA_H_
#define _DIFFVIEWSHOWNDATA_H_

#include <qmap.h>
#include "stdafx.h"
#include "diffStruct.h"

typedef struct _ConvertKey
{
	int diffIndex;
	int oldCol;

	_ConvertKey(int d=-1, int o=-1)
	{
		diffIndex = d;
		oldCol	  = o;
	};

	BOOL operator< (const _ConvertKey &temp2) const
	{

		if(diffIndex < temp2.diffIndex)
			return true;
		else if (  (diffIndex == temp2.diffIndex)
			&& (oldCol < temp2.oldCol))
			return true;
		else
			return false;

	};

	
} ConvertKey;

typedef QMap<ConvertKey,int> IndexConverter;


class DiffViewShownData
{

public:
	DiffViewShownData();

	~DiffViewShownData();
	
	void addViewShownData(ViewShownData *vs);

	void rearrangeView(bool isSeparateCpu = false);

	unsigned int getSampleColumnMap(DiffViewColumnInfoMap **pMap );
	unsigned int getComplexColumnMap(ComplexColumnInfoMap **pMap );

	DIFF_VIEW_OPTIONS* getDiffViewOptions()
	{ return &m_diffViewOptions; };
	
	void setDiffViewOptions(DIFF_VIEW_OPTIONS* ops )
	{ m_diffViewOptions = *ops; };

	int getDiffIndex(int col,bool *isAddr); 

	int getNumColumn()
	{
		return m_columnMap.size() + m_complexColumnMap.size();
	};
	
private:

	void rearrangeViewLeftRight(int *nextCol, bool isSeparateCpu);
	void rearrangeViewSideBySide(int *nextCol, bool isSeparateCpu);
	void rearrangeViewDelta(int *nextCol, bool isSeparateCpu);
	

	DIFF_VIEW_OPTIONS 		m_diffViewOptions;
	DiffViewColumnInfoMap 		m_columnMap;
	ComplexColumnInfoMap		m_complexColumnMap;
	IndexConverter			m_indexConverter;
	QValueVector<ViewShownData*> 	m_viewShownVec;
	unsigned int 			m_viewCount;
	

};

#endif //_DIFFVIEWSHOWNDATA_H_

