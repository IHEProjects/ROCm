// implementation of the GraphView class
//
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.


#include <stdlib.h>
#include <time.h>
#include <qcombobox.h>

#include "stdafx.h"
#include "graphview.h"
#include "auxil.h"
#include "helperAPI.h"
#include "colorDlg.h"
#include "symbolengine.h"
#include "EventMaskEncoding.h"

#include "dataagg.h"

//////////////////////////////////////////////////////////////////////
// All these can be made into user defined optons
//

enum LocalFileEnumType
{
	SPACE = 1,
	LEFT_BORDER = 5,
	RIGHT_BORDER = 20,
	BOTTOM_BORDER = 20,
	TOP_BORDER = 50,
	MAX_LBL_WIDTH = 72,
	// The whole thing is broke if i set MAX_DISPLAY to an odd number
	MAX_DISPLAY = 100,
	LEG_TO_XAXIS = 20,
	LEG_SRS_SPACE = 10,
	LEG_SRS_RECT = 16,
	LEG_TXT_2_RECT = 2,
	TICK_HEIGHT = 8,
	TICK_PADDING = 2,
	LEGEND_SPACE = 15,
	MIN_ELEMENT_HEIGHT = 4,	//the least height of the event bar
	DEFAULT_ELEMENT_HEIGHT = 20,
	GRAPH_AREA_HEIGHT_MIN = 200,
	GRAPH_AREA_WIDTH_MIN = 300
};

#define LBL_WIDTH_MULT 1.05

#define FONT_SIZE      (font().pointSize())

#define WIN_W       width()
#define WIN_H       height()

#define GRAPH_ORG_Y (WIN_H - (BOTTOM_BORDER + m_legend_height + LEG_TO_XAXIS))
#define GRAPH_ORG_X (LEFT_BORDER + m_max_txt_width + LEG_SRS_RECT + 5)
#define GRAPH_MAX_X (WIN_W - TOP_BORDER - LEG_TO_XAXIS)
#define GRAPH_MAX_Y (TOP_BORDER)

/* 
* Suravee: This is to prevent some rounding problem and make sure that
*          width is >= 0
*/
#define WIDTH_Y_AX  ((GRAPH_ORG_Y > GRAPH_MAX_Y)?(GRAPH_ORG_Y - GRAPH_MAX_Y):0)
#define WIDTH_X_AX  ((GRAPH_MAX_X > GRAPH_ORG_X)?(GRAPH_MAX_X - GRAPH_ORG_X):0)

#define TICK_LABEL_WIDTH (fontMetrics().width ("00.00%"))

// Suravee: This is to prevent some rounding problem in how we calculate 
// NUM_TICKS. 
#define NUM_TICKS   (( WIDTH_X_AX > TICK_LABEL_WIDTH)?((WIDTH_X_AX - TICK_LABEL_WIDTH) / (2 * TICK_LABEL_WIDTH)):0)

#define MIN_BAR_WIDTH (4 * TICK_LABEL_WIDTH)

#define ELEMENT_AREA    (m_element_height + SPACE)
#define BAR_HEIGHT  (m_element_height / m_pViewShown->shown.size())

#define FUNCTION_DATA   (0 != m_module_name.length())

#define GRAPH_AREA_WIDTH  (width())
#define NUM_ELEMENTS_DISPLAYED (m_num_displayed)
#define GRAPH_AREA_HEIGHT (NUM_ELEMENTS_DISPLAYED * ELEMENT_AREA \
	+ TOP_BORDER + BOTTOM_BORDER + m_legend_height \
	+ LEG_TO_XAXIS )

#define ARBITRATY_QT_WIDGET_MAX 32767



GraphItem::GraphItem ()
{
	pCpuSamples = NULL;
}


// QSortList mandates that the < operator be defined
bool GraphItem::operator< (GraphItem item)
{
	if (dataToSort > item.dataToSort)
		return TRUE;
	else
		return FALSE;
}

// QSortList mandates that the == operator be defined
bool GraphItem::operator== (GraphItem item)
{
	if (dataToSort == item.dataToSort)
		return TRUE;
	else
		return FALSE;
}


GraphArea::GraphArea (ViewShownData *pViewShown, QWidget * parent)
		:QWidget (parent)
{

	CATuneOptions ao;

	ao.getCpuColorList (&m_colorList);

	m_pViewShown = pViewShown;
	getComplexColumnsMap();

	m_num_elements = 1;
	m_max_txt_width = 0;
	m_max_cum_val = 0;

	QString longest;
	for (UINT i= 0; i < m_pViewShown->available.size(); i++) {
		if (m_pViewShown->tips[i].length () > longest.length()) {
			longest = m_pViewShown->tips[i];
		}
	}

	m_one_legend_width = LEG_TXT_2_RECT	+ fontMetrics().width (longest) 
		+ 2 * LEG_SRS_SPACE	+ LEG_SRS_RECT;

	m_element_height = DEFAULT_ELEMENT_HEIGHT;
	if (m_element_height < (m_pViewShown->shown.size() * MIN_ELEMENT_HEIGHT)) {
		m_element_height = m_pViewShown->shown.size() * MIN_ELEMENT_HEIGHT;
	}

	// Delete the data when the class is deleted
	m_data.setAutoDelete (TRUE);
}

void GraphArea::addGraphItem(GraphItem *gItem)
{
	m_num_elements++;

	// append items;
	m_data.append (gItem);
}

bool GraphArea::initialize (QString title)
{

	// Initialize the popup window
	m_popup = new QPopupMenu (this);
	if (!m_popup)
		return false;

	QObject::connect (m_popup, SIGNAL (activated (int)),
		SLOT (onDisplay (int)));

	m_popup_id[GM_COLORS] = m_popup->insertItem( "Manage Colors", this,
		SLOT (OnManageColors()) );

	m_title = title;

	return true;
}// GraphArea::initialize()


void GraphArea::scaleArea()
{
	if (!m_popup)
		return;

	m_totalData.clear();
	m_totalData.resize (m_pViewShown->available.size(), 0);

	attributeTotalToColumns(m_pTotalSampleDataMap, m_totalData);

	int i = 1;
	int id = 0;

	m_popup->clear();

	m_start_index = 1;

	int max_display = MAX_DISPLAY;

	if (m_num_elements > max_display)
		m_num_displayed = max_display;
	else
		m_num_displayed = m_num_elements; 

	if (recalculateHeight (width()) > ARBITRATY_QT_WIDGET_MAX)
	{
		max_display = (GRAPH_ORG_Y - TOP_BORDER) / ELEMENT_AREA;
		if (m_num_elements > max_display)
			m_num_displayed = max_display;
		else
			m_num_displayed = m_num_elements; 
		recalculateHeight (width());
	}	

	if (m_num_elements > max_display)
		m_stop_index = max_display;
	else
		m_stop_index = m_num_elements;

	m_popup_id[GM_COLORS] = m_popup->insertItem( "Manage Colors", this,
		SLOT (OnManageColors()) );

	m_popup->insertItem ("View Data", this, SLOT (onSwitchToDataView()));

	m_popup->insertSeparator ();

	// Insert the items to show 1-99 100-199 etc.
	do {
		QString txt;
		int stop;
		if ((i + max_display - 1) > m_num_elements)
			stop = m_num_elements;
		else
			stop = i + max_display - 1;
		txt.sprintf ("%u - %u", i, stop);

		id = m_popup->insertItem (txt);

		if (1 == i) {
			m_prev_id = id;
			m_popup->setItemChecked (id, TRUE);
			if (m_num_elements > max_display)
				m_num_displayed = max_display;
			else
				m_num_displayed = m_num_elements;
		}

		i += max_display;
	} while ((i + max_display - 1) <= m_num_elements);

	recalculateHeight (width());
	//	calculateLabelWidth ();
	setGeometry (0, 0, GRAPH_AREA_WIDTH, GRAPH_AREA_HEIGHT);
}

//The given width may affect the height of the legend
int GraphArea::recalculateHeight (int width)
{
	m_legend_height = (FONT_SIZE + LEGEND_SPACE) * calculateLegendRows(width);
	setMinimumHeight (GRAPH_AREA_HEIGHT);
	return GRAPH_AREA_HEIGHT;
}


GraphArea::~GraphArea ()
{
	m_data.clear();
	m_pTotalSampleDataMap = NULL;
	m_totalData.clear();
}

void GraphArea::clearData()
{
	m_data.clear();
//	m_pTotalSampleDataMap = NULL;
	m_totalData.clear();
	m_num_elements = 1;
}

void GraphArea::draw (QPaintEvent * event)
{
	QPainter p (this);
	p.setClipping (TRUE);
	p.setClipRect (event->rect ());
	p.setPen (Qt::black);

	drawTitle (&p);
	drawAxes (&p);
	drawLegend (&p);
	drawTickMarks (&p);
	drawDataBars (&p);
}


// Overriden from QWidget::paintEvent()
// Any time, there is any painting to do, just redraw the whole thing....
// After all, we will be running on a K8 right??
//
void GraphArea::paintEvent (QPaintEvent * event)
{
	draw (event);
}


// Overriden from QWidget::mousePressEvent()
//
void GraphArea::mousePressEvent (QMouseEvent * e)
{
	if (RightButton != e->button ())
		return;

	m_popup->popup (QPoint (e->globalX (), e->globalY ()));
}


// Fired when the user clicks on an 1-X.. item
//
void GraphArea::onDisplay (int id)
{
	QString txt = m_popup->text (id);

	if (id == m_popup_id[GM_COLORS])
		return;
	if (!txt.contains ("-"))
		return;

	// If they did not select the current view, show the new view
	if (id != m_prev_id) {
		for (int i = m_start_index; i <= m_stop_index; ++i) {
			GraphItem * item = m_data.at (i - 1);
			if (NULL == item)
				continue;
			// Remove the old cpu rectangle(s)
			QToolTip::remove (this, item->rect);
		}

		m_stop_index = txt.right (txt.length () - txt.findRev ("-")
			- 2).toInt ();
		m_start_index = txt.left (txt.length () - (txt.length ()
			- txt.findRev ("-"))
			- 1).toInt ();

		m_num_displayed = m_stop_index - m_start_index + 1;

		m_popup->setItemChecked (m_prev_id, FALSE);
		m_popup->setItemChecked (id, TRUE);

		calculateLabelWidth();
		m_prev_id = id;
	}

	// If they just selected the current view, again, do nothing.
	setFocus ();
}


// Overriden from QWidget::mouseDoubleClickEvent()
//
// On a dbl click we, must get the graph item that
// was dbl clicked and display the function graph
// for that module
//
void GraphArea::mouseDoubleClickEvent (QMouseEvent * e)
{
	GraphItem *item;
	
	if (!e) return;

	// Check to see if we double clicked the Title
	if (m_title_rect.contains (e->pos ())) {
		QString txt;
		bool is_ok;
		bool isNameOk = false;
		do{
			txt = QInputDialog::getText ("New Graph Title", "Enter the new"
				" Chart Title", QLineEdit::Normal,
				m_title, &is_ok);

			if (is_ok && txt.isEmpty ())
			{
				QMessageBox::warning(this,"CodeAnalyst Warning","Invalid graph title. Please re-enter graph title\n");
			} else{
				isNameOk = true;
			}
		}while(!isNameOk);

		if (is_ok)
		{
			m_title = txt;
			update();
		}
		return;
	}

	// Clicked on the bar
	QString modName;
	QString taskName;
	for (int i = m_start_index; i < m_stop_index; ++i) 
	{
		item = m_data.at (i - 1);
		if(!item) return;
		if (item->rect.contains (e->pos ())) 
		{
			emit graphItemDblClicked(item->label, item->address);
			break;
		} //end if 
	} // end for
} // GraphArea::mouseDoubleClickEvent


void GraphArea::onSwitchToDataView ()
{
	emit viewDataTab ();
}


// Draws the graph title
//
void GraphArea::drawTitle (QPainter * painter)
{
	QFont f; 
	QFontMetrics fm(f);

	m_title_rect.setRect (
		( (width()/2) - (fm.width(m_title)/2) ),
		((TOP_BORDER/2) - fm.height()),
		fm.width(m_title),
		fm.height());
	painter->setFont (f);
	painter->drawText (m_title_rect, 0, m_title);
}


// This function is independent of whether we are in Cummulative view
// or CPU view... whew!!
//
void GraphArea::drawAxes (QPainter * painter)
{
	// y axis
	painter->drawLine (GRAPH_ORG_X, GRAPH_MAX_Y, GRAPH_ORG_X, GRAPH_ORG_Y);
	// x axis
	painter->drawLine (GRAPH_ORG_X, GRAPH_ORG_Y, GRAPH_MAX_X, GRAPH_ORG_Y);
}


// Draws the legend box displaying the Event / CPU series information
//
void GraphArea::drawLegend (QPainter * painter)
{
	int y = WIN_H - (BOTTOM_BORDER + m_legend_height) + FONT_SIZE;
	int x = LEFT_BORDER;

	//for each shown data
	for (UINT i = 0; i < m_pViewShown->shown.size(); i++) {

		int index = m_pViewShown->shown[i];

		if(m_ComplexColumnIndexList.end() 
			!= m_ComplexColumnIndexList.find(index))
			continue;

		if ((x + m_one_legend_width) > GRAPH_AREA_WIDTH) {
			y += FONT_SIZE + 15;
			x = LEFT_BORDER;
		}
		int text_width = m_one_legend_width - (LEG_SRS_RECT
			+ LEG_SRS_SPACE);
		int next_x = x + text_width;
		painter->drawText (x, y, text_width, LEG_SRS_RECT, Qt::AlignRight,
			m_pViewShown->tips [index]);

		if (i >= m_colorList.count()) {
			UINT maxCol = i - m_colorList.count();
			for (UINT j = 0; j <= maxCol; j++) {
				m_colorList.push_back (QColor ( QRgb (rand())));
			}
			CATuneOptions ao;
			ao.setCpuColorList (&m_colorList);
		}
		painter->fillRect( next_x, y, LEG_SRS_RECT, LEG_SRS_RECT, m_colorList[i]);
		painter->drawRect( next_x, y, LEG_SRS_RECT, LEG_SRS_RECT );

		x += m_one_legend_width;
	}
}// GraphArea::drawLegend


//Draw the tick Marks..The upmost value will be the maximum percentage
void GraphArea::drawTickMarks (QPainter * painter)
{
	float perc = 0;
	unsigned int tick_step = (unsigned int) WIDTH_X_AX;
	int num_ticks = (int) NUM_TICKS;

	float perc_step = 100.0;

	//If there are more than two ticks, this takes the last tick into account
	//	when calculating the spacing and percentage steps.
	if (num_ticks > 0) {
		tick_step = tick_step / (num_ticks + 1);
		perc_step = perc_step / (num_ticks + 1);
	}

	unsigned int x = GRAPH_ORG_X;
	for (int i = 0; i < (num_ticks + 2);i++, x += tick_step, 
			perc += perc_step) {
		QString str;
		str.sprintf ("%.2f%%", perc);

		//This insures that even if the tick step is off by a little (due to
		//	float -> int), the end label will be placed accurately
		if ((num_ticks + 1) == i)
			x = GRAPH_ORG_X + WIDTH_X_AX;

		//top tick
		painter->drawLine (x, (GRAPH_MAX_Y - TICK_HEIGHT), x, GRAPH_MAX_Y);
		painter->drawText ((x - fontMetrics().width (str) / 2),
			(GRAPH_MAX_Y - TICK_HEIGHT - TICK_PADDING), str);

		//bottom tick
		painter->drawLine (x, GRAPH_ORG_Y, x, GRAPH_ORG_Y + TICK_HEIGHT);
		painter->drawText ((x - fontMetrics().width (str) / 2),
			(GRAPH_ORG_Y + FONT_SIZE + TICK_HEIGHT+ TICK_PADDING), str);
	}

} //GraphArea::drawTickMarks


int GraphArea::helpDrawBar (QPainter * painter, 
			    QRect & rect, int w, int x, int y, 
			    int index, QColor color)
{
	int ret_width = 0;

	float columntotal = float (m_totalData[index]);

	if (columntotal)
		ret_width = (int)(((float)WIDTH_X_AX / (float)columntotal) * w);

	rect.setX (x);
	rect.setY (y);
	rect.setWidth (ret_width);
	rect.setHeight (BAR_HEIGHT);

	painter->fillRect (rect.x (), rect.y (), rect.width (), rect.height (),
		color);
	painter->drawRect (rect.x (), rect.y (), rect.width (), rect.height ());
	return ret_width;
}

// NOTE: This function attributes the total number of samples for each event
//       to the DataArray used in percentage calculation for each column. 
void GraphArea::attributeTotalToColumns(SampleDataMap *pDataMap, DataArray &data)
{
	SampleDataMap::iterator sample = pDataMap->begin ();
	SampleDataMap::iterator sample_end = pDataMap->end();

	// For each event type
	for(; sample != sample_end; sample++) 
	{
		unsigned long long deEvent;
		unsigned char deUMask;
		DecodeEventMask(sample->first.event, &deEvent, &deUMask);
		for(unsigned int i = 0 ; i < m_numCpus; i++)
		{
			CpuEventType key(i, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			UINT index = m_pViewShown->indexes[key];
			if (index >= m_pViewShown->available.size())
				continue;

			// Accumulate samples into column index (do it once)
			if(data[index] != 0)
				continue;
			
			data[index] += sample->second;

		}
	}
}

void GraphArea::dataComplexCalc(SampleDataMap *pDataMap, DataArray &data)
{
	SampleDataMap::iterator sample = pDataMap->begin ();
	SampleDataMap::iterator sample_end = pDataMap->end();

	for(; sample != sample_end; sample++) 
	{
		unsigned long long deEvent;
		unsigned char deUMask;
		DecodeEventMask(sample->first.event, &deEvent, &deUMask);
		CpuEventType key(sample->first.cpu, deEvent, deUMask); 

		//if event is not show for this view, skip
		if (!m_pViewShown->indexes.contains (key))
			continue;

		//given cpu/event select from profile, find column index
		UINT index = m_pViewShown->indexes[key];
		if (index >= m_pViewShown->available.size()) {
			continue;
		}

		// Accumulate samples into column index
		data[index] += sample->second;

		//if part of complex column, re-calculate
		ComplexDependentMap::Iterator complex = 
			m_pViewShown->calculated.find (index);

		if (complex != m_pViewShown->calculated.end()) {
			ListOfComplex::Iterator cpxIt = (*complex).begin();
			ListOfComplex::Iterator cpxItEnd = (*complex).end();
			for (; cpxIt != cpxItEnd; ++cpxIt) {
				float calc = m_pViewShown->setComplex (&(*cpxIt), &(data));
				int complexIndex = (*cpxIt).columnIndex;
				data[complexIndex] = calc;
			}
		}
	}
}


// We need a method choosing an appropriate number of elements to display....
// LEI: need to look at how to calculate item rect size;
void GraphArea::drawDataBars (QPainter * painter)
{
	int y_lbl = GRAPH_MAX_Y + (m_element_height + FONT_SIZE) / 2;
	int y_data = GRAPH_MAX_Y;
	QString tip_string;
	GraphItem *item = NULL;

	unsigned int max_bars =  m_pViewShown->shown.size();

	// For each bar
	for (int i = m_start_index; i <= m_stop_index; ++i) {
		int max_width = 0;
		item = m_data.at (i - 1);
		if (NULL == item)
			continue;

		// Draw the label
		QString label = item->label.right (MAX_LBL_WIDTH );
		if (item->label.length () > MAX_LBL_WIDTH)
			label.prepend ("...");

		painter->drawText ((LEFT_BORDER + (m_max_txt_width 
			- (int) (LBL_WIDTH_MULT * fontMetrics().width (label)))),
			y_lbl, label);

		// Remove the old cpu rectangle(s)
		QToolTip::remove (this, item->rect);

		DataArray tData;
		tData.clear();
		tData.resize (m_pViewShown->available.size(), 0);
		dataComplexCalc(item->pCpuSamples, tData);
		
		// Draw the bar data
		int x = GRAPH_ORG_X + 1;
		for (UINT ind = 0; ind < max_bars; ind++) 
		{
			int index = m_pViewShown->shown[ind];

			if(m_ComplexColumnIndexList.end() 
				!= m_ComplexColumnIndexList.find(index))
				continue;

			int temp_width = 0;
			temp_width = helpDrawBar (painter, item->rect, (int)tData[index], 
				x,(y_data + ind * BAR_HEIGHT), index, m_colorList[ind]);

			if (temp_width > max_width)
				max_width = temp_width;
		}

		item->rect.setX (GRAPH_ORG_X + 1);
		item->rect.setY ( y_data);
		item->rect.setHeight (m_element_height);
		item->rect.setWidth (max_width);

		QString TipString = item->label + " - [0x" + QString::number(item->address,16) + "]";
		// LEI:TODO: handle tip later;
		//if( max_samples != 0)
		//	TipString += "\n" + QString::number( 100 * item->valueTotal()
		//	/ max_samples) + "%";
		//TipString += "\n" + QString::number( item->valueTotal() );

		// Add the new rectangle(s)
		QToolTip::add( this, item->rect, TipString );
		y_lbl += m_element_height + SPACE;
		y_data += m_element_height + SPACE;
	}
} // GraphArea::drawDataBars


void GraphArea::OnManageColors ()
{
	ColorDlg *pColor = new ColorDlg (m_pViewShown->available, &m_colorList, this, NULL, true);
	RETURN_IF_NULL (pColor, this);
	pColor->exec ();
}

void GraphArea::getComplexColumnsMap()
{
	m_ComplexColumnIndexList.clear();

	ComplexDependentMap::iterator it = m_pViewShown->calculated.begin();
	ComplexDependentMap::iterator end = m_pViewShown->calculated.end();
	for(; it != end ; it++)
	{
		ListOfComplex::iterator lit = it.data().begin();
		ListOfComplex::iterator lend = it.data().end();
		for (; lit != lend ; lit++)
		{
			if(m_ComplexColumnIndexList.find((*lit).columnIndex) == 
				m_ComplexColumnIndexList.end())
			{
				m_ComplexColumnIndexList.append((*lit).columnIndex);
			}
		}
	}
}

void GraphArea::onViewChanged (ViewShownData* pShownData)
{
	QString longest;

	m_pViewShown = pShownData;
	getComplexColumnsMap();

	for (UINT i= 0; i < m_pViewShown->available.size(); i++) {
		if (m_pViewShown->tips[i].length () > longest.length()) {
			longest = m_pViewShown->tips[i];
		}
	}

	m_one_legend_width = LEG_TXT_2_RECT
		+ fontMetrics().width (longest) + 2 * LEG_SRS_SPACE
		+ LEG_SRS_RECT;

	m_element_height = DEFAULT_ELEMENT_HEIGHT;
	if (m_element_height < 
		(m_pViewShown->available.size() * MIN_ELEMENT_HEIGHT)) {
			m_element_height = m_pViewShown->available.size() * 
					MIN_ELEMENT_HEIGHT;;

	}

	GraphItem *item;
	m_max_cum_val = 0;
	//For each graph item
	for (item = m_data.first (); item != 0; item = m_data.next ()) {
		ULONG64 totals = 0;
		//for each possible data sample
		SampleDataMap::iterator sampIt = item->pCpuSamples->begin ();
		SampleDataMap::iterator sampEnd = item->pCpuSamples->end ();
		for(; sampIt != sampEnd; sampIt++) {
			unsigned long long deEvent;
			unsigned char deUMask;
			DecodeEventMask(sampIt->first.event, &deEvent, &deUMask);
			CpuEventType key(sampIt->first.cpu, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			UINT index = m_pViewShown->indexes[key];
			if (index >= m_pViewShown->available.size()) {
				continue;
			}
			totals += sampIt->second;
		}

		// LEI:TODO: just to total for here. later we will give 
		// option for sorting
		(*item).dataToSort = (unsigned int) totals;

		if( totals > m_max_cum_val )
			m_max_cum_val = totals;
	}

	// Sort the data
	m_data.sort ();
	calculateLabelWidth ();

	update ();
}//GraphArea::onViewChanged


//I have to do this calculation here, because the GraphArea has the
// maximum current text width
inline int GraphArea::getMinWidth()
{
	return GRAPH_ORG_X + MIN_BAR_WIDTH + RIGHT_BORDER;
}


int GraphArea::calculateLegendRows(int width )
{
	int shown = m_pViewShown->shown.size();
	//the number of columns for the current width == the number of
	//	keys on one row
	int columns = width / m_one_legend_width;
	if (columns < 1)
		columns = 1;
	int rows = shown / columns;
	if ((shown % columns) > 0)
		rows++;
	return rows;
}


void GraphArea::calculateLabelWidth()
{
	m_max_txt_width = 0;
	for (int i = m_start_index; i <=  m_stop_index; i++) {
		GraphItem * item = m_data.at (i -1);
		if (NULL == item)
			continue;

		QString label = item->label.right (MAX_LBL_WIDTH);
		if (item->label.length () > MAX_LBL_WIDTH)
			label.prepend ("...");

		int temp =(int) (LBL_WIDTH_MULT * fontMetrics ().width (label));
		if (temp > m_max_txt_width) {
			m_max_txt_width = temp;
		}
	}
}


SysGraphView::SysGraphView (ViewShownData *pViewShown, QWidget * parent,
			const char *name, int wflags)
			:DataTab (pViewShown, parent, name, wflags )
{
	setDockMenuEnabled (false);
	m_exportString = "";
	m_indexOffset = 0;
	m_graph_area = NULL;
	m_scroll_view = NULL;
	m_userCanClose = false;
	m_tbp_file = NULL;
}


SysGraphView::~SysGraphView ()
{
	if (m_graph_area) {
		delete m_graph_area;
		m_graph_area = NULL;
	}

	if (m_scroll_view) {
		delete m_scroll_view;
		m_scroll_view = NULL;
	}

	m_tbp_file = NULL;

	m_mod_list.clear();

	m_taskId_name_map.clear();
}


void SysGraphView::onViewChanged (ViewShownData* pShownData)
{
	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}
	
	// remove data;
	m_graph_area->clearData();
	m_mod_list.clear();

	readSysDataSection();

	m_graph_area->scaleArea();
	m_graph_area->onViewChanged (m_pViewShown);

	helpResizeArea();
}


//This function has to resize the graph correctly when it's not
// visible and when it it visible
void SysGraphView::resizeEvent (QResizeEvent * event)
{
	DataTab::resizeEvent (event);
	helpResizeArea();
}

void SysGraphView::helpResizeArea()
{
	int h = 0;

	m_scroll_view->verticalScrollBar()->setValue (0);
	m_scroll_view->setGeometry (0, h, width (), (height() - h));

	//The view width minus the size of a scroll bar is an acceptable
	// kludge for the initial size
	int w = m_scroll_view->width () - 20;

	//It only has the correct visible width when it is visible
	if (m_scroll_view->isVisible())
		w = m_scroll_view->visibleWidth();

	int aw = m_graph_area->getMinWidth();
	if (w <aw )
		w = aw ;

	m_graph_area->setGeometry (0, 0, w, m_graph_area->recalculateHeight (w));
}

bool SysGraphView::init (TbsReader * tbp_file)
{
	QValueList<SYS_LV_ITEM> task_list;
	QValueList<SYS_LV_ITEM>::iterator it;
	QValueList<SYS_LV_ITEM>::iterator end;

	m_taskId_name_map.clear();

	tbp_file->readProcInfo (task_list);

	it  = task_list.begin();
	end = task_list.end();
	for(; it != end; it++)
	{
		QString shortName = QString ((*it).ModName);
		shortName = shortName.section('/', -1);

		// Populate id->name map
		m_taskId_name_map[(*it).taskId] = shortName;
	}

	m_scroll_view = new QScrollView (this);
	RETURN_FALSE_IF_NULL (m_scroll_view, this);
	setCentralWidget (m_scroll_view);


	m_graph_area = new GraphArea (m_pViewShown, m_scroll_view);
	RETURN_FALSE_IF_NULL (m_graph_area, this);

	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	QObject::connect (m_graph_area,
		SIGNAL (graphItemDblClicked (QString, VADDR)),
		SLOT (onModuleDblClicked (QString, VADDR)));
	
	QObject::connect (m_graph_area,
		SIGNAL (viewDataTab ()),
		SLOT (onViewSysData ()));

	QString title = "System View - " + tbp_file->getName ();
	bool ret = m_graph_area->initialize (title);
	if (!ret) return ret;

	m_tbp_file = tbp_file;

	m_graph_area->setNumCpus(m_tbp_file->getNumCpus());

	m_scroll_view->addChild (m_graph_area);
	
	ret = readSysDataSection();
	if (!ret) return ret;

	m_graph_area->scaleArea();
	m_graph_area->onViewChanged (m_pViewShown);

	return ret;
} // SysGraphView::init 

void SysGraphView::onViewSysData ()
{
	emit viewSysData ();
}

bool SysGraphView::readSysDataSection()
{
	bool ret = false;
	SampleDataMap totalSample;
	totalSample.clear();

	QValueList<SYS_LV_ITEM>::iterator it  ;
	QValueList<SYS_LV_ITEM>::iterator end ;

	// Check if separated by task
	if (m_pViewShown->separateTasks)
		ret = m_tbp_file->readModInfo (m_mod_list, &totalSample);
	else
		ret = m_tbp_file->readAggregatedModInfo (m_mod_list, &totalSample);

	if(!ret) return ret;

	// Calculate the total
	m_totalSampleDataMap.clear();
	SampleDataMap::iterator sit  = totalSample.begin ();
	SampleDataMap::iterator send = totalSample.end ();
	for(; sit != send; ++sit) {
		// We use -1 to denote "ALL CPU"
                SampleKey key(-1,sit->first.event); 
                SampleDataMap::iterator tit  = m_totalSampleDataMap.find(key); 
                SampleDataMap::iterator tend  = m_totalSampleDataMap.end();
                if( tit != tend)
                        tit->second += sit->second;
                else
                        m_totalSampleDataMap.insert(SampleDataMap::value_type(key,sit->second));
	}
	m_graph_area->setTotal(&m_totalSampleDataMap);

	// Populate graph with system data
	it = m_mod_list.begin();
	end = m_mod_list.end();
	for (;it != end; it++) {
		SYS_LV_ITEM & mi = *it;
		GraphItem *graph_item = new GraphItem();
		if (NULL == graph_item) {
			QMessageBox::critical (this, "Error", "Insufficient memory");
			break;
		}
		graph_item->label = mi.ModName;
		if (m_pViewShown->separateTasks)
		{
			QString shortTaskName=m_taskId_name_map[mi.taskId].section('/',-1);
			graph_item->label += " - [ " + shortTaskName + " ]";
		}

		graph_item->pCpuSamples = &(mi.CpuSamples);
		m_graph_area->addGraphItem(graph_item);
	}
	return ret;
} // SysGraphView::readSysDataSection()

void SysGraphView::onModuleDblClicked ( QString label, VADDR )
{
	// Send signal to sessionNav
	// convert module_name with 
	unsigned int taskId = 0;
	QString modName;
	QString tempStr = label.section(" - [ ",1,1);

	if(tempStr.length() != 0)
	{
		// Separated by task name
		modName  = label.section(" - [ ",0,0);
		QString taskName = tempStr.section(" ]",0,0);
		
		map<unsigned int, QString>::iterator it = m_taskId_name_map.begin();
		map<unsigned int, QString>::iterator itEnd = m_taskId_name_map.end();
		for (; it != itEnd; it++) {
			QString shortTaskName = it->second.section('/',-1);
			if (taskName == shortTaskName) {
				taskId = it->first;
				break;
			}
		}
	} else {
		modName = label;
	}

	emit moduleDblClicked (modName, TAB_GRAPH, taskId);
}


//////////////////////////////
// ModGraphView
ModGraphView::ModGraphView (ViewShownData *pViewShown, QWidget * parent,
			  const char *name, int wflags)
			  :DataTab (pViewShown, parent, name, wflags )
{
	setDockMenuEnabled (false);

	// Why here? Why not in constructor of DataTab?
	m_exportString = "";
	m_indexOffset = 0;

	m_pTaskToolbar = NULL;
	m_scroll_view = NULL;
	m_graph_area = NULL;
	m_pTaskIdBox = NULL;
	m_pTaskSampMap = NULL;
	m_pJitBlkPtrVec = NULL;
	m_tbp_file = NULL;

	m_pProgressDlg = NULL;
}


ModGraphView::~ModGraphView ()
{
	m_taskId_name_map.clear();
	m_taskName_id_map.clear();

	if (m_pTaskToolbar) {
		delete m_pTaskToolbar;
		m_pTaskToolbar = NULL;
	}
	
	if (m_scroll_view) {
		delete m_scroll_view;
		m_scroll_view = NULL;
	}
/*
	if (m_graph_area) {
		delete m_graph_area;	
		m_graph_area = NULL;
	}

	if (m_pTaskIdBox) {
		delete m_pTaskIdBox;
		m_pTaskIdBox = NULL;
	}
*/
	// just set it to NULL since it was allocated by session navigator;
	m_pTaskSampMap = NULL;
	m_pJitBlkPtrVec = NULL;

	if (m_tbp_file) {
		//RemoveModGlobalMap(m_tbp_file->getPath(), m_moduleName);
		m_tbp_file = NULL;
	}
}


bool ModGraphView::init (TbsReader * tbp_file, char *module_name, 
				TaskSampleMap	*pTaskSampMap, 
				JitBlockPtrVec * pJitBlkPtrVec,	
				unsigned int taskId)
{
	bool bRet = false;

	if (!tbp_file || !module_name || !pTaskSampMap || !pJitBlkPtrVec)
		return false;

	CATuneOptions ao;
	m_moduleName = module_name;
	QString title = m_moduleName + " - " + tbp_file->getName ();
	m_taskId = taskId;

	if (!readTaskInfo(tbp_file))
		goto out;

	m_pTaskSampMap = pTaskSampMap;
	m_pJitBlkPtrVec = pJitBlkPtrVec;
	
	// read samples
	if (!readInstSamples(tbp_file))
		goto out;

	//////////////////////////////////////////////////////////
	/* [Suravee]  
	 * In subsequent access of profile samples, since we use 
	 * the data stored in the global map, we need to 
	 * check the type of module from the size of maps
	 * instead of reading from TBP file.
	 */
	if (m_pTaskSampMap->size() != 0)
	{
		m_prof_att.modType = UNMANAGEDPE;
	}

	if (m_pJitBlkPtrVec->size() != 0){
		m_prof_att.modType = JAVAMODULE;
	}
	//////////////////////////////////////////////////////////

	m_graph_area = new GraphArea (m_pViewShown, m_scroll_view);

	if (!m_graph_area)
		goto out;

	m_tbp_file = tbp_file;

	if (!initModuleToolBar (tbp_file, module_name, taskId))
		goto out;


	m_scroll_view = new QScrollView (this);
	if (!m_scroll_view)
		goto out;

	setCentralWidget (m_scroll_view);

	QObject::connect (m_graph_area,
		SIGNAL (graphItemDblClicked(QString, VADDR)),
		SLOT (onSymDblClicked(QString, VADDR)));

	QObject::connect (m_graph_area,
		SIGNAL (viewDataTab ()),
		SLOT (onViewModuleData ()));

	if (!m_graph_area->initialize (title))
		goto out;

	m_scroll_view->addChild (m_graph_area);

	if (!AddSamplesIntoGraph())
		goto out;

	m_graph_area->scaleArea();

	ao.getPrecision ( &m_precision );
	m_graph_area->onViewChanged (m_pViewShown);

	bRet = true;

out:

	if (!bRet) {
		if (m_graph_area) {
			delete m_graph_area;
			m_graph_area = NULL;
		}

		if (m_scroll_view) {
			delete m_scroll_view;
			m_scroll_view = NULL;
		}
	}
	return bRet;
} // ModGraphView::init 


bool ModGraphView::readTaskInfo(TbsReader * tbp_file)
{
	QValueList<SYS_LV_ITEM> task_list;
	QValueList<SYS_LV_ITEM>::iterator it;
	QValueList<SYS_LV_ITEM>::iterator end;

	/*
	* Build m_taskId_name_map, and m_taskName_id_map
	*/
	m_taskId_name_map.clear();
	m_taskName_id_map.clear();
	m_taskId_name_map[0] = "";  // taskId = 0 has no name

	if(!tbp_file->readProcInfo (task_list))
		return false;

	it  = task_list.begin();
	end = task_list.end();
	for(; it != end; it++)
	{
		QString shortName = QString((*it).ModName);
		shortName = shortName.section('/',-1);

		// Populate id->name map
		m_taskId_name_map[(*it).taskId] = shortName;

		// Populate name->id map
		m_taskName_id_map[shortName] = (*it).taskId;
	}

	return true;
}

bool ModGraphView::readInstSamples(TbsReader *tbp_file)
{
	if (m_pTaskSampMap->size())
		return true;

	bool bRet = false;

	// Initialize progress bar
	QString progDlgMesg = "Looking for module section: " + m_moduleName; 

	if (!m_pProgressDlg) {
		m_pProgressDlg = new QProgressDialog ( 
				progDlgMesg, "Cancel", 0, 
				this, NULL, FALSE, 
				Qt::WStyle_Customize 
				| Qt::WStyle_DialogBorder 
				| Qt::WStyle_Title);
		if (!m_pProgressDlg)
			return false;
	}

	m_pProgressDlg->setProgress(0);
	m_pProgressDlg->setTotalSteps(100);
	m_pProgressDlg->show();

	m_display_progress_calls = 0;
	m_display_progress_threshold = 200;
	
	TBSDisFunctor<ModGraphView> * dis_functor = new TBSDisFunctor<ModGraphView> (this, 
						&ModGraphView::tbsDisplayProgress_callback);

	bRet = tbp_file->readInstSampleInfo(m_moduleName, 
					m_pTaskSampMap, 
					m_pJitBlkPtrVec, 
					&m_prof_att, 	
					dis_functor);

	if (bRet) {
		m_prof_att.sessionPath = tbp_file->getPath();
		m_prof_att.modName = m_moduleName;
		m_prof_att.modPath = m_moduleName;

	}
	
	m_pProgressDlg->close();
	if(m_pProgressDlg)
	{
		delete m_pProgressDlg;
		m_pProgressDlg = NULL;
	}
	
	if(dis_functor) {
		delete dis_functor;
		dis_functor = NULL;
	}

	return bRet;
}

// TODO: This logic for progress bar is not accurate.
bool ModGraphView::tbsDisplayProgress_callback(const char * msg)
{
	bool ret = true;

	if (!m_pProgressDlg)
		return ret;

	if (msg != NULL)
		m_pProgressDlg->setLabelText(QString(msg));


	if (m_display_progress_calls > m_display_progress_threshold) {
		int currentProg = m_pProgressDlg->progress();
		if (currentProg < 99) {
			m_pProgressDlg->setProgress(currentProg + 1);
			qApp->processEvents(); 
			m_display_progress_calls = 0;
		} else {
			m_pProgressDlg->setProgress(1);
		}
	} else {
		m_display_progress_calls++;
	}


	if (m_pProgressDlg->wasCancelled())
		ret = false;
	return ret;

}


bool ModGraphView::AddSamplesIntoGraph()
{
	bool bRet = false;
	if (JAVAMODULE == m_prof_att.modType) {
		bRet = drawJavaGraphItems();
	} else {
		bRet = drawElfGraphItems();
	}

	return bRet;
}

bool ModGraphView::drawJavaGraphItems()
{
	TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
	if (taskIt == m_pTaskSampMap->end())
		return false;
	bool bRet = true;

	GraphItem * graph_item = NULL;

	JIT_BLOCK_INFO jit_blk;

	JitBlockPtrVec::iterator jbIter    = m_pJitBlkPtrVec->begin();
	JitBlockPtrVec::iterator jbIterEnd = m_pJitBlkPtrVec->end();

	//For each jitblock in the module
	for (; jbIter != jbIterEnd; jbIter++) {

		jit_blk.jit_load_addr    = (*jbIter)->jit_load_addr;
		jit_blk.jit_fun_name     = (*jbIter)->jit_fun_name;

		SampleMap::iterator sampleIter = (*jbIter)->javaSampleMap.begin();
		SampleMap::iterator sampleEnd  = (*jbIter)->javaSampleMap.end();
		for (; sampleIter != sampleEnd; sampleIter++){
			VADDR address = sampleIter->first;
			
			graph_item = new GraphItem;
			if (!graph_item)
				return false;
		
			graph_item->address = address;
			graph_item->label   = jit_blk.jit_fun_name;
			if (jit_blk.jit_load_addr != address) {
				VADDR offset = address - jit_blk.jit_load_addr;
				graph_item->label += "+ 0x" + QString::number (offset,16);
			}
		
			graph_item->pCpuSamples = &(sampleIter->second);

			m_graph_area->addGraphItem(graph_item);
		}
	}
	return bRet;
} // ModGraphView::drawJavaGraphItems()


bool ModGraphView::drawElfGraphItems()
{
	bool bRet = true;
	TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
	if (taskIt == m_pTaskSampMap->end())
		return false;

	GraphItem * graph_item = NULL;

	SymbolEngine symbol_engine;
	//check for java type
	int rc = symbol_engine.open (m_moduleName.data());
	if(SymbolEngine::OKAY != rc)
		return false;

	SampleMap::iterator sampIt = taskIt->second.begin(); 
	SampleMap::iterator sampEnd = taskIt->second.end(); 

	UINT64 address = 0, offset = 0;
	for (; sampIt != sampEnd; sampIt++) {
		address = sampIt->first;

		graph_item = new GraphItem;
		if (!graph_item) {
			bRet = false;
			break;
		}

		graph_item->address = address;

		sym_info sym;
		rc = symbol_engine.getSymbolForAddr(address, &sym);
		if (SymbolEngine::OKAY == rc) {
			graph_item->label = sym.name;
			if (sym.sym_start != address) {
				offset = address - sym.sym_start;
				graph_item->label += "+ 0x" + QString::number (offset,16);
			}
		} else {
			graph_item->label.sprintf("Unknown 0x%llx", 
							(unsigned long long) address);
		}

		graph_item->pCpuSamples = &(sampIt->second);

		m_graph_area->addGraphItem(graph_item);
	}

	symbol_engine.closeEngine();
	return bRet;

} // ModGraphView::drawElfGraphItems

void ModGraphView::onSymDblClicked (QString label, VADDR address)
{
	Q_UNUSED(label);
	if (JAVAMODULE == m_prof_att.modType
	&& !m_moduleName.endsWith(".jo")) {
		JitBlockPtrVec::reverse_iterator r_jitIt    = m_pJitBlkPtrVec->rbegin();
		JitBlockPtrVec::reverse_iterator r_jitItEnd = m_pJitBlkPtrVec->rend();
		for (; r_jitIt != r_jitItEnd; r_jitIt++) {
			if ((*r_jitIt)->jit_load_addr <= address)
				break;
		}

		if (r_jitIt != r_jitItEnd) {
			char addrstr[100];
			sprintf(addrstr, " - 0x%lx", (unsigned long) (*r_jitIt)->jit_load_addr);
			m_prof_att.modPath = m_tbp_file->getTbpDir() 
						+ "/" + (*r_jitIt)->jnc_file_path;
			m_prof_att.modName = (*r_jitIt)->jit_fun_name;
			m_prof_att.modName += addrstr;
			emit symDblClicked (address, &((*r_jitIt)->javaSampleMap), m_prof_att);
		} 
	} else {
		m_prof_att.modName = m_moduleName;
		m_prof_att.modPath = m_moduleName;

		// need to find out which task map it should be.
		TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
		if(taskIt != m_pTaskSampMap->end()) 
			emit symDblClicked (address, &(taskIt->second), m_prof_att);
	}
}

void ModGraphView::onViewModuleData ()
{
	emit viewModuleData (m_moduleName, TAB_DATA);
}

bool ModGraphView::initModuleToolBar (TbsReader * tbp_file, char *pModName, 
			unsigned int taskId)
{
	m_pTaskToolbar = new QToolBar( this, "Module Toolbar" );
	RETURN_FALSE_IF_NULL (m_pTaskToolbar, this);
	m_pTaskToolbar->setLabel ("Module Toolbar" );
	m_pTaskToolbar->setMovingEnabled (false);



	/*************************************
	* Build the combo box for task separated module information
	*/
	m_pTaskIdBox = new QComboBox (m_pTaskToolbar);
	RETURN_FALSE_IF_NULL (m_pTaskIdBox, this);
	m_pTaskIdBox->insertItem ("All", SHOW_ALL_TASKS);

	QValueList<SYS_LV_ITEM> mod_list;

	// Populate the combo box with the taskName
	SampleDataMap totalSample;
	tbp_file->readModInfo (mod_list, &totalSample);

	// Check if total sample is available. It might not be available 
	// if we get the cached value from GlobalSampleMap
	if(m_prof_att.modTotal.size() == 0) {
		SampleMap::iterator sit    = m_pTaskSampMap->find(0)->second.begin();
		SampleMap::iterator sitEnd = m_pTaskSampMap->find(0)->second.end();
		
		for (; sit != sitEnd; sit++) 
			AggregateSamples(m_prof_att.modTotal, sit->second);
	}

	// Aggregate samples from JIT modules
	JitBlockPtrVec::iterator jbIter    = m_pJitBlkPtrVec->begin();
	JitBlockPtrVec::iterator jbIterEnd = m_pJitBlkPtrVec->end();

	//For each jitblock in the module
	for (; jbIter != jbIterEnd; jbIter++) {

		SampleMap::iterator sampleIter = (*jbIter)->javaSampleMap.begin();
		SampleMap::iterator sampleEnd  = (*jbIter)->javaSampleMap.end();
		for (; sampleIter != sampleEnd; sampleIter++){
			AggregateSamples(m_prof_att.modTotal, sampleIter->second);
		}
	}

	// Calculate the total
	m_totalSampleDataMap.clear();
	SampleDataMap::iterator it  = totalSample.begin ();
	SampleDataMap::iterator end = totalSample.end ();
	for(; it != end; ++it) {
		// We use -1 to denote "ALL CPU"
                SampleKey key(-1,it->first.event);
                SampleDataMap::iterator tit  = m_totalSampleDataMap.find(key);
                SampleDataMap::iterator tend  = m_totalSampleDataMap.end();
                if( tit != tend)
                        tit->second += it->second;
                else
                        m_totalSampleDataMap.insert(SampleDataMap::value_type(key,it->second));
	}

	m_graph_area->setTotal(&m_totalSampleDataMap);
	m_graph_area->setNumCpus(m_tbp_file->getNumCpus());

	//Populate task id box
	QValueList<SYS_LV_ITEM>::iterator m_it  = mod_list.begin();
	QValueList<SYS_LV_ITEM>::iterator m_end = mod_list.end();
	int i = 1;
	for(; m_it != m_end; m_it++)
	{
		if(QString(pModName) == (*m_it).ModName.data() )
		{
			QString shortName = m_taskId_name_map[(*m_it).taskId].section('/',-1);
			m_pTaskIdBox->insertItem (shortName);
			if(taskId == (*m_it).taskId)
			{
				m_pTaskIdBox->setCurrentItem(i);
			}
			i++;
		}
	}

	connect (m_pTaskIdBox, SIGNAL (activated (int)), SLOT (OnSelectTask (int)));
			
	return true;
} //ModGraphView::initModuleToolBar

void ModGraphView::onViewChanged(ViewShownData* pShownData)
{
	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}

	m_graph_area->scaleArea();
	m_graph_area->onViewChanged (m_pViewShown);
	m_graph_area->update();

	helpResizeArea();
}

void ModGraphView::OnSelectTask (int index)
{
	unsigned int task;
	if (SHOW_ALL_TASKS == index) {
		task = SHOW_ALL_TASKS;
	} else {
		task = m_taskName_id_map[m_pTaskIdBox->currentText()];
	}

	if (task == m_taskId)
		return;

	if (m_scroll_view == NULL
	||  m_scroll_view->verticalScrollBar() == NULL)
		return;

	m_scroll_view->verticalScrollBar()->setValue (0);
	m_taskId = task;

	m_graph_area->clearData();

	CATuneOptions ao;
	ao.getPrecision ( &m_precision );

	AddSamplesIntoGraph();
	
	m_graph_area->scaleArea();
	m_graph_area->onViewChanged (m_pViewShown);
	m_graph_area->update();
}


void ModGraphView::resizeEvent (QResizeEvent * event)
{
	DataTab::resizeEvent (event);
	helpResizeArea();
}

void ModGraphView::helpResizeArea()
{
	int h = 0;
	if (NULL != m_pTaskToolbar)
		h = m_pTaskToolbar->height();

	if (m_scroll_view == NULL
	||  m_scroll_view->verticalScrollBar() == NULL)
		return;

	m_scroll_view->verticalScrollBar()->setValue (0);
	m_scroll_view->setGeometry (0, h, width (), (height() - h));

	//The view width minus the size of a scroll bar is an acceptable
	// kludge for the initial size
	int w = m_scroll_view->width () - 20;

	//It only has the correct visible width when it is visible
	if (m_scroll_view->isVisible())
		w = m_scroll_view->visibleWidth();

	if (w <= m_graph_area->getMinWidth())
		w = m_graph_area->getMinWidth();

	m_graph_area->setGeometry (0, 0, w, m_graph_area->recalculateHeight (w));
}
