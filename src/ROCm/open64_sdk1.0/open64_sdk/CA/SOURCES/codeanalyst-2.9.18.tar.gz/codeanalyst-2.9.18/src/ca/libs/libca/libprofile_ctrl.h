/*
* Copyright 2004 ADVANCED MICRO DEVICES, INC.
* @author Reeja John
*
* Copyright 2002 OProfile authors
* @author John Levon
* @author Philippe Elie
*
* YOUR USE OF THIS CODE IS SUBJECT TO THE TERMS
* AND CONDITIONS OF THE GNU GENERAL PUBLIC
* LICENSE FOUND IN THE "GPL.TXT" FILE THAT IS 
* INCLUDED WITH THIS FILE AND POSTED AT
* http://www.gnu.org/licenses/gpl.html
************************************************/
/* 
* libprofile_ctrl shared library header file 
* Provides API interface to CodeAnalyst	
*/

#ifndef _LIBPROF_CTRL_H_
#define  _LIBPROF_CTRL_H_

#define PROCESS_START 4
#define PROCESS_EXIT 16
#define MODULE_MAP 2
#define MODULE_UNMAP 64


#define BIT_MASK   0x00FF0000
#define ESCR_USER 0x4
#define ESCR_OS	  0x8

/* prd and .ti file signature */

#define SIGNATURE_PRD "CAPRDLIN"
#define SIGNATURE_TI "CATI"

#define CA_VERSION 1 

#define NUM_EVENT_COUNTERS 4
#define PROF_MAX_PATH_LEN 256

struct event_properties{
	unsigned int event_value[NUM_EVENT_COUNTERS];
	unsigned int event_count[NUM_EVENT_COUNTERS];
};

struct event{
	unsigned int event_index:8;
	unsigned int unit_mask:8;
	unsigned int bit_mask:8;
	unsigned int counter_mask:8;
};
struct prd_header{
	char signature[8];
	unsigned int version;
	unsigned int counter[4];
	unsigned int count[4];
};
struct prd_record{
	unsigned long long time_stamp;
	unsigned long long eip; /**< eip value where occur interrupt */
	pid_t  pid; /* same as pid? */
	pid_t  tgid; /**< always equal to pid for kernel < 2.4.0 */
	char event_index; /**< counter nr */
	char cpu_nr;
	char padding [2]; /* for alignment */ 
};



struct task_info_header{

	char signature[4];
	unsigned int version;
	unsigned long long start_time;
	unsigned long long stop_time;
	unsigned int affinity; 
};
struct task_info_record{

	pid_t pid;
	pid_t tgid;
	unsigned long start_addr;
	unsigned long module_len;
	unsigned long offset;
	unsigned long long time_stamp;
	unsigned int module_name_len;
	char module_name[PROF_MAX_PATH_LEN];
	unsigned int record_type;
};

#ifdef __cplusplus
extern "C" {
#endif

int prof_set_param(char* buff,int val);
int profile_set_event(struct event_properties *events);
int profile_set_output(char * file_name,unsigned int file_len);
int profile_set_vmlinux(char* vmlinux_name, unsigned int file_len);
int profile_set_note_buffer_size(unsigned long);
int profile_set_sample_buffer_size(unsigned long);
int profile_init(void);
int profile_start(void);
int profile_stop(void);
int profile_pause(void);
int profile_resume(void);
int profile_set_kernel_range(unsigned long kernel_start, unsigned long kernel_stop);

#ifdef __cplusplus
}
#endif

#endif
