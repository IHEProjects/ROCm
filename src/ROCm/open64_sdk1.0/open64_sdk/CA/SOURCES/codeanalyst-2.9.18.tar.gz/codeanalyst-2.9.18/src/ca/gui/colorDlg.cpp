//$Id: colorDlg.cpp 16624 2009-05-18 21:13:09Z ssuthiku $

/*
// CodeAnalyst for Open Source
// Copyright 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdlib.h>
#include <qcolordialog.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include "colorDlg.h"

ColorDlg::ColorDlg (QStringList labels, ColorList *pColors, QWidget* parent, 
					const char* name, bool modal, WFlags fl)
					: IColorDlg (parent, name, modal, fl)
{
	m_modified = false;
	m_pColorList = pColors;
	m_tempColors = *pColors;
	m_pLabels->insertStringList (labels);
	//Make sure that there's at least the number of colors for the labels.
	if (labels.count() > m_pColorList->count())
	{
		UINT maxCol = labels.count() - m_pColorList->count();
		for (unsigned int i = 0; i <= maxCol; i++)
		{
			m_pColorList->push_back (QColor ( QRgb (rand())));
		}
		CATuneOptions ao;
		ao.setCpuColorList (m_pColorList);

	}
	onLabelChanged (0);

	connect (m_pApply, SIGNAL (clicked ()), SLOT (onApply ()));
	connect (buttonOk, SIGNAL (clicked ()), SLOT (onOk ()));
	connect (m_pColorButton, SIGNAL (clicked ()), SLOT (onColorBrowse ()));
	connect (m_pLabels, SIGNAL (activated (int)), SLOT (onLabelChanged (int)));
	m_pApply->setEnabled (false);
}


ColorDlg::~ColorDlg()
{
}


void ColorDlg::onOk ()
{
	onApply ();
	accept();
}


void ColorDlg::onApply ()
{
	if (m_modified)
	{ 
		*m_pColorList = m_tempColors;
		CATuneOptions ao;
		ao.setCpuColorList (m_pColorList);
	}
	m_modified = false;
	m_pApply->setEnabled (m_modified);
	if (NULL != parent())
		((QWidget*) parent())->update();
}


void ColorDlg::onColorBrowse ()
{
	int index = m_pLabels->currentItem();
	QColor newColor = QColorDialog::getColor (m_tempColors[index]);
	if (newColor.isValid() && newColor != m_tempColors[index])
	{
		m_modified = true;
		m_tempColors[index] = newColor;
		updateColorButton (newColor);
	}
	m_pApply->setEnabled (m_modified);
}

void ColorDlg::onLabelChanged (int index)
{
	updateColorButton (m_tempColors[index]);
}


void ColorDlg::updateColorButton (QColor color)
{
	m_pColorButton->setPaletteBackgroundColor (color);
	m_pColorButton->setPaletteForegroundColor (color);
}
