/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "config.h"
#include "helperAPI.h"
#include "oprofile_interface.h"

#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string>
#include <elf.h>
#include <sys/types.h> 
#include <sys/stat.h>

#include <qstring.h>
#include <qstringlist.h>
#include <qfileinfo.h>
#include <qdir.h>
#include <qprocess.h>
#include <qtimer.h>
#include <qmessagebox.h>
#include <qprocess.h>
#include <qinputdialog.h>

#include "stdafx.h"


#define PACKED_DIR_NAME "capacked"

#if defined(__i386__) && defined(__PIC__)
/* %ebx may be the PIC register.  */
        #define __cpuid(level, a, b, c, d)                      \
          __asm__ ("xchgl\t%%ebx, %1\n\t"                       \
                   "cpuid\n\t"                                  \
                   "xchgl\t%%ebx, %1\n\t"                       \
                   : "=a" (a), "=r" (b), "=c" (c), "=d" (d)     \
                   : "0" (level))
#else
        #define __cpuid(level, a, b, c, d)                      \
          __asm__ ("cpuid\n\t"                                  \
                   : "=a" (a), "=b" (b), "=c" (c), "=d" (d)     \
                   : "0" (level))
#endif

/* 
* folderRemove:
* Recursive contents within the folder and the folder
* itself.
* It is the same code from oprofile_interface.cpp
*/
bool folderRemove (const QDir & _d)
{
	QDir d = _d;

	QStringList entries = d.entryList(QDir::All|QDir::Hidden);
	QStringList::Iterator it = entries.begin();

	for (; it != entries.end (); ++it)
	{
		if (*it == "." || *it == "..")
			continue;
		QFileInfo info (d, *it);
		if (info.isDir ())
		{
			if (!folderRemove (QDir (info.filePath ())))
				return false;
		}
		else
		{
			d.remove (info.filePath ());
		}
	}

	QString name = d.dirName ();

	if (!d.cdUp ())
		return false;

	d.rmdir (name);
	return true;
}

void untar_packed_file(QString * packed_path, QString * temp_dir )
{
	QDir dir;
	if (!QFile::exists(*packed_path)) {
		return;    
	}

	srand(time(0));
	temp_dir->sprintf("/tmp/CA%ld/", random());
	dir.mkdir(*temp_dir);

	// todo hook the output to the dialog
	// todo use a randomly generated directory
	QString command = "tar zxf " + *packed_path + " -C " + *temp_dir;
	system(command.data());
}


void mkdir_p(QString & absPath)
{
	QStringList list =  QStringList::split("/", absPath);
	QStringList::iterator it = list.begin();

	QString dir_path = "/";
	for (; it != list.end(); ++it) {
		dir_path = dir_path + (*it) + "/";
		QDir dir(dir_path);

		if (!dir.exists())  {
			if (!dir.mkdir(dir_path))
				qDebug("mkdir failed");
		}

	}
}


void copy_files(QFileInfo & info, QString & dest_dir)
{
	// Copy any non-directory file to the new path
	QDir dir = QDir(info.filePath());
	dir.setFilter(QDir::Files);
	QStringList file_list = dir.entryList(); 
	QStringList::Iterator itFile = file_list.begin();
	for (; itFile != file_list.end(); ++itFile) {
		QFileInfo info(dir, (*itFile));

		QString command = "cp \"" + info.absFilePath() + "\" \"" + dest_dir + "\"";

		system(command.data());
	}
}


void recurse_dirs(QString & parent_dir_str, 
			QString & dest_dir_str, 
			QString & subs_dir,
			bool prev_dep)
{
	QDir current_dir = QDir(parent_dir_str);   

	current_dir.setFilter(QDir::Dirs);
	QStringList old_dir_list = current_dir.entryList();
	QStringList::Iterator it = old_dir_list.begin();

	for (; it != old_dir_list.end(); ++it) {
		bool dep = false;
		if (*it == "." || *it == "..")
			continue;

		QFileInfo info(current_dir, *it);
		QString path = info.filePath(); 

		QString temp = dest_dir_str + "/" + *it;

		if ((*it).contains("{dep}"))
			dep = true;
		else if (((*it).contains("{root}") || (*it).contains("{kern}")) 
		       &&  prev_dep == true)
			temp += subs_dir;
		else
			dep =false;

		mkdir_p(temp);
		copy_files(info, temp);
		recurse_dirs(path, temp, subs_dir, dep);
	}
}


unsigned int rename_files(QString * temp_dir, 
			QString * op_sample_path,
			QString * cpuinfo_path)
{
	//todo capacked is hard coded right now.
	QString top_dir = *temp_dir;
	QString op_current_dir_str = *temp_dir + PACKED_DIR_NAME + "/current";
	QDir op_current_dir(op_current_dir_str );

	// Move the sample file to correct directory structure
	// For example: sample files in  
	// /tmp/CA_982/capacked/current/{root}/bin/basename 
	// needs to be moved to 
	// /tmp/CA_982/capacked/current/{root}/tmp/CA_982/capacked/binary/bin/basename/

	// Since we will be recursing capacked/current directory tree tree
	// the new structure is crecated at at capacked/new_current
	QString dest_topdir_str = top_dir + "capacked/samples/current/{root}" 
		+ *temp_dir + "capacked/binary";

	*op_sample_path = top_dir + "capacked/samples/current/";

	*cpuinfo_path = top_dir + "capacked/cpuinfo";

	QString subs_dir = *temp_dir + "capacked/binary/{root}/";

	// Loop through the original directory structure and create 
	// correspondent directory under the new directory tree structure
	recurse_dirs(op_current_dir_str, dest_topdir_str, subs_dir, false);

	return 0;
}


int getBitness(const char * path)
{ 	
	char elf_header[EI_NIDENT];
	FILE *fp;
	int ret = -1;

	if (!path)
		goto out;

	fp = fopen(path, "r");

	/**
	* The reporting libraries does not return correct path
	* of kernel module under 2.6.1.  This function will not
	* under this situation.
	*/
	if (NULL == fp) 
		goto out;

	fread(&elf_header, 16, 1, fp);
	if (ferror(fp)) {
                fclose (fp);
                goto out;
        }
        fclose(fp);

        if (0 != strncmp(elf_header, ELFMAG, SELFMAG))
                goto out;

        switch (elf_header[EI_CLASS]) {
                case ELFCLASS32:
                        ret = 32; 
                        break;
                case ELFCLASS64:
                        ret = 64;
                        break;
        }
out:
	return ret; 

}


int ca_exec_command (QStringList & args, 
			QString & stdOut,
			QString & stdErr,
			int & status,
			bool isBlock)
{
	int rt = -1;

	QProcess * proc = new QProcess();
	if (!proc)
		goto out;	

	proc->setArguments (args);

//	fprintf(stderr,"ca_exec_command = %s\n", proc->arguments().join(" ").ascii());

	if(!proc->start ()) {
		goto out;
	}

	// Since the process being launch are non-blocking daemon,
	// sysctl, mknod, etc, just wait for the command to finish
	while (proc->isRunning ()) { 
		if (!isBlock)
			break;
	}

	// Get exit status/stdOut/stdErr
	status = proc->exitStatus();
	stdErr = QString(proc->readStderr());
	stdOut = QString(proc->readStdout());

	// Check for normal Exit
	if (proc->normalExit () && status == 0)
		rt = 0;
out:
	if (proc)
		delete proc;
	return rt;
}


int ca_exec_sudo_command (QStringList & args, 
			QString & stdOut,
			QString & stdErr,
			int & status,
			bool isBlock)
{
	int rt = -1;

	QStringList cmd;
	cmd.append("sudo");
	cmd.append("-S");
	cmd += args;

	QProcess * proc = new QProcess();
	if (!proc)
		goto out;	

	proc->setArguments (cmd);

//	fprintf(stderr,"ca_exec_command = %s\n", proc->arguments().join(" ").ascii());

	if(!proc->start ()) {
		goto out;
	}

	/* NOTE:
	 * sudo, should never output to the stderr.
	 * We consider this error and will just exit out.
	 */
	while (proc->isRunning ()) { 
		if (!isBlock)
			break;
		if (proc->readStderr().size() != 0){
			proc->tryTerminate();
			QTimer::singleShot(1000, proc, SLOT(kill()));
			break;
		}
	}

	// Get exit status/stdOut/stdErr
	status = proc->exitStatus();
	stdErr = QString(proc->readStderr());
	stdOut = QString(proc->readStdout());

	// Check for normal Exit
	if (proc->normalExit () && status == 0)
		rt = 0;
out:
	if (proc)
		delete proc;
	return rt;
}


bool cssConversion(QString cgOutput)
{
	// TODO: Suravee: Currently we directly call cgreport
	// since we want cgprocessing code to be a standalone utility.
	// and can eliminate the build dependency.  We might want
	// to integrate this into the gui in the future.
	QString cgreportPath  	= QString(CA_BIN_DIR) + "/cgreport"; 
	QString cgFile 		= QString("/var/lib/oprofile/samples/ca_oprofile.cg");

	if (!QFile::exists (cgreportPath)) {
		QMessageBox::critical(NULL, "CSS Conversion Error",
			QString("CodeAnalyst could not process call-stack sampling data.\n") +
			"Please install " + cgreportPath + ".\n");
		return false;
	}

	if (!QFile::exists (cgFile)) {
		QMessageBox::critical(NULL, "CSS Conversion Error",
			cgFile + " not found.\n" +
			"Please rerun the profile with proper CSS setting.\n");
		return false;
	}

	QStringList cmd;
	cmd.append(cgreportPath);
	cmd.append(QString("-i"));
	cmd.append(cgFile);
	cmd.append(QString("-o"));
	cmd.append(cgOutput + "/callgrind.out");

	QString stdOut, stdErr;
	int status;
	return (ca_exec_command(cmd, stdOut, stdErr, status) == 0
		&& status == 0);
}

unsigned long getModelFromCpuInfo(const char * file)
{
	if (NULL == file)
		return 0;
	QFile devices (file);
	unsigned long model = 0;

	if (devices.open(IO_ReadOnly)) 
	{
		QTextStream stream(&devices);
		while (!stream.atEnd()) 
		{
			QString tmp = stream.readLine();
			if (tmp.contains ("model")) 
			{
				model = tmp.section(": ", 1, 1).toUInt();
				break;
			}
		}
	}

	return model;
}

unsigned long getFamilyFromCpuInfo(const char * file)
{
	if (NULL == file)
		return 0;
	QFile devices (file);
	unsigned long family = 0;

	if (devices.open(IO_ReadOnly)) 
	{
		QTextStream stream(&devices);
		while (!stream.atEnd()) 
		{
			QString tmp = stream.readLine();
			if (tmp.contains ("family")) 
			{
				family = tmp.section(": ", 1, 1).toUInt();
				break;
			}
		}
	}

	return family;
}

int XpFileContains(const char * file, const char * str)
{
    if ((NULL == file) || (NULL == str))
	return 0;
    QFile devices (file);
    int nTimes = 0;

    if (devices.open(IO_ReadOnly)) {
	QTextStream stream(&devices);
	while (!stream.atEnd()) {
	    QString tmp = stream.readLine();
	    if (tmp.contains (str)) {
		nTimes++;
	    }
	}
    }
    
    return nTimes;
}


unsigned int XpGetNumCpus()
{
	return XpFileContains ("/proc/cpuinfo", "processor");
}

unsigned int XpGetNumCoresPerSocket()
{
	unsigned int numCores = 1; 

	QFile devices ("/proc/cpuinfo");

	if (devices.open(IO_ReadOnly)) 
	{
		QTextStream stream (&devices);
		while (!stream.atEnd()) 
		{
			QString tmp = stream.readLine();
			if (tmp.contains ("cpu cores")) 
			{
				numCores = tmp.section(": ", 1, 1).toUInt();
			}
		}
	}
	    devices.close();

	return numCores;
}


/********************************************************
 Function: TimeStamp (assume athlon)
 RDTSC returns 64 bits of data in EAX,EDX
 We only use the lower 32 bits so, an overflow could occur every 8 seconds.
********************************************************/

unsigned int TimeStamp()
{
	
  unsigned int TickVal = 0;
	
  __asm__ __volatile__ (
			"rdtsc"
			: "=a" (TickVal)
			: /*no inputs*/
			: "%edx");
  
  return TickVal;	
}	


void XpGetAppPath(QString & path)
{
         path = QDir::currentDirPath();
}


void CpuId( char *vendor_id, 
		unsigned long *family, 
		unsigned long *model, 
		unsigned long *stepping)
{
	if ((NULL == vendor_id) || (NULL == family) 
	||  (NULL == model)     || (NULL == stepping))
		return;

	QFile devices ("/proc/cpuinfo");

	if (devices.open(IO_ReadOnly)) 
	{
		QTextStream stream (&devices);
		while (!stream.atEnd()) 
		{
			QString tmp = stream.readLine();
			if (tmp.contains ("vendor_id")) 
			{
				sprintf ( vendor_id, "%12s", tmp.section(": ", 1, 1).data());
			} 
			else if (tmp.contains ("cpu family")) 
			{
				*family = tmp.section(": ", 1, 1).toUInt();
			}  
			else if (tmp.contains ("model\t")) 
			{
				*model = tmp.section(": ", 1, 1).toUInt();
			} 
			else if (tmp.contains ("stepping")) 
			{
				*stepping = tmp.section(": ", 1, 1).toUInt();
			}
		}
	}
	devices.close();

} //CpuId


bool hasLocalApic() 
{
	unsigned long eax, ebx, ecx, edx;
	__cpuid(1, eax, ebx, ecx, edx);

	// Local Apic Feature: CPUID Fn0000_0001_EDX [9]
	if ((edx & (0x1 << 9)) > 0)
		return true;
	return false;
}


void getCpuIdIbs( unsigned long *ibsFeatureFlag) 
{
	if (NULL == ibsFeatureFlag)
		return;

	unsigned long lFuncExt, ebx, ecx, edx;

	/* Check LFuncExt: CPUID Fn8000_0000_EAX */
	__cpuid(0x80000000, lFuncExt, ebx, ecx, edx);
	if (lFuncExt >= 0x8000001B) {
		/* Get Ibs Specific Feature: CPUID Fn8000_001B_EAX */
		__cpuid(0x8000001B, *ibsFeatureFlag, ebx, ecx, edx);
	} else {
		*ibsFeatureFlag = 0;
	}

} //CpuIdIbs


bool isCpuIbsOpDispatchOpOk(unsigned long ibsFeatureFlag)
{
	/* Check IBS Op Counting Mode Supported: CPUID Fn8000_001B_EAX[4] */
	return ((ibsFeatureFlag & (0x1 << 4))? true: false);
}


bool isCpuIbsCountExtOk(unsigned long ibsFeatureFlag)
{
	/* Check IBS Count Extended Supported: CPUID Fn8000_001B_EAX[6] */
	return ((ibsFeatureFlag & (0x1 << 6))? true: false);
}


bool isCpuAMD ()
{
    QFile devices ("/proc/cpuinfo");

    if (devices.open(IO_ReadOnly)) 
    {
	QTextStream stream (&devices);
	while (!stream.atEnd()) 
	{
	    QString tmp = stream.readLine();
	    if (tmp.contains ("vendor_id")) 
	    {
		char vendor_id[13];
		sprintf ( vendor_id, "%12s", tmp.section(": ", 1, 1).data());
		vendor_id[12] = '\0';
		if (0 == strcmp (vendor_id, "AuthenticAMD"))
		    return true;
		break;
	    }
	}
    }
    devices.close();
    return false;
}


bool isCpuIbsOk()
{
	unsigned long eax, ebx, ecx, edx;
	
	// IBS Feature: CPUID Fn8000_0001_ECX[10]
	__cpuid(0x80000001, eax, ebx, ecx, edx);

	if ((ecx & (0x1 << 10)) > 0)
		return true;
	return false;
}


bool isDriverIbsOk()
{
	struct stat sb;
	if (stat("/dev/oprofile/ibs_fetch",&sb ) == -1
	||  stat("/dev/oprofile/ibs_op",&sb ) == -1) {
		return false;
	}

	return true;
}

bool isDriverMuxOk()
{
	struct stat sb;
	if(stat("/dev/oprofile/time_slice",&sb ) == -1)
	{
		return false;
	}

	return true;
}

bool isDriverIbsOpDispatchOpOk()
{
	struct stat sb;
	if(stat("/dev/oprofile/ibs_op/dispatched_ops",&sb ) == -1)
	{
		return false;
	}

	return true;
}


bool isCpuIbsOpDispatchedOpOk()
{
	struct stat sb;
	if(stat("/dev/oprofile/ibs_op/dispatched_ops",&sb ) == -1)
	{
		return false;
	}

	return true;
}


QString helpGetEventFile(QString cpuType)
{
	if (cpuType == "i386/athlon") {
		return helpGetEventFile(ATHLON_FAMILY);	
	} else if (cpuType == "x86-64/hammer") {
		return helpGetEventFile(OPTERON_FAMILY);	
	} else if (cpuType == "x86-64/family10") {
		return helpGetEventFile(GREYHOUND_FAMILY);	
	} else if (cpuType == "x86-64/family11h") {
		return helpGetEventFile(GRIFFIN_FAMILY);	
	} else if (cpuType == "x86-64/family12h") {
		return helpGetEventFile(FAMILY12H_FAMILY);	
	} else if (cpuType == "x86-64/family14h") {
		return helpGetEventFile(FAMILY14H_FAMILY);	
	} else if (cpuType == "x86-64/family15h") {
		return helpGetEventFile(FAMILY15H_FAMILY);	
	} else {
		return helpGetOpXmlEventFile(cpuType);	
	}
	return QString();
}


QString helpGetOpXmlEventFile(QString cpuType)
{
	QString userHomePath = QDir::home().path();
	QString path = QDir::home ().path();
	path += "/.CodeAnalyst/oprofile/" + cpuType + ".xml";
	path.replace ('\\', '/');

	return path;
}


QString helpGetEventFile(unsigned long cpuFamily, unsigned long cpuModel)
{
	Q_UNUSED(cpuModel);

        char * dir = getenv("OPROFILE_EVENTS_DIR");
        QString file;
        if (NULL == dir)
                file = CA_DATA_DIR + QString("/events/");
	else
		file = dir;

        switch(cpuFamily) {
                case OPTERON_FAMILY:
                        file += K8_EVENTS_FILE;
                        break;
                case ATHLON_FAMILY:
                        file += K7_EVENTS_FILE;
                        break;
                case GRIFFIN_FAMILY:
                        file += GR_EVENTS_FILE;
                        break;
                case FAMILY12H_FAMILY:
                        file += FAMILY12H_EVENTS_FILE;
                        break;
                case FAMILY14H_FAMILY:
                        file += FAMILY14H_EVENTS_FILE;
                        break;
                case FAMILY15H_FAMILY:
                        file += FAMILY15H_EVENTS_FILE;
                        break;
                case GREYHOUND_FAMILY:
                default:
			file += GH_EVENTS_FILE;
                        break;
        }
        return file;
}


unsigned int getTickSysFS()
{
        bool ok;
        unsigned int tps;
        QString line;
        QFile max_freq("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
        QTextStream stream;

        if (!max_freq.open(IO_ReadOnly))
                return 0;

        stream.setDevice(&max_freq);
        line = stream.readLine();
        tps = line.toUInt(&ok);
        if (!ok)
                return 0;

        tps = tps * 1000;
        max_freq.close();

        return tps;
}

unsigned int getTickCPUInfo()
{
        float tps = 0;
        QTextStream stream;
        QString line;
        QFile cpuinfo("/proc/cpuinfo");

        if (!cpuinfo.open(IO_ReadOnly))
                return 0;

        stream.setDevice(&cpuinfo);
        do
        {
                line = stream.readLine();
                if (line.contains("cpu MHz"))
                {
                        bool ok;
                        QString stripped = line.stripWhiteSpace();
                        QString mhz = stripped.section(':', 1,1);
                        tps = mhz.toFloat(&ok);
                        if (!ok)
                                return 0;

                        tps = tps * 1000000;
                        break;
                }
        }
        while(!line.isNull());
        cpuinfo.close();

        return (unsigned int)tps;
}

// Calculate how many ticks in a second.
unsigned int getTick ()
{
        unsigned int tps = getTickSysFS();
        if (tps)
                return tps;
        else
                return getTickCPUInfo();
}


bool isSupportedAmdCpuType(QString cpuType)
{
	if (cpuType == "i386/athlon"
	||  cpuType == "x86-64/hammer"
	||  cpuType == "x86-64/family10"
	||  cpuType == "x86-64/family11h"
	||  cpuType == "x86-64/family12h"
	||  cpuType == "x86-64/family14h"
	||  cpuType == "x86-64/family15h") {
		return true;
	}
	return false;
}


QString getCurrentCpuType()
{
	// Get the current cputype from OProfile driver
	QString type;

	QFile tmp("/dev/oprofile/cpu_type");
	if(!tmp.exists()) {
		oprofile_interface opIf;
		if (!opIf.loadOprofileDriver()
		||  !opIf.checkOprofileDriverStatus())
			return type;
	}

	if(!tmp.open(IO_ReadOnly))
		return type;

	tmp.readLine(type, 100);
	tmp.close();
	
	return type;
}


QString helpGetFamilyDir(unsigned long cpuFamily)
{
	QString dir = "";
	
	switch(cpuFamily) 
	{
	case ATHLON_FAMILY:
		dir += "K7/";
		break;
	case OPTERON_FAMILY:
		dir += "K8/";
		break;
	case GREYHOUND_FAMILY:
		dir += "GH/";
		break;
	case GRIFFIN_FAMILY:
		dir += "GR/";
		break;
	case FAMILY12H_FAMILY:
		dir += "family12h/";
		break;
	case FAMILY14H_FAMILY:
		dir += "family14h/";
		break;
	case FAMILY15H_FAMILY:
		dir += "family15h/";
		break;
	default:
		dir += "/";
		break;
	}
	return dir;	
}

QString getDefaultBrowser()
{
	QString defaultBrowser = "";

	if (QFile::exists("/usr/bin/gnome-open")) {
		defaultBrowser = QString("/usr/bin/gnome-open");
	} else if (QFile::exists("/usr/bin/kde-open")) {
		defaultBrowser = QString("/usr/bin/kde-open");
	} else {
		bool isOk = false;
		QString temp = QInputDialog::getText(
				"Please specify browser for viewing help document.",
				"Path to browser:",
				QLineEdit::Normal, "", &isOk);
		if (isOk)
			defaultBrowser = temp;
	}
	return defaultBrowser;
}


QString getDefaultPdfReader()
{
	QString defaultReader= "";

	if (QFile::exists("/usr/bin/gnome-open")) {
		defaultReader = QString("/usr/bin/gnome-open");
	} else if (QFile::exists("/usr/bin/kde-open")) {
		defaultReader = QString("/usr/bin/kde-open");
	} else {
		bool isOk = false;
		QString temp = QInputDialog::getText(
				"Please specify PDF Reader for viewing help document.",
				"Path to PDF Reader:",
				QLineEdit::Normal, "", &isOk);
		if (isOk)
			defaultReader = temp;
	}
	return defaultReader;
}
