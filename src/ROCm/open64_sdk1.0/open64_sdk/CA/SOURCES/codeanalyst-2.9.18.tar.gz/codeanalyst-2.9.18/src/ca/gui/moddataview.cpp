// implementation of the ModuleDataTab class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the 
// terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along 
// with this program; if not, write to the Free Software Foundation, Inc., 
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <qcombobox.h>
#include <qiconset.h>

#include "stdafx.h"
#include "moddataview.h"
#include "graphview.h"
#include "auxil.h"
#include "atuneoptions.h"
#include "EventMaskEncoding.h"
#include "bbanalysis.h"
#include "DataListItem.h"
#include "dataagg.h"

#define _MODDATAVIEW_ICONS_
#include "xpm.h"
#undef  _MODDATAVIEW_ICONS_

ModuleItem::ModuleItem ( ViewShownData *pViewShown, int indexOffset,
					QListView * parent, QListViewItem * after)
					:DataListItem (pViewShown, indexOffset, parent, after)
{
	m_last_child = NULL;
}// ModuleItem::ModuleItem


// Constructs an item that is a child of another item
//
ModuleItem::ModuleItem (ViewShownData *pViewShown, int indexOffset,
					QListViewItem * item, QListViewItem * after)
					: DataListItem (pViewShown, indexOffset, item, after)
{
	m_last_child = NULL;
}// ModuleItem::ModuleItem


//This suppliments the string comparison for sorting of a list view by writing
// the integers to a string with zeros to the left, same with the floats
//
QString ModuleItem::key (int column, bool ascending) const
{
	Q_UNUSED (ascending);
	QString ret_string;
	static int updateCounter = 0;

	if (MOD_SYMBOL == column) {
		return text(column);
	}

	// Every 100 sorts, tell the app to handle gui stuff, for a max of 
	// 1 milisecond
	if (0 == (updateCounter++ % 100))
		qApp->processEvents (1);

	// for anything else, do integer comparison
	//20 characters is > the max length of a uint64 as a decimal.
	QString target_string = text (column);
	target_string.replace(QChar('.'),"");
	target_string.replace(QChar('%'),"");
	ret_string.fill ('0', (20 - target_string.length()));
	ret_string.append (target_string);
	return ret_string;
}


ModuleDataTab::ModuleDataTab (QString module_name, TbsReader* tbp_file,
						  ViewShownData *pViewShown,
						  QWidget * parent, const char *name, int wflags)
						  :  DataTab (pViewShown, parent, name, wflags)
{
	m_pProgressDlg = NULL;
	m_tbp_file = tbp_file;
	//m_tbp_file->readEnvInfo();

	m_workspace = (QWorkspace *) parent;
	m_module_name = m_prof_att.modName = module_name;
	m_prof_att.modPath = module_name;
	m_prof_att.sessionPath = tbp_file->getPath();

//	m_tbp_file->getModAttributes (module_name, &m_prof_att);
	
	m_prof_att.cpuNum  = tbp_file->getNumCpus ();
	m_prof_att.totalSamples = tbp_file->getNumSamples ();
	m_prof_att.eventNum = tbp_file->getNumEvents ();

	setDockMenuEnabled (false);
	m_exportString = "&Export Module Data...";
	m_indexOffset = MOD_OFFSET_INDEX;

	m_pTaskSampMap = NULL;
	m_pJitBlkPtrVec  = NULL;
	
	m_pModDataViewToolbar = NULL;
	m_pModAggregationToolbar = NULL;
	m_pExpandCollapse = NULL;
		
	m_pAggregationId = NULL;

}// ModuleDataTab::ModuleDataTab


bool ModuleDataTab::initialize (unsigned int taskId, UINT64 address)
{
	m_taskId = taskId;

	bool ret = true;

	//***********************************************************
	/* 
	* TIMESTAMP SANITY CHECK
	* Description: Here we check if the profile time in TBP 
	* is older than the modules creation time.
	*/
	if (!m_pTaskSampMap || !m_pJitBlkPtrVec)
		return false;

	// Get TBP Timestamp
	QString tbp_dt_str = 
			QString(m_tbp_file->getTimestamp()).simplifyWhiteSpace();

	/* NOTE:
	* We need to do this since QT has a bug in function 
	* QDateTime::fromString() !!!!
	*/
	struct tm tmp_dt;	
	strptime(tbp_dt_str.ascii(),"%a %b %d %H:%M:%S %Y",&tmp_dt);
	time_t tmp_dt2 = mktime(&tmp_dt);

	QDateTime tbp_dt ;
	tbp_dt.setTime_t(tmp_dt2);

	QString oldModuleName = "";
	QFileInfo f_info = QFileInfo(m_module_name);

	// Check modules
	if(f_info.created() > tbp_dt)
	{
		oldModuleName += (m_module_name + "\n");
	}

	// Give warning message if module is newer than profiling time
	if(oldModuleName.length() != 0)
	{
		QString msg = "Module:\n\n" + oldModuleName
			+ "\nhas creation time ("+ f_info.created().toString()
			+") later than the profiling time ("+ tbp_dt.toString()
			+").\n"
			+ "Symbol information might be inaccurate.\n"
			+ "Please re-run the profile.\n\n" 
			+ "Do you want to continue?\n"; 

		if( QMessageBox::warning(this,"CodeAnalyst Warning", msg, 
				QMessageBox::Yes, QMessageBox::No)	!= QMessageBox::Yes)
		{
			return FALSE;
		}
	}

	// Initialize the list view
	m_pList = new QListView( this );
	RETURN_FALSE_IF_NULL (m_pList, this);

	setColumns();

	// init the popup menu
	m_popup = new QPopupMenu( this );
	RETURN_FALSE_IF_NULL(m_popup, this);

	m_popup->insertItem ("Copy Selection", this, SLOT (onCopySelection ()),
					        CTRL + Key_C);
	int id = m_popup->insertItem( "Data View" );
	m_popup->insertItem( "Graph View", this, SLOT( onViewGraph() ) );

	m_popup->setItemChecked( id, TRUE );

	// connect signals to slots
	QObject::connect( m_pList, SIGNAL( doubleClicked( QListViewItem* )  ),
		SLOT( onDblClicked( QListViewItem* ) ) );
	QObject::connect( m_pList, SIGNAL( rightButtonClicked ( QListViewItem *,
		const QPoint &, int ) ), SLOT( onRightClick( QListViewItem *,
		const QPoint &, int ) ) );

	//This allows the user to summarize data over the selected lines
	m_pList->setSelectionMode (QListView::Extended);
	QObject::connect(m_pList, SIGNAL (selectionChanged ()), this,
		SLOT (onSelectionChange( )));

	m_pModAggregationToolbar = new QToolBar( this, "Module Aggregation Toolbar" );
	RETURN_FALSE_IF_NULL (m_pModAggregationToolbar, this);
	m_pModAggregationToolbar->setLabel ("Module Aggregation Toolbar" );
	m_pModAggregationToolbar->setMovingEnabled (true);

	/*************************************
	* Build the combo box for task separated module information
	*/
	m_pTaskId = new QComboBox (m_pModAggregationToolbar);
	RETURN_FALSE_IF_NULL (m_pTaskId, this);
	m_pTaskId->insertItem ("All", SHOW_ALL_TASKS);

	QValueList<SYS_LV_ITEM> mod_list;
	QValueList<SYS_LV_ITEM> task_list;
	QValueList<SYS_LV_ITEM>::iterator it; 
	QValueList<SYS_LV_ITEM>::iterator end;
	map<unsigned int, QString> taskId_name_map;

	// Build task_id_map
	m_tbp_file->readProcInfo (task_list);
	it  = task_list.begin();
	end = task_list.end();
	for(; it != end; it++)
	{
		taskId_name_map[(*it).taskId] = (*it).ModName;
	}

	/*************************************
	* Populate the combo box with the taskName
	*/
	m_taskName_id_map.clear();

	m_tbp_file->readModInfo (mod_list);
	it  = mod_list.begin();
	end = mod_list.end();
	int i = 1;
	for(; it != end; it++)
	{
		if(m_module_name == (*it).ModName.data() )	
		{
			QString taskName = taskId_name_map[(*it).taskId];
			m_pTaskId->insertItem (taskName);
			m_taskName_id_map[taskName] = (*it).taskId;
			if( m_taskId == (*it).taskId )
			{
				m_pTaskId->setCurrentItem(i);
			}
			i++;
		}	
	}

	connect (m_pTaskId, SIGNAL (activated (int)), SLOT (onSelectTask (int)));

	m_taskId = taskId;
	m_bbaInit = false;
	m_address = address;

	/*********************************
	* Get default setting from CATune
	*/
	CATuneOptions   ao;
	ao.getPrecision ( &m_precision );
	ao.getShowAggregationController(&m_showAggCtrl);
	ao.getDataAggregation(&m_dataAggType);

	/*************************************
	* Build the combo box for Aggregation Selection
	*/
	if (m_showAggCtrl == SHOW_AGG_CONTROLLER) {
		m_pAggregationId = new QComboBox (m_pModAggregationToolbar);
		RETURN_FALSE_IF_NULL (m_pAggregationId, this);
#ifdef ENABLE_DWARF
		m_pAggregationId->insertItem ("Aggregate samples into instance of inline function", 
						AGG_INLINEINSTANCE);
		m_pAggregationId->insertItem ("Aggregate samples into original inline function",
						AGG_INLINEFUNCTION);
		m_pAggregationId->insertItem ("Aggregate samples into basic blocks",
						AGG_BASICBLOCK);
#else
		m_pAggregationId->insertItem ("Aggregate samples into function", 0);
		m_pAggregationId->insertItem ("Aggregate samples into basic blocks", 1);
#endif //ENABLE_DWARF
		
		m_pAggregationId->setCurrentItem(m_dataAggType);

		connect (m_pAggregationId, SIGNAL (activated (int)), SLOT (onAggregationChanged(int)));
	}
	
	/*************************************
	* Expand/Collapse
	*/
	m_pModDataViewToolbar = new QToolBar( this, "Module Data View Toolbar" );
	RETURN_FALSE_IF_NULL (m_pModDataViewToolbar, this);
	m_pModDataViewToolbar->setLabel ("Module Data View Toolbar" );
	m_pModDataViewToolbar->setMovingEnabled (true);
	QIconSet icon(QPixmap((const char**)expandCollapseIcon));
	m_pExpandCollapse = new QPushButton(icon, "",m_pModDataViewToolbar);
	m_pExpandCollapse->setMaximumHeight(20);
	m_pExpandCollapse->setMaximumWidth(20);
	m_pExpandCollapse->setToggleButton(true);
	connect(m_pExpandCollapse,SIGNAL(toggled(bool)), 
		this,SLOT(onExpandCollapseToggled(bool)));
	QToolTip::add(m_pExpandCollapse,QString("Expand / Collapse all symbols"));

	/////////////////////////////////////////////////////////////////


	//Add the data initially
	ret = readAndAggregateData();

	calculateTotalData();

	// Read module attribute from tbp/ebp file
/*	
	if(m_prof_att.modType == 0)
	{
		ret = false;
	}
*/
	
	if (m_pTaskSampMap->size() != 0)
	{
		m_prof_att.modType = UNMANAGEDPE;
	}
	
	if (m_pJitBlkPtrVec->size() != 0){
		m_prof_att.modType = JAVAMODULE;
	}
	
	//If non-java type, initialize the symbol engine.
	if (m_prof_att.modType != JAVAMODULE) {
		int i = m_symbol_engine.open(m_module_name, true);

		if ((SymbolEngine::NO_SYMBOLS == i) 
		||  (SymbolEngine::NO_SYMBOL_TABLE == i)) {
			m_no_symbols = true;
		}
		else {
			m_no_symbols = false;
		}

		if ((SymbolEngine::OKAY != i) 
		&&  (SymbolEngine::NO_SYMBOLS != i)
		&&  (SymbolEngine::NO_SYMBOL_TABLE != i) ) {
			return false;
		}
	} else {
		// if this is Java module.
		if (!m_pJitBlkPtrVec) {
			ret = false;
		}
	}

	setFocusProxy( m_pList );
	setCentralWidget( m_pList );

	if (ret) {
		ret = addItemsAndDisplayData();
	}

	return ret;
}// ModuleDataTab::initialize 


ModuleDataTab::~ModuleDataTab ()
{
	m_taskName_id_map.clear();
	m_pTaskSampMap = NULL;
	m_pJitBlkPtrVec = NULL;

	if (m_bbaInit) 
		m_bba.bba_cleanup();

	if (m_tbp_file) {
		//RemoveModGlobalMap(m_tbp_file->getPath(), m_module_name);
		m_tbp_file = NULL;
	}
}

void ModuleDataTab::onExpandCollapseToggled(bool b)
{
	QListViewItem *pLine = m_pList->firstChild();
	while(pLine != NULL)
	{
		m_pList->setOpen(pLine,b);
		pLine = pLine->nextSibling();
	} 
	
	pLine = m_pList->currentItem();
	if(pLine)
	{
		m_pList->ensureItemVisible(pLine);
	}
}


//helper function for Display(), sets up the columns
void ModuleDataTab::setColumns()
{
	m_pList->addColumn( "CS:EIP" );
	m_pList->addColumn( "Symbol + Offset", 200);

	/*
	* Separate by thread is not currently supported 
	*/
	//m_pList->addColumn ("Thread Id");

	m_pList->setColumnAlignment( MOD_ADDR,    AlignLeft  );
	m_pList->setColumnAlignment( MOD_SYMBOL, AlignLeft  );
	//m_pList->setColumnAlignment( MOD_THREAD_ID,  AlignRight );

	// Other options for the list view
	m_pList->setShowSortIndicator (TRUE);
	m_pList->setAllColumnsShowFocus (TRUE);
	m_pList->setRootIsDecorated (TRUE);
	m_pList->setSelectionMode (QListView::Extended);
}//ModuleDataTab::setColumns

void ModuleDataTab::calculateTotalData()
{

	// Check if total sample is available. It might not be available 
	// if we get the cached value from GlobalSampleMap
	if(m_prof_att.modTotal.size() == 0) {
		SampleMap::iterator sit    = m_pTaskSampMap->find(0)->second.begin();
		SampleMap::iterator sitEnd = m_pTaskSampMap->find(0)->second.end();
		
		for (; sit != sitEnd; sit++) 
			AggregateSamples(m_prof_att.modTotal, sit->second);
	}

	// Aggregate samples from JIT modules
	JitBlockPtrVec::iterator jbIter    = m_pJitBlkPtrVec->begin();
	JitBlockPtrVec::iterator jbIterEnd = m_pJitBlkPtrVec->end();

	//For each jitblock in the module
	for (; jbIter != jbIterEnd; jbIter++) {

		SampleMap::iterator sampleIter = (*jbIter)->javaSampleMap.begin();
		SampleMap::iterator sampleEnd  = (*jbIter)->javaSampleMap.end();
		for (; sampleIter != sampleEnd; sampleIter++){
			AggregateSamples(m_prof_att.modTotal, sampleIter->second);
		}
	}

	// Calculate total for this module	
	m_TotalSampleDataMap.clear();
	SampleDataMap::iterator it = m_prof_att.modTotal.begin();
	SampleDataMap::iterator itEnd = m_prof_att.modTotal.end();
	for (; it != itEnd; it++) {
		// We use -1 to denote "ALL CPU"
		SampleKey key(-1,it->first.event);
                SampleDataMap::iterator tit  = m_TotalSampleDataMap.find(key);
                SampleDataMap::iterator tend  = m_TotalSampleDataMap.end();
                if( tit != tend)
			tit->second += it->second;
                else
			m_TotalSampleDataMap.insert(SampleDataMap::value_type(key,it->second));
	}
}

//This adds appropriate items to the listview
bool ModuleDataTab::updateData ()
{
	// There is for fixing the bug in QT library. detail in bug62002
	//m_pList->hide();

	m_pList->setSorting(-1, false);
	m_pList->setUpdatesEnabled(false);

	unsigned int sessionTotal = m_prof_att.totalSamples;
	calculateTotalData();

	if (!m_pProgressDlg) {
		m_pProgressDlg = new QProgressDialog (
			"Redraw data for new configuration. Please wait...", "Cancel", 0,
			this, NULL, FALSE, Qt::WStyle_Customize
			| Qt::WStyle_DialogBorder 
			| Qt::WStyle_Title);	
	}
	
	if (m_pProgressDlg) {
		m_pProgressDlg->setProgress(0);
		m_pProgressDlg->setTotalSteps(m_pList->childCount());
		m_pProgressDlg->show();
	}


	ModuleItem *pFirstLvItem = (ModuleItem*) m_pList->firstChild();

	int i = 0;
	int b = 0;
	while (NULL != pFirstLvItem) {
		if (i == 10) {
			m_pProgressDlg->setProgress(b++);
			i = 0;
		}
		
		SampleDataMap firstLvData;
		firstLvData.clear();

		if (pFirstLvItem->childCount()) {
			ModuleItem *pSecondLvItem = (ModuleItem*) 
					pFirstLvItem->firstChild ();

			while (pSecondLvItem) {
				SampleDataMap secondLvData;
				secondLvData.clear();

				if (pSecondLvItem->childCount()) {
					ModuleItem *p3rdLvItem = (ModuleItem*) 
							pSecondLvItem->firstChild ();
					while (p3rdLvItem) {
						SampleDataMap *pThirdData = 
								p3rdLvItem->getItemSamples();

						if (pThirdData) {
							p3rdLvItem->setTotal(&m_TotalSampleDataMap);
							p3rdLvItem->drawData(pThirdData, sessionTotal);
							AggregateSamples(secondLvData, *pThirdData);
						}
						p3rdLvItem = (ModuleItem*) p3rdLvItem->nextSibling();
					}
				} else {
					pSecondLvItem->getItemSamples(secondLvData);
				}
				
				// draw second level data;	
				pSecondLvItem->setTotal(&m_TotalSampleDataMap);
				pSecondLvItem->drawData(&secondLvData, sessionTotal);

				// aggregate second level data to first level	
				AggregateSamples(firstLvData, secondLvData);
			
				pSecondLvItem = (ModuleItem*) pSecondLvItem->nextSibling();
			}
			pFirstLvItem->setTotal(&m_TotalSampleDataMap);
			pFirstLvItem->drawData(&firstLvData, sessionTotal);
		} else {
			SampleDataMap *pData = pFirstLvItem->getItemSamples();
			pFirstLvItem->setTotal(&m_TotalSampleDataMap);
			pFirstLvItem->drawData(pData, sessionTotal);
		}
		
		pFirstLvItem = (ModuleItem*) pFirstLvItem->nextSibling();
	}

	// Enable sorting
	m_pList->setSorting( MOD_OFFSET_INDEX, false);
	m_pList->setUpdatesEnabled(true);

	//This is where it sorts the list for the first time
	m_pList->setCurrentItem (m_pList->firstChild());

	m_pList->show();
	m_pList->triggerUpdate();

	m_pProgressDlg->close ();
	if (m_pProgressDlg) 
	{
		delete m_pProgressDlg;
		m_pProgressDlg = NULL;
	}

	return true;
}    // ModuleDataTab::updateData


//This is called to add items at module level and display data;
bool ModuleDataTab::addItemsAndDisplayData()
{

	bool bRet = false;
	
	if (!m_pProgressDlg) {
		m_pProgressDlg = new QProgressDialog (
			"Sorting view items by first column. Please wait...", "Cancel", 0,
			this, NULL, FALSE, Qt::WStyle_Customize
			| Qt::WStyle_DialogBorder 
			| Qt::WStyle_Title);	
		if (m_pProgressDlg) {
			m_pProgressDlg->setProgress(0);
			m_pProgressDlg->setTotalSteps(100);
			m_pProgressDlg->show();
		}
	}

	//remove all columns
	if (!clearShownColumns ())
		goto out;

	//update shown columns
	if (NULL != m_pColumnMenu)
		m_pColumnMenu->clear();

	if (NULL != m_pColumnIndex) {
		delete [] m_pColumnIndex;
		m_pColumnIndex = NULL;
	}

	//add data columns
	if (!initMenu ())
		goto out;


	if(NULL != m_popup) {
		if (-1 == m_popup->idAt (MOD_POP_SHOWN))
			m_popup->insertItem ("&Show", m_pColumnMenu);
	}

	m_pList->clear ();
	m_pList->hide();

	m_pList->setSorting(-1, false);
	m_pList->setUpdatesEnabled(false);

	switch(m_prof_att.modType) {
		case UNMANAGEDPE:
			bRet = DisplayELFData();
			break;

		case JAVAMODULE:
			bRet = DisplayJavaData();
			break;

		default:
			break;
	}

	if (bRet) {
		// NOTE: We need to force expand before sorting
		//       to make sure everything being sorted properly
		//       before collapsing it.
		onExpandCollapseToggled(true);

		// Enable sorting
		m_pList->setSorting( MOD_OFFSET_INDEX, false);
		m_pList->setUpdatesEnabled(true);
		
		//This is where it sorts the list for the first time
		m_pList->setCurrentItem (m_pList->firstChild());

		m_pList->show();
		m_pList->triggerUpdate();
	}

	// Setup current Expand/collapse
	onExpandCollapseToggled(m_pExpandCollapse->isOn());

	m_pList->show();

out:
	m_pProgressDlg->close ();
	if (m_pProgressDlg) 
	{
		delete m_pProgressDlg;
		m_pProgressDlg = NULL;
	}

	return bRet;
}//ModuleDataTab::addItemsAndDisplayData


//This is called when the View Configuration are changed or
//"Show" is toggled.
void ModuleDataTab::onViewChanged (ViewShownData* pShownData)
{
	if(pShownData != NULL)
	{
		m_pViewShown = pShownData;
	}

	onExpandCollapseToggled(m_pExpandCollapse->isOn());
/*
	// There are 2 issues about crash on updating data based on 
	// view configurations. The crash is in the QT lib. 
	// BUG62002 and BUG62390.
	// -Lei 09/26/2008
	
	//remove all columns
	clearShownColumns ();
	
	updateData ();
*/
	addItemsAndDisplayData();
}

bool ModuleDataTab::tbsDisplayProgress_callback(const char * msg)
{
	bool ret = true;

	if (!m_pProgressDlg)
		return true;

	if (msg != NULL)
		m_pProgressDlg->setLabelText(QString(msg));

	if (m_display_progress_calls > m_display_progress_threshold) {
		int currentProg = m_pProgressDlg->progress();
		if (currentProg < 99) {
			m_pProgressDlg->setProgress(m_pProgressDlg->progress () + 1);
			qApp->processEvents();
			m_display_progress_calls = 0;
		} else {
			m_pProgressDlg->setProgress(1);
		}
	} else {
		m_display_progress_calls++;
	}

	if (m_pProgressDlg->wasCancelled())
		ret = false;

	return ret;
}

bool ModuleDataTab::readAndAggregateData()
{
	bool bRet = true;

	if (m_pTaskSampMap->size())
		return true;

	// Setting up for progress bar
	QString dlgStr = "Looking for module section: " + m_module_name;

	if (!m_pProgressDlg) {
		m_pProgressDlg = new QProgressDialog (
			dlgStr, "Cancel", 0,
			this, NULL, FALSE, 
			Qt::WStyle_Customize
			| Qt::WStyle_DialogBorder 
			| Qt::WStyle_Title);	
		if (!m_pProgressDlg)
			return false;
	}

	m_pProgressDlg->setProgress(0);
	m_pProgressDlg->setTotalSteps(100);
	m_pProgressDlg->show();

	m_display_progress_calls = 0;
	m_display_progress_threshold = 200;
	
	TBSDisFunctor<ModuleDataTab> * dis_functor = new TBSDisFunctor<ModuleDataTab> (this, 
					&ModuleDataTab::tbsDisplayProgress_callback);

	// Read sample from tbp/ebp file
	bRet = m_tbp_file->readInstSampleInfo (m_module_name, 
						m_pTaskSampMap, 
						m_pJitBlkPtrVec, 
						&m_prof_att, 
						dis_functor);

	m_pProgressDlg->close ();
	if(m_pProgressDlg)
	{
		delete m_pProgressDlg;
		m_pProgressDlg = NULL;
	}

	if(dis_functor) {
		delete dis_functor;
		dis_functor = NULL;
	}

	return bRet;
}// ModuleDataTab::readAndAggregateData()



ModuleItem* ModuleDataTab::AddFirstLvElfItem(VADDR addr, 
			sym_info &firstLvSym, ModuleItem *pFirstLvItem,
			SYM_INFO_VECTOR &inlineVec,
			BLOCKMAP::iterator &bbIter, BLOCKMAP::iterator bbEnd,
		    bfd_vma imageBase)

{
	ModuleItem *pItem = NULL;
	bfd_vma tmp_start = 0;
	bfd_vma tmp_end = 0;

	int retCode = m_symbol_engine.getSymbolForAddr(addr, &firstLvSym);
	
	if (retCode == 	SymbolEngine::OKAY) {
		// delete content pointer of inline vector, 
		// and clear the vector.
		delete_SYM_INFO_VECTOR(inlineVec);
				
		// query inline instances and put this infor InlineInstanceList;
		if (m_symbol_engine.getNumInlineDwarf(firstLvSym.sym_start)) {
			m_symbol_engine.getInlinesForFunctionDwarf(
							firstLvSym.sym_start, inlineVec);
		}

		// move block iterator to first block instance inside function
		while(bbIter != bbEnd) {
			tmp_end = bbIter->first.bb_start + 	
					bbIter->second.bb_size + imageBase;
			if (tmp_end <= firstLvSym.sym_start) {
				bbIter--;
			} else {
				break;
			}
		};

	} else {
		// No symbol,
		firstLvSym.sym_start = addr; 
		firstLvSym.possible_end = addr;
		firstLvSym.name = "Unknown Sample";
		while ( bbIter != bbEnd) {
			tmp_start = bbIter->first.bb_start + imageBase;
			tmp_end = bbIter->first.bb_start +
							bbIter->second.bb_size + imageBase;
			if (tmp_end <= addr) {
				bbIter--;
			} else {
				if (tmp_start <= addr) {
					firstLvSym.sym_start = tmp_start;
					firstLvSym.possible_end = tmp_end;
					firstLvSym.name.sprintf("Block [ 0x%lx - 0x%lx ]",
							tmp_start, tmp_end);
				}
				break;
			}
		}
	
		// no function info, no inline; cleanup
		delete_SYM_INFO_VECTOR(inlineVec);
	}
	
	// update first level data and insert first level item here; 
	pItem = new ModuleItem(m_pViewShown, MOD_OFFSET_INDEX, 
							m_pList, pFirstLvItem);
	return pItem;
}	

// count load / store in a block. and generate a string 
QString UpdateMemoryAccess(sym_info &secondLvSym, 
			MEMACCESSMAP::iterator &memAccIter, 
			MEMACCESSMAP::iterator memAccEnd,
			bfd_vma imageBase)
{
	QString lsStr = "";
	unsigned int load = 0;
	unsigned int store = 0;

	while (memAccIter != memAccEnd) {
		if (memAccIter->first + imageBase < secondLvSym.sym_start) {
			memAccIter++;
			continue;
		}
		
		if (memAccIter->first + imageBase >= secondLvSym.possible_end)
			break;

		switch(memAccIter->second) {
			case MA_READ:
				load++;
				break;
			case MA_WRITE:
				store++;
				break;

			case MA_READWRITE:
				load++;
				store++;
				break;

			default:
				break;
		}
		memAccIter++;
	}

	lsStr.sprintf(" : ( %d / %d )", load, store);
	return lsStr;
}

bool ModuleDataTab::DisplayELFData ()
{
	bool bRet = true;
	switch(m_dataAggType) {
		case AGG_BASICBLOCK:
			bRet = DisplayBasicBlocks();
			break;
		case AGG_INLINEFUNCTION:
			bRet = DisplayInlineInstance(false);
			break;
		case AGG_INLINEINSTANCE:
		default:
			bRet = DisplayInlineInstance();
			break;
	}

	return bRet;
}


bool ModuleDataTab::InitializeBBA() {
	if (m_bbaInit)
		return true;

	if (m_bba.bba_init(m_module_name.ascii()) == OK ) {
		if (m_bba.bba_analyze_all() == OK) 
			m_bbaInit = true;
	}

	return m_bbaInit;
}


bool ModuleDataTab::DisplayInlineInstance(bool bInstance)
{
	bool bRet = true;

	unsigned int sessionTotal = m_prof_att.totalSamples;

	// to keep inline data
	InlineDataList inlinelist;

	// Get the base address of this module (address of .text section)
	bfd_vma imageBase = 0;
	m_symbol_engine.getImageBaseAddr((bfd_vma *)&imageBase);

	// First level item - usually it's function symbol
	sym_info firstLvSym;
	firstLvSym.clear();
	ModuleItem *pFirstLvItem = NULL;
	SampleDataMap firstLvData;	


	// Second level item - usually it's inline function or block 
	sym_info secondLvSym;
	secondLvSym.clear();
	ModuleItem *pSecondLvItem = NULL;
	SampleDataMap secondLvData;

	// Third level item - sample item;
	ModuleItem *pThirdLvItem = NULL;

	char buff[20];

	TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
	if(taskIt == m_pTaskSampMap->end())
		return false;

	SampleMap::iterator sampleIter = taskIt->second.begin();
	SampleMap::iterator sampleEnd = taskIt->second.end();

	//For each sample in the module
	for (; sampleIter != sampleEnd; sampleIter++) {
		VADDR sampAddr = sampleIter->first;
		
		// update progress dialog;
		tbsDisplayProgress_callback(NULL);

		sym_info inlineSym;
		sym_info funcSym;
		inlineSym.clear();

		int retCode = m_symbol_engine.getSymbolForAddr(sampAddr, 
						&funcSym, &inlineSym);
		if (retCode == 	SymbolEngine::OKAY) {
			if ((funcSym.sym_start != firstLvSym.sym_start) 
			||  (funcSym.possible_end != firstLvSym.possible_end)
			||  pFirstLvItem == NULL)
			{
				// new fucntion;
				firstLvSym.sym_start = funcSym.sym_start; 
				firstLvSym.possible_end = funcSym.possible_end;
				firstLvSym.name = funcSym.name;
				pFirstLvItem = new ModuleItem(m_pViewShown, MOD_OFFSET_INDEX, 
							m_pList, pFirstLvItem);
				if(!pFirstLvItem)
					return false;
					
				sprintf(buff, "0x%lx", firstLvSym.sym_start);
				pFirstLvItem->setText (MOD_ADDR, buff);
				pFirstLvItem->setText (MOD_SYMBOL, firstLvSym.name); 
				
				secondLvData.clear();
				secondLvSym.clear();
				pSecondLvItem = NULL;
				pThirdLvItem = NULL;
				firstLvData.clear();
			}

			if (inlineSym.sym_start != 0) {
				// case 1: sample is in inline function;
				if (inlineSym.sym_start != secondLvSym.sym_start) {
					pSecondLvItem = new ModuleItem(m_pViewShown, 
							MOD_OFFSET_INDEX, pFirstLvItem, pSecondLvItem);

					// new inline instance
					// highlight the fucntion and inline instance
					pFirstLvItem->setItemColor(Qt::blue);
					pSecondLvItem->setItemColor(Qt::blue);

					secondLvSym.sym_start = inlineSym.sym_start; 
					secondLvSym.possible_end = inlineSym.possible_end;
					secondLvSym.name = firstLvSym.name + " -> " + inlineSym.name;
					secondLvData.clear();	
					pThirdLvItem = NULL;
				} 

				if (bInstance) {
					// aggregate sample at inline instance (caller) side
					AggregateSamples(firstLvData, sampleIter->second);
					AggregateSamples(secondLvData, sampleIter->second);
					sprintf(buff, "0x%lx", secondLvSym.sym_start);
					pSecondLvItem->setText (MOD_ADDR, buff);
					pSecondLvItem->setText (MOD_SYMBOL, secondLvSym.name); 
					pSecondLvItem->setPrecision(m_precision);
					pSecondLvItem->setTotal(&m_TotalSampleDataMap);
					pSecondLvItem->drawData(&secondLvData, sessionTotal);

					// add 3rd level view item
					if((pThirdLvItem = new ModuleItem(m_pViewShown, 
						MOD_OFFSET_INDEX, pSecondLvItem, pThirdLvItem))){
						sprintf(buff, "0x%lx", (unsigned long) sampAddr);
						pThirdLvItem->setText(MOD_ADDR, buff);
						sprintf(buff, " + 0x%lx", (unsigned long) 
							sampAddr - secondLvSym.sym_start);
						pThirdLvItem->setText(MOD_SYMBOL, secondLvSym.name + buff);
						pThirdLvItem->setPrecision(m_precision);
						pThirdLvItem->setTotal(&m_TotalSampleDataMap);
						pThirdLvItem->drawData(&(sampleIter->second),
									sessionTotal, true); 
					}
				} else {
					// put inline into inline list;
					InlineData ilData;
					ilData.inlineFuncName = inlineSym.name;
					ilData.functionName = firstLvSym.name;
					ilData.sampleAddr = sampAddr;
					ilData.pSamp = &(sampleIter->second);

					// We need the beginning of inline instance
					ilData.inlineInstAddr = inlineSym.sym_start; 
					ilData.functionAddr = firstLvSym.sym_start;
					inlinelist.push_back(ilData);	
					
					sprintf(buff, "0x%lx", secondLvSym.sym_start);
					pSecondLvItem->setText (MOD_ADDR, buff);
					pSecondLvItem->setText (MOD_SYMBOL, secondLvSym.name); 
					pSecondLvItem->setPrecision(m_precision);
					pSecondLvItem->setTotal(&m_TotalSampleDataMap);
					pSecondLvItem->drawData(NULL, sessionTotal);
				}

			} else {
				// case2 : sample is not in inline function
				pThirdLvItem = NULL;
				pSecondLvItem = new ModuleItem(m_pViewShown, 
						MOD_OFFSET_INDEX, pFirstLvItem, pSecondLvItem);
				if(pSecondLvItem)
				{
					secondLvSym.sym_start = sampAddr;
					secondLvSym.possible_end = 0;
					secondLvSym.name.sprintf("%s + 0x%lx",
						firstLvSym.name.data(),
						sampAddr - firstLvSym.sym_start);
					sprintf(buff, "0x%lx", (unsigned long)sampAddr);
					pSecondLvItem->setText (MOD_ADDR, buff);
					pSecondLvItem->setText (MOD_SYMBOL, secondLvSym.name); 
				
					secondLvData.clear();	
					AggregateSamples(secondLvData, sampleIter->second);
					pSecondLvItem->setPrecision(m_precision);
					pSecondLvItem->setTotal(&m_TotalSampleDataMap);
					pSecondLvItem->drawData(&(sampleIter->second), 
									sessionTotal, true);

					//since it's not inline, aggregate first level
					AggregateSamples(firstLvData, sampleIter->second);
				}
			}
		
			if(pFirstLvItem)
			{
			// draw first level
				pFirstLvItem->setPrecision(m_precision);
				pFirstLvItem->setTotal(&m_TotalSampleDataMap);
				pFirstLvItem->drawData(&firstLvData, sessionTotal);
			}
		} else  {
			// case 3: Sample is unknown samples;

			firstLvSym.sym_start = sampAddr; 
			firstLvSym.possible_end = sampAddr;
			firstLvSym.name = "Unknown Sample";
			pFirstLvItem = new ModuleItem(m_pViewShown, MOD_OFFSET_INDEX, 
							m_pList, pFirstLvItem);
			sprintf(buff, "0x%lx", (unsigned long)sampAddr);
			pFirstLvItem->setText (MOD_ADDR, buff);
			pFirstLvItem->setText (MOD_SYMBOL, firstLvSym.name); 
			
			// clear previous first level data
			firstLvData.clear();
			pFirstLvItem->setPrecision(m_precision);
			// since unknown sample data is in the data map, 
			// let dataListItem keeps the pointer
			pFirstLvItem->setTotal(&m_TotalSampleDataMap);
			pFirstLvItem->drawData(&(sampleIter->second), sessionTotal, true);

			pSecondLvItem = NULL;
			secondLvSym.clear();
		}

	}	// sample Iterator loop

	if (!bInstance) {
		bRet =  DisplayInlineFunction(inlinelist);
	}
	
	inlinelist.clear();	

	return bRet;
} //bool ModuleDataTab::DisplayInlineInstance


bool ModuleDataTab::DisplayInlineFunction(InlineDataList &inlinelist)
{
	unsigned int sessionTotal = m_prof_att.totalSamples;

	// First level item - usually it's function symbol
	sym_info firstLvSym;
	firstLvSym.clear();
	ModuleItem *pFirstLvItem = NULL;
	SampleDataMap firstLvData;	

	// Second level item - usually it's inline function or block 
	sym_info secondLvSym;
	secondLvSym.clear();
	ModuleItem *pSecondLvItem = NULL;
	SampleDataMap secondLvData;

	// Third level item - sample item;
	ModuleItem *pThirdLvItem = NULL;

	char buff[20];
	
	// put inline data into inline function
	firstLvSym.clear();
	secondLvSym.clear();
	firstLvData.clear();
	secondLvData.clear();
	pFirstLvItem = NULL;
	pSecondLvItem = NULL;
	
	InlineDataList::iterator ilIter = inlinelist.begin();
	InlineDataList::iterator ilEnd = inlinelist.end();
	for (; ilIter != ilEnd; ilIter++) {
			
		// update progress dialog;
		tbsDisplayProgress_callback(NULL);
		
		// Update inline function if necessary.
		// TODO:Need to use subroutine_id to differenciate fucntions
		if(firstLvSym.name != ilIter->inlineFuncName)
		{
			// new inline function
			// Try to find if the inline function has instance
			ModuleItem *pItem = findItemForFunction(ilIter->inlineFuncName);
			if (pItem) {
				// has instance
				pFirstLvItem = pItem;
				firstLvData.clear();
				GetChildrenSamples(pItem, firstLvData);
			} else {
				// not have yet, create one
				pFirstLvItem = new ModuleItem(m_pViewShown, 
						MOD_OFFSET_INDEX, m_pList, pFirstLvItem);
				firstLvData.clear();
				secondLvSym.name = "";
				pFirstLvItem->setText (MOD_ADDR, "");
				pFirstLvItem->setText (MOD_SYMBOL, ilIter->inlineFuncName); 
			}
			firstLvSym.name = ilIter->inlineFuncName;
			pFirstLvItem->setItemColor(Qt::red);
		} 
		
		// Aggregate for the first level.
		AggregateSamples(firstLvData, *(ilIter->pSamp));

		pFirstLvItem->setPrecision(m_precision);
		pFirstLvItem->setTotal(&m_TotalSampleDataMap);
		pFirstLvItem->drawData(&firstLvData, sessionTotal);
		
		// NOTE: We temporary use "possible_end" here
		// to keep track of inline instance address
		// for the second level here.
		if (secondLvSym.possible_end!= ilIter->inlineInstAddr) 
		{
			// Get the new caller function for this inline
			secondLvData.clear();
			
			pSecondLvItem = new ModuleItem(m_pViewShown, 
						MOD_OFFSET_INDEX, pFirstLvItem, pSecondLvItem);
			secondLvSym.name = ilIter->functionName;
			secondLvSym.sym_start = ilIter->functionAddr;
			secondLvSym.possible_end = ilIter->inlineInstAddr;

			// Need to pull address here
			char buffer[20];
			sprintf(buffer, "0x%lx", ilIter->inlineInstAddr);
			pSecondLvItem->setText (MOD_ADDR, buffer);
			pSecondLvItem->setText (MOD_SYMBOL, ilIter->inlineFuncName + " <- " +
							ilIter->functionName); 
			pSecondLvItem->setItemColor(Qt::red);
		} 

		AggregateSamples(secondLvData, *(ilIter->pSamp));
		pSecondLvItem->setPrecision(m_precision);
		pSecondLvItem->setTotal(&m_TotalSampleDataMap);
		pSecondLvItem->drawData(&secondLvData, sessionTotal);

		// add 3rd level view item
		if((pThirdLvItem = new ModuleItem(m_pViewShown, 
						MOD_OFFSET_INDEX, pSecondLvItem, pThirdLvItem))){
			sprintf(buff, "0x%lx", (unsigned long) ilIter->sampleAddr);
			pThirdLvItem->setText(MOD_ADDR, buff);
			
			sprintf(buff, " + 0x%lx", ilIter->sampleAddr - secondLvSym.sym_start);
			pThirdLvItem->setText(MOD_SYMBOL, secondLvSym.name + buff);
			pThirdLvItem->setPrecision(m_precision);
			pThirdLvItem->setTotal(&m_TotalSampleDataMap);
			pThirdLvItem->drawData(ilIter->pSamp, sessionTotal, true); 
		}
	}
	return true;
}

void ModuleDataTab::GetChildrenSamples(ModuleItem* pItem, SampleDataMap &data)
{
	if (!pItem)
		return;

	ModuleItem* pSecondItem = (ModuleItem*) pItem->firstChild();
	while (NULL != pSecondItem) {
		if (pSecondItem->childCount()) {
			ModuleItem *pChildItem = (ModuleItem*) pSecondItem->firstChild ();
			while (NULL != pChildItem) {
				pChildItem->getItemSamples(data);
				pChildItem = (ModuleItem*) pChildItem->nextSibling();
			}	
		} else {
			pSecondItem->getItemSamples(data);
		}
		pSecondItem = (ModuleItem*) pSecondItem->nextSibling();
	}
}

bool ModuleDataTab::DisplayBasicBlocks()
{
	bool bRet = true;

	unsigned int sessionTotal = m_prof_att.totalSamples;

	// Set the Column Header
	m_pList->setColumnText(MOD_SYMBOL,
					QString("Basic Block : ( Load / Store )"));

	// Get the base address of this module (address of .text section)
	bfd_vma imageBase = 0;
	int ret_val = m_symbol_engine.getImageBaseAddr((bfd_vma *)&imageBase);

	if(ret_val != SymbolEngine::OKAY)
	{
		return false;
	}

	// First level item - usually it's function symbol
	sym_info firstLvSym;
	firstLvSym.clear();
	ModuleItem *pFirstLvItem = NULL;
	SampleDataMap firstLvData;	

	// Second level item - usually it's inline function or block 
	sym_info secondLvSym;
	secondLvSym.clear();
	ModuleItem *pSecondLvItem = NULL;
	SampleDataMap secondLvData;

	// Third level item - sample item;
	ModuleItem *pThirdLvItem = NULL;

	// enable BBA analysis;
	BLOCKMAP *pBBMap = NULL;
	BLOCKMAP::iterator bbIter;
	BLOCKMAP::iterator bbEnd;

	// Memory access
	MEMACCESSMAP *pMemMap = NULL;
	MEMACCESSMAP::iterator memAccIter;
	MEMACCESSMAP::iterator memAccEnd;

	char buff[20];

	if (!InitializeBBA())
		return false;

	// inline instance vector and variables
	SYM_INFO_VECTOR inlineVec;

	pBBMap = m_bba.bba_get_block_map();
	// Note: the blockmap key, BASIC_BLOCK_KEY, is sorted in 
	// descending order.
	bbIter = bbEnd = pBBMap->end();
	if (pBBMap->size()) 
		bbIter--;	

	pMemMap = m_bba.bba_get_mem_map();
	memAccIter = pMemMap->begin();
	memAccEnd = pMemMap->end();
	
	TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
	if(taskIt == m_pTaskSampMap->end())
		return false;

	SampleMap::iterator sampleIter = taskIt->second.begin();
	SampleMap::iterator sampleEnd = taskIt->second.end();

	//For each sample in the module
	for (; sampleIter != sampleEnd; sampleIter++) {
		VADDR sampAddr = sampleIter->first;

		// update progress dialog;
		tbsDisplayProgress_callback(NULL);

		// Get First level (function level) info
		if (firstLvSym.possible_end < sampAddr) {
			// before create new function level item, update previous
			if (pFirstLvItem) {
				pFirstLvItem->setPrecision(m_precision);
				pFirstLvItem->setTotal(&m_TotalSampleDataMap);
				pFirstLvItem->drawData(&firstLvData, sessionTotal);
			} 

			if (pSecondLvItem) {
				pSecondLvItem->setTotal(&m_TotalSampleDataMap);
				pSecondLvItem->drawData(&secondLvData, sessionTotal);
			}

			firstLvData.clear();	
			firstLvSym.clear();
			secondLvData.clear();	
			secondLvSym.clear();
			pSecondLvItem = NULL;

			AggregateSamples(firstLvData, sampleIter->second);
			
			// move to new function, Need to add New first level Item;
			pFirstLvItem = AddFirstLvElfItem(sampAddr, firstLvSym, 
							pFirstLvItem,inlineVec, bbIter, bbEnd, imageBase);

			if (inlineVec.size()) {	
				// This function Item has inlines
				pFirstLvItem->setItemColor(Qt::blue);
			}
			sprintf(buff, "0x%lx", (unsigned long)firstLvSym.sym_start);

			pFirstLvItem->setText (MOD_ADDR, buff);
			pFirstLvItem->setText (MOD_SYMBOL, firstLvSym.name); 
		} else {
			// update first level data
			AggregateSamples(firstLvData, sampleIter->second);
		}

		// Get second/third level items. 
		// Note: the basic block iterator already move to begin of the function
		if (secondLvSym.possible_end <= sampAddr) {
			// if previous 2nd level exist; update view Item
			if (pSecondLvItem) {
				pSecondLvItem->setPrecision(m_precision);
				pSecondLvItem->setTotal(&m_TotalSampleDataMap);
				pSecondLvItem->drawData(&secondLvData, sessionTotal);
				
				secondLvData.clear();
				secondLvSym.clear();
			} 

			while (bbIter != bbEnd) {
				// if block is out of range of current function. Stop.
				if (bbIter->first.bb_start+imageBase > firstLvSym.possible_end)
					break;

				secondLvSym.sym_start = bbIter->first.bb_start + imageBase;
				if (secondLvSym.sym_start < firstLvSym.sym_start)
					secondLvSym.sym_start = firstLvSym.sym_start;
				secondLvSym.possible_end = bbIter->first.bb_start +
						bbIter->second.bb_size + imageBase;

				secondLvSym.name.sprintf("[ 0x%lx - 0x%lx )",
								(unsigned long) secondLvSym.sym_start,
								(unsigned long) secondLvSym.possible_end);

				QString ls_str = UpdateMemoryAccess(secondLvSym, memAccIter, 
								memAccEnd, imageBase);

				pSecondLvItem = new ModuleItem(m_pViewShown, 
							MOD_OFFSET_INDEX, pFirstLvItem, pSecondLvItem);

				pSecondLvItem->setPrecision(m_precision);
				sprintf(buff, "0x%lx", (unsigned long)
							secondLvSym.sym_start);
				pSecondLvItem->setText (MOD_ADDR, buff);
				pSecondLvItem->setText (MOD_SYMBOL, secondLvSym.name + ls_str);
				
				// Check if this is inline function
				if(m_symbol_engine.isInlineInstance(secondLvSym.sym_start))
				{
					pSecondLvItem->setItemColor(Qt::red);
				}
				
				bbIter--;

				if (secondLvSym.possible_end <= sampAddr) {
					// add new item with no data	
					pSecondLvItem->setTotal(&m_TotalSampleDataMap);
					pSecondLvItem->drawData(&secondLvData, sessionTotal); 
					continue;	
				} else {
					// update 2nd level data
					AggregateSamples(secondLvData, sampleIter->second);

					// add 3rd level view item
					if((pThirdLvItem = new ModuleItem(m_pViewShown, 
							MOD_OFFSET_INDEX, pSecondLvItem, pThirdLvItem))){
						sprintf(buff, "0x%lx", (unsigned long) sampAddr);
						pThirdLvItem->setText(MOD_ADDR, buff);
						sprintf(buff, " + 0x%lx", (unsigned long) 
							sampAddr - secondLvSym.sym_start);
						pThirdLvItem->setText(MOD_SYMBOL, secondLvSym.name + buff);
						pThirdLvItem->setPrecision(m_precision);
						pThirdLvItem->setTotal(&m_TotalSampleDataMap);
						pThirdLvItem->drawData(&(sampleIter->second), 
										sessionTotal, true); 

						// Check if this is inline function
						if(m_symbol_engine.isInlineInstance(sampAddr))
						{
							pThirdLvItem->setItemColor(Qt::red);
						}
					}
					
					// break the while loop to move on to next sample;
					break;
				}
			};	// block iteration loop;
		} else {
			// update 2nd level data
			AggregateSamples(secondLvData, sampleIter->second);
			// add 3rd level view item
			if(( pThirdLvItem = new ModuleItem(m_pViewShown, MOD_OFFSET_INDEX, 
							pSecondLvItem, pThirdLvItem))){
				sprintf(buff, "0x%lx", (unsigned long) sampAddr);
				pThirdLvItem->setText(MOD_ADDR, buff);
				sprintf(buff, " + 0x%lx", (unsigned long) 
							sampAddr -	secondLvSym.sym_start);
				pThirdLvItem->setText(MOD_SYMBOL, secondLvSym.name + buff);
				pThirdLvItem->setPrecision(m_precision);
				pThirdLvItem->setTotal(&m_TotalSampleDataMap);
				pThirdLvItem->drawData(&(sampleIter->second), sessionTotal, true); 
				// Check if this is inline function
				if(m_symbol_engine.isInlineInstance(sampAddr))
				{
					pThirdLvItem->setItemColor(Qt::red);
				}
			}
		}
	}	// sample Iterator loop

	// update last function level item 
	if (pFirstLvItem) {
		pFirstLvItem->setTotal(&m_TotalSampleDataMap);
		pFirstLvItem->drawData(&firstLvData, sessionTotal);
	}
	
	// update last second level item
	if (pSecondLvItem) {
		pSecondLvItem->setTotal(&m_TotalSampleDataMap);
		pSecondLvItem->drawData(&secondLvData, sessionTotal);
	}

	if (inlineVec.size()) {	
		delete_SYM_INFO_VECTOR(inlineVec);
	}

	return bRet;
}

bool ModuleDataTab::DisplayJavaFunctions()
{
	bool bRet = true;
	char buff[20];
	unsigned int sessionTotal = m_prof_att.totalSamples;
	// First level item - usually it's Java function name 
	ModuleItem *pFirstLvItem = NULL;
	SampleDataMap firstLvData;	
	JIT_BLOCK_INFO jit_blk;

	// Second level item - usually it's instruction address 
	ModuleItem *pSecondLvItem = NULL;

	JitBlockPtrVec::iterator jbIter    = m_pJitBlkPtrVec->begin();
	JitBlockPtrVec::iterator jbIterEnd = m_pJitBlkPtrVec->end();

	//For each jitblock in the module
	for (; jbIter != jbIterEnd; jbIter++) {
		firstLvData.clear();
		
		// update progress dialog;
		tbsDisplayProgress_callback(NULL);

		jit_blk.jit_load_addr    = (*jbIter)->jit_load_addr;
		jit_blk.jit_fun_name     = (*jbIter)->jit_fun_name;

		// new fucntion;
		pFirstLvItem = new ModuleItem(m_pViewShown, MOD_OFFSET_INDEX, m_pList, pFirstLvItem);
		sprintf(buff, "0x%lx", (unsigned long)jit_blk.jit_load_addr);
		pFirstLvItem->setText (MOD_ADDR, buff);
		pFirstLvItem->setText (MOD_SYMBOL, jit_blk.jit_fun_name); 
		
		SampleMap::iterator sampleIter = (*jbIter)->javaSampleMap.begin();
		SampleMap::iterator sampleEnd  = (*jbIter)->javaSampleMap.end();
		for (; sampleIter != sampleEnd; sampleIter++){
			pSecondLvItem = NULL;
			VADDR sampAddr = sampleIter->first;

			// aggregate sample at first level 
			AggregateSamples(firstLvData, sampleIter->second);

			// add second level view item - instruction level 
			pSecondLvItem = new ModuleItem(m_pViewShown, 
							MOD_OFFSET_INDEX, pFirstLvItem, pSecondLvItem);
			sprintf(buff, "0x%lx", (unsigned long) sampAddr);
			pSecondLvItem->setText(MOD_ADDR, buff);
			sprintf(buff, " + 0x%lx", (unsigned long) (sampAddr - 
								jit_blk.jit_load_addr));
			pSecondLvItem->setText(MOD_SYMBOL, jit_blk.jit_fun_name + buff);
			pSecondLvItem->setPrecision(m_precision);
			pSecondLvItem->setTotal(&m_TotalSampleDataMap);
			pSecondLvItem->drawData(&(sampleIter->second),sessionTotal, true); 
		}// sample Iterator loop
		pFirstLvItem->setPrecision(m_precision);
		pFirstLvItem->setTotal(&m_TotalSampleDataMap);
		pFirstLvItem->drawData(&firstLvData, sessionTotal);
	}
	return bRet;
}


bool ModuleDataTab::DisplayJavaData ()
{
	bool bRet = true;
	switch(m_dataAggType) {
		case AGG_BASICBLOCK:
		case AGG_INLINEINSTANCE:
		case AGG_INLINEFUNCTION:
		default:
			bRet = DisplayJavaFunctions();
			break;
	}

	return bRet;
}


void ModuleDataTab::onRightClick (QListViewItem * item, const QPoint & pt,
								  int col)
{
	Q_UNUSED (item);
	Q_UNUSED (col);
	m_popup->popup (pt);
}


void ModuleDataTab::onViewGraph ()
{
	emit viewGraph (m_module_name, TAB_GRAPH);
}


void ModuleDataTab::onDblClicked (QListViewItem * item)
{
	QString txt = item->text(MOD_ADDR);
	VADDR addr = 0;

	// Check if this item contains addres information
	if(!txt.startsWith("0x"))
		return;

	// When double click on an item, do not expand/collapse it.
	if(item->isOpen()) {
		item->setOpen(false);
	}else{
		item->setOpen(true);
	}

	addr = strtoul (item->text (MOD_ADDR).data (), NULL, HEX_BASE);

	if (JAVAMODULE == m_prof_att.modType
	&& !m_module_name.endsWith(".jo")) {
		// use JIT Detail to find jnc file path for a given addr
		JitBlockPtrVec::reverse_iterator r_jitIt    = m_pJitBlkPtrVec->rbegin();
		JitBlockPtrVec::reverse_iterator r_jitItEnd = m_pJitBlkPtrVec->rend();
		for (;r_jitIt != r_jitItEnd; r_jitIt++) {
			if ((*r_jitIt)->jit_load_addr <= addr)
				break; 
		}
		
		if (r_jitIt != r_jitItEnd) {
			char addrstr[100];
			sprintf(addrstr, " - 0x%lx", (*r_jitIt)->jit_load_addr);
			QString path = (*r_jitIt)->jnc_file_path;
			if (!path.startsWith("/")) {
				m_prof_att.modPath = m_tbp_file->getTbpDir() 
						+ "/" + (*r_jitIt)->jnc_file_path;
			} else {
				m_prof_att.modPath = (*r_jitIt)->jnc_file_path;
			}
			m_prof_att.modName = (*r_jitIt)->jit_fun_name; 
			m_prof_att.modName += addrstr; 
			emit symDblClicked (addr, &((*r_jitIt)->javaSampleMap), m_prof_att);
		} 	
	} else {
		TaskSampleMap::iterator taskIt = m_pTaskSampMap->find(m_taskId);
		if (taskIt != m_pTaskSampMap->end()) 
			emit symDblClicked (addr, &(taskIt->second), m_prof_att);
	}
	return;
}


void ModuleDataTab::onSelectTask (int index)
{
	unsigned int taskid = SHOW_ALL_TASKS;
	if (SHOW_ALL_TASKS == index)
		taskid = SHOW_ALL_TASKS;
	else
	{
		taskid = m_taskName_id_map[m_pTaskId->currentText()];
	}
	if (taskid != m_taskId) {
		m_taskId = taskid;
		addItemsAndDisplayData();
	}

	onExpandCollapseToggled(m_pExpandCollapse->isOn());
}


QListView *ModuleDataTab::getListView ()
{
	return m_pList;
}

ModuleItem* ModuleDataTab::findItemForFunction(QString funcName)
{
	ModuleItem *pItem = NULL;

	pItem = (ModuleItem*) m_pList->firstChild();
	while(NULL != pItem) {
		QString itemFunc = pItem->text (MOD_SYMBOL);
		if (funcName == itemFunc)
			break;
		pItem = (ModuleItem*) pItem->nextSibling();
	}

	return pItem;
}


void ModuleDataTab::onSelectionChange ()
{
/*
	static bool no_reentry = false;
	if (no_reentry)
		return;
	no_reentry = true;
	QListViewItem *pItem = (QListViewItem *) m_pList->firstChild();

	unsigned int funCount = 0;
	unsigned int instCount = 0;
	UINT64 sampleCount = 0;

	while (NULL != pItem) {
		if ((pItem->isSelected()) && (!pItem->isOpen())) {
			funCount++;
			instCount += pItem->childCount();
			sampleCount += ((ModuleItem *)pItem)->getItemTotal();
		}
		else {
			if (pItem->isOpen()) {
				bool bAddFun = false;
				QListViewItem *pChildItem = pItem->firstChild ();
				while (NULL != pChildItem) {
					if (pChildItem->isSelected()) {
						bAddFun = true;
						instCount++;

						sampleCount += ((ModuleItem *)pChildItem)->getItemTotal();
					}
					pChildItem = pChildItem->nextSibling();
				}
				if (bAddFun)
					funCount++;
			}
		}
		pItem = (QListViewItem *) pItem->nextSibling();
	}

	float pct = 0.0;

	if (m_tbp_file->getNumSamples () != 0)
		pct = (float) sampleCount * 100 / (float) m_tbp_file->getNumSamples ();

	m_selectText.sprintf("%u function%s, %u instruction%s, "
		"Total: %llu sample%s, %.2f%c of total session samples",
		funCount, ((funCount != 1)?"s":""), instCount,
		((instCount != 1)?"s":""), sampleCount, ((sampleCount != 1)?"s":""),
		pct, '%');

	statusBar()->message (m_selectText);
	no_reentry = false;
*/
}

void ModuleDataTab::onAggregationChanged(int aggregationType)
{
#ifdef ENABLE_DWARF
	m_dataAggType = aggregationType;
#else
	/* Conversion from index to aggregation type */
	switch (aggregationType) {
	case 0:
		m_dataAggType = AGG_INLINEINSTANCE;
		break;
	case 1:
		m_dataAggType = AGG_BASICBLOCK;
		break;
	}
#endif
		
	addItemsAndDisplayData();
	
	onExpandCollapseToggled(m_pExpandCollapse->isOn());
}
