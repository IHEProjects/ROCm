
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _OPROFILEDAEMONDOCKVIEW_H_
#define _OPROFILEDAEMONDOCKVIEW_H_

#include <qdockwindow.h>
#include <qtabwidget.h>
#include <qthread.h>
#include <qlayout.h>
#include <qmutex.h>

#include "MonitorDockView.h"
#include "DaemonMonitorTool.h"

class OprofileDaemonDockView : public MonitorDockView
{
	Q_OBJECT;
public:
	OprofileDaemonDockView(QWidget * parent, const char * name = 0, WFlags f = 0);
	virtual ~OprofileDaemonDockView();
	virtual void updateWithSnapshot();

public slots:

protected:
	virtual bool init();

	DaemonMonitorTool 		* m_pDaemonMonitorTool;
	DaemonMonitorSnapshot 		* m_pSnapDaemon;
	QBoxLayout			* m_pBLayout;
};

#endif //_OPROFILEDAEMONDOCKVIEW_H_


