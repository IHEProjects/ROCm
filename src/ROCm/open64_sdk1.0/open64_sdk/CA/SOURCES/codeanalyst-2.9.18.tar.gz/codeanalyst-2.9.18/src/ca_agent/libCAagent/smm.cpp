/**
 * @file smm.h
 *
 * @remark Read the file COPYING
 *
 * @author Lei Yu 
 * @author Jason Yeh
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <iostream>
#include <limits.h>
#include <string.h>

#include "smm.h"
#include "slock.h"
#include "config.h"

using namespace std;

namespace {
	// key is defined as group id and page number
	// each page contains 512 entries. That means we have 
	// 51200 entries total.
	void generate_key(pid_t tgid, unsigned int page, key_t * key)
	{
		*key = tgid * 100 + page;
	}

};  /// anonymous namespacesize

smm::smm()
{
}


void * smm::create_shared_memory(pid_t tgid, 
				unsigned int page_id,
				unsigned int size) 
{
	void *buffer = NULL;
	int shmid;
	key_t key;
	
	if (NULL != buffer)
		goto out;

	generate_key(tgid, page_id, &key);
	if (key < 0) {
		goto out;
	}

	shmid = shmget(key, size, IPC_CREAT|0666);    
	if (shmid < 0) {
		goto out;
	}
    
    /// attach the segment to the data space.
    if ((buffer = shmat(shmid, NULL, 0)) == (void *) -1)  {
		buffer = NULL;
	}
    
out:
	return buffer;
}


void* smm::open_shared_memory(pid_t tgid, 
				unsigned int page_id,
				unsigned int size)
{
	void *buffer = NULL;
	int shmid;
	key_t key;

	generate_key(tgid, page_id, &key);
	if(key < 0)
		goto out;

	if ((shmid = shmget(key, size, 0666)) < 0)
		goto out;

	buffer = (char*) shmat(shmid, NULL, 0);
	if ( buffer == (char *) -1)
		buffer = NULL;

out:
	return buffer;
}


void smm::remove_shared_memory(pid_t tgid, 
				unsigned int page_id, unsigned int size)
{
	key_t key;
	int shmid;

	generate_key(tgid, page_id, &key);
    if ((shmid = shmget(key, size, 0666)) > 0)
		shmctl(shmid, IPC_RMID, NULL);
}

