/**
 * @file libCAagent.h
 * API for agent to communicate with Oprofile daemon
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#ifndef _LIB_CAAGENT_H
#define _LIB_CAAGENT_H

#include <sys/types.h>
#include <bfd.h>


struct ca_jit_shm_entry
{
	unsigned long long start_address;
	unsigned int size;
}__attribute__((packed));


int ca_open_agent(pid_t tgid);

void ca_close_agent(pid_t tgid);

int ca_add_mapping(struct ca_jit_shm_entry const * entry);

int ca_write_native_code(char const * symbol_name, const void* code_addr, 
	unsigned int size);


#endif

