#ifndef _PERFEVENTCONTAINER_H_
#define _PERFEVENTCONTAINER_H_

#include <qmap.h>
#include <qvaluelist.h>

#include "PerfEvent.h"
#include "stdafx.h"
#include "EventMaskEncoding.h"
#include "eventsfile.h"

typedef QValueList<PerfEvent> 		PerfEventList;

typedef QMap<PerfEventList, QString> 	AllocMap;

class PerfEventContainer
{
public:
	PerfEventContainer();

	~PerfEventContainer();

	bool operator==(const PerfEventContainer & opt) const;

	bool add(const PerfEvent & event);

	bool remove(const PerfEvent & event);
	
	unsigned int count();
	
	unsigned int countPmc();

	unsigned int countIbsFetch();
	
	unsigned int countIbsOp();

	bool getCounterAllocation(AllocMap * alloc);

	PerfEventList * getPerfEventList() { return &m_perfEventList; };
	
	PerfEventList::iterator getPerfEventListBegin() { return m_perfEventList.begin(); };
	
	PerfEventList::iterator getPerfEventListEnd() { return m_perfEventList.end(); };
	
	void dumpPerfEvents();

	void setIbsFetchCountUmask(unsigned long count, unsigned int umask);

	bool getIbsFetchCountUmask(unsigned long & count, unsigned int & umask);

	void setIbsOpCountUmask(unsigned long count, unsigned int umask);

	bool getIbsOpCountUmask(unsigned long & count, unsigned int & umask);

	bool hasIbs();

	bool validateEvents(QString & errorStr);

	bool validateIbs(QString & errorStr);
	
	bool validateOpName(QString & errorStr);

	void enumerateAllEvents(EventMaskEncodeMap & event_map);

	int populateOpNames(CEventsFile * pEventFile);

	void dumpAllEvents();
protected:
	PerfEventList	m_perfEventList;
	
};

#endif /*_PERFEVENTCONTAINER_H_*/
