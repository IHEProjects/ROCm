//$Id: moddataview.h,v 1.3 2005/02/14 16:52:40 jyeh Exp $
//interface for the ModuleDataView class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2007 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _MODDATAVIEW_H
#define _MODDATAVIEW_H

#include <pthread.h>

#include "stdafx.h"
#include "graphview.h"
#include "tbsreader.h"
#include "symbolengine.h"
#include "sessionnav.h"
#include "bbanalysis.h"

struct InlineData {
	QString inlineFuncName;	// this is the name of inline function
	QString functionName;	// this is the fucntion called inline function;
	VADDR functionAddr;		// this is the fucntion address 
	VADDR inlineInstAddr;		// this is the inline instance address 
	VADDR sampleAddr;
	SampleDataMap *pSamp;
};

typedef list<InlineData> InlineDataList;

class ModuleItem;

//////////////////////////////////////////////////////////////////////////////
enum MODULE_COLUMNS {
	MOD_ADDR = 0,
	MOD_SYMBOL,
	//	MOD_THREAD_ID,
	MOD_OFFSET_INDEX,
	MOD_INVALID
};

enum MOD_POPUPS {
	//M0D_POP_SEP = 0,
	MOD_POP_DATA = 1,
	MOD_POP_GRAPH,
	MOD_POP_SHOWN
};

#ifdef _x86_64_
static const char EIPSTRING[] = "CS:RIP";
#else
static const char EIPSTRING[] = "CS:EIP";
#endif


class ModuleItem : public DataListItem {
public:
	ModuleItem (ViewShownData *pViewShown, int indexOffset, 
		QListView * parent, QListViewItem * after);
	ModuleItem (ViewShownData *pViewShown, int indexOffset, 
		QListViewItem * item, QListViewItem * after);

	void clearData();
protected:
	QString key (int column, bool ascending) const;

public:
	QListViewItem * m_last_child;
};

//////////////////////////////////////////////////////////////////////////////
// ModuleDataTab Class
//

class ModuleDataTab:public DataTab {
	Q_OBJECT
public:
	ModuleDataTab (QString ModuleName, TbsReader* pTbsFile, 
		ViewShownData *pViewShown, QWidget * parent,
		const char *name, int wflags);
	virtual ~ ModuleDataTab ();
	
	void setDataMapPointer(TaskSampleMap *pTMap, 
				//JitBlockMap *pJitMap) {
				JitBlockPtrVec *pJitBlkPtrVec) {
		m_pTaskSampMap = pTMap;
		m_pJitBlkPtrVec = pJitBlkPtrVec;
	};

	bool initialize (unsigned int taskId, UINT64 address = 0);
	QListView *getListView ();
	bool tbsDisplayProgress_callback(const char * msg);
	void setAttributeType(ProfileAttribute attr){ m_prof_att = attr; };

private:
	bool updateData ();
	void calculateTotalData();
	bool addItemsAndDisplayData();
	void setColumns();
	bool readAndAggregateData();

	ModuleItem* AddFirstLvElfItem(VADDR addr, 
				sym_info &firstLvSym, ModuleItem *pFirstLvItem,
				SYM_INFO_VECTOR &inlineVec,
				BLOCKMAP::iterator &bbIter, BLOCKMAP::iterator bbEnd,
				bfd_vma imageBase);
	
	ModuleItem* AddFirstLvElfItem(VADDR addr, 
				sym_info &firstLvSym, ModuleItem *pFirstLvItem);

	bool InitializeBBA();
	bool DisplayELFData ();
	bool DisplayJavaData ();
	bool DisplayInlineInstance(bool bInstance = true);
	bool DisplayInlineFunction(InlineDataList &inlinelist);
	bool DisplayBasicBlocks();
	bool DisplayJavaFunctions();

	void getJoSymbol(VADDR sampAddr, QString &funcName);

	ModuleItem* findItemForFunction(QString funcName); 
	void GetChildrenSamples(ModuleItem* pItem, SampleDataMap &data);

	QString 	m_module_name;
	QPopupMenu 	*m_popup;
	QWorkspace 	*m_workspace;
	TbsReader 	*m_tbp_file;
	SymbolEngine 	m_symbol_engine;
	TaskSampleMap 	*m_pTaskSampMap;
	JitBlockPtrVec 	*m_pJitBlkPtrVec;
	ProfileAttribute	m_prof_att;

	bool		m_no_symbols;
	UINT64 		m_address;
	QProgressDialog * m_pProgressDlg;

	unsigned int 	m_taskId;
	QPushButton 	*m_pExpandCollapse;
	QToolBar 	*m_pModDataViewToolbar;
	QToolBar 	*m_pModAggregationToolbar;
	QComboBox 	*m_pTaskId;
	QComboBox 	*m_pAggregationId;
	map<QString,unsigned int> m_taskName_id_map;

	UINT		m_dataAggType;
	UINT		m_showAggCtrl;
	BBAnalysis 	m_bba;
	bool 		m_bbaInit;

	/* Number of the next threshold to actually update the gui */
	unsigned int 	m_display_progress_threshold;
	/* Number of times the callback has been called */
	unsigned int 	m_display_progress_calls;

private slots:
	void onDblClicked (QListViewItem * item);
	void onRightClick (QListViewItem * item, const QPoint & pt, int col);
	void onViewGraph ();
	void onSelectionChange ();
	void onSelectTask (int index);
	void onExpandCollapseToggled(bool b);
	void onAggregationChanged(int aggregationType);

public slots:
	virtual void onViewChanged (ViewShownData * pShownData);

signals:
	void symDblClicked (VADDR address,SampleMap *samp_map, 
			ProfileAttribute prof_att);

	void viewGraph (QString module_name, TAB_TYPE type);
};

#endif // #ifndef _MODDATAVIEW_H
