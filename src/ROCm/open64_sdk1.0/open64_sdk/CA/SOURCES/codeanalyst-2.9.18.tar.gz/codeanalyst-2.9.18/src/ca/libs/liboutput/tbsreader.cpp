//$Id: tbsreader.cpp 17391 2009-11-13 21:41:13Z ssuthiku $
//  interface for the TbsReader class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/


#include "stdafx.h"
#include "tbsreader.h"
#include "dataagg.h"

#define PARSE_LINE_UINT  line.section ('=', 1,1).toUInt()
#define PARSE_LINE_ULONG line.section ('=', 1,1).toULong()
void get_tbp_samps(QString const & line, EnvValues &env_vals)
{
	//
	// I read the samples into a float because if it gets a number divisible
	// by 1000 (like 1024000), it seems to print in scientific notation (like
	// 1.024e+06), which is interpreted as a ulong of 1.
	
	float temp;
	temp = line.section ("=", 1, 1).toFloat ();
	env_vals.m_num_samples = (unsigned long) temp;
}

TbsReader::TbsReader()
{
	m_tbp_file_path = "";
	m_tbp_dir = "";
	m_file = NULL;
	m_stream = NULL;
	m_largestOffset = 0;
	m_tbp_version = 0;
}

TbsReader::~TbsReader()
{
	m_tbp_file_path = "";
	m_tbp_dir = "";

	delete_filestream();

	m_offsetMap.clear();
}

bool TbsReader::OpenTbsFile(QString tbp_file_path)
{
	bool bRet = true;
	
	if (!m_file) {
		m_tbp_file_path = tbp_file_path;
		int i = m_tbp_file_path.findRev("/");
		m_tbp_dir = tbp_file_path.left(i);
		m_file = NULL;
		m_stream = NULL;
		m_tbp_version = 0;
		m_largestOffset = 0;
		bRet = open_filestream();
	}

	if (bRet) {
		// read version and [ENV] section;
		bRet = readEnvSection();
	}

	return bRet;
}

unsigned int TbsReader::getTbpFileVersion()
{
	return m_tbp_version;
}


void TbsReader::delete_filestream()
{
	if (m_file) {
  		m_file->close();
		delete m_file;
		m_file = NULL;
	}

	if (m_stream) {
		delete m_stream;
		m_stream = NULL;
	}
}


bool TbsReader::open_filestream()
{
	bool bRet = true;

	if (m_file)
		return bRet;

	if(m_tbp_file_path.length() == 0)
		return false;
	
	m_file = new QFile(m_tbp_file_path);
	if (m_file) { 
		bRet = m_file->open (IO_ReadOnly);
	}

	if (bRet) {
		m_stream = new QTextStream(m_file);
		if (!m_stream) {
			m_file->close();
			m_file = NULL;
			bRet = false;
		}
	}
	return bRet;
}

bool TbsReader::readEnvSection()
{
	if (!m_file)
		return false;

	QString line, line2, endSection;
	bool ret = true;

	// move file to head;
	m_file->reset();

	// First Line in the file should specify TBPFILEVERSION for 6 and upper
	line = m_stream->readLine();

	line2 = m_stream->readLine();
	
	if (m_stream->eof())
		return false;

	if (line.contains("[ENV]")) {
		// this could be the version 3 
		line = line2;
	}
	
	if (!line.contains("TBPFILEVERSION") || 
			!line.startsWith ("TBPFILEVERSION")) {
		return false;
	}

	m_tbp_version = line.section ("=", 1).toUInt();
	switch(m_tbp_version) {
		case TBPFILEVERSION_3:
			endSection = "[/ENV]";
			break;
		default:
			endSection = "[END]";
			break;
	}

	m_file->reset();
	/***********************************************************
	 * This section parses all lines from [ENV] to [END] or the EOF
	 * whichever one comes first.  No need to look for the beginning tag 
	 * [ENV] as this function should be called right after the constructor in
	 * the init() function.
	 */
	do {
		line = m_stream->readLine();
	} while (!line.contains("[ENV]") && !m_stream->eof());
	markOffset("[ENV]");

	// Process [ENV] section	
	do {
		line = m_stream->readLine();
		processEnvLine(line);
	}while(!line.contains(endSection) && !m_stream->eof());
	markOffset("");

	//***********************************************************

	if (m_stream->eof()) {
		ret = false;
	}

	return ret;
}

bool TbsReader::getModAttributes (QString modName, ProfileAttribute *pAtt)
{
	bool ret = false;
	unsigned int offset = 0;
	QString line;
	QString modSectName = "[" + modName + "]";
	
	if (!m_file )
		return ret;
	
	bool bModDataSig = GetOffset(modSectName, &offset);

	if (!bModDataSig) {
		/// [ModuelName] section
		while(1) {
			line = m_stream->readLine();

			if (m_stream->eof() ) {
				ret = false;
				goto out;
			}
		
			if (line.startsWith("[")) {
				// this is either [ModuleName] or [END] line

				if (line.contains(modSectName)) {
					// if the line is the module that we are looking for
					markOffset(modSectName);
					break;
				}

				if (line.contains("[END]")) {
					markOffset("");
				} else {
					markOffset(line);
				}
			}	// end of if (line.startsWith("["))
		}; // end of while loop;
	}else {
		m_file->at(offset);
	}
	
	ret = readModAttributes (pAtt);
out:
	return ret;
}


bool TbsReader::readModAttributes (ProfileAttribute *pAtt)
{
	bool bRet = false;

	if (!m_file)
		return bRet;

    QString line;

    //"BASE="
    line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
    pAtt->modPatchLoadAddr = line.section ("=", 1).toULongLong (NULL, 16);

    // "SIZE="
    line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;

    // "SAMPS="
    line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
    pAtt->totalSamples = line.section ("=", 1).toULong ();

    //"ModuleType="
    line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
    pAtt->modType = line.section ("=", 1).toULong ();

	if (m_tbp_version >= TBPFILEVERSION_8) {
		// this is new in VERSION 8
		
		//"LINECOUNT="
    	line = m_stream->readLine();
		if (m_stream->eof()) 
			goto out;
    	// pAtt->modType = line.section ("=", 1).toULong ();
	}
 	bRet = true;

out:	
    return bRet;
}

void TbsReader::processEnvLine(QString const & line)
{
	QString tmp = "";
	if (line.contains("CPUFAMILY") ) {
		switch(m_tbp_version) {
			case TBPFILEVERSION_6:
				m_env_vals.m_cpufamily = PARSE_LINE_ULONG;
				break;
			case TBPFILEVERSION_7:
			case TBPFILEVERSION_8:
			case TBPFILEVERSION_9:
				tmp = line.section("=",1,1);
				m_env_vals.m_cpufamily = tmp.section(',',0,0).toULong();
				m_env_vals.m_cpumodel  = tmp.section(',',1,1).toULong();
				break;
			default:
				break;
		}
	} else if (line.contains("CPU") ) {
		m_env_vals.m_num_cpus = PARSE_LINE_UINT;
	} else if (line.contains("NumEvents") ) {
		m_env_vals.m_num_events = PARSE_LINE_UINT;
	} else if (line.contains("MODULES") ) {
		m_env_vals.m_num_modules = PARSE_LINE_UINT;
	} else if (line.contains("SAMPS") ) {
		get_tbp_samps(line, m_env_vals);
	} else if (line.contains("Event") ) {
		switch(m_tbp_version) {
			case TBPFILEVERSION_6:
			case TBPFILEVERSION_7:
			case TBPFILEVERSION_8:
			case TBPFILEVERSION_9:
				{
					// format : Event <index>,<event+mask>, <norm>
					// Example: Event 0,64,250000.000
					// Note   : at this point, we are not using the norm in 
					// 			the calculation.
					unsigned long long event;
				   event = line.section(",",1,1).toULongLong();
				   m_env_vals.m_event_list.append(event);
				}
				break;
			case TBPFILEVERSION_3:
				{
					unsigned int event = PARSE_LINE_UINT;
					m_env_vals.m_event_list.append(event);
				}
				break;
			default:
				break;
		}
	} else if (line.contains("TIMESTAMP") ) {
		switch(m_tbp_version) {
			case TBPFILEVERSION_6:
			case TBPFILEVERSION_7:
			case TBPFILEVERSION_8:
			case TBPFILEVERSION_9:
				m_env_vals.m_timestamp = line.section('=',1,1);	
				break;
			case TBPFILEVERSION_3:
			default:
				break;
		};			
	}
}

/*
 * Description: This function process each line withing [PROCESSDATA] section
 * 
 * Format of each line in [PROCESSDATA] section in version 6:
 *       PID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,32-BIT-FLAG,CSS-FLAG,
 * 				MODULE-NAME
 * 
 * Note: this is only for TBPFILEVERSION_6 or higher.
 */
void TbsReader::tbp_processProcLine(QValueList<SYS_LV_ITEM> & list, 
						QString & line)
{
	if (m_tbp_version < TBPFILEVERSION_6) 
		return;

	int k = 0;
	unsigned int eventIndex = 0;
	SYS_LV_ITEM sys_item;
	QString buffer; 
	QString threeTwoBitFlag; 

	// Get PID
	sys_item.taskId = line.section(TBS_LINE_DELIMITER, k, k).toUInt();
	k++;

	// Get TOTALSAMPLE
	sys_item.TotalSamples = 
		line.section(TBS_LINE_DELIMITER, k, k).toULongLong(NULL, 16);
	k++;
	sys_item.PercSamples.sprintf ("%.2f", 100
			* (float) sys_item.TotalSamples
			/ m_env_vals.m_num_samples);

	// bypass the #evnetset
	k++;

	// Get each [CPU INDEX] #SAMPLE
	do {
		SampleKey key;
		unsigned long count;

		buffer = line.section(TBS_LINE_DELIMITER, k, k);
		k++;
		if (!buffer.data())
			continue;
		else if (!buffer.startsWith("["))
			break;

		sscanf(buffer.data(), "[%u %u] %lu", 
					&key.cpu, 
					&eventIndex,
					&count);
		key.event = m_env_vals.m_event_list[eventIndex];
		sys_item.CpuSamples.insert(SampleDataMap::value_type(key, count));
	} while(buffer.startsWith("["));

	// Get 32-BIT-FLAG
	threeTwoBitFlag      = buffer;

	if(threeTwoBitFlag == "1")
	{
		//sys_item.ThreeTwoBit = sys_item.TotalSamples;
		sys_item.ThreeTwoBit = QString("1");
	}
	else
	{
		//sys_item.SixFourBit  = sys_item.TotalSamples;
		sys_item.SixFourBit = QString("1");
	}

	// Get CSS-FLAG
	// Linux don't currently use it
	k++;	

	// Get MODULE-NAME
	sys_item.ModName = line.section(TBS_LINE_DELIMITER, k);
	list.append(sys_item);
}

/*
 * Description: This function process each line withing [MODDATA] section
 *
 * Format of each line in [MODDATA] section in version 3:
 *       TOTALSAMPLE,[CPU INDEX]#SAMPLE,32-BIT-SAMPLE,64-BIT-SAMPLE,MODULE-NAME
 *
 * Format of each line in [MODDATA] section in version 6:
 *       PID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,32-BIT-FLAG,MODULE-NAME
 */
void TbsReader::tbp_processModLine(QValueList<SYS_LV_ITEM> & list, 
						QString & line, SampleDataMap *pTotal)
{
	int k = 0;
	unsigned int event_OR_Index = 0;
	SYS_LV_ITEM sys_item;
	QString buffer; 
	QString threeTwoBitFlag; 

	// get PID, only for TBPFILEVERSION_6 or higher
	if (m_tbp_version >= TBPFILEVERSION_6) {
		sys_item.taskId = line.section(TBS_LINE_DELIMITER, k, k).toUInt();
		// pass the PID part.
		k++;
	}
	
	// get total samples
	sys_item.TotalSamples =
		line.section(TBS_LINE_DELIMITER, k, k).toULongLong(NULL, 16);
	k++;
	sys_item.PercSamples.sprintf ("%.2f", 
		100* (float) sys_item.TotalSamples / m_env_vals.m_num_samples);

	// pass the #evnetSet part; for version TBPFILEVERSION_6 or later;
	if (m_tbp_version >= TBPFILEVERSION_6) {
		k++;
	}

	// Get each [CPU INDEX] #SAMPLE for TBPFILEVERSION_6 or later;
	// get each [CPU EVENT] #SAMPLE for TBPFILEVERSION_3
	do {
		SampleKey key;
		unsigned long count = 0;

		buffer = line.section(TBS_LINE_DELIMITER, k, k);
		k++;
		if (!buffer.data())
			continue;
		else if (!buffer.startsWith("["))
			break;

		sscanf(buffer.data(), "[%u %u] %lu", 
					&key.cpu, &event_OR_Index, &count);

		switch(m_tbp_version) {
			case TBPFILEVERSION_6:
			case TBPFILEVERSION_7:
			case TBPFILEVERSION_8:
			case TBPFILEVERSION_9:
				// This is index, convert it to event;
				key.event = m_env_vals.m_event_list[event_OR_Index];
				sys_item.CpuSamples.insert(SampleDataMap::value_type(key, count));
				break;

			case TBPFILEVERSION_3:
				// this is event;
				key.event = event_OR_Index;
				sys_item.CpuSamples.insert(SampleDataMap::value_type(key, count));
				break;

			default:
				break;
		}
   	}while(buffer.startsWith("["));
	

	// get 32-bit-flag:
	// 32-BIT-SAMPLE,64-BIT-SAMPLE, verion 3;
	// 32-BIT-FLAG, for version 6 or higher;
	switch(m_tbp_version) {
		case TBPFILEVERSION_6:
		case TBPFILEVERSION_7:
		case TBPFILEVERSION_8:
		case TBPFILEVERSION_9:
			threeTwoBitFlag = buffer;
			if(threeTwoBitFlag == "1") {
				//sys_item.ThreeTwoBit = sys_item.TotalSamples;
				sys_item.ThreeTwoBit = QString("1");
			} else {
				//sys_item.SixFourBit  = sys_item.TotalSamples;
				sys_item.SixFourBit = QString("1");
			}
			break;

		case TBPFILEVERSION_3:
			sys_item.ThreeTwoBit = buffer;
			sys_item.SixFourBit = line.section(TBS_LINE_DELIMITER, k, k);
			k++;
			break;

		default:
			break;
	}

	// Get MODULE-NAME
	sys_item.ModName = line.section(TBS_LINE_DELIMITER, k);
	list.append(sys_item);
	
	if (pTotal) {
		AggregateSamples(*pTotal, sys_item.CpuSamples); 
	}
}


/*
 * Description:	This function process each line within [Each Module] section
 * 
 * Format of each line in [Each Module] section of version 9 or higher:
 *	 PID,TID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,address,
 *
 * Format of each line in [Each Module] section of version 6 or higher:
 *	 PID,TID,TOTALSAMPLE,#EVENTSET,[CPU INDEX] #SAMPLE,address,FUNCNAME,
 * 			FUNCBASEADDR,SRCFILE,JNCFILE
 *
 * Format of each line in [Each Module] section of version 3:
 *	 TOTALSAMPLE,[CPU INDEX]#SAMPLE,32-BIT-SAMPLE,64-BIT-SAMPLE,address,
 * 			FUNCNAME,FUNCBASEADDR,SRCFILE,JNCFILE
 */
bool TbsReader::tbp_processInstSampleLine(QString & line, MOD_LV_ITEM &inst_item)
{
	unsigned int eventOrIndex = 0;
	int k = 0;
	QString buffer;

	if (!line.contains(","))
		return false;

	if (m_tbp_version >= TBPFILEVERSION_6) {
		// Get PID
		inst_item.taskId = line.section(TBS_LINE_DELIMITER, k, k).toUInt();
		k++;

		// Get TID
		inst_item.threadId = line.section(TBS_LINE_DELIMITER, k, k).toUInt();
		k++;
	} else {
		inst_item.taskId = SHOW_ALL_TASKS;
		inst_item.threadId = 0;
	}

	// Get TOTALSAMPLE
	inst_item.Samples = line.section(
					TBS_LINE_DELIMITER, k, k).toULongLong(NULL, 16);
	k++;

	if (m_tbp_version >= TBPFILEVERSION_6) {
		// pass the #eventset
		k++;
	}

	// Get [CPU INDEX] #SAMPLE 
	do {
		SampleKey key;
		unsigned long count;

		buffer = line.section(TBS_LINE_DELIMITER, k, k);
		k++;

		if (!buffer.data())
			continue;
		else if (!buffer.startsWith("["))
			break;

		sscanf(buffer.data(), "[%u %u] %lu",
				&key.cpu, &eventOrIndex,&count);

		switch(m_tbp_version) {
			case TBPFILEVERSION_6:
			case TBPFILEVERSION_7:
			case TBPFILEVERSION_8:
			case TBPFILEVERSION_9:
				// This is index, convert it to event;
				key.event = m_env_vals.m_event_list[eventOrIndex];
				inst_item.CpuSamples.insert(SampleDataMap::value_type(key, count));
				break;

			case TBPFILEVERSION_3:
				// this is event;
				key.event = eventOrIndex;
				inst_item.CpuSamples.insert( SampleDataMap::value_type(key, count));
				break;

			default:
				break;
		}
	} while(buffer.startsWith("["));

	if (m_tbp_version >= TBPFILEVERSION_6) {
		// Get address
		inst_item.CsEip = buffer.toULongLong(NULL, 16) ;
		if (m_tbp_version >= TBPFILEVERSION_9)
			return true;	
	} else if (m_tbp_version == TBPFILEVERSION_3){
		// Get the 32 bit sample count
		//inst_item.ThreeTwoBit = buffer;
		
		// Get the 64 bit sample count
		//inst_item.SixFourBit = 
		line.section (TBS_LINE_DELIMITER, k, k);
		k++;
	
		// get address for Version 3	
		buffer = line.section(TBS_LINE_DELIMITER, k, k);
		k++;

		inst_item.CsEip = buffer.toULongLong(NULL, 16) ;
	}

	// Get FUNCNAME
	QString tmp = line.section (TBS_LINE_DELIMITER, k, -1);

	// Check if it contains "("
	if ( tmp.find("(") != -1)
	{
		// Trying to parse the function name with format
		// ClassName::FuncName(param1,param2,...,param n)...,0x
		tmp = tmp.section (",0x", 0,0);
		inst_item.FuncName = tmp;

		// Count number of "," in tmp so that we can update k
		// accordingly.
		int c = 0;
		int i = 0;
		while ((i = tmp.find(',',i)) != -1)
		{
			i++;
			c++;
		}
		k += c; 	
	}else{
		inst_item.FuncName = tmp.section(TBS_LINE_DELIMITER,0,0);
	}	
	k++;

	// Get FUNCBASEADDR
	inst_item.funcStartAddr = line.section (
					TBS_LINE_DELIMITER, k, k).toULongLong(NULL, 16);
	k++;

	// Get Java SRCFILE;
	inst_item.JavaSrcFile = line.section(TBS_LINE_DELIMITER, k, k);
	k++;

	// Get JNC file path
	if (m_tbp_version >= TBPFILEVERSION_8) {
		QString tmpStr = line.section (TBS_LINE_DELIMITER, k, k);
		inst_item.JncFilePath = m_tbp_dir + "/" + tmpStr;
	} else {
		inst_item.JncFilePath = line.section (TBS_LINE_DELIMITER, k, k);
	}
	k++;

	return true;
}// bool TbsReader::tbp_processInstSampleLine


unsigned int TbsReader::GetFileOffset(QString str)
{
	unsigned int fileOffset = 0;

	FileOffsetMap::iterator it = m_offsetMap.find(str);
	if (it != m_offsetMap.end())
		fileOffset = it->second;

	return fileOffset;
}

void TbsReader::markOffset(QString mark)
{
	if (m_file->atEnd())
		return;

	unsigned int offset = m_file->at();

	if (m_largestOffset < offset)
		m_largestOffset = offset;

	if (!mark.isEmpty()) {
		m_offsetMap.insert(FileOffsetMap::value_type(mark, offset));
	}

	return;
}

bool TbsReader::GetOffset(QString mark, unsigned int *pOffset)
{
	// internal call. I don't change pOffset;
	bool bRet = true;

	FileOffsetMap::iterator it = m_offsetMap.find(mark);
	if (it != m_offsetMap.end()) {
		bRet = true;
		*pOffset = it->second;	
	}else {
		bRet = false;
		*pOffset = m_largestOffset;
	}

	return bRet;
}

bool TbsReader::readProcInfo(QValueList<SYS_LV_ITEM> & list)
{
	bool bRet = true;

    if(m_tbp_version == TBPFILEVERSION_3)
		return true;

	if (!m_file)
		return false;

	QString line;
	unsigned int offset = 0;
	bool bProcSig = GetOffset("[PROCESSDATA]", &offset);

	if (!bProcSig) {
		/// Locate the PROCESSDATA section 
		do {
			line = m_stream->readLine();
		} while (!line.contains("[PROCESSDATA]") && !m_stream->eof());
		
		if (m_stream->eof()) {
			bRet = false;
			goto out;
		}

		markOffset("[PROCESSDATA]");
	}else {
		m_file->at(offset);
	}

	/// Parse all the line in between [PROCESSDATA]
	while (1) {
		line = m_stream->readLine();
		
		// end of file, stop
		if(m_stream->eof()) {
			bRet = false;
			break;
		}

		// find [END], end of section, update latest offset; STOP;
		if (line.contains("[END]")) {
			markOffset("");
			break;
		}

		tbp_processProcLine(list, line);
	}

out:
	return bRet;

}

bool TbsReader::readModInfo(QValueList<SYS_LV_ITEM> & list,
				SampleDataMap *pTotal)
{
	bool bRet = true;
	if (!m_file)
		return false;

	QString line, endSection;
	
	switch(m_tbp_version) {
		case TBPFILEVERSION_3:
			endSection = "[/MODDATA]";
			break;
		default:
			endSection = "[END]";
			break;
	}

	unsigned int offset = 0;
	bool bModDataSig = GetOffset("[MODDATA]", &offset);

	if (!bModDataSig) {
		/// Locate the PROCESSDATA section 
		do {
			line = m_stream->readLine();
		} while (!line.contains("[MODDATA]") && !m_stream->eof());
		
		if (m_stream->eof()) {
			bRet = false;
			goto out;
		}
		markOffset("[MODDATA]");
	}else {
		m_file->at(offset);
	}

	/// Parse all the line in between [MODDATA]
	while (1) {
		line = m_stream->readLine();

		// end of file stop
		if (m_stream->eof()) {
			bRet = false;
			break;
		}

		if (line.contains(endSection)) {
			markOffset("");
			break;
		}

		tbp_processModLine(list, line, pTotal);
	}

out:
	return bRet;

}

bool TbsReader::readAggregatedModInfo(QValueList<SYS_LV_ITEM> & list,
				SampleDataMap *pTotal)
{
	QValueList<SYS_LV_ITEM> tmpList;
	map<QString,SYS_LV_ITEM> modMap;
	map<QString,SYS_LV_ITEM>::iterator it_mod; 

	bool ret = readModInfo(tmpList, pTotal);

	if (ret) {
		// Here we go though the tempList and
		// create a map to aggregate the data.
		QValueList<SYS_LV_ITEM>::iterator it  = tmpList.begin();
		QValueList<SYS_LV_ITEM>::iterator end = tmpList.end();
		for(; it != end; it++)
		{
			it_mod = modMap.find((*it).ModName);
			if (it_mod == modMap.end()) {
				SYS_LV_ITEM sys_item;
				sys_item.ModName = (*it).ModName;
				sys_item.TotalSamples = (*it).TotalSamples;
				sys_item.ThreeTwoBit = (*it).ThreeTwoBit;
				sys_item.SixFourBit= (*it).SixFourBit;
				AggregateSamples(sys_item.CpuSamples, (*it).CpuSamples);
				modMap[(*it).ModName] = sys_item;
			} else {
				unsigned int total = (*it).TotalSamples;
				if (!total)
					continue;

				total += AggregateSamples(it_mod->second.CpuSamples, 
								(*it).CpuSamples);

				(*it).TotalSamples = total;

			}

		} // end for 

		it_mod  = modMap.begin();	
		map<QString,SYS_LV_ITEM>::iterator end_mod = modMap.end();	
		for(;it_mod != end_mod; it_mod++)
		{
			list.append(it_mod->second);	
		}
	}

	return ret;
}

bool TbsReader::readInstSampleInfo(QString       & name, 
				TaskSampleMap    * pTaskSampMap, 
				JitBlockPtrVec   * pJitBlkPtrVec,
				ProfileAttribute * pAtt, 
				TFunctor         * dis_callback)
{
	if (!m_file || !pTaskSampMap )
		return false;

	bool ret = true;
	
	TaskSampleMap::iterator taskIt;
	SampleMap allTaskSampMap;
	JIT_BLOCK_INFO_PTR pJitBlkInfo = NULL;

	QString line;
	QString modSectName = "[" + name + "]";
	
	unsigned int offset = 0;
	bool bModDataSig = GetOffset(modSectName, &offset);

	if (!bModDataSig) {
		/// [ModuelName] section
		while(1) {
			line = m_stream->readLine();

			if (m_stream->eof()) {
				return false;
			}
		
			//callback to update the progress bar;
			if (dis_callback) {
				ret = (*dis_callback)(NULL);
				if (!ret)
					return false;
			}	

			if (line.startsWith("[")) {
				// this is either [ModuleName] or [END] line

				if (line.contains(modSectName)) {
					// if the line is the module that we are looking for
					markOffset(modSectName);
					break;
				}

				if (line.contains("[END]")) {
					markOffset("");
				} else {
					markOffset(line);
				}
			}	// end of if (line.startsWith("["))

		}; // end of while loop;
	}else {
		m_file->at(offset);
	}
	
	if (!readModAttributes (pAtt)) {
		return false;
	}

	//callback to update the progress bar;
	if (dis_callback) {
		string msg = string("Reading Module Detail for section") +  modSectName.ascii();
		ret = (*dis_callback)(msg.c_str());
		if (!ret)
			return false;
	}	

	// Reading through the section
	while (1) 
	{
		line = m_stream->readLine();

		// Look for the end of this module info section
		if (line.contains("[END]"))
			break;
		
		if (m_stream->eof()) {
			return false;
		}
		
		//callback to update the progress bar;
		if (dis_callback) {
			ret = (*dis_callback)(NULL);
			if (!ret)
				return false;
		}	

		/*
		 * Handling Java samples 
		 */
		if (pAtt->modType == JAVAMODULE){
			if (!pJitBlkPtrVec)
				continue;

			if ( m_tbp_version >= TBPFILEVERSION_9) {
				/*
				 * In version 9, we process jit block
				 */
				if (line.startsWith("[JIT_BEGIN]")
				&& processJitBlock(&pJitBlkInfo)) {
					pJitBlkPtrVec->push_back(pJitBlkInfo);
				}
			} else {
				/*
				 * Before version 9, we process each line
				 */
				MOD_LV_ITEM inst_item;
				if (!tbp_processInstSampleLine(line, inst_item)) {
					continue;
				}

				/*
				 * If this is new jnc file, start new one.
				 */
				if (!pJitBlkInfo
				||  pJitBlkInfo->jit_load_addr != inst_item.funcStartAddr) {
					pJitBlkInfo = new JIT_BLOCK_INFO();
					if (!pJitBlkInfo)
						return false;
					
					pJitBlkInfo->jit_load_addr = inst_item.funcStartAddr;
					pJitBlkInfo->jit_fun_name  = inst_item.FuncName;
					pJitBlkInfo->jnc_file_path = inst_item.JncFilePath; 
					pJitBlkInfo->javaSrcFile   = inst_item.JavaSrcFile; 
/*
					fprintf(stderr,"DEBUG: addr %lx, name %s, jnc %s, src %s\n",
							pJitBlkInfo->jit_load_addr,
							pJitBlkInfo->jit_fun_name.ascii(),
							pJitBlkInfo->jnc_file_path.ascii(),
							pJitBlkInfo->javaSrcFile.ascii());
*/
						
					pJitBlkPtrVec->push_back(pJitBlkInfo);
				}

				// Add samples
				pJitBlkInfo->javaSampleMap.insert(SampleMap::value_type
							(inst_item.CsEip, inst_item.CpuSamples));

				// Update end addr
				pJitBlkInfo->jit_possible_end = inst_item.CsEip;
			}
			
			continue; 
		} 

		/*
		 * Handling native samples
		 */
		else {
			// Process line
			MOD_LV_ITEM inst_item;
			if (!tbp_processInstSampleLine(line, inst_item)) {
				continue;
			}

			// add into map;
			taskIt = pTaskSampMap->find(inst_item.taskId);
			if (taskIt == pTaskSampMap->end()) {
				SampleMap sampMap;
				sampMap.insert(SampleMap::value_type(
							inst_item.CsEip, inst_item.CpuSamples));
				pTaskSampMap->insert(TaskSampleMap::value_type(
								inst_item.taskId, sampMap));
			} else {

				// task exists, directly add item since EIP is unique;
				taskIt->second.insert(SampleMap::value_type(
								inst_item.CsEip, inst_item.CpuSamples));
			}		
	
			if (m_tbp_version >= TBPFILEVERSION_6) {
				// aggregate for SHOW_ALL_TASKS;
				SampleMap::iterator a_it = allTaskSampMap.find(inst_item.CsEip)	;
				if(a_it == allTaskSampMap.end())
				{
					allTaskSampMap.insert(SampleMap::value_type(
							inst_item.CsEip,inst_item.CpuSamples));
				}else{
					AggregateSamples(a_it->second, inst_item.CpuSamples);
				}
			}
			AggregateSamples(pAtt->modTotal, inst_item.CpuSamples);
		}

	}; // end of while loop

	if (m_tbp_version >= TBPFILEVERSION_6) {
		pTaskSampMap->insert(TaskSampleMap::value_type( SHOW_ALL_TASKS, allTaskSampMap));	
	}

	return ret;
}


bool TbsReader::readJitAttribute( QString & jitSym,
				QString & jitSrc,
				unsigned long & jitBase,
				unsigned int & jitSize,
				unsigned int & lineCount)
{
	bool bRet = false;

	if (!m_file)
		return bRet;

	QString line;
	
	//"JITSRC="
	line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
	jitSym = line.section ("=", 1);

	//"JITSRC="
	line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
	jitSrc = line.section ("=", 1);

	// "JITBASE="
	line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
	jitBase = line.section ("=", 1).toULongLong (NULL, 16);

	// "JITSIZE="
	line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
	jitSize = line.section ("=", 1).toUInt ();

	//"LINECOUNT="
    	line = m_stream->readLine();
	if (m_stream->eof()) 
		goto out;
	lineCount = line.section ("=", 1).toUInt ();
	
 	bRet = true;

out:	
    return bRet;
}


bool TbsReader::processJitBlock(JIT_BLOCK_INFO ** pJitBlkInfo) 
{
	bool ret = false;
	unsigned int jitSize = 0;
	unsigned int lineCount = 0;

	*pJitBlkInfo = new JIT_BLOCK_INFO();
	if (!(*pJitBlkInfo))
		return ret;

	if (!readJitAttribute(  (*pJitBlkInfo)->jit_fun_name,
				(*pJitBlkInfo)->jnc_file_path,
				(*pJitBlkInfo)->jit_load_addr,
				jitSize,
				lineCount))
		return ret;

	// Read each data line of JitBlock 
	QString line;
	while(1) {
		line = m_stream->readLine();
		
		if (line.startsWith("[JIT_END]")) {
			ret = true;
			break;
		}
		
		if (m_stream->eof())
			break;
		
		MOD_LV_ITEM inst_item;
		if (!tbp_processInstSampleLine(line, inst_item)) {
			break;	
		}
	
		(*pJitBlkInfo)->javaSampleMap.insert(SampleMap::value_type
				(inst_item.CsEip, inst_item.CpuSamples));
	}
	return ret;
}
