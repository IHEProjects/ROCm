/**
 * @file libCAagent.cpp
 * Implementation of CAagent library
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#include "libCAagent.h"
#include "libCAagent_imp.h"
#include "config.h"


static CAagent_buffer * shared_buffer = NULL;


int ca_open_agent(pid_t tgid)
{
	struct stat buf;
	int status = stat(CA_JIT_DIR, &buf);   

	if (status < 0 && ENOENT == errno)
		mkdir(CA_JIT_DIR, 0777);

	if (status < 0 && ENOENT == errno)
		mkdir(CA_JAVA_DIR, 0777);

	if (NULL == shared_buffer)
		shared_buffer = new CAagent_buffer();

	if (NULL == shared_buffer)
		return -1;

	return shared_buffer->open_agent(tgid);
}


void ca_close_agent(pid_t tgid)
{
	if (NULL != shared_buffer) {
		shared_buffer->close_agent(tgid);
		delete shared_buffer;
		shared_buffer = NULL;
	}
}


int ca_add_mapping(struct ca_jit_shm_entry const * new_entry)
{
	if (NULL != shared_buffer) 
		return shared_buffer->add_mapping(new_entry);
	else 
		return -1;
}


int ca_write_native_code(char const * symbol_name, const void* code_addr, 
	unsigned int size)
{
	if (NULL != shared_buffer) 
		return shared_buffer->write_native_code(symbol_name, code_addr, size);
	else
		return -1;
}


