// implementation for CSessionNavigator class

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <qcombobox.h>
#include <qdatetime.h>
#include <qclipboard.h>

#include "stdafx.h"
#include "sessionnav.h"
#include "sysdataview.h"
#include "moddataview.h"
#include "TaskTab.h"
#include "dasmview.h"
#include "sourceview.h"
#include "atuneoptions.h"
#include "ViewCfg.h"
#include "helperAPI.h"
#include "EventMaskEncoding.h"
#include <math.h>
#include "eventsfile.h"
#include "dataagg.h"
#include "amdArrow.xpm"

#define _SESSIONNAV_ICONS_
#include "xpm.h"
#undef  _SESSIONNAV_ICONS_

CSessionNavigator::CSessionNavigator (QString sampling_file_path,
				  QWidget * parent, const char *name,
				  int wflags)
				  :  QMainWindow (parent, name, wflags)
{
	m_pViewBox = NULL;
	m_pViewCfg = NULL;
	m_tbp_file = NULL;
	m_evArray = NULL;
	m_evCount = 0;
	m_tbp_file_path = sampling_file_path;
	setDockMenuEnabled (false);
	setIcon (QPixmap (amdArrowLogo));
}


CSessionNavigator::~CSessionNavigator ()
{
	if (NULL != m_tbp_file)
	{
		delete m_tbp_file;
		m_tbp_file = NULL;
	}

	if (NULL != m_evArray) 
	{
		delete [] m_evArray;
		m_evArray = NULL;
		m_evCount = 0;
	}
	ClearSessionGlobalMap(m_tbp_file_path);
}

void clearTaskSampleMap(TaskSampleMap &tMap)
{
	TaskSampleMap::iterator tIt = tMap.begin();
	TaskSampleMap::iterator tEnd = tMap.end();
	for (; tIt != tEnd; tIt++) {
		tIt->second.clear();
	}
}


bool CSessionNavigator::display (QString caption, 
				CawFile *pProject, 
				QString eventProfile)
{
	m_pProject = pProject;
	if (m_tbp_file_path.isEmpty ())
	{
		return false;
	}
	m_tbp_file = new TbsReader();
	RETURN_FALSE_IF_NULL (m_tbp_file, this);

	if (!m_tbp_file->OpenTbsFile(m_tbp_file_path)) {
		//LEI:TODO: pop up message for cann't open tbs file;
		return false;
	}
	m_pTabWidget = new QTabWidget( this );
	RETURN_FALSE_IF_NULL ( m_pTabWidget, this);
	QObject::connect( m_pTabWidget, 
		SIGNAL(currentChanged(QWidget *)), 
		SLOT(onCurrentTabChanged(QWidget *)) );	
	setFocusProxy   ( m_pTabWidget );
	setCentralWidget( m_pTabWidget );

	// This must be called after the tbp file is actually initialized
	// in order to read the CPU family information

	unsigned long cpuFamily = 0;
	unsigned long model, stepping;
	cpuFamily = m_tbp_file->getCpuFamily();
	model = m_tbp_file->getCpuModel();

	if (cpuFamily == 0)
	{
		char VenderId[15];
		CpuId(VenderId, &cpuFamily, &model, &stepping);
	}

	m_views.readAvailableViews(cpuFamily);

	//***********************************************************
	/* 
	* TIMESTAMP SANITY CHECK
	* Description: Here we check if the profile time in TBP 
	* is older than the modules creation time.
	*/
	/*
	// Get TBP Timestamp
	QDateTime tbp_dt = QDateTime::fromString(m_tbp_file->getTimestamp());
	QString oldModuleName = "";

	// Check modules
	QValueList<SYS_LV_ITEM> mod_list;
	m_tbp_file->readModInfo(mod_list);

	QValueList<SYS_LV_ITEM>::iterator it  = mod_list.begin();
	QValueList<SYS_LV_ITEM>::iterator end = mod_list.end();
	for(; it != end; it++) 
	{
	QString name = (*it).ModName;

	// Check timestamp
	QFileInfo f_info = QFileInfo(name);
	if(f_info.created() > tbp_dt)
	{
	oldModuleName += (name + "\n");
	}
	}

	// Give warning message if module is newer than profiling time
	if(oldModuleName.length() != 0)
	{
	QString msg = "Module:\n\n" + oldModuleName
	+ "\nhas creation later than the profiling time.\n"
	+ "Symbol information might be inaccurate.\n"
	+ "Please re-run the profile.\n\n" 
	+ "Do you want to continue?\n"; 

	if( QMessageBox::warning(this,"CodeAnalyst Warning",msg, QMessageBox::Yes, QMessageBox::No)
	!= QMessageBox::Yes)
	{
	return FALSE;
	}
	}
	*/
	//*********************************************************
	/*
	* Add View Toolbar
	*/
	m_pViewBar = new QToolBar( this, "View Tool Bar" );
	RETURN_FALSE_IF_NULL (m_pViewBar, this);
	addToolBar( m_pViewBar, "View Tool Bar", Top, FALSE );

	//*********************************************************
	/*
	* Add View Combo Box 
	*/
	m_pViewBox = new QComboBox (m_pViewBar);
	RETURN_FALSE_IF_NULL (m_pViewBox, this);

	connect (m_pViewBox, SIGNAL (activated (const QString &)), 
		SLOT (onViewChanged (const QString &)));
	connect (m_pViewBox, SIGNAL (highlighted ( const QString &)),
		SLOT (onViewMaybeTip (const QString &)));

	//*********************************************************
	/*
	* Add View Config Button
	*/
	m_pViewCfg = new QPushButton ("Manage", m_pViewBar);
	RETURN_FALSE_IF_NULL (m_pViewCfg, this);

	connect (m_pViewCfg, SIGNAL (clicked ()), SLOT (onConfigureView ()));
	m_pViewCfg->show();

	//*********************************************************
	QValueList<unsigned long long> tempEv;

	// Get list of event from TBP files
	// Note: In TBP version 6, these events are 64-bit Event+UMask encoded.
	tempEv = m_tbp_file->getEventList ();

	// Change data structure 
	if(m_evArray == NULL)
	{
		m_evArray = new EventConfig[tempEv.size()];
		RETURN_FALSE_IF_NULL (m_evArray, this);
		m_evCount = 0;
	}

	for (UINT i = 0; i < tempEv.size(); i++)
	{
		m_evArray[i] = (tempEv[i]);
		m_evCount++;
	}
	m_views.addAllDataView (m_evArray, m_evCount, cpuFamily,model);

	calculateEventNorms (eventProfile);

	int indexDefault = 0;
	//gets the list of views applicable to the data set
	QStringList viewList = m_views.getListOfViews (m_evArray, m_evCount, &indexDefault);
	m_pViewBox->insertStringList (viewList);

	//*********************************************************

	// Modified by Suravee
	// Set default view
	//m_pViewBox->setCurrentItem (indexDefault);
	m_pViewBox->setCurrentItem (0);

	// TODO: Modify to add cpufamily information
	onViewChanged (m_pViewBox->currentText());
	QString newTip;
	if (m_views.getViewTexts (m_pViewBox->currentText(), &newTip, NULL))
		QToolTip::add (m_pViewBox, newTip);
	m_pViewBox->show();

	//*********************************************************
	/*
	* Allocate the button to close source tabs
	*/
	m_pCloseTab = new QToolButton (m_pTabWidget);
	RETURN_FALSE_IF_NULL (m_pCloseTab, this);
	m_pCloseTab->setText (" X ");
	m_pCloseTab->setMaximumHeight(23);
	m_pCloseTab->setMaximumWidth(25);
	QToolTip::add (m_pCloseTab, "Close the current tab");
	connect (m_pCloseTab, SIGNAL (clicked()), SLOT (OnCloseTab()));

	m_pTabWidget->setCornerWidget (m_pCloseTab);
	m_pCloseTab->show();
	//*********************************************************


	// Add Tabs to the Navigator for the Data and Graph Views

	/*
	* System Data View
	*/
	m_sys_dat_view = new SystemDataTab (m_tbp_file, &m_viewShown,
						this, SYS_DATA_WIDGET, 
						WDestructiveClose);
	RETURN_FALSE_IF_NULL (m_sys_dat_view, this);
	addTabToNavigatorBar (m_sys_dat_view, SYS_DATA_STRING);

	connect (this, SIGNAL (shownDataChange(ViewShownData*)), 
		m_sys_dat_view, SLOT (onViewChanged(ViewShownData*)));

	connect (m_sys_dat_view, SIGNAL (shownDataChange(ViewShownData*)), 
		this , SLOT (onShownColumnToggled(ViewShownData*)));

	connect (m_sys_dat_view,
		SIGNAL (moduleDblClicked (QString, TAB_TYPE, unsigned int)),
		SLOT (onModuleDblClicked (QString, TAB_TYPE, unsigned int)));

	connect (m_sys_dat_view,
		SIGNAL (moduleRightClicked (QString, TAB_TYPE,unsigned int)),
		SLOT (onModuleDblClicked (QString, TAB_TYPE, unsigned int)));

	connect (m_sys_dat_view, 
		SIGNAL (viewGraph ()),
		SLOT (onViewSystemGraph ()));

	connect (m_sys_dat_view, 
		SIGNAL (viewTasks ()),
		SLOT (onViewSystemTask ()));

	/*
	* Graph View Tab 
	*/
	m_sys_graph_view = new SysGraphView (&m_viewShown, this, 
					"SysGraph", WDestructiveClose);
	RETURN_FALSE_IF_NULL (m_sys_graph_view, this);

	connect (this, SIGNAL (shownDataChange(ViewShownData*)), m_sys_graph_view, 
		SLOT (onViewChanged(ViewShownData*)));
	connect (m_sys_graph_view, SIGNAL (shownDataChange(ViewShownData*)), 
		this , SLOT (onShownColumnToggled(ViewShownData*)));

	if (!m_sys_graph_view->init (m_tbp_file))
		return false;

	addTabToNavigatorBar (m_sys_graph_view, SYS_GRAPH_STRING);
	QObject::connect (m_sys_graph_view,
		SIGNAL (moduleDblClicked (QString, TAB_TYPE, unsigned int)),
		SLOT (onModuleDblClicked (QString, TAB_TYPE, unsigned int)));
	
	QObject::connect (m_sys_graph_view,
		SIGNAL (viewSysData()),
		SLOT (onViewSystemData()));

	/*
	* Task Data Tab
	*/
	TaskTab *pTempTask = new TaskTab (m_tbp_file, &m_viewShown, this,
		"TaskView", WDestructiveClose);
	m_pTaskTab = pTempTask;
	if (NULL == pTempTask)
	{
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		delete m_sys_dat_view ;
		m_sys_dat_view = NULL;
		delete m_sys_graph_view;
		m_sys_graph_view = NULL;
		return FALSE;
	}
	connect (this, SIGNAL (shownDataChange(ViewShownData*)), m_pTaskTab, 
		SLOT (onViewChanged(ViewShownData*)));
	connect (m_pTaskTab, SIGNAL (shownDataChange(ViewShownData*)), 
		this , SLOT (onShownColumnToggled(ViewShownData*)));

	if (pTempTask->display (caption, SHOW_ALL_TASKS))
	{
		addTabToNavigatorBar( pTempTask, SYS_TASK_STRING);
		QObject::connect( pTempTask, SIGNAL(taskDblClicked (unsigned int, QString)), 
			SLOT (onViewOneTask (unsigned int, QString)) );
		QObject::connect (pTempTask, SIGNAL(viewGraph()),
			SLOT(onViewSystemGraph()) );
		QObject::connect(pTempTask, SIGNAL (viewSysData()),
			SLOT (onViewSystemData()) );
	} else {

		delete m_pTaskTab ;
		m_pTaskTab  = NULL;
	}

	m_pTabWidget->setCurrentPage(0);

	bool ret = m_sys_dat_view->display (caption);

	return ret;
} // CSessionNavigator::display


QWidget * CSessionNavigator::findTab (QString caption, QString filePath)
{
	for (int i= 0; i < m_pTabWidget->count(); i++)
	{
		QWidget * pWidget = m_pTabWidget->page (i);
		if (m_pTabWidget->tabToolTip (pWidget) == caption) 
		{
			if (!filePath.isEmpty()) 
			{
				if (pWidget->iconText() == filePath)
					return pWidget;
			} else
				return pWidget;
		}
	}
	return NULL;
}


static bool bModProcessing = false;

void CSessionNavigator::onModuleDblClicked (QString module_name, 
				TAB_TYPE type, unsigned int taskId)
{
	if (bModProcessing)
		return;

	bModProcessing = true;
	
	QString caption;
	TaskSampleMap *pTMap = NULL;
	JitBlockPtrVec *pJitBlkPtrVec = NULL;	

	if (TAB_DATA == type) 
	{
		caption = module_name + " - Data";
		// Add the Data Tab if not already shown
		QWidget *pOldTab = findTab (caption);
		if (NULL == pOldTab)
		{
			// Initializing Module Data Tab
			ModuleDataTab *view = 	new ModuleDataTab (module_name, 
					m_tbp_file, &m_viewShown, this,
					MOD_DATA_WIDGET, WDestructiveClose);
	
			if (!view) {
				QMessageBox::critical(this, NOMEM_HEADER, NOMEM_MSG);
				goto out;
			}

			AddModGlobalMap(m_tbp_file_path, module_name, &pTMap, &pJitBlkPtrVec);
			view->setDataMapPointer(pTMap, pJitBlkPtrVec);
			
			addTabToNavigatorBar (view, caption);

			if (!view->initialize (taskId)) 
			{
				m_pTabWidget->removePage ( view );
				if(view != NULL)
				{
				    delete view;
				    view = NULL;
				}
				QMessageBox::warning (this, "CodeAnalyst symbols problem",
					"The module tab for " + module_name
					+ " is unavailable.");
				goto out;
			}

			m_pTabWidget->showPage ( view );

			QObject::connect (view,
				SIGNAL (symDblClicked (VADDR, SampleMap*, ProfileAttribute)),
				SLOT (onSymDblClicked (VADDR, SampleMap*, ProfileAttribute)));

			QObject::connect (view,
				SIGNAL (viewGraph (QString, TAB_TYPE)),
				SLOT (onModuleDblClicked (QString, TAB_TYPE)));

			connect (this, SIGNAL (shownDataChange(ViewShownData*)), view, 
				SLOT (onViewChanged(ViewShownData*)));
			connect (view, SIGNAL (shownDataChange(ViewShownData*)),
				this , SLOT (onShownColumnToggled(ViewShownData*)));

		} else {
			m_pTabWidget->showPage ( pOldTab );
		}
	} else {
		caption = module_name + " - Graph";

		// Add the Graph Tab if not already shown
		QWidget *pOldTab = findTab (caption);
		if (NULL == pOldTab)
		{
			ModGraphView *graph = new ModGraphView (&m_viewShown, this, 
							"ModGraph", WDestructiveClose);
			if (!graph) {
				QMessageBox::critical(this, NOMEM_HEADER, NOMEM_MSG);
				goto out;
			}

			AddModGlobalMap(m_tbp_file_path, module_name, &pTMap, &pJitBlkPtrVec);

			if (!graph->init (m_tbp_file, (char *) module_name.data (), 
							pTMap, pJitBlkPtrVec, taskId))
			{
				delete graph;
				QMessageBox::warning (this, "CodeAnalyst symbols problem",
					"The module graph tab for " + module_name
					+ " is unavailable.");
				goto out;
			}

			// Add the Graph Tab
			addTabToNavigatorBar (graph, caption);
			m_pTabWidget->showPage ( graph );
			graph->setFocus();

			QObject::connect (graph,
				SIGNAL (symDblClicked (VADDR, SampleMap*, ProfileAttribute)),
				SLOT (onSymDblClicked (VADDR, SampleMap*, ProfileAttribute)));

			QObject::connect (graph,
				SIGNAL (viewModuleData (QString, TAB_TYPE)),
				SLOT (onModuleDblClicked (QString, TAB_TYPE)));

			connect (this, SIGNAL (shownDataChange(ViewShownData*)), graph, 
				SLOT (onViewChanged(ViewShownData*)));
			connect (graph, SIGNAL (shownDataChange(ViewShownData*)),
				this , SLOT (onShownColumnToggled(ViewShownData*)));

		} else {
			m_pTabWidget->showPage ( pOldTab );
			m_pTabWidget->currentPage()->setFocus();
		}
	}

out:
	bModProcessing = false;
	return;
} // CSessionNavigator::OnModuleDblClicked


bool CSessionNavigator::launchSourceView (VADDR address, SampleMap *samp_map,
					  ProfileAttribute prof_att)
{
	CATuneOptions ao;
	QString caption;
	QString qs_file;

	DWORD bypass = NO_BYPASS_SOURCE;
	ao.getBypassSource( &bypass );
	if( bypass == BYPASS_SOURCE ) {
		return false;
	}

	if (prof_att.modType == JAVAMODULE)
		return false;

	SourceDataTab *src = 
		new SourceDataTab (&m_viewShown, prof_att.modName, address, 
		m_tbp_file, samp_map, this, SRC_VIEW_WIDGET,
		WDestructiveClose);
	RETURN_FALSE_IF_NULL (src, this);

	qs_file = src->getSourceFileName ();
	if (!qs_file.isEmpty ()) {
		caption.sprintf ("%s - src - %s", prof_att.modName.data (), 
						qs_file.data ());
	} else {
		// To handle when no source file information available
		uint ask_about_src;
		ao.getAlertNoSource (&ask_about_src);
		if(ask_about_src)
		{
			QMessageBox::warning(this,"CodeAnalyst Warning",
				QString("WARNING:\n")
				+ "Module \"" + prof_att.modName  + "\" does not contain source file information.\n"
				+ "CodeAnalyst will bypass to disassembly view.\n");
		}
		delete src;
		return false;
	}
	
	bool bRet = true;
	SourceDataTab *pOldTab = (SourceDataTab*)findTab (caption);
	if (NULL != pOldTab)
	{
		sym_info *cur = pOldTab->getCurrentSymInfo();
		if(cur->sym_start > address 
		|| address >= cur->possible_end)
		{
			// Note: Since we only put assembly instructions 
			//	 into the current function, if selecting
			//	 a new function, we need to recreate the 
			//	 source view.
			delete pOldTab;
			pOldTab = NULL;
		}else{
			// Use the existing tab
			delete src;
			src = NULL;
			emit newHotspot (address, caption, samp_map);

			m_pTabWidget->showPage ( pOldTab );
			m_pTabWidget->currentPage()->setFocus();
			return bRet;
		}
	} 

	src->setCaption (caption);

	if (src->displaySource (prof_att)) 
	{

		qs_file = src->getSourceFileName ();

		QObject::connect (this, SIGNAL (newHotspot (VADDR, 
								QString, SampleMap*)),
			src, SLOT (onNewHotSpot (VADDR, QString, SampleMap*)));

		QObject::connect (src, SIGNAL(disassembledDone()),
			this, SLOT (onDisassembledDone()));

		QObject::connect (this, SIGNAL (densityVisibilityChanged()),
			src, SLOT (onDensityVisibilty()));

		connect (this, SIGNAL (shownDataChange(ViewShownData*)), src, 
			SLOT (onViewChanged(ViewShownData*)));
		connect (src, SIGNAL (shownDataChange(ViewShownData*)),
			this , SLOT (onShownColumnToggled(ViewShownData*)));

		addTabToNavigatorBar (src, caption);

	} else {
		delete src;
		src = NULL;
		bRet = false;
	}

	return bRet;
} //CSessionNavigator::launchSourceView



void CSessionNavigator::onDisassembledDone() 
{
}


//It would be better if we could just connect the  ApplicationWindow object
// to the dasm object, but that pointer wasn't passed.
void CSessionNavigator::onDensityVisibilty ()
{
	emit densityVisibilityChanged ();
}


bool CSessionNavigator::launchDasmTab ( VADDR address,
				   SampleMap *samp_map,
				   ProfileAttribute prof_att,
				   QString more_caption)
{
	QString caption = prof_att.modName;

	if (!more_caption.isEmpty())
		caption += " - " + more_caption;
	caption += " - asm";
	
	QWidget *pOld = findTab (caption);
	if (NULL == pOld)
	{
		DasmTab *dasm = new DasmTab ( address, samp_map, &m_viewShown,
			prof_att, this , "DASM",
			WDestructiveClose);

		if (!dasm->Init ()) {
			delete dasm;
			return false;
		}

		if (!dasm->Dasm ()) {
			delete dasm;
			return false;
		}

		dasm->Tag (caption);
		addTabToNavigatorBar (dasm, prof_att.modName + 
			QString (" - asm"));
		QObject::connect (this, SIGNAL(newHotspot(VADDR, QString, SampleMap *)),
			dasm, SLOT (OnNewHotspot (VADDR, QString, SampleMap*)));

		QObject::connect (this, SIGNAL (densityVisibilityChanged()),
			dasm, SLOT (OnDensityVisibilty()));
		connect (this, SIGNAL (shownDataChange(ViewShownData*)), dasm, 
			SLOT (onViewChanged(ViewShownData*)));
		connect (dasm, SIGNAL (shownDataChange(ViewShownData*)),
			this , SLOT (onShownColumnToggled(ViewShownData*)));

	} else {
		emit newHotspot (address, caption, samp_map);
		m_pTabWidget->showPage ( pOld );
		m_pTabWidget->currentPage()->setFocus();

	} 

	return true;
} //CSessionNavigator::launchDasmTab


void CSessionNavigator::onSymDblClicked (VADDR address,
					 SampleMap *samp_map,
					 ProfileAttribute prof_att)
{
	if (!samp_map)
		return;
	
	bool ret;
	// first try viewing source code
	if (!(ret = launchSourceView (address, samp_map, prof_att))) 
	{
		//  now try doing dissassembly
		launchDasmTab (address, samp_map, prof_att);
	}
}


void CSessionNavigator::addTabToNavigatorBar (QWidget * main_tab_widget,
					  QString tab_caption)
{
	// adds the view to the session navigator
	QWidget  *pOldTab = findTab (tab_caption);

	// Add the Data Tab if not already shown

	if (NULL == pOldTab)
	{
		// Add Data Tab
		QString trunc;
		if (tab_caption.length() > 50)
			trunc = QString("...") + tab_caption.right(50);	
		else
			trunc = tab_caption;
			
		m_pTabWidget->insertTab (main_tab_widget, trunc);
		m_pTabWidget->setTabToolTip (main_tab_widget, tab_caption);
		m_pTabWidget->showPage (main_tab_widget);
	} else {
		m_pTabWidget->showPage (pOldTab);
	}
}                               // CSessionNavigator::AddTabToNavigatorBar


void CSessionNavigator::onViewSystemGraph ()
{
	m_pTabWidget->showPage ( findTab (SYS_GRAPH_STRING));
}

void CSessionNavigator::onViewSystemTask ()
{
	m_pTabWidget->showPage ( findTab (SYS_TASK_STRING));
}

void CSessionNavigator::onViewSystemData()
{
	m_pTabWidget->showPage ( findTab (SYS_DATA_STRING));
}


void CSessionNavigator::onCurrentTabChanged (QWidget * widget)
{
	if (NULL == widget) 
	{
		QString temp;
		emit DataViewChanged( temp, NULL );
		return;
	}
	if (NULL == m_pCloseTab)
		return;
	DataTab *pDataTab = (DataTab *)widget;

	//Disable the close tab button if not on closable tab
	m_pCloseTab->setEnabled (pDataTab->CanUserClose());

	// Notify the Application to change menu options accordingly
	emit DataViewChanged( pDataTab->GetExportString(), 
		pDataTab->GetExportList() );
}


QWidget *CSessionNavigator::getCurrentView ()
{
	if (NULL != m_pTabWidget)
		return m_pTabWidget->currentPage ();
	else 
		return NULL;
}

//called when the close tab button (The x on the far upper right of the tab)
//	is pressed
void CSessionNavigator::OnCloseTab ()
{
	DataTab *pDataTab = (DataTab *)m_pTabWidget->currentPage();

	//Just in case it was enabled
	if (!pDataTab->CanUserClose())
		return;

	m_pTabWidget->removePage (pDataTab);

	// Suravee: removePage doesn't actually close the tab
	pDataTab->close();
}

void CSessionNavigator::OnTabMessageForStatus (const QString & message, int mS)
{
	Q_UNUSED (message);
	Q_UNUSED (mS);
}

// This slot handle signal from application.cpp for when modifying
// view configuration from global view management.
void CSessionNavigator::onGlobalShownChanged (QString viewName)
{
	unsigned long model, stepping;
	unsigned long cpuFamily = m_tbp_file->getCpuFamily();
	model = m_tbp_file->getCpuModel();
	if (cpuFamily == 0)
	{
		char VenderId[15];
		CpuId(VenderId, &cpuFamily, &model, &stepping);
	}

	// Re-read available view since it might be changed.
	m_views.updateView(viewName,cpuFamily);

	onViewChanged(m_pViewBox->currentText());
}


// Session specific view management
void CSessionNavigator::onViewChanged (const QString & view)
{
	unsigned long model, stepping;
	unsigned long cpuFamily = m_tbp_file->getCpuFamily();
	model = m_tbp_file->getCpuModel();
	if (cpuFamily == 0)
	{
		char VenderId[15];
		CpuId(VenderId, &cpuFamily, &model, &stepping);
	}
	
	if (m_views.getViewConfig (view, &m_viewShown, 
				m_tbp_file->getNumCpus(), 
				cpuFamily,model,	
				&m_normMap))
	{
		//if it hasn't been initialized yet, not needed.
		if ((NULL != m_pViewBox) && (NULL != m_pViewCfg))
		{
			m_pViewCfg->setEnabled (false);
			m_pViewBox->setEnabled (false);
			qApp->setOverrideCursor (Qt::WaitCursor);
		}

		//reload data for all tabs from file
		emit shownDataChange (&m_viewShown);

		if ((NULL != m_pViewBox) && (NULL != m_pViewCfg))
		{
			qApp->restoreOverrideCursor ();
			m_pViewBox->setEnabled (true);
			m_pViewCfg->setEnabled (true);
		}
	}
}

void CSessionNavigator::onShownColumnToggled(ViewShownData* viewShown)
{
	//reload data for all tabs from file
	emit shownDataChange (viewShown);
}


void CSessionNavigator::onViewMaybeTip (const QString & view)
{
	QToolTip::remove (m_pViewBox);
	QString newTip;

	if (m_views.getViewTexts (view, &newTip, NULL))
		QToolTip::add (m_pViewBox, newTip);
}


void CSessionNavigator::onConfigureView ()
{
	//create new ViewCfgDlg
	ViewCfgDlg *pViewCfgDlg = new ViewCfgDlg (this);
	RETURN_IF_NULL (pViewCfgDlg, this);

	//fill view data
	unsigned long model, stepping;
	unsigned long cpuFamily = m_tbp_file->getCpuFamily();
	model = m_tbp_file->getCpuModel();
	if (cpuFamily == 0)
	{
		char VenderId[15];
		CpuId(VenderId, &cpuFamily, &model, &stepping);
	}

	pViewCfgDlg->setViews (m_pViewBox->currentText(), cpuFamily, model, false, &m_views);

	if (QDialog::Accepted == pViewCfgDlg->exec())
	{
		//reload viewshown from view
		onViewChanged (m_pViewBox->currentText());
	}
}



/* 
* NOTE: (Suravee)
* Instead of using the norm from TBP file, we just calculate them from
* the session setting when viewing it.
*
* -----------------
* Formulas
* -----------------
*
*    active fraction [e]  = (number of occurences [e]) / (number of event groups [e])
*                   
*    norm factor [e]      = (sampling period [e]) / (active fraction [e])
*
*    norm samples [e]     = (norm factor [e]) * (number of samples [e])
*
*    DC access rate = norm samples          /  norm samples
*                                 DC access                ret inst
*
*/

void CSessionNavigator::calculateEventNorms (QString eventSessionName)
{
	calculateEventNormsEBP(eventSessionName);
}

//TODO: Suravee: Delete
#if 0
bool CSessionNavigator::calculateEventNormsIBS (QString eventSessionName)
{
	bool ret = false;

	if (eventSessionName.isEmpty())
		return ret;

	// Change data structure 
	if(m_evArray != NULL 
	&& m_evCount != 0)
	{
		for (UINT i = 0; i < m_evCount; i++)
		{
			m_normMap[m_evArray[i]] = 1;
		}
	}

	ret = true;
	return ret;	
}
#endif


bool CSessionNavigator::calculateEventNormsEBP (QString eventSessionName)
{
	bool ret = false;

	if (eventSessionName.isEmpty())
		return ret;

	EBP_OPTIONS opts;
	m_pProject->getSessionDetails (eventSessionName, &opts);
	
	/*
	* For each event 
	*/
	PerfEventList::iterator it     = opts.getEventContainer()->getPerfEventListBegin();
	PerfEventList::iterator it_end = opts.getEventContainer()->getPerfEventListEnd();

	for (; it != it_end ; it++) {
		EventMaskType tempEvent = EncodeEventMask((*it).select, (*it).umask);
		if (m_normMap.contains (tempEvent))
			continue;
		m_normMap[tempEvent] =  (*it).count;
	} // End for each event 

	ret = true;
	return ret;
} //CSessionNavigator::calculateEventNormsEBP


void CSessionNavigator::onViewOneTask (unsigned int taskId, QString name)
{
	QString caption = name; 

	QWidget *pOldTab = findTab (caption, name);
	if( NULL == pOldTab )
	{
		TaskTab *pTask = new TaskTab (m_tbp_file, &m_viewShown, this, 
			"TaskView", WDestructiveClose,taskId);
		RETURN_IF_NULL (pTask, this);

		// In case there are two files with different paths, 
		// but the same file name
		pTask->setIconText (name);
		if (pTask->display (caption, taskId))
		{
			addTabToNavigatorBar (pTask, caption);
			m_pTabWidget->showPage (pTask);
			QObject::connect( pTask, 
				SIGNAL(moduleClicked(QString, TAB_TYPE, unsigned int)), 
				SLOT(onModuleDblClicked(QString, TAB_TYPE, unsigned int)));

			// This is for manage dialog
			connect (this,  SIGNAL (shownDataChange(ViewShownData*)), 
				pTask, SLOT (onViewChanged(ViewShownData*)));
			connect (pTask, SIGNAL (shownDataChange(ViewShownData*)),
				this , SLOT (onShownColumnToggled(ViewShownData*)));

		} else
			delete pTask;
	} else {
		m_pTabWidget->showPage ( pOldTab );
	}
} //CSessionNavigator::onViewOneTask

void CSessionNavigator::onViewTasks ()
{
	m_pTabWidget->showPage ( m_pTaskTab );
	m_pTaskTab->setFocus();
}

//////////////////////////////////////////////////////
// DataTab Class
//////////////////////////////////////////////////////

//for each item in the list, update the text
/*
void DataTab::onShownChanged () 
{
	if (NULL == m_pList)
		return;

	//remove all columns
	clearShownColumns ();
	m_pList->setUpdatesEnabled (false);

	//update shown columns
	addShownColumns();

	QListViewItemIterator it( m_pList );
	while ( it.current() ) 
	{
		DataListItem *pDataItem = static_cast<DataListItem *>(it.current());
		pDataItem->updateShown();
		++it;
	}
	m_pList->setUpdatesEnabled (true);
}
*/


bool DataTab::clearShownColumns ()
{
	//remove all columns from the list view
	
	for (int col = m_pList->columns() - 1; col >= m_indexOffset; --col)
	{
		m_pList->removeColumn (col);
	}
	return true;
}

bool DataTab::initMenu ()
{
	if(m_pColumnMenu == NULL) 
	{
		m_pColumnMenu = new QPopupMenu (this);
		RETURN_FALSE_IF_NULL (m_pColumnMenu, this);

		//when the menu item is selected, the id of the column will be sent to 
		//	OnColumnToggled
		connect (m_pColumnMenu, SIGNAL (activated (int)), 
						SLOT (OnColumnToggled (int)));

	}

	m_pColumnMenu->setCheckable (true);

	m_pColumnIndex = new int[m_pViewShown->available.count()];
	RETURN_FALSE_IF_NULL (m_pColumnIndex, this);

	QStringList::Iterator it = m_pViewShown->available.begin();
	for (int i = 0; it != m_pViewShown->available.end(); ++it, ++i)
	{
		//save id of name in m_pColumnIndex[index]
		m_pColumnIndex[i] = m_pColumnMenu->insertItem( *it);
		//if index in m_pViewShown (ViewShownData::iterator itData)
		IndexVector::iterator itShown = m_pViewShown->shown.begin ();
		for (; itShown != m_pViewShown->shown.end(); ++itShown)
		{
			//if index is in m_pViewShown->shown
			if ((*itShown) == i)
			{
				//set the item to be checked.
				m_pColumnMenu->setItemChecked (m_pColumnIndex[i], true);
				break;
			}
		}
	}

	return addShownColumns();
} //DataTab::initMenu


//This will add columns to the list view for each column that shows data
bool DataTab::addShownColumns ()
{
	if (NULL == m_pList)
		return false;

	int column = m_indexOffset;
/*
	if (m_pViewShown->showPercentage)
	{
		m_pList->addColumn ("Total %", 60);
		m_pList->setColumnAlignment( column++ , AlignRight );
	}
*/
	IndexVector::iterator itShown = m_pViewShown->shown.begin ();

	for (; itShown != m_pViewShown->shown.end(); ++itShown, column++)
	{
		//add view columns
		m_pList->addColumn (m_pViewShown->available[*itShown], 100 );
		m_pList->setColumnAlignment( column, AlignRight );
	}

	if (NULL == m_pHeaderTip)
	{
		m_pHeaderTip = new HeaderTip (m_pList, m_pViewShown, m_indexOffset);
	}
	return true;
} //DataTab::addShownColumns


//This handles the right-click menu changing which columns are shown
void DataTab::OnColumnToggled (int id)
{
	int index = -1;
	//find index for menu id
	int i;
	for ( i = 0; i < (int) m_pViewShown->available.count(); i++)
	{
		if (m_pColumnIndex[i] == id)
		{
			index = i;
			break;
		}

	}
	//if not found,
	if (index < 0)
	{
		return;
	}

	//toggle the selected column
	bool notFound = true;
	IndexVector::iterator it = m_pViewShown->shown.begin ();
	for (; it != m_pViewShown->shown.end(); ++it)
	{
		//if index is in m_pViewShown, remove
		if ((*it) == index)
		{

			if(m_pViewShown->shown.size() == 1)
			{
				QMessageBox::critical (this, "CodeAnalyst Error","ERROR: Please select at least one event.\n");
				return;
			}


			m_pColumnMenu->setItemChecked (m_pColumnIndex[index], false);
			m_pViewShown->shown.erase (it); 
			//since it will be undefined...
			notFound = false;
			break;
		}
	}
	// if index was not in m_pViewShown, add
	if (notFound)
	{
		m_pColumnMenu->setItemChecked (m_pColumnIndex[index], true);
		m_pViewShown->shown.push_back (index);
	}

	emit shownDataChange(m_pViewShown);
} //DataTab::OnColumnToggled


void DataTab::onCopySelection()
{
	DataListItem *p_item = (DataListItem*) m_pList->firstChild ();
	QClipboard *clip = QApplication::clipboard ();

	if (NULL == clip) {
		return;
	}

	QString temp_str;

	int column_num = m_pList->columns ();
	int column_count;
	unsigned int *columns = NULL;

	columns = (unsigned int *) new unsigned int[column_num];
	if (NULL == columns) {
		QMessageBox::critical (this, NOMEM_HEADER, NOMEM_MSG);
		return;
	}
	memset (columns, 0, sizeof (unsigned int) * column_num);
	for (column_count = 0; column_count < column_num; column_count++) {
		temp_str = m_pList->columnText (column_count);
		if (columns[column_count] < temp_str.length () + 1)
			columns[column_count] = temp_str.length () + 1;
	}

	while (NULL != p_item) {
		if (p_item->isSelected ()) {
			for (column_count = 0; column_count < column_num; column_count++) {
				temp_str = p_item->text (column_count);
				if (columns[column_count] < temp_str.length () + 1)
					columns[column_count] = temp_str.length () + 1;
			}
		}

		p_item = (DataListItem*) p_item->itemBelow ();
	}

	QString text_str;
	QString header_str;
	for (column_count = 0; column_count < column_num; column_count++) {
		temp_str = m_pList->columnText (column_count);
		temp_str = temp_str.leftJustify (columns[column_count], ' ');
		header_str.append (temp_str);
		header_str.append ("\t");
	}
	header_str.append ("\n");

	p_item = (DataListItem*) m_pList->firstChild ();
	while (NULL != p_item) {
		if (p_item->isSelected ()) {
			for (column_count = 0; column_count < column_num; column_count++) {
				temp_str = p_item->text (column_count);
				temp_str = temp_str.leftJustify (columns[column_count], ' ');
				text_str.append (temp_str);
				text_str.append ("\t");
			}
			text_str.append ("\n");
		}
		
		p_item = (DataListItem*) p_item->itemBelow ();
	}
	
	if (!text_str.isEmpty ()) {
		clip->setText (header_str + text_str);
	}
	delete[]columns;

}


DataTab::DataTab( ViewShownData *pViewShown, QWidget* parent, 
			const char* name, int wflags )
			: QMainWindow (parent, name, wflags) 
{
	m_exportString = "&Export data...";
	m_pList = NULL; 
	m_userCanClose = true;
	m_pViewShown = pViewShown;
	m_pColumnMenu = NULL;
	m_pColumnIndex = NULL;
	m_pHeaderTip = NULL;
	m_indexOffset = 0;

	CATuneOptions ao;
	ao.getPrecision ( &m_precision );
};


DataTab::~DataTab ()
{
	if (NULL != m_pHeaderTip)
		delete m_pHeaderTip; 
};


void DataTab::keyPressEvent(QKeyEvent *e)
{
	Q_UNUSED(e);
}


//the tooltip has to be for the viewport of the listview, or it won't receive
// mouse events to call maybeTip
TabListTip::TabListTip (int tipColumn,  QListView * pParent) 
: QToolTip (pParent->viewport ())
{
	m_tipColumn = tipColumn;
	m_pList = pParent;
	m_pList->viewport()->setMouseTracking (true);
}


//this is called when a mousemove event happens, in the viewport of the 
//	listview
void TabListTip::maybeTip (const QPoint &pt)
{
	QPoint pt_local = m_pList->viewportToContents (pt );
	//If it is hovering over the notes column...
	if (m_tipColumn == m_pList->header()->sectionAt (pt_local.x())) 
	{
		//find the current list view item
		DataListItem *p_temp = (DataListItem *) m_pList->itemAt (pt);

		//If it's over an actual item...
		if (NULL != p_temp) 
		{
			QRect tempRect = m_pList->itemRect(p_temp);
			tempRect.setLeft (0);
			tempRect.setWidth (m_pList->width());
			//The tip shouldn't change while the cursor stays over the same item.
			tip (tempRect, p_temp->getTipString());
		}
	}
}


//this static function will calculate a number, based on the predefined 
//	complex relationship.  Currently, only +, -, *, and \ are allowed between 
//	two basic values
//the complexcomponent defines the relationship and holds the indexes into the
//	data given.
//Note that to make the values more meaningful, the raw data has been 
//	normalized to a per-group/count value
float ViewShownData::setComplex (ComplexComponents *pComplex, DataArray *pData)
{
	float calc = 0;
	float normOp1 = (*pData)[pComplex->op1Index] * pComplex->op1NormValue;
	float normOp2 = (*pData)[pComplex->op2Index] * pComplex->op2NormValue;
	switch (pComplex->complexType) 
	{
	case ColumnRatio:
		if (0 != normOp2)
		{
			calc = normOp1 / normOp2;
		}
		break;
	case ColumnSum:
		calc = normOp1 + normOp2;
		break;
	case ColumnDifference:
		calc = normOp1 - normOp2;
		break;
	case ColumnProduct:
		calc = normOp1 * normOp2;
		break;
	default:
		break;
	}
	return calc;
}


HeaderTip::HeaderTip ( QListView *pParent, ViewShownData *pViewShown,
					  int indexOffset) 
					  : QToolTip (pParent->header())
{
	m_pList = pParent;
	m_pList->header()->setMouseTracking (true);
	m_pViewShown = pViewShown;
	m_indexOffset = indexOffset;
}


void HeaderTip::maybeTip (const QPoint &pt)
{
	QHeader *pHeader = m_pList->header();
	QPoint pt_local = m_pList->viewportToContents (pt );

	int section = pHeader->sectionAt( pt_local.x() );
	section -= m_indexOffset;
	if (m_pViewShown->showPercentage)
		--section;
	if (section >= 0)
	{
		IndexVector::iterator it = m_pViewShown->shown.begin(); ;
		for (int i = 0; i < section; ++i)
			++it;
		if (m_pViewShown->showPercentage)
			++section;

		if (m_pViewShown->shown.end() != it)
			tip( pHeader->sectionRect( section + m_indexOffset ), 
			m_pViewShown->tips[(*it)]);
	}
}


