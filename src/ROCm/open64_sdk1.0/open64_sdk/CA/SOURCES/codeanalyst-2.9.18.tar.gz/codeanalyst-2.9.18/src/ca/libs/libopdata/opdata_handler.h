//$Id: opdata_handler.h $
// Interface for processing profile data.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _OPDATA_HANDLER_H_
#define _OPDATA_HANDLER_H_
#include <string>
#include <map>
#include <set>
#include <vector>

#include "stdafx.h"
#include "catranslate_display.h"
#include "catranslate_console_display.h"

using namespace std;

struct parsed_filename;
class op_bfd;

enum BitnessVal {
	evUnknown = 0,
	ev32bit,
	ev64bit 
};

// task summary info
typedef struct _TASK_TYPE {
	unsigned int taskid;
	unsigned int bitness; // 32bit or 64bit;
	unsigned long long total;
	SampleDataMap sampMap;
} TASK_TYPE;


// key (string) is the task name;
typedef map<string, TASK_TYPE> task_summary_map;


// module summary info
typedef struct _MODULE_SUMMARY_TYPE {
	string name;
	unsigned int taskid;
	unsigned int bitness;
	unsigned int modtype;	// java or normal elf
	unsigned long long total;
	SampleDataMap sampMap;
} MODULE_SUMMARY_TYPE;

typedef list<MODULE_SUMMARY_TYPE> mod_summary_list;

// module detail info
struct Detail_Key {
	int jitId;
	unsigned int taskId;
	unsigned long long rip;

	Detail_Key() {
		jitId  = -1;
		rip    = 0;
		taskId = 0;
	};

	bool operator == (const Detail_Key & right) const {
		return (   jitId  == right.jitId
			&& rip    == right.rip 
			&& taskId == right.taskId);
	};

	/* Sort by TaskId, JitId, Rip */
	bool operator < (const Detail_Key & other) const {
		if (this->taskId > other.taskId)
			return false;
		else if (this->taskId == other.taskId)
			if (this->jitId > other.jitId)
				return false;
			else if (this->jitId  == other.jitId)
				if (this->rip >= other.rip)
					return false;
				else
					return true;
			else
				return true;
		else
			return true;
	};

	const Detail_Key& operator = (const Detail_Key &right) {
		if (this != &right) {
			rip    = right.rip ;
			jitId  = right.jitId;
			taskId = right.taskId;
			return (*this);
		}
	};
};

typedef struct _jitDetail {
	unsigned long long jitAddr;
	unsigned int jitSize;
	string jitSym;
	string jncFile;

	_jitDetail() { jitAddr = 0; };

	_jitDetail( unsigned long long a, 
		unsigned int z, 
		string s, 
		string f) 
	{ 
		jitAddr = a; 
		jitSize = z;
		jitSym  = s; 
		jncFile = f; 
	};

} jitDetail;

typedef vector<jitDetail> jitDetailVec;

typedef map<Detail_Key, SampleDataMap> SampleDetail;
// key (string) is the module name;
typedef map<string, SampleDetail> MOD_DETAIL_MAP;



// key (unsigned int) is the REAL java task id;
// data (string) is the java app arguments;
typedef map<unsigned int, string> java_app_name_map;

struct mod_total {
	string modname;
	unsigned long total;
	unsigned modtype;
};
struct mod_total_compare {
	bool operator() (mod_total const &m1, mod_total const &m2) const {
		return m1.total >= m2.total;
	};
};

typedef set<mod_total, mod_total_compare> sorted_mod_set;

class opdata_handler
{
public:
	opdata_handler();

	virtual ~opdata_handler();

	virtual void init(EventMaskEncodeMap evt_map);

	void reset_data();

	bool write_ebp_output(string outputfile, 
				unsigned int ncpu,
				unsigned long cpuFamily, 
				unsigned long cpuModel);

	void set_display(ca_translate_display * display) 
	{
		if (display)
			m_ca_display = display;
	};

	void getJitDetailVec(jitDetailVec &fVec) 
	{
		fVec = m_jitDetailVec;
	};

	bool hasJoFile();

	bool copyJoFile(QString dirPath);

protected:
	void addTaskData(string taskname, unsigned int taskid,
					unsigned int bit, 
					SampleDataMap taskdata);

	SampleDetail* getDetailMap(string modname);
	
	void getSortedModset(sorted_mod_set &modset);

	unsigned int getTaskBitness(string taskname);

protected:
	unsigned int 		m_missed;
	ca_translate_display* 	m_ca_display;
	EventMaskEncodeMap 	m_event_encode_map;
	MOD_DETAIL_MAP 		m_mod_detail;
	mod_summary_list	m_mod_summary;
	task_summary_map	m_task_summary;
	jitDetailVec		m_jitDetailVec;
};

#endif //_OPDATA_HANDLER_H_
