// classic2.h : "Textbook" implementation of matrix multiply

inline void inlined_multiply_matrices(
	float matrix_a[][COLUMNS] ,    // Left matrix operand
	float matrix_b[][COLUMNS] ,    // Right matrix operand
	float matrix_r[][COLUMNS]      // Matrix result
	)
{
    // Multiply the two matrices
    for (int i = 0 ; i < ROWS ; i++) {
	for (int j = 0 ; j < COLUMNS ; j++) {
	    float sum = 0.0 ;
            for (int k = 0 ; k < COLUMNS ; k++) {
                sum = sum + matrix_a[i][k] * matrix_b[k][j] ;
            }
	    matrix_r[i][j] = sum ;
	}
    }
}

