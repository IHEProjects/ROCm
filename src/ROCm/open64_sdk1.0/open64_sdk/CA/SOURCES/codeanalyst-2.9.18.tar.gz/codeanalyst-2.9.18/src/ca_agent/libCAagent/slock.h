/**
 * @file slock.h
 * Class header of locking mechanism
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */

#ifndef SLOCK_H_
#define SLOCK_H_

#include <sys/types.h>


class shared_lock
{
public:
	shared_lock() { held_key = -1; };
	
	int get_semaphore(pid_t tgid);
	int create_semaphore(pid_t tgid);
	int lock();
	int unlock();
	void delete_lock(pid_t tgid);
private:
	unsigned int semid;
	key_t held_key;
};


#endif /*SLOCK_H_*/

