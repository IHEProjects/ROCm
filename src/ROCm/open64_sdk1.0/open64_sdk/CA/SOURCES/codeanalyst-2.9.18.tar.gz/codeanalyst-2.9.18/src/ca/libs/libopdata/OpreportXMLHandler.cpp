//$Id: OpreportXMLHandler.cpp $
// Class for handling Opreport XML output.

/*
// CodeAnalyst for Open Source
// Copyright 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "OpreportXMLHandler.h"

OpreportXMLHandler::OpreportXMLHandler()
{
	m_binary 	= NULL;
	m_countSample 	= false;
	m_getCount	= false;
}

OpreportXMLHandler::~OpreportXMLHandler()
{
	close();
}

//-------------------------------------------------------------------

void
OpreportXMLHandler::init(
		std::vector<op_event>		* eventVec,
		CLASS_MAP			* classMap,
		BINARY_LIST			* binaryList,
		std::vector<op_symboldata>	* symbolVec,
		std::vector<op_symboldetails>	* symbolDetailsVec)
{
	m_eventVec   = eventVec;
	m_classMap   = classMap;
	m_binaryList = binaryList;
	m_symbolVec  = symbolVec;
	m_symbolDetailsVec = symbolDetailsVec;
}

bool
OpreportXMLHandler::open(const char *file_path )
{
	QFile			xmlFile( file_path );
	QXmlInputSource		source( xmlFile );
	QXmlSimpleReader	reader;

	/* set our xml handler to do work on the data */
	reader.setContentHandler( this );
    
	return reader.parse( source );
}

void
OpreportXMLHandler::close()
{
	m_binary 	= NULL;
	m_eventVec 	= NULL;
	m_classMap 	= NULL;
	m_binaryList 	= NULL;
	m_symbolVec  	= NULL;
	m_symbolDetailsVec = NULL;
}

//-------------------------------------------------------------------
// XML HANDLER FUNCTIONS
bool
OpreportXMLHandler::startElement(const QString & namespaceURI, 
				const QString & localName, 
				const QString & qName, 
				const QXmlAttributes & atts )
{
	Q_UNUSED(namespaceURI);
	Q_UNUSED(localName);

	if( qName == "count" )
	{
		if(m_getCount)
		{
			m_detaildata.evclass	= string(atts.value("class").ascii());
			m_countSample = true;	
		}
	}
	else if( qName == "detaildata" )
	{
		// For each sample address
		m_getCount	= true;
		m_detaildata.id		= atts.value("id").toUInt();
		m_detaildata.vmaoffset	= atts.value("vmaoffset").toULong(0,16);
	}
	else if( qName == "symboldetails" )
	{
		m_symboldetails.id	= atts.value("id").toUInt();
	}
	else if( qName == "symboldata" )
	{
		m_symboldata.name	= string(atts.value("name").ascii());
		m_symboldata.startingaddr = atts.value("startingaddr").toULong(NULL,16);
	}
	else if( qName == "symbol" )
	{
		m_symbol.idref		= atts.value("idref").toUInt();	
		m_symbol.lo		= atts.value("detaillo").toUInt();	
		m_symbol.hi		= atts.value("detailhi").toUInt();	
		m_symbolCount++;
	}
	else if( qName == "module" )
	{
		if(m_symbolCount != 0 && m_binary)
		{
			m_binary->symbolCount 	= m_symbolCount;
		}
		m_isInBinary		= false;
		m_symbolCount		= 0;	
		m_module.name		= string(atts.value("name").ascii());
	}
	else if( qName == "binary" )
	{
		m_binary 		= new op_binary();
		m_binary->name 		= string(atts.value("name").ascii());
		m_symbolCount		= 0;
		m_isInBinary		= true;
	}
	else if( qName == "class" )
	{
		m_class.name		= string(atts.value("name").ascii());
		m_class.cpu		= atts.value("cpu").toUInt();
		unsigned int event	= atts.value("event").toUInt();
		m_class.event 		= &((*m_eventVec)[event]);
		m_class.mask		= atts.value("mask").toUInt();
	}
	else if( qName == "eventsetup" )
	{
		m_event.eventname 	= string(atts.value("eventname").ascii());
		m_event.setupcount	= atts.value("setupcount").toULong();
	}
	else if( qName == "detailtable" )
	{
	}

	return true;
}

bool
OpreportXMLHandler::endElement(	const QString & namespaceURI, 
				const QString & localName, 
				const QString & qName )
{
	Q_UNUSED(namespaceURI);
	Q_UNUSED(localName);

	if( qName == "count" )
	{
		if(m_getCount)
		{
			m_countSample = false;	
		}
	}
	else if( qName == "detaildata" )
	{
		m_getCount = false;
		m_symboldetails.detaildataVec.push_back(m_detaildata);
	}
	else if( qName == "symboldetails" )
	{
		m_symbolDetailsVec->push_back(m_symboldetails);	
		m_symboldetails.detaildataVec.clear();
	}
	else if( qName == "symboldata" )
	{
		m_symbolVec->push_back(m_symboldata);
	}
	else if( qName == "symbol" )
	{
		if(m_isInBinary)
		{
			m_binary->symbolList.push_back(m_symbol);
		}else{
			m_module.symbolList.push_back(m_symbol);
		}
	}
	else if( qName == "module" )
	{
		m_module.symbolCount = m_symbolCount;
		m_symbolCount = 0;

		if(m_binary)
		{
			m_binary->modList.push_back(m_module);
			m_module.symbolList.clear();
		}
	}
	else if( qName == "binary" )
	{
		if(m_binary)
		{
			m_binaryList->push_back(*m_binary);
			delete m_binary;
			m_binary = NULL;
		}
	}
	else if( qName == "class" )
	{
		m_classMap->insert(CLASS_MAP::value_type(m_class.name,m_class));
	}
	else if( qName == "eventsetup" )
	{
		m_eventVec->push_back(m_event);
	}
	else if( qName == "detailtable" )
	{

	}

	return true;
}

bool
OpreportXMLHandler::characters( const QString & ch )
{
	if(m_countSample)
	{
		m_detaildata.evcount = ch.simplifyWhiteSpace().toULong();
	}
	return true;
}
//-------------------------------------------------------------------
