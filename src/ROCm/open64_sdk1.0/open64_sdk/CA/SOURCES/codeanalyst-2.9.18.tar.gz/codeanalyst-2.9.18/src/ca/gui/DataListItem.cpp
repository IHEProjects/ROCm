#include <math.h>
#include "DataListItem.h"
#include "EventMaskEncoding.h"
#include "dataagg.h"

///////////////////////////////////////////////////////////////////////////////////////

DataListItem::DataListItem( ViewShownData *pViewShown, int indexOffset, 
						   QListView * pParent)
						   : QListViewItem (pParent)
{
	m_pViewShown = pViewShown;
	m_indexOffset = indexOffset;
	m_checkColumn = -1;
	m_pSampMap = NULL;
	m_pTotalData = NULL;
	m_precision = 6;
}

DataListItem::DataListItem( ViewShownData *pViewShown, int indexOffset, 
						   QListView * pParent, QListViewItem * pAfter) 
						   : QListViewItem (pParent, pAfter)
{
	m_pViewShown = pViewShown;
	m_indexOffset = indexOffset;
	m_checkColumn = -1;
	m_pSampMap = NULL;
	m_pTotalData = NULL;
	m_precision = 6;
}

DataListItem::DataListItem( ViewShownData *pViewShown, int indexOffset, 
						   QListViewItem * pItem)
						   : QListViewItem (pItem)
{
	m_pViewShown = pViewShown;
	m_indexOffset = indexOffset;
	m_checkColumn = -1;
	m_pSampMap = NULL;
	m_pTotalData = NULL;
	m_precision = 6;
}

DataListItem::DataListItem( ViewShownData *pViewShown, 
				int indexOffset,
				QListViewItem * pItem, QListViewItem * pAfter) 
: QListViewItem (pItem, pAfter)
{
	m_pViewShown = pViewShown;
	m_indexOffset = indexOffset;
	m_checkColumn = -1;
	m_pSampMap = NULL;
	m_pTotalData = NULL;
	m_precision = 6;
}

DataListItem::~DataListItem()
{
	m_pSampMap = NULL;
	m_pTotalData = NULL;
}

void DataListItem::setPrecision (int precision)
{
	m_precision = precision;
}

//This function will use the precision set in setPrecision() to write the 
// text value of the data in the samples list to the appropriate columns
void DataListItem::drawData (SampleDataMap *pSampMap, UINT64 sessionTotal, bool bAssign	)
{
	Q_UNUSED(sessionTotal);
	DataArray sampleArray;
	QValueVector<EventMaskType> evIndexArray;

	sampleArray.resize (m_pViewShown->available.size(), 0);
	evIndexArray.resize (m_pViewShown->available.size(), 0);

	if (pSampMap) {
		SampleDataMap::iterator sample = pSampMap->begin ();
		SampleDataMap::iterator sample_end = pSampMap->end ();
		for(; sample != sample_end; ++sample ) 
		{
			unsigned long long deEvent;
			unsigned char deUMask;
			DecodeEventMask(sample->first.event, &deEvent, &deUMask);
			CpuEventType key(sample->first.cpu, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			UINT index = m_pViewShown->indexes[key];
			if (index >= m_pViewShown->available.size()) {
				continue;
			}
			sampleArray[index] += sample->second;
			evIndexArray[index] = sample->first.event;
	
			//if part of complex column, re-calculate
			ComplexDependentMap::Iterator complex = 
					m_pViewShown->calculated.find (index);
	
			if (complex != m_pViewShown->calculated.end()) {
				ListOfComplex::Iterator cpxIt = (*complex).begin();
				ListOfComplex::Iterator cpxItEnd = (*complex).end();
				for (; cpxIt != cpxItEnd; ++cpxIt) {
					float calc = m_pViewShown->setComplex (&(*cpxIt),
						&(sampleArray));

					int complexIndex = (*cpxIt).columnIndex;
					sampleArray[complexIndex] = calc;
				}
			}
		}
	}
	if (bAssign)
		m_pSampMap = pSampMap;




	//For each item of data that should be shown
	int column = m_indexOffset;
	IndexVector::iterator it     = m_pViewShown->shown.begin();
	IndexVector::iterator it_end = m_pViewShown->shown.end();
	for (; it != it_end; ++it, ++column)
	{
		if (sampleArray.size() == 0)
			continue;
 
		float data = sampleArray[*it];
		if (data == 0)
			continue;

		//TODO: Get precision????
		int precision = m_precision;
		if (fmod (data, (float)1.0) == 0.0)
			precision = 0;

		//show the approriate data in the column
		if (m_pViewShown->showPercentage) {
			if(!m_pTotalData)
				continue;

			float columnTotal = 0;
			// We used CPU -1 to denote "ALL CPU"
			SampleKey key(-1,evIndexArray[*it]);
			SampleDataMap::iterator sit = m_pTotalData->find(key);
			if(sit != m_pTotalData->end()) {
				columnTotal = sit->second;
			}

			if (0 == columnTotal) {
				setText(column, "");
			}else{
				float percent = (data * 100.0) / columnTotal;
				// TODO: Currently fixed precision to 2 digits.
				//       QString round down 0.005.
				if (percent > 0.005 )
					setText(column, QString::number(percent, 'f', 2) + "%");
				else
					setText(column,"");
			}
		} else {
			// For non percentage view
			setText (column, QString::number (data, 'f', precision));
		}
	}
	sampleArray.clear();
} //DataListItem::drawData


/*
 * Mainly used by DiffAnalyst currently.
 */
void DataListItem::drawPercent (SamplePercentMap *pSampMap)
{
	//for each sample
	DataArray sampleArray;
	sampleArray.resize (m_pViewShown->available.size(), 0);

	if (pSampMap) {
		SamplePercentMap::iterator sample = pSampMap->begin ();
		SamplePercentMap::iterator sample_end = pSampMap->end ();
		for(; sample != sample_end; ++sample ) 
		{
			if(!m_pViewShown->separateCpus 
			&& sample->first.cpu != -1)
				continue;

			unsigned long long deEvent;
			unsigned char deUMask;
			DecodeEventMask(sample->first.event, &deEvent, &deUMask);

			// ViewShownData doesn't have indexes for CPU -1 (All CPU) column
			// So, we using CPU 0 instead.
			// CpuEventType key(sample->first.cpu, deEvent, deUMask); 
			CpuEventType key;
			if(!m_pViewShown->separateCpus)
				key = CpuEventType(0, deEvent, deUMask); 
			else
				key = CpuEventType(sample->first.cpu, deEvent, deUMask); 

			//if event is not show for this view, skip
			if (!m_pViewShown->indexes.contains (key))
				continue;

			//given cpu/event select from profile, find column index
			UINT index = m_pViewShown->indexes[key];
			if (index >= m_pViewShown->available.size()) {
				continue;
			}
			sampleArray[index] += sample->second;
	
			//if part of complex column, re-calculate
//			ComplexDependentMap::Iterator complex = 
//					m_pViewShown->calculated.find (index);
//	
//			if (complex != m_pViewShown->calculated.end()) {
//				ListOfComplex::Iterator cpxIt = (*complex).begin();
//				ListOfComplex::Iterator cpxItEnd = (*complex).end();
//				for (; cpxIt != cpxItEnd; ++cpxIt) {
//					float calc = m_pViewShown->setComplex (&(*cpxIt),
//						&(sampleArray));
//
//					int complexIndex = (*cpxIt).columnIndex;
//					sampleArray[complexIndex] = calc;
//				}
//			}
		}
	}

	//For each item of data that should be shown
	int column = m_indexOffset;
	IndexVector::iterator it     = m_pViewShown->shown.begin();
	IndexVector::iterator it_end = m_pViewShown->shown.end();
	for (; it != it_end; ++it, ++column)
	{
		float data = sampleArray[*it];
		if ((sampleArray.size() != 0) && (0 != data) )
		{
			int precision = m_precision;
			if (fmod (data, (float)1.0) == 0.0)
				precision = 0;
			//show the approriate data in the column
			setText (column, QString::number (data, 'f', precision) + "%");
		}
	}
	sampleArray.clear();
} //DataListItem::drawPercent



// aggregate item sample into data
void DataListItem::getItemSamples(SampleDataMap &data)
{
	if (m_pSampMap) {
		AggregateSamples(data, *m_pSampMap);
	}
}


void DataListItem::updateShown ()
{
	//For each item of data that should be shown
	int column = m_indexOffset;
	if (m_pViewShown->showPercentage)
	{
		column++;
	}

	IndexVector::iterator it     = m_pViewShown->shown.begin();
	IndexVector::iterator it_end = m_pViewShown->shown.end();
	for (; it != it_end; ++it, ++column)
	{
		if ( m_dataList.size() != 0 && 0 != m_dataList[*it] )
		{
			//show the approriate data in the column
			setText (column, m_dataList[*it]);
		}
	}
}


void DataListItem::setChecked (int column)
{
	m_checkColumn = column;
}


//We needed to customize this so we can show checks in a column
void DataListItem::paintCell (QPainter * p, const QColorGroup & cg, 
							  int column, int width, int align)
{
	//Only items that should be checked have a valid m_checkColumn
	if (m_checkColumn == column)
	{
		//Similar to qlistview.cpp, for the check in the list view item column
		QListView *lv = listView();
		if ( !lv )
			return;

		const BackgroundMode bgmode = lv->viewport()->backgroundMode();
		QColorGroup::ColorRole crole = QPalette::backgroundRoleFromMode( bgmode );
		if (isSelected ())
			crole = QColorGroup::Highlight;
		p->fillRect( 0, 0, width, height(), cg.brush( crole ) );

		QFontMetrics fm( lv->fontMetrics() );
		int boxsize = lv->style().pixelMetric( QStyle::PM_CheckListButtonSize,
			lv);
		int margin = lv->itemMargin();

		int styleflags = QStyle::Style_Default | QStyle::Style_On 
			| QStyle::Style_Enabled;
		if ( isSelected() )
			styleflags |= QStyle::Style_Selected;

		int x = ((width - boxsize) / 2) + margin;
		int y = ( ( height() - boxsize ) / 2 ) + margin;

		lv->style().drawPrimitive (QStyle::PE_CheckMark, p,
			QRect (x, y, boxsize, boxsize), cg, styleflags, 
			QStyleOption(this));
	} else {
		QColorGroup cg1(cg);
		if (m_textColor.isValid()) {
			cg1.setColor(QColorGroup::Text, m_textColor);
		}
		if (m_backColor.isValid()) {
			cg1.setColor(QColorGroup::Base, m_backColor);
		}
		QListViewItem::paintCell (p, cg1, column, width, align);
	}
} //DataListItem::paintCell


//will display text with no decimal point if unneeded
void DataListItem::appendData (float data, int precision)
{
	if (fmod (data, (float)1.0) == 0.0)
		precision = 0;

	m_dataList.append (QString::number (data, 'f', 
		precision));
}


