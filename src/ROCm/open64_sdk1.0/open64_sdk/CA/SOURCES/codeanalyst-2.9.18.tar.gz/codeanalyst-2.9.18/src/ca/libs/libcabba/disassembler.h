#ifndef _DISASSEMBLER_H_
#define _DISASSEMBLER_H_

#define MAJOR_VERSION 3
#define MINOR_VERSION 8
#define BUILD_LEVEL 5

/*******************************************************************************
Copyright (C) Advanced Micro Devices 2000

LIMITATION OF LIABILITY:  THE MATERIALS ARE PROVIDED AS IS WITHOUT ANY EXPRESS
OR IMPLIED WARRANTY OF ANY KIND INCLUDING WARRANTIES OF MERCHANTABILITY, 
NONINFRINGEMENT OF THIRD-PARTY INTELLECTUAL PROPERTY, OR FITNESS FOR ANY 
PARTICULAR PURPOSE.   IN NO EVENT SHALL AMD OR ITS SUPPLIERS BE LIABLE FOR ANY 
DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF PROFITS, 
BUSINESS INTERRUPTION, LOSS OF INFORMATION) ARISING OUT OF THE USE OF OR 
INABILITY TO USE THE MATERIALS, EVEN IF AMD HAS BEEN ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.  BECAUSE SOME JURISDICTIONS PROHIBIT THE EXCLUSION OR 
LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE
LIMITATION MAY NOT APPLY TO YOU.  AMD does not assume any responsibility for 
any errors which may appear in the Materials nor any responsibility to support 
or update the Materials.  AMD retains the right to make changes to its test 
specifications at any time, without notice.

NO SUPPORT OBLIGATION: AMD is not obligated to furnish, support, or make any 
further information, software, technical information, know-how, or show-how 
available to you."
*******************************************************************************/

/******************************************************************************/
// This is the header file for the CDisassembler class.  This class provides
// a generic x86 disassembler.  It currently supports 3dnow, MMX, SSE, SSE2,
// REX, SEM, PNI, and BNI instruction extensions.
//
// The interfaces of interest can be found in the public sections of the
// CInstructionData class and the derived CDisassembler class.
/******************************************************************************/

#if defined( WIN32 )				// Assume WINxx implies Visual C++
#pragma warning( disable: 4514 )	// "unreferenced inline function has been removed"
#pragma warning( disable: 4127 )	// "conditional expression is constant"
#pragma warning( disable: 4710 )	// "... not inlined"
#undef REG_NONE
#elif defined( _WIN64 )
#pragma warning( disable: 4514 )	// "unreferenced inline function has been removed"
#pragma warning( disable: 4127 )	// "conditional expression is constant"
#pragma warning( disable: 4710 )	// "... not inlined"
#undef REG_NONE
#endif

#undef EXPORTCLASS
#ifdef _USRDLL				// define this for projects using the disassembler via a dll
#ifdef _INDISASSEMBLERDLL	// don't define this in the project that is using the dll
	#define	EXPORTCLASS _declspec(dllexport)
#else						//     because this is used in projects using the dll
	#define EXPORTCLASS _declspec(dllimport)
#endif
#else
#define EXPORTCLASS
#endif

#include <vector>
#include <list>
#include "typedefs.h"

// ---------------------------------------------------------------------------
//  Defines
// ---------------------------------------------------------------------------

#define MAX_INSTRUCTION_BYTES 15
#define MAX_MNEMONIC_LENGTH 64
#define MAX_OPCODES 5
#define MAX_OPERANDS 4

#define NUM_CONTROL_REGISTERS 9

#define PREFIX_ES		0x26
#define PREFIX_CS		0x2e
#define PREFIX_SS		0x36
#define PREFIX_DS		0x3e
#define PREFIX_FS		0x64
#define PREFIX_GS		0x65
#define PREFIX_DATA		0x66
#define PREFIX_ADDR		0x67
#define PREFIX_LOCK		0xf0
#define PREFIX_REPNE	0xf2
#define PREFIX_REP		0xf3

// Used in the inst_flags bit vector (32 bits)
#define INST_LONGOPCODE_POS		0
#define INST_DATA16_POS			1
#define INST_ADDR16_POS			2
#define INST_DATA32_POS			3
#define INST_ADDR32_POS			4
#define INST_DATA64_POS			5
#define INST_ADDR64_POS			6
#define INST_DATAOVRD_POS		7
#define INST_ADDROVRD_POS		8
#define INST_SEGOVRD_POS		9
#define INST_REP_POS			10
#define INST_REPNE_POS			11
#define INST_LOCK_POS			12
#define INST_AMD3D_POS			13
#define INST_AMD64INVALID_POS	14
#define INST_DREX_POS			15
#define INST_NO_OC_POS			16
#define INST_OC_2_POS			17
#define INST_LOCK_OVERUSED_POS	18

#define INST_NONE			(0)
#define INST_LONGOPCODE		(1<<INST_LONGOPCODE_POS)
#define INST_DATA16			(1<<INST_DATA16_POS)
#define INST_ADDR16			(1<<INST_ADDR16_POS)
#define INST_DATA32			(1<<INST_DATA32_POS)
#define INST_ADDR32			(1<<INST_ADDR32_POS)
#define INST_DATA64			(1<<INST_DATA64_POS)
#define INST_ADDR64			(1<<INST_ADDR64_POS)
#define INST_DATAOVRD		(1<<INST_DATAOVRD_POS)
#define INST_ADDROVRD		(1<<INST_ADDROVRD_POS)
#define INST_SEGOVRD		(1<<INST_SEGOVRD_POS)   
#define INST_REP			(1<<INST_REP_POS)
#define INST_REPNE			(1<<INST_REPNE_POS)
#define INST_LOCK			(1<<INST_LOCK_POS)   
#define INST_AMD3D			(1<<INST_AMD3D_POS)
#define INST_AMD64INVALID	(1<<INST_AMD64INVALID_POS)
#define INST_DREX			(1<<INST_DREX_POS)
#define INST_NO_OC			(1<<INST_NO_OC_POS)
#define INST_OC_2			(1<<INST_OC_2_POS)
#define INST_LOCK_OVERUSED	(1<<INST_LOCK_OVERUSED_POS)   

// Used to index the size qualifier array (S_size_qualifiers)
#define SIZE_BYTE	0
#define SIZE_WORD	1
#define SIZE_DWORD	2
#define SIZE_48BIT	3
#define SIZE_QWORD	4
#define SIZE_TWORD	5
#define SIZE_DQWORD	6
#define SIZE_NONE	7

////////////////////////////////////////////////////////////////////////////////
// x86 Register definitions
////////////////////////////////////////////////////////////////////////////////

namespace n_Disassembler
{
	enum e_Registers
	{
		// this block ordered by modrm rm values (including REX extensions)
		REG_EAX		= 0,
		REG_ECX		= 1,
		REG_EDX		= 2,
		REG_EBX		= 3,
		REG_ESP		= 4,
		REG_EBP		= 5,
		REG_ESI		= 6,
		REG_EDI		= 7,
		REG_R8		= 8,
		REG_R9		= 9,
		REG_R10		= 10,
		REG_R11		= 11,
		REG_R12		= 12,
		REG_R13		= 13,
		REG_R14		= 14,
		REG_R15		= 15,
		REG_R16		= 16,
		REG_R17		= 17,
		REG_R18		= 18,
		REG_R19		= 19,
		REG_R20		= 20,
		REG_R21		= 21,
		REG_R22		= 22,
		REG_R23		= 23,
		REG_R24		= 24,
		REG_R25		= 25,
		REG_R26		= 26,
		REG_R27		= 27,
		REG_R28		= 28,
		REG_R29		= 29,
		REG_R30		= 30,
		REG_R31		= 31,

		REG_ST0		= 32,
		REG_ST1		= 33,
		REG_ST2		= 34,
		REG_ST3		= 35,
		REG_ST4		= 36,
		REG_ST5		= 37,
		REG_ST6		= 38,
		REG_ST7		= 39,
		REG_ST		= 40,

		REG_MM0		= 41,
		REG_MM1		= 42,
		REG_MM2		= 43,
		REG_MM3		= 44,
		REG_MM4		= 45,
		REG_MM5		= 46,
		REG_MM6		= 47,
		REG_MM7		= 48,

		REG_XMM0	= 49,
		REG_XMM1	= 50,
		REG_XMM2	= 51,
		REG_XMM3	= 52,
		REG_XMM4	= 53,
		REG_XMM5	= 54,
		REG_XMM6	= 55,
		REG_XMM7	= 56,
		REG_XMM8	= 57,
		REG_XMM9	= 58,
		REG_XMM10	= 59,
		REG_XMM11	= 60,
		REG_XMM12	= 61,
		REG_XMM13	= 62,
		REG_XMM14	= 63,
		REG_XMM15	= 64,
		REG_XMM16	= 65,
		REG_XMM17	= 66,
		REG_XMM18	= 67,
		REG_XMM19	= 68,
		REG_XMM20	= 69,
		REG_XMM21	= 70,
		REG_XMM22	= 71,
		REG_XMM23	= 72,
		REG_XMM24	= 73,
		REG_XMM25	= 74,
		REG_XMM26	= 75,
		REG_XMM27	= 76,
		REG_XMM28	= 77,
		REG_XMM29	= 78,
		REG_XMM30	= 79,
		REG_XMM31	= 80,

		REG_CR0		= 81,
		REG_CR1		= 82,
		REG_CR2		= 83,
		REG_CR3		= 84,
		REG_CR4		= 85,
		REG_CR5		= 86,
		REG_CR6		= 87,
		REG_CR7		= 88,
		REG_CR8		= 89,
		REG_CR9		= 90,
		REG_CR10	= 91,
		REG_CR11	= 92,
		REG_CR12	= 93,
		REG_CR13	= 94,
		REG_CR14	= 95,
		REG_CR15	= 96,

		REG_DR0		= 97,
		REG_DR1		= 98,
		REG_DR2		= 99,
		REG_DR3		= 100,
		REG_DR4		= 101,
		REG_DR5		= 102,
		REG_DR6		= 103,
		REG_DR7		= 104,
		REG_DR8		= 105,
		REG_DR9		= 106,
		REG_DR10	= 107,
		REG_DR11	= 108,
		REG_DR12	= 109,
		REG_DR13	= 110,
		REG_DR14	= 111,
		REG_DR15	= 112,

		// ordered by modrm reg values
		REG_ES		= 113,
		REG_CS		= 114,
		REG_SS		= 115,
		REG_DS		= 116,
		REG_FS		= 117,
		REG_GS		= 118,

		REG_NONE	= 119
	};

	enum e_OperandType
	{
		OPERANDTYPE_REGISTER	= 0,
		OPERANDTYPE_IMMEDIATE	= 1,
		OPERANDTYPE_PCOFFSET	= 2,
		OPERANDTYPE_MEMORY		= 3,
		OPERANDTYPE_RIPRELATIVE	= 4,
		OPERANDTYPE_CONDITION	= 5,
		OPERANDTYPE_NONE		= 6
	};

	enum e_OperandSize
	{
		OPERANDSIZE_8		= 0,
		OPERANDSIZE_16		= 1,
		OPERANDSIZE_32		= 2,
		OPERANDSIZE_48		= 3,
		OPERANDSIZE_64		= 4,
		OPERANDSIZE_80		= 5,
		OPERANDSIZE_128		= 6,
		OPERANDSIZE_NONE	= 7
	};

	enum e_OperandSpecifier
	{
		OPRND_na		= 0, 
		OPRND_1			= 1,	
		OPRND_AL		= 2,
		OPRND_AX		= 3, 
		OPRND_eAX		= 4,
		OPRND_Ap		= 5, 
		OPRND_CL		= 6,
		OPRND_Cd		= 7, 
		OPRND_Dd		= 8, 
		OPRND_DX		= 9, 
		OPRND_eDX		= 10,
		OPRND_Eb		= 11,
		OPRND_Ew		= 12, 
		OPRND_Ed		= 13,
		OPRND_Ev		= 14,
		OPRND_Ep		= 15,
		OPRND_Mt		= 16,
		OPRND_Gb		= 17, 
		OPRND_Gw		= 18, 
		OPRND_Gd		= 19,
		OPRND_Gq		= 20, 
		OPRND_Gv		= 21, 
		OPRND_Ib		= 22,
		OPRND_Iv		= 23,
		OPRND_Iw		= 24,
		OPRND_Jb		= 25,
		OPRND_Jv		= 26,
		OPRND_M			= 27,
		OPRND_Mp		= 28,
		OPRND_Mq		= 29,
		OPRND_Ms		= 30,
		OPRND_Ob		= 31,
		OPRND_Ov		= 32,
		OPRND_Pq		= 33,
		OPRND_Pd		= 34,
		OPRND_Qq		= 35,
		OPRND_Rd		= 36,
		OPRND_Sw		= 37,
		OPRND_Xb		= 38,
		OPRND_Xv		= 39,
		OPRND_Yb		= 40,
		OPRND_Yv		= 41,
		OPRND_breg		= 42,
		OPRND_vreg		= 43,
		OPRND_ST		= 44, // stack top
		OPRND_ST0		= 45,
		OPRND_ST1		= 46,
		OPRND_ST2		= 47,
		OPRND_ST3		= 48,
		OPRND_ST4		= 49,
		OPRND_ST5		= 50,
		OPRND_ST6		= 51,
		OPRND_ST7		= 52,
		OPRND_Vps		= 53, // SSE additions
		OPRND_Vq		= 54,
		OPRND_Vss		= 55,
		OPRND_Wps		= 56,
		OPRND_Wq		= 57,
		OPRND_Wss		= 58,
		OPRND_Vpd		= 59,	// SSE2 additions
		OPRND_Wpd		= 60,
		OPRND_Vsd		= 61,
		OPRND_Wsd		= 62,
		OPRND_Vdq		= 63,
		OPRND_Wdq		= 64,
		OPRND_Vd		= 65,
		OPRND_FPU_AX	= 66,
		OPRND_Mw		= 67,
		OPRND_Md		= 68,
		OPRND_Iv64		= 69,	// added to support 64 bit immediate moves (B8-BF)
		OPRND_eBXAl		= 70,	// added to support XLAT
		OPRND_Ed_q		= 71,	// added to support REX extensions to MOVD, CVTSI2SS, CVTSI2SD
		OPRND_Pd_q		= 72,	// added to support REX extensions to MOVD, CVTSI2SS, CVTSI2SD
		OPRND_Vd_q		= 73,	// added to support REX extensions to MOVD, CVTSI2SS, CVTSI2SD
		OPRND_Gd_q		= 74,	// added to support REX extensions to CVTTSI2SS, CVTSS2SI, CVTTSD2SI, CVTSD2SI, MOVNTI
		OPRND_Md_q		= 75,	// added to support REX extensions to MOVNTI
		OPRND_Ew_v		= 76,	// added to support SLDT
		OPRND_Mq_dq		= 77,	// added to support CMPXCHG QWORD and CMPXCHG DQWORD
		OPRND_Mb		= 78,

		OPRND_Bss		= 79,	// BNI additions
		OPRND_Bsd		= 80,
		OPRND_Bps		= 81,
		OPRND_Bpd		= 82,

		OPRND_BsB		= 83,
		OPRND_BsW		= 84,
		OPRND_BsD		= 85,
		OPRND_BsQ		= 86,
		OPRND_BsO		= 87,

		OPRND_VsB		= 88,
		OPRND_VsW		= 89,
		OPRND_VsD		= 90,
		OPRND_VsQ		= 91,
		OPRND_VsO		= 92,

		OPRND_WsB		= 93,
		OPRND_WsW		= 94,
		OPRND_WsD		= 95,
		OPRND_WsQ		= 96,
		OPRND_WsO		= 97,

		OPRND_BpB		= 98,
		OPRND_BpW		= 99,
		OPRND_BpD		= 100,
		OPRND_BpQ		= 101,

		OPRND_VpB		= 102,
		OPRND_VpW		= 103,
		OPRND_VpD		= 104,
		OPRND_VpQ		= 105,

		OPRND_WpB		= 106,
		OPRND_WpW		= 107,
		OPRND_WpD		= 108,
		OPRND_WpQ		= 109,

		OPRND_oc		= 110,
		OPRND_CCb		= 111
	};

	enum e_DisassemblerErrorCodes { NO_EXCEPTION, FORMAT_EXCEPTION, LENGTH_EXCEPTION, TABLE_EXCEPTION };

	enum e_AlternateDecodings
	{
		ALTERNATE_LZCNT = 0,
		ALTERNATE_POPCNT = 1,
		ALTERNATE_NONE = 2
	};

	enum e_RegisterOrigins
	{
		REGORIGIN_OPCODE = 0,
		REGORIGIN_MODRM_REG = 1,
		REGORIGIN_MODRM_RM = 2,
		REGORIGIN_DREX = 3,
		REGORIGIN_NONE = 4
	};
}

#define NORMALIZE_GPREG(reg) ((AMD_UINT8)(reg))
#define NORMALIZE_FPUREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_ST0))
#define NORMALIZE_MMXREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_MM0))
#define NORMALIZE_XMMREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_XMM0))
#define NORMALIZE_CONTROLREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_CR0))
#define NORMALIZE_DEBUGREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_DR0))
#define NORMALIZE_SEGREG(reg) ((AMD_UINT8)(reg - n_Disassembler::REG_ES))

////////////////////////////////////////////////////////////////////////////////

#undef RM
#undef MOD
#undef REG
#undef MEM

#define MOD(modrm) ((AMD_UINT8)(((modrm) >> 6) & 0x3))
#define REG(modrm) ((AMD_UINT8)(((modrm) >> 3) & 0x7))
#define RM(modrm)  ((AMD_UINT8)((modrm) & 0x7))

#define MEM(modrm) ((modrm) < 0xC0)

#define SS(sib)    MOD(sib)
#define IDX(sib)   REG(sib)
#define BASE(sib)  RM(sib)

#define OPCODE3_OPCODE(opcode) ((AMD_UINT8)((opcode) >> 3))
#define OPCODE3_OC1(opcode) ((AMD_UINT8)(((opcode) >> 2) & 1))
#define OPCODE3_OPS(opcode) ((AMD_UINT8)((opcode) & 3))
#define OPCODE3_OC1_OPS(opcode) ((AMD_UINT8)((opcode) & 7))

#define DREX_DEST(drex) ((AMD_UINT8)(((drex) >> 4)))
#define DREX_OC0(drex)  ((AMD_UINT8)(((drex) >> 3) & 1))
#define DREX_R(drex)    ((AMD_UINT8)(((drex) >> 2) & 1))
#define DREX_X(drex)    ((AMD_UINT8)(((drex) >> 1) & 1))
#define DREX_B(drex)    ((AMD_UINT8)(((drex) & 1)))

////////////////////////////////////////////////////////////////////////////////
// 64-bit support
////////////////////////////////////////////////////////////////////////////////

#define REX_OPERANDSIZE_POS				3
#define REX_MODRM_REG_POS				2
#define REX_SIBINDEX_POS				1
#define REX_MODRMRM_SIBBASE_OPREG_POS	0

#define REX_PREFIX(x) ((x >= 0x40) && (x <= 0x4f))

#define REX_OPERAND32(x)		((x & (1 << REX_OPERANDSIZE_POS)) == 0)
#define REX_OPERAND64(x)		((x & (1 << REX_OPERANDSIZE_POS)) != 0)
#define REX_MODRM_REG(x)		((x & (1 << REX_MODRM_REG_POS)) != 0)
#define REX_MODRM_RM(x)			((x & (1 << REX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define REX_OPCODE_REG(x)		((x & (1 << REX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define REX_SIB_BASE(x)			((x & (1 << REX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define REX_SIB_INDEX(x)		((x & (1 << REX_SIBINDEX_POS)) != 0)

#define SREX_OPCODE_OPERAND_POS			3
#define SREX_MODRM_REG_POS				2
#define SREX_SIBINDEX_POS				1
#define SREX_MODRMRM_SIBBASE_OPREG_POS	0

#define SREX_PREFIX(x) ((x >= 0x50) && (x <= 0x5f))

#define SREX_OPCODE_OPERAND(x)	((x & (1 << SREX_OPCODE_OPERAND_POS)) != 0)
#define SREX_MODRM_REG(x)		((x & (1 << SREX_MODRM_REG_POS)) != 0)
#define SREX_MODRM_RM(x)		((x & (1 << SREX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define SREX_OPCODE_REG(x)		((x & (1 << SREX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define SREX_SIB_BASE(x)		((x & (1 << SREX_MODRMRM_SIBBASE_OPREG_POS)) != 0)
#define SREX_SIB_INDEX(x)		((x & (1 << SREX_SIBINDEX_POS)) != 0)

////////////////////////////////////////////////////////////////////////////////
//	Classes
////////////////////////////////////////////////////////////////////////////////

// This is a small support class used by the disassembler to handle operand
// information during decode/disassembly

// used in the COperandInfo flags field and the Inst_Info operand flags fields
#define OPF_NONE			0
#define OPF_SHOWSIZE		(1<<0)
#define OPF_FARPTR			(1<<1)
#define OPF_SPECIAL64		(1<<2)
#define OPF_LOCK			(1<<3)
#define OPF_IMPLICIT		(1<<4)		// use this flag to hide an operand in the mnemonic
#define OPF_MEMORY			(1<<5)
#define OPF_REGISTER		(1<<6)
#define OPF_BYTEHIGH		(1<<7)		// OPF_ defines from here down (i.e. >= 7) apply only to COperandInfo.flags
#define OPF_STRING			(1<<8)

// a few terse defines to shorten flag manipulations
#define OPF_SS		OPF_SHOWSIZE
#define OPF_64		OPF_SPECIAL64
#define OPF_SS_64	(OPF_SHOWSIZE | OPF_SPECIAL64)
#define OPF_SS_LOCK	(OPF_SHOWSIZE | OPF_LOCK)
#define OPF_REG		OPF_REGISTER
#define OPF_I		OPF_IMPLICIT

#define EXPLICIT_OPERAND(x) (((x).flags & OPF_IMPLICIT) == 0)

class EXPORTCLASS COperandInfo
{
public:
	AMD_UINT8 reg;		// only valid if type == OPERANDTYPE_REGISTER, or if type == OPERANDTYPE_MEMORY and ((flags & OPF_STRING) != 0), or if type == OPERANDTYPE_CONDITION
	AMD_UINT32 flags;	// see OPF_ defines above for values
	n_Disassembler::e_OperandType type;
	n_Disassembler::e_OperandSize size;
	n_Disassembler::e_Registers regBlock;		// offset into the e_Registers enumeration
	n_Disassembler::e_RegisterOrigins regOrigin;

	COperandInfo(){};
	inline void Initialize( AMD_UINT32 _flags )
	{
		flags = _flags;
		reg = 0; 
		type = n_Disassembler::OPERANDTYPE_NONE; 
		size = n_Disassembler::OPERANDSIZE_NONE; 
		regBlock = n_Disassembler::REG_NONE;
		regOrigin = n_Disassembler::REGORIGIN_NONE;
	}
	inline n_Disassembler::e_Registers GetRegister() { return( (n_Disassembler::e_Registers)(regBlock + reg) ); }
	inline n_Disassembler::e_OperandSize GetSize() { return( size ); }
	inline n_Disassembler::e_OperandType GetType() { return( type ); }
	inline n_Disassembler::e_Registers GetRegisterBlock() { return regBlock; }
	inline n_Disassembler::e_RegisterOrigins GetRegisterOrigin() { return regOrigin; }
	inline bool IsHighByte() { return( (flags & OPF_BYTEHIGH) != 0 ); }
	inline bool IsString() { return( (flags & OPF_STRING) != 0 ); }
};

// CDisassembler derived classes wishing to extend CDisassembler's opcode
// tables should create arrays of objects derived from CExtraInstInfo and hook
// to CDisassembler's opcode table extension mechanism (i.e. GetExtraInfoPtr()).
// This requires initializing CDisassembler's opcode table entry "pExtraInfo" to
// point to the CDisassembler derived classes' arrays of CExtraInstInfo derived
// objects in the CDisassembler derived classes' constructor.
class CExtraInstInfo
{
public:
	virtual void Print() = 0;
	virtual ~CExtraInstInfo() {}
};

class EXPORTCLASS CDisassembler;

typedef void (CDisassembler::*PVOIDMEMBERFUNC)();

// This is the data type in the instruction opcode tables
class Inst_Info
{
public:
	const void *mnem;					// either the mnemonic (char *) or a nested table ptr (Inst_Info *)

	// ptr to optional routine to access nested table
	// Some of the nested table access routines move bytes from the prefix
	// byte list to the opcode byte list to support overused prefix bytes
	// on a special case basis (categorized by nested table access routines).
	Inst_Info *(*GetInfoPtr)(CDisassembler *pThis);		

	AMD_UINT32 instruction_flags;
	CExtraInstInfo *pExtraInfo;				// hook for derived classes to provide additional instruction info
	AMD_UINT16 operands[MAX_OPERANDS];
	AMD_UINT16 operand_flags[MAX_OPERANDS];

	// This routine will report the number of entries in the Inst_Info table
	// pointed to by mnem when GetInfoPtr != NULL (i.e.  when there is
	// a nested table), zero when GetInfoPtr == NULL (i.e. when there is not a
	// nested table).  This can help to navigate nested tables.  Note that
	// when GetInfoPtr == NULL, mnem will not point to a nested table.
	int SizeofNestedTable();
};

// This is a small support class used by the disassembler to handle
// instruction prefix bytes.
class EXPORTCLASS CInstructionBytes
{
	AMD_UINT32 m_count;
	AMD_UINT8 m_bytes[MAX_INSTRUCTION_BYTES];

public:
	CInstructionBytes() { ClearBytes(); };
	inline void ClearBytes( void ) { m_count = 0; }
	inline bool AddByte( AMD_UINT8 byte )
	{
		if( m_count < MAX_INSTRUCTION_BYTES ) {	m_bytes[m_count++] = byte; return true;	}
		else return false;
	}
	inline bool GetLastByte( AMD_UINT8 *byte )
	{
		if( m_count > 0 ) { *byte = m_bytes[m_count - 1]; return true; }
		else return false;
	}
	inline bool GetNextToLastByte( AMD_UINT8 *byte )
	{
		if( m_count > 1 ) { *byte = m_bytes[m_count - 2]; return true; }
		else return false;
	}
	inline bool GetByte( AMD_UINT32 index, AMD_UINT8 *byte )
	{
		if( index < m_count ) { *byte = m_bytes[index]; return true; }
		else return false;
	}
	inline bool RemoveIndex( AMD_UINT32 index )
	{
		if( index < m_count )
		{
			for( AMD_UINT32 i = (index + 1); i < m_count; i++, index++ ) m_bytes[index] = m_bytes[i];
			m_count--;
			return true;
		}
		else return false;
	}
	inline bool RemoveByte( AMD_UINT8 byte )
	{
		for( int i = (m_count - 1); i >= 0; i-- )
			if( m_bytes[i] == byte )
			{
				for( int j = (i + 1); j < (int)m_count; j++, i++ ) m_bytes[i] = m_bytes[j];
				m_count--;
				return true;
			}
		return false;
	}
	inline int FindByte( AMD_UINT8 byte )
	{
		for( int i = (m_count - 1); i >= 0; i-- ) if( m_bytes[i] == byte ) return i;
		return -1;
	}
	inline bool IsLastByte( AMD_UINT8 byte ) { return( (m_count > 0) && (m_bytes[m_count-1] == byte) ); }
	inline void RemoveLastByte( void ) { if( m_count > 0 ) m_count--; }
	inline AMD_UINT32 GetCount() { return m_count; };
};

// Here it is!!!  The start of the useful public classes.  
// CInstructionData is the parent class for CDisassembler and contains most of the
// instruction specific stuff.  CInstructionData contains most of the mechanisms 
// for getting at the instruction pieces. CDisassembler contains most
// of the mechanisms for initializing CInstructionData from instruction bytes.
class EXPORTCLASS CInstructionData
{
protected:
	AMD_UINT8 *m_inst_buf;
	int m_len;
	AMD_UINT8 m_seg_reg;
	AMD_UINT8 m_modrm;
	AMD_UINT8 m_modrm_mod;
	AMD_UINT8 m_modrm_reg;
	AMD_UINT8 m_modrm_rm;
	AMD_UINT8 m_sib;
	AMD_UINT8 m_drex;
	AMD_UINT8 m_base;			// in longmode, this includes rex extensions (i.e. 4 bits instead of 3)
	AMD_UINT8 m_index;			// in longmode, this includes rex extensions (i.e. 4 bits instead of 3)
	AMD_UINT8 m_rex_prefix;
	AMD_UINT32 m_numOperands;
	AMD_UINT32 m_inst_flags;
	AMD_UINT64 m_immd;
	AMD_INT64 m_disp;			// m_disp doubles as relative offset because it is signed
	AMD_UINT64 m_rip;			// for rip-relative calculations
	bool m_bCalculateRipRelative;		// set this to generate rip-relative instead of $+ semantics
	bool m_dbit;
	bool m_longmode;
	bool m_rex32mode;
	bool m_svmmode;
	bool m_bHasIndex;
	bool m_bHasBase;
	bool m_bModrmDecoded;
	char *m_mnem;					// you can point this at your buffer instead of the builtin
	char m_mnem_buffer[MAX_MNEMONIC_LENGTH];
	CInstructionBytes m_prefix_bytes;
	COperandInfo m_operands[MAX_OPERANDS];
	int m_operand_indices[MAX_OPERANDS];		// internal support for bni operand reordering

	int m_numOpcodes;
	int m_opcodeOffsets[MAX_OPCODES];

	int m_modrmOffset;
	int m_sibOffset;
	int m_drexOffset;
	int m_displacementOffset;
	int m_immediateOffset;

	int m_displacementLength;	// length in bytes
	int m_immediateLength;		// length in bytes

	void LogOpcodeOffset( int offset );

public:
	/**************************************************************************/
	// This class contains instruction data.  Use it to obtain data about an
	// instruction.
	/**************************************************************************/

	// These return true if the data size or address size is as queried
	inline bool IsData64() { return( (m_inst_flags & INST_DATA64) != 0 ); }
	inline bool IsAddr64() { return( (m_inst_flags & INST_ADDR64) != 0 ); }
	inline bool IsData32() { return( (m_inst_flags & INST_DATA32) != 0 ); }
	inline bool IsAddr32() { return( (m_inst_flags & INST_ADDR32) != 0 ); }
	inline bool IsData16() { return( (m_inst_flags & INST_DATA16) != 0 ); }
	inline bool IsAddr16() { return( (m_inst_flags & INST_ADDR16) != 0 ); }

	// Returns true if the instruction is a 3dnow instruction
	inline bool IsAmd3d() { return( (m_inst_flags & INST_AMD3D) != 0 ); }

	// Returns true if the instruction is a two byte escape instruction
	inline bool IsLongopcode() { return( (m_inst_flags & INST_LONGOPCODE) != 0 ); }

	// Returns true if the instruction has a MODRM byte
	inline bool HasModrm() { return( m_modrmOffset > -1 ); }

	// Returns true if the instruction has a SIB byte
	inline bool HasSib() { return( m_sibOffset > -1 ); }

	// Returns true if the instruction has a DREX byte
	inline bool HasDrex() { return( m_drexOffset > -1 ); }

	// Returns true if the instruction has a SIB scale factor
	inline bool HasScale() { return( HasSib() && (SS(m_sib) != 0) ); }

	// Returns true if the instruction has a modrm or SIB index register
	inline bool HasIndex() { return( m_bHasIndex ); }

	// Returns true if the instruction has a modrm or SIB base register
	inline bool HasBase() { return( m_bHasBase ); }

	// Returns true if the instruction has immediate data
	inline bool HasImmediate() { return( m_immediateOffset > -1 ); }

	// Returns true if the instruction has displacement data
	inline bool HasDisplacement() { return( m_displacementOffset > -1 ); }

	// Returns true if the instruction has at least one prefix byte
	inline bool HasPrefix() { return( m_prefix_bytes.GetCount() != 0 ); }

	// These return true if the instruction has the specific prefix byte queried
	// for, and the byte is used (i.e. in the case of conflicting prefixes, these 
	// return true if the prefix was not overridden).
	inline bool HasSegOvrdPrefix() { return( (m_inst_flags & INST_SEGOVRD) != 0 ); }
	inline bool HasRepPrefix() { return( (m_inst_flags & INST_REP) != 0 ); }
	inline bool HasRepnePrefix() { return( (m_inst_flags & INST_REPNE) != 0 ); }
	inline bool HasLockPrefix() { return( (m_inst_flags & INST_LOCK) != 0 ); }
	inline bool HasRexPrefix() { return( REX_PREFIX( m_rex_prefix ) ); }
	inline bool HasDataOvrdPrefix() { return( (m_inst_flags & INST_DATAOVRD) != 0 ); }
	inline bool HasAddressOvrdPrefix() { return( (m_inst_flags & INST_ADDROVRD) != 0 ); }

	// These return the user settable mode status.
	inline bool IsLongMode() { return m_longmode; }
	inline bool IsRex32Mode() { return m_rex32mode; }
	inline bool IsSvmMode() { return m_svmmode; }

	// Use this to have the disassembler use your buffer for the mnemonic (instead
	// of CInstructionData's internal mnemonic buffer).  This will save you from having
	// to copy the mnemonic over.  Make sure the buffer you provide is long enough for 
	// the longest mnemonic (MAX_MNEMONIC_LENGTH+1)
	inline char *SetMnemonicBuffer( char *pBuffer ) { m_mnem = pBuffer; return m_mnem; }
	inline void RestoreMnemonicBuffer() { m_mnem = m_mnem_buffer; }

	// This returns a pointer to the instruction mnemonic buffer
	inline char *GetMnemonic() { return( m_mnem ); }

	// Returns the overall length of the instruction in bytes
	inline int GetLength() { return( m_len ); }

	// These routines return the portions of the instruction stream that are opcodes
	inline int GetNumOpcodeBytes() { return m_numOpcodes; }
	inline AMD_UINT8 GetOpcode( int index )
	{
		return( m_inst_buf[m_opcodeOffsets[(index >= 0) ? index : (m_numOpcodes + index)]] );
	}
	inline int GetOpcodeOffset( int index )
	{
		return( m_opcodeOffsets[(index >= 0) ? index : (m_numOpcodes + index)] );
	}

	// Returns the modrm byte (if applicable)
	inline AMD_UINT8 GetModrm() { return( m_modrm ); }

	// Return pieces of the modrm byte
	inline AMD_UINT8 GetModrmMod() { return( m_modrm_mod ); }
	inline AMD_UINT8 GetModrmReg() { return( m_modrm_reg ); }
	inline AMD_UINT8 GetModrmRm() { return( m_modrm_rm ); }

	// Returns the sib byte (if applicable)
	inline AMD_UINT8 GetSib() { return( m_sib ); }

	// Return pieces of the sib byte
	inline AMD_UINT8 GetSibScale() { return( SS( m_sib ) ); }
	inline AMD_UINT8 GetSibIndex() { return( IDX( m_sib ) ); }
	inline AMD_UINT8 GetSibBase() { return( BASE( m_sib ) ); }

	// Returns the drex byte (if applicable)
	inline AMD_UINT8 GetDrex() { return( m_drex ); }

	// Return pieces of the drex byte
	inline AMD_UINT8 GetDrexDest() { return( DREX_DEST( m_drex ) ); }
	inline AMD_UINT8 GetDrexOC0() { return( DREX_OC0( m_drex ) ); }
	inline AMD_UINT8 GetDrexR() { return( DREX_R( m_drex ) ); }
	inline AMD_UINT8 GetDrexX() { return( DREX_X( m_drex ) ); }
	inline AMD_UINT8 GetDrexB() { return( DREX_B( m_drex ) ); }

	// Returns the instruction immediate value (if applicable)
	// For instructions with more than one immediate, the immediates are concatenated
	// together in little endian order just like they appear in the instruction stream
	// e.g. "mnemonic eax,ib,iw" would produce an immediate = iwib (i.e. "ib iwlo iwhi")
	inline AMD_UINT64 GetImmediate() { return( m_immd ); }

	// Returns the length (in bytes) of the immediate field
	inline AMD_UINT32 GetImmediateLength() { return m_immediateLength; }

	// Returns the instruction displacement value (if applicable)
	inline AMD_INT64 GetDisplacement() { return( m_disp ); }

	// Returns the length (in bytes) of the displacement field
	inline AMD_UINT32 GetDisplacementLength() { return m_displacementLength; }

	// Returns the number of prefix bytes
	inline AMD_UINT32 GetPrefixCount() { return( m_prefix_bytes.GetCount() ); }

	// Returns a specific prefix byte (if applicable)
	inline AMD_UINT8 GetPrefixByte( AMD_UINT32 index )
	{
		AMD_UINT8 prefixByte;
		return( m_prefix_bytes.GetByte( index, &prefixByte ) ? prefixByte : (AMD_UINT8)0 );
	}

	// Returns the segment register given that a segment override was used
	inline AMD_UINT8 GetSegmentRegister() { return( NORMALIZE_SEGREG(m_seg_reg) ); }

	// Returns the rex prefix byte (will be zero if there is no rex prefix).
	inline AMD_UINT8 GetRexPrefix() { return( m_rex_prefix ); }

	///////////////////////////////////////////////////////////////////////////////////////////////
	// Do not call the following routines with an operand index >= the number of operands as returned by GetNumOperands().
	///////////////////////////////////////////////////////////////////////////////////////////////

	// returns the number of explicit operands in the instruction.
	inline AMD_UINT32 GetNumOperands() { return m_numOperands; };

	// returns the type of the operand
	n_Disassembler::e_OperandType GetOperandType( AMD_UINT32 operand ) { return( m_operands[operand].GetType() ); }

	// returns the bit size of the operand
	inline n_Disassembler::e_OperandSize GetOperandSize( AMD_UINT32 operand ) { return( m_operands[operand].GetSize() ); }

	// For register operands, returns the block of registers an operand references (e.g. GP (REG_EAX), MMX (REG_MM0), ...)
	inline n_Disassembler::e_Registers GetOperandRegBlock( AMD_UINT32 operand ) { return( m_operands[operand].GetRegisterBlock() ); }

	// For register operands, returns the origin of a register index (e.g. REGORIGIN_MODRM_REG, ...)
	inline n_Disassembler::e_RegisterOrigins GetOperandRegOrigin( AMD_UINT32 operand ) { return( m_operands[operand].GetRegisterOrigin() ); }

	// NOTE: For string instructions (movs, cmps, stos, ...), use OperandHasIndex() and
	// GetOperandIndexRegister(operand) to get the index register (esi or edi) for the appropriate operand.  HasIndex()
	// and GetIndexRegister only apply to instructions with a modrm and/or SIB.
	// 
	// returns the e_Registers equivalent values
	// Do not call this routine with an operand index >= the number of operands as returned by GetNumOperands().
	inline n_Disassembler::e_Registers GetRegister( AMD_UINT32 operand ) { return( m_operands[operand].GetRegister() ); }
	inline n_Disassembler::e_Registers GetBaseRegister() { return (n_Disassembler::e_Registers)m_base; }
	inline n_Disassembler::e_Registers GetIndexRegister() { return (n_Disassembler::e_Registers)m_index; }

	// returns true if the indicated operand has an index register associated with it
	// Do not call this routine with an operand index >= the number of operands as returned by GetNumOperands().
	bool OperandHasIndex( AMD_UINT32 operand )
	{
		if( HasIndex() )
			return( GetOperandType( operand ) == n_Disassembler::OPERANDTYPE_MEMORY ); 
		else 
			return m_operands[operand].IsString();
	}

	// returns the index register for the indicated operand
	// don't call this before calling OperandHasIndex(operand) and getting back "true"
	n_Disassembler::e_Registers GetOperandIndexRegister( AMD_UINT32 operand )
	{ 
		return( HasIndex() ? GetIndexRegister() : GetRegister( operand ) ); 
	}

	// returns true if the indicated operand is a far ptr (selector:offset)
	inline bool OperandIsFarPtr( AMD_UINT32 operand ) { return( (m_operands[operand].flags & OPF_FARPTR) != 0 ); }

	///////////////////////////////////////////////////////////////////////////////////////////////
	// End of operand specific routines
	///////////////////////////////////////////////////////////////////////////////////////////////

	// The following return the offset to each part of the instruction (where present)
	inline int GetModrmOffset() { return m_modrmOffset; }
	inline int GetSIBOffset() { return m_sibOffset; }
	inline int GetDisplacementOffset() { return m_displacementOffset; }
	inline int GetImmediateOffset() { return m_immediateOffset; }
	inline int GetDrexOffset() { return m_drexOffset; }

#ifdef _DEBUG
	/**************************************************************************/
	// Debug only routines
	/**************************************************************************/
	void ShowOperands();
	void ShowOpcodes();
	char *OperandSizeString( n_Disassembler::e_OperandSize size );
	char *OperandTypeString( n_Disassembler::e_OperandType type );
	char *RegisterString( n_Disassembler::e_Registers reg );
	/**************************************************************************/
#endif
};

class EXPORTCLASS CDisassembler : public CInstructionData
{
	AMD_UINT64 m_immediateData;		// internal: to support mnemonic generation

protected:
	Inst_Info *m_opcode_table_ptr;
	COperandInfo *m_pOperand;
	int m_maxInstructionBytes;

	const char *m_hexPostfix;
	const char *m_opcodeSeperator;
	bool m_bUpperCase;
	bool m_bShowSize;
	n_Disassembler::e_DisassemblerErrorCodes m_errorLevel;
	AMD_UINT32 m_alternateDecodings;	// by default, all alternate interpretations are disabled

	static const char *S_PrefixByteStrings[];
	void GetPrefixBytesString( char *str );

	static const char *S_modrm16_str[];
	static const char *S_rex_byte_regs[];
	static const char *S_byte_regs[];
	static const char *S_word_regs[];
	static const char *S_dword_regs[];
	static const char *S_qword_regs[];
	static const char *S_control_regs[];
	static const char *S_debug_regs[];
	static const char *S_segment_regs[];
	static const char *S_fpu_regs[];	// "st0", "st1", ..., "st"	(stack top is last)
	static const char *S_mmx_regs[];
	static const char *S_xmmx_regs[];

	static Inst_Info *S_3dnow_ptrs[256];

	static PVOIDMEMBERFUNC S_DecodeOperandFnPtrs[];
	static PVOIDMEMBERFUNC S_DisassembleOperandFnPtrs[];
	static PVOIDMEMBERFUNC S_PrefixByteFnPtrs[];

	AMD_UINT8 GetByte();
	AMD_UINT8 PeekByte( int offset = 0 );

	inline char *UINT64HexString( AMD_UINT64 val );
	inline char *SignedString( AMD_INT64 value, int width, bool prependPlus = false );
	inline char *UnsignedString( AMD_UINT64 value, int width, bool prependPlus = false );

	inline void GetByteModrm();
	inline void GetWordModrm();
	inline void GetDwordModrm();
	inline void GetWDQModrm();
	inline void GetWQModrm();
	inline void GetDQModrm();
	inline void GetOwordModrm();
	inline void GetByteModrmSS();
	inline void GetWordModrmSS();
	inline void GetDwordModrmSS();
	inline void GetWDQModrmSS();
	inline void GetWQModrmSS();
	inline void GetRegFromReg();
	inline void GetByteRegFromReg();
	inline void GetWordRegFromReg();
	inline void GetDwordRegFromReg();
	inline void GetQwordRegFromReg();
	inline void GetWDQRegFromReg();
	inline void GetDQRegFromReg();
	inline void GetByteImmediate();
	inline void GetByteImmediateSS();
	inline void GetWordImmediate();
	inline void GetWordOrDwordImmediate();
	inline void GetWordOrDwordImmediateSS();
	inline void GetWDQImmediate();
	inline void GetByteJump();
	inline void GetWordOrDwordJump();
	inline void GetByteRegFromOpcode();
	inline void GetWDQRegFromOpcode();
	inline void GetRegAL();
	inline void GetRegAX();
	inline void GetRegeAX();
	inline void GetRegCL();
	inline void GetRegDX();
	inline void GetRegeDX();
	inline void GetMemoryModrm();
	inline void GetDwordOrFwordMemory();
	inline void GetDwordOrFwordDirect();
	inline void GetOffsetByte();
	inline void GetOffsetWDQ();
	inline void GetMMXReg();
	inline void GetMMXDwordReg();
	inline void GetMMXQwordReg();
	inline void GetMMXDQwordReg();
	inline void GetMMXQwordModrm();
	inline void GetDwordOrQwordReg();
	inline void GetDebugRegister();
	inline void GetControlRegister();
	inline void GetWordSegmentRegister();
	inline void GetByteMemoryEsi();
	inline void GetWDQMemoryEsi();
	inline void GetByteMemoryEdi();
	inline void GetWDQMemoryEdi();
	inline void GetSTReg();
	inline void GetST0Reg();
	inline void GetST1Reg();
	inline void GetST2Reg();
	inline void GetST3Reg();
	inline void GetST4Reg();
	inline void GetST5Reg();
	inline void GetST6Reg();
	inline void GetST7Reg();
	inline void GetSimdOwordReg();
	inline void GetSimdDwordReg();
	inline void GetSimdQwordReg();
	inline void GetSimdDQwordReg();
	inline void GetSimdReg();
	inline void GetSimdDwordModrm();
	inline void GetSimdQwordModrm();
	inline void GetSimdOwordModrm();
	inline void GetSimdModrm();
	inline void GetMemory();
	inline void GetByteMemory();
	inline void GetWordMemory();
	inline void GetDwordMemory();
	inline void GetWordOrDwordMemory();
	inline void GetDwordOrQwordMemory();
	inline void GetFwordMemory();
	inline void GetQwordMemory();
	inline void GetTwordMemory();
	inline void GetFpuAx();						// Same as GetAX except it gets a modrm byte as well
	inline void GeteBXAndAL();
	inline void GetWordMemoryOrWDQRegModrm();
	inline void GetQwordOrOwordMemory();
	inline void GetBniOpcodeOperand();
	inline void GetBniByteOpcode();
	inline void GetBniWordOpcode();
	inline void GetBniDwordOpcode();
	inline void GetBniQwordOpcode();
	inline void GetBniOwordOpcode();
	inline void GetBniReg();
	inline void GetBniByteReg();
	inline void GetBniWordReg();
	inline void GetBniDwordReg();
	inline void GetBniQwordReg();
	inline void GetBniOwordReg();
	inline void GetBniModrm();
	inline void GetBniByteModrm();
	inline void GetBniWordModrm();
	inline void GetBniDwordModrm();
	inline void GetBniQwordModrm();
	inline void GetBniOwordModrm();
	inline void GetOperandConfiguration();
	inline void GetBniByteCondition();

	void ModrmStr();
	inline void MemoryModrmStr();
	inline void MemoryModrmStrWithSIB();
	inline void MemoryModrmStrWithoutSIB();
	inline void RegisterModrmStr();
	inline void ByteRegStr();
	inline void WordRegStr();
	inline void DwordRegStr();
	inline void QwordRegStr();
	inline void WDQRegStr();
	inline void ByteImmediateStr();
	inline void WordImmediateStr();
	inline void WordOrDwordImmediateStr();
	inline void WDQImmediateStr();
	inline void SignedByteJumpStr();
	inline void SignedWordOrDwordJumpStr();
	inline void _1Str();
	inline void RegALStr();
	inline void RegAXStr();
	inline void RegeAXStr();
	inline void RegCLStr();
	inline void RegDXStr();
	inline void RegeDXStr();
	inline void AddressStr();
	inline void OffsetStr();
	inline void MMXRegStr();
	inline void MMXModrmStr();
	inline void RegisterStr();
	inline void ControlRegStr();
	inline void DebugRegStr();
	inline void SegmentRegStr();
	inline void DsEsiStr();
	inline void EsEdiStr();
	inline void FpuStr();
	inline void SimdModrmStr();
	inline void SimdRegStr();
	inline void RegeBXAndALStr();
	inline void BniConditionStr();

	void PrefixRex();
	void PrefixEsSegOveride();
	void PrefixCsSegOveride();
	void PrefixSsSegOveride();
	void PrefixDsSegOveride();
	void PrefixFsSegOveride();
	void PrefixGsSegOveride();
	void PrefixDataSize();
	void PrefixAddressSize();
	void PrefixLock();
	void PrefixRepne();
	void PrefixRep();
				
protected:
	static Inst_Info S_oneByteOpcodes_tbl[256];
	static Inst_Info S_twoByteOpcodes_tbl[256];

	// group tables for single byte opcodes
	static Inst_Info S_group_1_60_tbl[3];
	static Inst_Info S_group_1_61_tbl[3];
	static Inst_Info S_group_1_63_tbl[2];
	static Inst_Info S_group_1_6d_tbl[2];
	static Inst_Info S_group_1_6f_tbl[2];
	static Inst_Info S_group_1_80_tbl[8];
	static Inst_Info S_group_1_81_tbl[8];
	static Inst_Info S_group_1_82_tbl[8];
	static Inst_Info S_group_1_83_tbl[8];  
	static Inst_Info S_group_1_90_tbl[3];	// nop, xchg, and pause
	static Inst_Info S_group_1_98_tbl[3];
	static Inst_Info S_group_1_99_tbl[3];
	static Inst_Info S_group_1_9c_tbl[3];
	static Inst_Info S_group_1_9d_tbl[3];
	static Inst_Info S_group_1_a5_tbl[3];
	static Inst_Info S_group_1_a7_tbl[3];
	static Inst_Info S_group_1_ab_tbl[3];
	static Inst_Info S_group_1_ad_tbl[3];
	static Inst_Info S_group_1_af_tbl[3];
	static Inst_Info S_group_1_c0_tbl[8];
	static Inst_Info S_group_1_c1_tbl[8];
	static Inst_Info S_group_1_c2_tbl[3];
	static Inst_Info S_group_1_c3_tbl[3];
	static Inst_Info S_group_1_ca_tbl[3];
	static Inst_Info S_group_1_cb_tbl[3];
	static Inst_Info S_group_1_cf_tbl[3];
	static Inst_Info S_group_1_d0_tbl[8];
	static Inst_Info S_group_1_d1_tbl[8];
	static Inst_Info S_group_1_d2_tbl[8];
	static Inst_Info S_group_1_d3_tbl[8];
	static Inst_Info S_group_1_d8_tbl[72];
	static Inst_Info S_group_1_d9_tbl[72];
	static Inst_Info S_group_1_da_tbl[72];
	static Inst_Info S_group_1_db_tbl[72];
	static Inst_Info S_group_1_dc_tbl[72];
	static Inst_Info S_group_1_dd_tbl[72];
	static Inst_Info S_group_1_de_tbl[72];
	static Inst_Info S_group_1_df_tbl[72];
	static Inst_Info S_group_1_e3_tbl[3];
	static Inst_Info S_group_1_f6_tbl[8];
	static Inst_Info S_group_1_f7_tbl[8];
	static Inst_Info S_group_1_fa_tbl[2];
	static Inst_Info S_group_1_fb_tbl[2];
	static Inst_Info S_group_1_fe_tbl[8];  
	static Inst_Info S_group_1_ff_tbl[8];

	// group tables for multi byte opcodes
	static Inst_Info S_group_2_00_tbl[8];
	static Inst_Info S_group_2_01_tbl[8];
	static Inst_Info S_group_2_01_01_tbl[9];
	static Inst_Info S_group_2_01_03_tbl[9];
	static Inst_Info S_group_2_01_07_tbl[9];
	static Inst_Info S_group_2_0d_tbl[2];
	static Inst_Info S_group_2_0f_tbl[24];
	static Inst_Info S_group_2_10_tbl[4];
	static Inst_Info S_group_2_11_tbl[4];
	static Inst_Info S_group_2_12_tbl[4];
	static Inst_Info S_group_2_12_00_tbl[2];
	static Inst_Info S_group_2_13_tbl[4];
	static Inst_Info S_group_2_14_tbl[4];
	static Inst_Info S_group_2_15_tbl[4];
	static Inst_Info S_group_2_16_tbl[4];
	static Inst_Info S_group_2_16_00_tbl[2];
	static Inst_Info S_group_2_17_tbl[4];
	static Inst_Info S_group_2_18_tbl[16];

	static Inst_Info S_group_2_24_tbl[32];
	static Inst_Info S_group_2_24_00_tbl[4];
	static Inst_Info S_group_2_24_01_tbl[4];
	static Inst_Info S_group_2_24_02_tbl[4];
	static Inst_Info S_group_2_24_03_tbl[4];
	static Inst_Info S_group_2_24_04_tbl[4];
	static Inst_Info S_group_2_24_08_tbl[2];
	static Inst_Info S_group_2_24_08_00_tbl[4];
	static Inst_Info S_group_2_24_08_01_tbl[4];
	static Inst_Info S_group_2_24_09_tbl[2];
	static Inst_Info S_group_2_24_09_00_tbl[4];
	static Inst_Info S_group_2_24_10_tbl[4];
	static Inst_Info S_group_2_24_11_tbl[4];
	static Inst_Info S_group_2_24_12_tbl[4];
	static Inst_Info S_group_2_24_13_tbl[4];
	static Inst_Info S_group_2_24_14_tbl[4];
	static Inst_Info S_group_2_24_16_tbl[4];

	static Inst_Info S_group_2_25_tbl[32];
	static Inst_Info S_group_2_25_05_tbl[4];
	static Inst_Info S_group_2_25_09_tbl[4];
	static Inst_Info S_group_2_25_0d_tbl[4];

	static Inst_Info S_group_2_28_tbl[4];
	static Inst_Info S_group_2_29_tbl[4];
	static Inst_Info S_group_2_2a_tbl[4];
	static Inst_Info S_group_2_2b_tbl[4];
	static Inst_Info S_group_2_2c_tbl[4];
	static Inst_Info S_group_2_2d_tbl[4];
	static Inst_Info S_group_2_2e_tbl[4];
	static Inst_Info S_group_2_2f_tbl[4];
	static Inst_Info S_group_2_38_tbl[32];
	static Inst_Info S_group_2_38_00_tbl[2];
	static Inst_Info S_group_2_38_01_tbl[2];
	static Inst_Info S_group_2_38_02_tbl[2];
	static Inst_Info S_group_2_38_03_tbl[2];
	static Inst_Info S_group_2_38_04_tbl[2];
	static Inst_Info S_group_2_38_05_tbl[2];
	static Inst_Info S_group_2_38_06_tbl[2];
	static Inst_Info S_group_2_38_07_tbl[2];
	static Inst_Info S_group_2_38_08_tbl[2];
	static Inst_Info S_group_2_38_09_tbl[2];
	static Inst_Info S_group_2_38_0a_tbl[2];
	static Inst_Info S_group_2_38_0b_tbl[2];
	static Inst_Info S_group_2_38_17_tbl[2];
	static Inst_Info S_group_2_38_1c_tbl[2];
	static Inst_Info S_group_2_38_1d_tbl[2];
	static Inst_Info S_group_2_38_1e_tbl[2];
	static Inst_Info S_group_Typeof_2_3a_tbl[2];
	static Inst_Info S_group_2_3a_tbl[16];
	static Inst_Info S_group_2_3a_0f_tbl[2];
	static Inst_Info S_group_2_3a_Type2_tbl[32];
	static Inst_Info S_group_2_3a_01_Type2_tbl[4];
	static Inst_Info S_group_2_50_tbl[4];
	static Inst_Info S_group_2_51_tbl[4];
	static Inst_Info S_group_2_52_tbl[4];
	static Inst_Info S_group_2_53_tbl[4];
	static Inst_Info S_group_2_54_tbl[4];
	static Inst_Info S_group_2_55_tbl[4];
	static Inst_Info S_group_2_56_tbl[4];
	static Inst_Info S_group_2_57_tbl[4];
	static Inst_Info S_group_2_58_tbl[4];
	static Inst_Info S_group_2_59_tbl[4];
	static Inst_Info S_group_2_5a_tbl[4];
	static Inst_Info S_group_2_5b_tbl[4];
	static Inst_Info S_group_2_5c_tbl[4];
	static Inst_Info S_group_2_5d_tbl[4];
	static Inst_Info S_group_2_5e_tbl[4];
	static Inst_Info S_group_2_5f_tbl[4];
	static Inst_Info S_group_2_60_tbl[4];
	static Inst_Info S_group_2_61_tbl[4];
	static Inst_Info S_group_2_62_tbl[4];
	static Inst_Info S_group_2_63_tbl[4];
	static Inst_Info S_group_2_64_tbl[4];
	static Inst_Info S_group_2_65_tbl[4];
	static Inst_Info S_group_2_66_tbl[4];
	static Inst_Info S_group_2_67_tbl[4];
	static Inst_Info S_group_2_68_tbl[4];
	static Inst_Info S_group_2_69_tbl[4];
	static Inst_Info S_group_2_6a_tbl[4];
	static Inst_Info S_group_2_6b_tbl[4];
	static Inst_Info S_group_2_6c_tbl[4];
	static Inst_Info S_group_2_6d_tbl[4];
	static Inst_Info S_group_2_6e_tbl[4];
	static Inst_Info S_group_2_6f_tbl[4];
	static Inst_Info S_group_2_70_tbl[4];
	static Inst_Info S_group_2_71_tbl[8];
	static Inst_Info S_group_2_71_02_tbl[4];
	static Inst_Info S_group_2_71_04_tbl[4];
	static Inst_Info S_group_2_71_06_tbl[4];
	static Inst_Info S_group_2_72_tbl[8];
	static Inst_Info S_group_2_72_02_tbl[4];
	static Inst_Info S_group_2_72_04_tbl[4];
	static Inst_Info S_group_2_72_06_tbl[4];
	static Inst_Info S_group_2_73_tbl[8];
	static Inst_Info S_group_2_73_02_tbl[4];
	static Inst_Info S_group_2_73_03_tbl[4];
	static Inst_Info S_group_2_73_06_tbl[4];
	static Inst_Info S_group_2_73_07_tbl[4];
	static Inst_Info S_group_2_74_tbl[4];
	static Inst_Info S_group_2_75_tbl[4];
	static Inst_Info S_group_2_76_tbl[4];
	static Inst_Info S_group_2_78_tbl[4];
	static Inst_Info S_group_2_79_tbl[4];

	static Inst_Info S_group_2_7a_tbl[32];
	static Inst_Info S_group_2_7a_02_tbl[2];
	static Inst_Info S_group_2_7a_02_00_tbl[4];
	static Inst_Info S_group_2_7a_06_tbl[8];
	static Inst_Info S_group_2_7a_08_tbl[8];
	static Inst_Info S_group_2_7a_09_tbl[8];
	static Inst_Info S_group_2_7a_0a_tbl[8];
	static Inst_Info S_group_2_7a_0b_tbl[8];
	static Inst_Info S_group_2_7a_0c_tbl[8];

	static Inst_Info S_group_2_7b_tbl[32];
	static Inst_Info S_group_2_7b_08_tbl[2];
	static Inst_Info S_group_2_7b_08_00_tbl[4];

	static Inst_Info S_group_2_7c_tbl[4];
	static Inst_Info S_group_2_7d_tbl[4];
	static Inst_Info S_group_2_7e_tbl[4];
	static Inst_Info S_group_2_7f_tbl[4];
	static Inst_Info S_group_2_ae_tbl[16];
	static Inst_Info S_group_2_b8_tbl[2];
	static Inst_Info S_group_2_ba_tbl[8];
	static Inst_Info S_group_2_bd_tbl[2];
	static Inst_Info S_group_2_c2_tbl[4];
	static Inst_Info S_group_2_c4_tbl[4];
	static Inst_Info S_group_2_c5_tbl[4];
	static Inst_Info S_group_2_c6_tbl[4];
	static Inst_Info S_group_2_c7_tbl[8];
	static Inst_Info S_group_2_d0_tbl[4];
	static Inst_Info S_group_2_d1_tbl[4];
	static Inst_Info S_group_2_d2_tbl[4];
	static Inst_Info S_group_2_d3_tbl[4];
	static Inst_Info S_group_2_d4_tbl[4];
	static Inst_Info S_group_2_d5_tbl[4];
	static Inst_Info S_group_2_d6_tbl[4];
	static Inst_Info S_group_2_d7_tbl[4];
	static Inst_Info S_group_2_d8_tbl[4];
	static Inst_Info S_group_2_d9_tbl[4];
	static Inst_Info S_group_2_da_tbl[4];
	static Inst_Info S_group_2_db_tbl[4];
	static Inst_Info S_group_2_dc_tbl[4];
	static Inst_Info S_group_2_dd_tbl[4];
	static Inst_Info S_group_2_de_tbl[4];
	static Inst_Info S_group_2_df_tbl[4];
	static Inst_Info S_group_2_e0_tbl[4];
	static Inst_Info S_group_2_e1_tbl[4];
	static Inst_Info S_group_2_e2_tbl[4];
	static Inst_Info S_group_2_e3_tbl[4];
	static Inst_Info S_group_2_e4_tbl[4];
	static Inst_Info S_group_2_e5_tbl[4];
	static Inst_Info S_group_2_e6_tbl[4];
	static Inst_Info S_group_2_e7_tbl[4];
	static Inst_Info S_group_2_e8_tbl[4];
	static Inst_Info S_group_2_e9_tbl[4];
	static Inst_Info S_group_2_ea_tbl[4];
	static Inst_Info S_group_2_eb_tbl[4];
	static Inst_Info S_group_2_ec_tbl[4];
	static Inst_Info S_group_2_ed_tbl[4];
	static Inst_Info S_group_2_ee_tbl[4];
	static Inst_Info S_group_2_ef_tbl[4];
	static Inst_Info S_group_2_f0_tbl[4];
	static Inst_Info S_group_2_f1_tbl[4];
	static Inst_Info S_group_2_f2_tbl[4];
	static Inst_Info S_group_2_f3_tbl[4];
	static Inst_Info S_group_2_f4_tbl[4];
	static Inst_Info S_group_2_f5_tbl[4];
	static Inst_Info S_group_2_f6_tbl[4];
	static Inst_Info S_group_2_f7_tbl[4];
	static Inst_Info S_group_2_f8_tbl[4];
	static Inst_Info S_group_2_f9_tbl[4];
	static Inst_Info S_group_2_fa_tbl[4];
	static Inst_Info S_group_2_fb_tbl[4];
	static Inst_Info S_group_2_fc_tbl[4];
	static Inst_Info S_group_2_fd_tbl[4];
	static Inst_Info S_group_2_fe_tbl[4];

	static const char *S_size_qualifiers[8];		// "byte ", "word ", "dword ", "48 bit", "qword ", "tword ", "dqword ", "none "

	void GetModrmByte();
	void GetImmediateByte();
	void GetImmediateWord();
	void GetImmediateDword();
	void GetImmediateFword();
	void GetImmediateQword();
	void GetDisplacementByte();
	void GetDisplacementWord();
	void GetDisplacementDword();
	void GetDisplacementQword();
	void GetDrexByte();

	bool GetInfoPtr();
	void SetInstructionFlags( void );
	int DecodeAmdOperandBytes();
	void DecodeOpcodeBytes();
	void DecodeOperandBytes();
	void ConfigureBniOperands( void );

	inline bool ScanForAddressOverride()
	{
		for( int i = (GetPrefixCount() - 1); i >= 0; i-- )
			if( GetPrefixByte( i ) == PREFIX_ADDR )
				return true;

		return false;
	}

//	inline void DecodeModrm() { (m_modrm_mod == 3) ? DecodeRegisterModrm() : DecodeMemoryModrm(); }
	void DecodeModrm();
	void OperandModrm();
	void OperandMemoryModrm();
	void OperandRegisterModrm();

	inline const char *GetSizeQualifier() { return( S_size_qualifiers[m_pOperand->size] ); }

	// use this after decoding instructions which ignore REX extensions
	inline void UndoRegisterExtensions() { m_pOperand->reg &= ~(0x8); }

	// verifies lock usage, throws exception if not used correctly
	inline void CheckLockPrefix()
	{
		if
		(	!(((m_operands[0].type == n_Disassembler::OPERANDTYPE_MEMORY) || (m_operands[0].type == n_Disassembler::OPERANDTYPE_RIPRELATIVE)) && ((m_operands[0].flags & OPF_LOCK) != 0))
		 &&	!(((m_operands[1].type == n_Disassembler::OPERANDTYPE_MEMORY) || (m_operands[1].type == n_Disassembler::OPERANDTYPE_RIPRELATIVE)) && ((m_operands[1].flags & OPF_LOCK) != 0))
		 &&	!(m_inst_flags & INST_LOCK_OVERUSED)
		)
			throw CFormatException();
	}

	inline n_Disassembler::e_OperandSize GetWDQOperandSize()
	{
		if( m_inst_flags & INST_DATA64 )
			return n_Disassembler::OPERANDSIZE_64;
		else if( m_inst_flags & INST_DATA32 )
			return n_Disassembler::OPERANDSIZE_32;
		else
			return n_Disassembler::OPERANDSIZE_16;
	}

	// when tables are hooked in derived classes, the base table entries should pass the following checks
	inline void CheckHook( Inst_Info &entry, const char * tablename )
	{
		// if table is not nested and it has a mnem, then it needs to be hooked
		if( (entry.GetInfoPtr == NULL) && (entry.mnem != NULL) )
			if( entry.pExtraInfo == NULL )
			{
				m_errorLevel = n_Disassembler::TABLE_EXCEPTION;
				throw CTableException( tablename );
			}
	}
	
	// This exception class helps the disassembler avoid walking past the
	// end of an invalid instruction (instructions are at most 15 bytes 
	// long and can be restricted to shorter lengths).
	class CLengthException
	{
	public:
		CLengthException() {}
		~CLengthException() {}
	};

	// This exception class helps the disassembler signal errors in for invalid
	// instruction (e.g. receiving register modrm instruction bytes for instructions
	// which accept only memory modrm values).
	class CFormatException
	{
	public:
		CFormatException() {}
		~CFormatException() {}
	};

	// This exception class helps the disassembler signal table hook errors in
	// a derived classes.
	class CTableException
	{
	public:
		const char * m_tablename;

		CTableException() { m_tablename = (const char*) 0; }
		CTableException( const char * tablename ) { m_tablename = tablename; }
		~CTableException() {}
		const char * GetTablename( void ) { return m_tablename; }
	};

public:
	/**************************************************************************/
	// These routines are intended for use by derived and friend classes.
	/**************************************************************************/

	// This routine provides access to a generic pointer maintained for every
	// instruction.  This pointer can be set to point at user defined data
	// in derived classes to allow the disassembler to be extensable.
	inline CExtraInstInfo *GetExtraInfoPtr() { return( m_opcode_table_ptr ? m_opcode_table_ptr->pExtraInfo : NULL ); };

	// If you hook the base class's tables, you should call this routine after doing
	// so to verify that you hooked all of the relevant table entries.  This will
	// help flag the need to update your tables and initialization code to handle
	// new instructions added in future releases of the disassembler.
	bool TablesHooked();

	// This routine provides access to nested table entries
	Inst_Info *GetInstInfoPtr() { return m_opcode_table_ptr; };

	// These routines provide the algorithms necessary to index into nested
	// table entries.
	friend Inst_Info *GetFpuIndex( CDisassembler *pThis );
	friend Inst_Info *GetSSEIndex( CDisassembler *pThis );
	friend Inst_Info *GetSSEHiToLoIndex( CDisassembler *pThis );
	friend Inst_Info *Get3dnowIndex( CDisassembler *pThis );
	friend Inst_Info *GetGroupIndex( CDisassembler *pThis );
	friend Inst_Info *GetGroupCIndex( CDisassembler *pThis );		// includes special case handling of PPro nop
	friend Inst_Info *GetNewGroupIndex( CDisassembler *pThis );
	friend Inst_Info *GetArplMovsxdIndex( CDisassembler *pThis );
	friend Inst_Info *GetCliClxStiStxIndex( CDisassembler *pThis );
	friend Inst_Info *GetNopXchgPauseIndex( CDisassembler *pThis );
	friend Inst_Info *GetWDIndex( CDisassembler *pThis );
	friend Inst_Info *GetWDQIndex( CDisassembler *pThis );
	friend Inst_Info *GetWDQIndex64( CDisassembler *pThis );		// handles "64 bit data as default" under longmode
	friend Inst_Info *GetPrefetchIndex( CDisassembler *pThis );
	friend Inst_Info *GetModRmIndex( CDisassembler *pThis );	// index of 0 if mod != 3, index of rm+1 for the remainder
	friend Inst_Info *GetJcxIndex( CDisassembler *pThis );
	friend Inst_Info *Get_2_38_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_38_XX_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Typeof_2_3a_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_3a_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_3a_XX_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_3a_Type2_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_b8_Index( CDisassembler *pThis );
	friend Inst_Info *Get_2_bd_Index( CDisassembler *pThis );

	friend Inst_Info *Get_Opcode3_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Opcode3_Ops_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Opcode3_Oc1_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Opcode3_Oc1_Ops_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Opcode4_Ops_Index( CDisassembler *pThis );
	friend Inst_Info *Get_Opcode4_Oc1_Index( CDisassembler *pThis );
	friend Inst_Info *Get_BNI_Type1_Index( CDisassembler *pThis );

	/**************************************************************************/
	// These routines are for use during processing of instruction bytes.
	/**************************************************************************/

	// Returns true if the last instruction prefix was as queried (i.e. == prefix)
	bool IsLastPrefix( AMD_UINT8 prefix ) { return( m_prefix_bytes.IsLastByte( prefix ) ); }

	// Returns true if there is at least one prefix and sets prefix = last prefix, else
	// returns false
	bool GetLastPrefix( AMD_UINT8 *prefix ) { return( m_prefix_bytes.GetLastByte( prefix ) ); }

	// Returns true if there is at least two prefixes and sets prefix = next to last prefix, else
	// returns false
	bool GetNextToLastPrefix( AMD_UINT8 *prefix ) { return( m_prefix_bytes.GetNextToLastByte( prefix ) ); }

	// Removes the last prefix from the list of prefixes (e.g. use to remove a LOCK prefix).
	void RemoveLastPrefix() { m_prefix_bytes.RemoveLastByte(); }

	// Removes the last prefix matching 'prefix' from the list of prefixes (use when
	// prefixes aren't prefixes and need to be removed from the list of instruction prefix
	// bytes (e.g. "lock cli" == "clx", not "lock clx").
	bool RemovePrefixByte( AMD_UINT8 prefix ) { return( m_prefix_bytes.RemoveByte( prefix ) ); }

	// Call this to establish data size from prefix bytes and longmode/dbit prior to setting
	// m_inst_flags
	int GetDataSize();

	// Returns the address width (in hexadecimal characters)
	inline int GetAddressWidth() { return( m_longmode ? 16 : (m_dbit ? 8 : 4) ); }
	inline int GetDbit() { return m_dbit; }

	bool AlternateEnabled( n_Disassembler::e_AlternateDecodings alternate )
	{
		return( (m_alternateDecodings & (1 << alternate)) != 0 );
	}
	void EnableAlternate( n_Disassembler::e_AlternateDecodings alternate )
	{
		m_alternateDecodings |= (1 << alternate);
	}
	void DisableAlternate( n_Disassembler::e_AlternateDecodings alternate )
	{
		m_alternateDecodings &= ~(1 << alternate);
	}

	// Use these to locate and remove bytes from the list of prefix bytes
	// and move it into the list of opcode bytes on a special case basis.
	void HandleExtraPrefixOpcode();
	void HandleExtraRepOpcode();
	void HandleExtraF3Opcode();

	inline void SetIndex( AMD_UINT8 index ) { m_bHasIndex = true; m_index = index; }
	inline void SetBase( AMD_UINT8 base ) { m_bHasBase = true; m_base = base; }
	
public:
	/**************************************************************************/
	// These routines are intended for use by disassembler clients.
	/**************************************************************************/

	/**************************************************************************/
	// Disassembly involves telling the disassembler the dbit setting, the 
	// long mode setting (64-bit), and the instruction bytes.  The dbit and
	// long mode settings are modal and are not typically changed on every
	// instruction: call SetDbit and SetLongMode/SetRex32Mode to convey those
	// values.  After setting up those modes, call the disassembler with a
	// pointer to the instruction bytes.  The instruction bytes will be either
	// Decoded, or Decoded and Disassembled.  Decoding involves breaking the
	// instruction bytes into their constituent parts (prefix bytes, opcode
	// bytes, operand bytes, ...), Disassembly involves Decode as well as
	// mnemonic generation.  Either way (Decode or Disassemble), you can query
	// the disassembler afterwards for data about the instruction bytes (if
	// Decode or Disassembly succeeded).
	//
	// CDisassembler derives from CInstructionData (defined above).  Look at
	// that class to see how to query the CDisassembler object for data about
	// the instruction bytes after obtaining a successfull return value from
	// the Decode/Disassemble routines. 
	//
	// Note: The buffer containing the instruction bytes needs to be either at
	// least 15 bytes long (the maximum valid instruction length), or contain 
	// enough bytes for one valid instruction.  The disassembler will not look
	// past the last valid instruction byte: however, note that if you pass the
	// disassembler a pointer to a short buffer (less than 15 bytes) containing
	// nothing but instruction prefix bytes, the disassembler will look past 
	// the end of that short buffer until it looks at 15 bytes (at which time
	// it would indicate that the bytes could not be disassembled) or one 
	// complete instruction (presumably nonsense since some of the bytes came
	// from beyond the end of the buffer) unless you limit the disassembler to
	// less 15 bytes.
	/**************************************************************************/

	CDisassembler();
	virtual ~CDisassembler();

	// This routine is the main api to the disassembler.  It returns a pointer
	// to CDisassembler's internal mnemonics buffer on success, NULL on
	// failure.  The CDisassembler object will return meaningless values
	// unless you query it after this routine returns a success.  inst_buf
	// should point to an array of instruction bytes.
	virtual char *Disassemble( AMD_UINT8 *inst_buf );

	// This routine is the same as Disassembler( AMD_UINT8 *inst_buf ) except that
	// it allows the caller to convey the instruction pointer value.  This
	// value will be used to calculate and display memory locations instead of
	// relative offsets (i.e. mem_00401022 instead of $+1022)
	virtual char *Disassemble( AMD_UINT8 *inst_buf, AMD_UINT64 rip );

	// This routine provides a short circuit to the disassembler's decoder
	// without generating a mnemonic.  This will save time if instruction
	// decoding is all that is required (i.e. no mnemonics needed).  The
	// CDisassembler object will return meaningless values unless you query
	// it after this routine returns a success.  inst_buf should point to an
	// array of instruction bytes.
	virtual bool Decode( AMD_UINT8 *inst_buf );

	// This routine provides a one call solution to disassembly.  Normally,
	// the dbit is toggled only when it is changed: this routine allows you to
	// control it on an instruction by instruction basis in one call.  Same
	// caveats as char *Disassemble( AMD_UINT8 *inst_buf ) with regards to the
	// return values.  inst_buf should point to an array of instruction bytes.
	virtual char *Disassemble( AMD_UINT8 *inst_buf, bool dbit ) { SetDbit( dbit ); return Disassemble( inst_buf ); }

	// This routine provides a one call solution to decoding.  Normally, the
	// dbit is toggled only when it is changed: this routine allows you to
	// control it on an instruction by instruction basis in one call.  Same
	// caveats as bool *Decode( AMD_UINT8 *inst_buf ) with regards to the return
	// values.  inst_buf should point to an array of instruction bytes.
	virtual bool Decode( AMD_UINT8 *inst_buf, bool dbit ) { SetDbit( dbit ); return Decode( inst_buf ); }

	// These routines allow callers to limit inst_buf accesses to only the
	// specified number of bytes (bufferLength).  A CLengthException will be
	// thrown rather than access beyond the specified bufferLength.
	virtual char *Disassemble( AMD_UINT8 *inst_buf, int bufferLength );
	virtual char *Disassemble( AMD_UINT8 *inst_buf, int bufferLength, bool dbit );
	virtual char *Disassemble( AMD_UINT8 *inst_buf, int bufferLength, AMD_UINT64 rip );
	virtual bool Decode( AMD_UINT8 *inst_buf, int bufferLength );
	virtual bool Decode( AMD_UINT8 *inst_buf, int bufferLength, bool dbit );

	// This routine is provided to allow decoding and disassembly in two steps
	// First call Decode to break up the instruction bytes.  Then call this
	// routine to generate the mnemonic.
	virtual char *Disassemble();

	// Use these routines to control the Dbit and long mode/rex32 mode settings
	inline void SetDbit( bool dbit = true ) { m_dbit = dbit; };
	inline void ClearDbit() { m_dbit = false; };
	inline void SetLongMode( bool longmode = true ) { m_longmode = longmode; }
	inline void ClearLongMode() { m_longmode = false; }
	inline void SetRex32Mode( bool rex32mode = true ) { m_rex32mode = rex32mode; }
	inline void ClearRex32Mode() { m_rex32mode = false; }
	inline void SetSvmMode( bool svmmode = true ) { m_svmmode = svmmode; }
	inline void ClearSvmMode() { m_svmmode = false; }

	// Use this routine to turn on/off size qualifier strings for memory references
	// When off, size qualifiers will be provided for ambiguous cases only.
	inline void ShowMemorySize( bool showSize = true ) { m_bShowSize = showSize; }

	// These routines provide control over the case of the mnemonics generated
	inline void SetLowerCase( bool lowercase = true ) { m_bUpperCase = (lowercase == false); }
	inline void SetUpperCase( bool uppercase = true ) { m_bUpperCase = uppercase; }

	// This routine provides control over the character used to seperate the
	// opcode from the operands.  The default seperator is a space " ".
	inline void SetOpcodeSeperator( char *seperator ) { m_opcodeSeperator = seperator; }

	// This routine provides control over the string appended to indicate
	// hexadecimal.  The string pointed to by hexPostfix must remain valid
	// while the disassembler is active.  The default hex post fix is an "h":
	// you can set it to "" to eliminate the hex postfix.
	inline void SetHexPostfix( char *hexPostfix ) { m_hexPostfix = hexPostfix; }

	inline void GetVersion( int &major, int &minor, int &build ) 
	{ 
		major = MAJOR_VERSION;
		minor = MINOR_VERSION;
		build = BUILD_LEVEL;
	}

	// Returns the error level for failed decode attempts
	inline n_Disassembler::e_DisassemblerErrorCodes GetLastError() { return m_errorLevel; }

	// Look at CDisassembler's parent class CInstructionData to see how
	// to query the disassembler object for instruction data.
};

class CExtraExtraInstInfo : public CExtraInstInfo, public std::vector <CExtraInstInfo *>
{
public:
	CExtraInstInfo ** m_pExtraInfoPtr;

	CExtraExtraInstInfo( CExtraInstInfo ** pPtr, size_type t, CExtraInstInfo * ptr ) : std::vector <CExtraInstInfo *> ( t, ptr ) 
	{
		m_pExtraInfoPtr = pPtr;
		*pPtr = (CExtraInstInfo *)this;
	}
	virtual ~CExtraExtraInstInfo()
	{
		*m_pExtraInfoPtr = NULL;
	}
	void Print() {}
};

class CExtraInstInfoDisassembler : public CDisassembler
{
	static std::list <CExtraExtraInstInfo *> m_Hooks;	// list of allocated Vectors
	static unsigned int m_Count;	// number of indices (arraysize) of the vectors of ExtraInfoPtrs
	static unsigned int m_NumRegistered;	// number of registered derivatives.  Vectors are deleted when this goes to zero

public:
	CExtraInstInfoDisassembler(){}
	
	static int RegisterExtraInstInfo() { m_NumRegistered++; return m_Count++; }
	static void UnregisterExtraInstInfo()
	{
		if( --m_NumRegistered == 0 )
		{
			std::list <CExtraExtraInstInfo *>::iterator pos = m_Hooks.begin();
			while( pos != m_Hooks.end() )
				delete * pos++;
			m_Hooks.clear();
			m_Count = 0;
		}
	}

	virtual ~CExtraInstInfoDisassembler()
	{
	}

	CExtraInstInfo * GetExtraInfoPtr( int index )
	{
		CExtraInstInfo * ptr = m_opcode_table_ptr ? m_opcode_table_ptr->pExtraInfo : NULL;
		if( ptr != NULL )
		{
			CExtraExtraInstInfo & extraPtrs = *(CExtraExtraInstInfo *)ptr;
			if( (index >= 0) && ((int)extraPtrs.size() > index) )
				return extraPtrs[index];
		}
		
		return NULL;
	}
	static void HookTableEntry( int index, Inst_Info * pTableEntry, CExtraInstInfo * ptr )
	{
		CExtraExtraInstInfo * extraPtrs;
		if( pTableEntry->pExtraInfo == NULL )
		{
			extraPtrs = new CExtraExtraInstInfo( &(pTableEntry->pExtraInfo), m_Count, NULL );
			m_Hooks.push_back( extraPtrs );
		}
		else
		{
			extraPtrs = (CExtraExtraInstInfo *)(pTableEntry->pExtraInfo);
			if( extraPtrs->size() <= (unsigned int)index )
				extraPtrs->resize( (index + 1), NULL );
		}

		(*extraPtrs)[index] = ptr;
	}
};

#endif
