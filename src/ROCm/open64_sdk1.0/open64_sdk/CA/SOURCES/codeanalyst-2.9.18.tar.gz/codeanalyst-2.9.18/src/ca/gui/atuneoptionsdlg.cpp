//$Id: atuneoptionsdlg.cpp,v 1.3 2006/05/15 22:09:22 jyeh Exp $
//implementation of the CATuneOptionsDlg class.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2006 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdlib.h>
#include <qlayout.h> 
#include <qcombobox.h>
#include <qradiobutton.h>

#include "stdafx.h"
#include "atuneoptionsdlg.h"
#include "helperAPI.h"
//#include "plugin_manager.h" 

#define DEFAULT_OP_PLUGIN OP_091_PLUGIN

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CATuneOptionsDlg::CATuneOptionsDlg (QWidget* parent, const char* name,
				bool modal, WFlags fl )
				: IATuneOptionsDlg( parent, name, modal, fl )
{
	initializeOptions();
}


CATuneOptionsDlg::~CATuneOptionsDlg()
{}


//////////////////////////////////////////////////////////////////////////
// CATuneOptionsDlg::InitializeOptions()
// -------------------------------------
//
void CATuneOptionsDlg::initializeOptions()
{
	DWORD aggdata= AGG_INLINEINSTANCE;
	DWORD aggctrl = NO_SHOW_AGG_CONTROLLER;
	DWORD bypass = NO_BYPASS_SOURCE;
	DWORD alert  = NO_SOURCE_ALERT;
	DWORD replace_system = REPLACE_SYSDIR;
	DWORD hot_keys = NO_HK_USE;
	DWORD font_size = FONT_SIZE_DEFAULT;
	QString projdir = "";
	CATuneOptions ao;

	ao.getDataAggregation( &aggdata);
	ao.getShowAggregationController( &aggctrl);
	ao.getAlertNoSource ( &alert );
	ao.getBypassSource ( &bypass );
	ao.getDefaultProjectDir (projdir);
	ao.getReplaceSysDir ( &replace_system );
	ao.getUseHotKeys ( &hot_keys );
	ao.getFontSize ( &font_size);

	if (SOURCE_ALERT == alert )
		m_alert_no_src_avail->setChecked( TRUE );

	if ( BYPASS_SOURCE == bypass)
		m_bypass_src_code->setChecked( TRUE );

#ifdef ENABLE_DWARF
	switch(aggdata) {
		case AGG_INLINEFUNCTION:
			m_pInlineFunc->setChecked(TRUE);
			break;
		case AGG_BASICBLOCK:
			m_pBasicBlock->setChecked(TRUE);
			break;
		case AGG_INLINEINSTANCE:
		default:
			m_pInlineInstance->setChecked(TRUE);
			break;
	}
#else
	/* Hide check box and change description */
	m_pInlineInstance->setText("Aggregate samples into function");
	m_pInlineFunc->hide();
	switch(aggdata) {
		case AGG_BASICBLOCK:
			m_pBasicBlock->setChecked(TRUE);
			break;
		case AGG_INLINEFUNCTION:
		case AGG_INLINEINSTANCE:
		default:
			m_pInlineInstance->setChecked(TRUE);
			break;
	}
#endif

	if ( SHOW_AGG_CONTROLLER == aggctrl) 
		m_pAggCtrlBox->setChecked(TRUE);

	switch (font_size) {
	case FONT_SIZE_DEFAULT:
		m_font_size->setCurrentItem (FONT_CMB_DEFAULT);
		break;
	case FONT_SIZE_SMALL:
		m_font_size->setCurrentItem (FONT_CMB_SMALL);
		break;
	case FONT_SIZE_LARGE:
		m_font_size->setCurrentItem (FONT_CMB_LARGE);
		break;
	}

	if (!projdir.isEmpty())
		m_default_project_dir->setText ( projdir );
	else 
		m_default_project_dir->setText ( QDir::home().path() 
						+ "/AMD/CodeAnalyst/");

	initializeSearchPaths();
//	initializePluginSelection(ao);
}


//////////////////////////////////////////////////////////////////////////
// CATuneOptionsDlg::InitializeSearchPaths()
// -----------------------------------------
//
void CATuneOptionsDlg::initializeSearchPaths()
{
	QString paths;
	CATuneOptions ao;
	int i;
	QGridLayout * src_layout =  new QGridLayout( m_src_group->layout() );

	src_layout->setAlignment( Qt::AlignTop );
	for (i = 0; i < SOURCE_SEARCH_COUNT; i++) {
		m_src_dirs[i] = new QLineEdit ( m_src_group );
		src_layout->addWidget ( m_src_dirs[i], i, 0 );

		m_src_dir_browse[i] = new ElementPushButton ("Browse", m_src_group);
		m_src_dir_browse[i]->setMaximumSize( QSize( 50, 21 ) );
		m_src_dir_browse[i]->setCpu (i);
		QObject::connect (m_src_dir_browse[i], SIGNAL (pushClicked (int, 
			int )),
			this, SLOT (onSourcePathBrowse (int, int)));

		src_layout->addWidget( m_src_dir_browse[i], i, 1 );
	}

	ao.getDebugSearchPaths (paths);

	if (!paths.isEmpty()) {
		for (i = 0; i < SOURCE_SEARCH_COUNT; i++) {
			QString temp = paths.section (';', i, i);
			m_src_dirs[i]->setText ( temp );
		}
	}
}


void CATuneOptionsDlg::initializePluginSelection(CATuneOptions & ao)
{
	Q_UNUSED(ao);
#if 0
	QString pluginName;
	unsigned int index = OP_091;

	ao.getOPPlugIn(pluginName);
/*
	if (pluginName.isEmpty())
		pluginName = DEFAULT_OP_PLUGIN;
*/
	index =  OP_091;
	m_op_plugin->setCurrentItem(index);

	/* 
	*NOTE: In CA 2.7, we are not using this,
	* but we still keep it for future.
	* Setting it to default (OP_091).
	*/
	m_op_plugin->hide();
	TextLabel1_2_2_2_3->hide();
#endif
}


//////////////////////////////////////////////////////////////////////////
// CATuneOptionsDlg::SaveSearchPaths()
// -----------------------------------
//
void CATuneOptionsDlg::saveSearchPaths (CATuneOptions &ao)
{
	QString paths;

	for (int i = 0; i < SOURCE_SEARCH_COUNT; i++)
		paths += m_src_dirs[i]->text() + ";";

	ao.setDebugSearchPaths( paths);
}


//////////////////////////////////////////////////////////////////////////
// CATuneOptionsDlg::SaveOptions()
// -------------------------------
//
void CATuneOptionsDlg::saveOptions()
{
	DWORD aggdata = AGG_INLINEINSTANCE;
	DWORD aggctrl = NO_SHOW_AGG_CONTROLLER;
	DWORD bypass = NO_BYPASS_SOURCE;
	DWORD alert  = NO_SOURCE_ALERT;
	DWORD replace_system = REPLACE_SYSDIR;
	DWORD hot_keys = NO_HK_USE;
	DWORD font_size = FONT_SIZE_DEFAULT;
	DWORD temp = FONT_SIZE_DEFAULT;
	QString projdir = "";
	QString op_plugin = "";
	CATuneOptions ao;

	if (m_pInlineFunc->isChecked()) 
		aggdata = AGG_INLINEFUNCTION;
	if (m_pBasicBlock->isChecked())
		aggdata = AGG_BASICBLOCK;
	if (m_pInlineInstance->isChecked())
		aggdata = AGG_INLINEINSTANCE;

	if (m_pAggCtrlBox->isChecked())
		aggctrl = SHOW_AGG_CONTROLLER;

	if ( m_alert_no_src_avail->isChecked() )
		alert = SOURCE_ALERT;

	if ( m_bypass_src_code->isChecked() )
		bypass = BYPASS_SOURCE;

	projdir = m_default_project_dir->text();

	ao.getFontSize (&temp);

	switch (m_font_size->currentItem()) {
		case FONT_CMB_DEFAULT:
			font_size = FONT_SIZE_DEFAULT;
			break;
		case FONT_CMB_SMALL:
			font_size = FONT_SIZE_SMALL;
			break;
		case FONT_CMB_LARGE:
			font_size = FONT_SIZE_LARGE;
			break;
	}

/*
	switch (m_op_plugin->currentItem()) {
		default:
		case OP_091:
			//op_plugin = OP_091_PLUGIN;
			break;
	}
*/
	if (temp != font_size) {
		qApp->setFont (QFont (qApp->font().family(), font_size), TRUE);
		ao.setFontSize (font_size);
	}

	ao.setDataAggregation(aggdata);
	ao.setShowAggregationController(aggctrl);
	ao.setAlertNoSource (alert);
	ao.setBypassSource (bypass);
	ao.setDefaultProjectDir (projdir);
	ao.setReplaceSysDir (replace_system);
	ao.setUseHotKeys (hot_keys);
	ao.setOPPlugIn(op_plugin);

	saveSearchPaths (ao);
}


bool CATuneOptionsDlg::validateOptions()
{
	// TODO: To be implemented
	return true;
}

void CATuneOptionsDlg::onOk()
{
	if (validateOptions()) {
		saveOptions();
		accept();
	}
}


void CATuneOptionsDlg::onApply()
{
	if (validateOptions()) {
		saveOptions();
	}
}


//////////////////////////////////////////////////////////////////////////
// CATuneOptionsDlg::OnProjectDirectoryBrowse()
// --------------------------------------
//
void CATuneOptionsDlg::onProjectDirectoryBrowse()
{
	QString path;

	path = QFileDialog::getExistingDirectory (
		m_default_project_dir->text(), this, NULL, "Select a project "
		"directory");

	if( !path.isNull() )
		m_default_project_dir->setText (path);
}


void CATuneOptionsDlg::onSourcePathBrowse (int index, int)
{
	QString path;

	path = QFileDialog::getExistingDirectory ( m_src_dirs[index]->text(),
		this, NULL, "Select a "
		"source file directory");

	if( !path.isNull() )
		m_src_dirs[index]->setText (path);
}

ElementPushButton::ElementPushButton (const QString & text, 
					QWidget * parent,
					const char * name)
: QPushButton (text, parent, name)
{
	m_cpu = 0;
	m_event = 0;
	QObject::connect (this, SIGNAL (clicked ()), this, SLOT (onClicked ()));
}


void ElementPushButton::setCpu ( int cpu)
{
	m_cpu = cpu;
}


void ElementPushButton::setEvent (int event)
{
	m_event = event;
}

void ElementPushButton::onClicked ()
{
	emit pushClicked (m_cpu, m_event);
}
