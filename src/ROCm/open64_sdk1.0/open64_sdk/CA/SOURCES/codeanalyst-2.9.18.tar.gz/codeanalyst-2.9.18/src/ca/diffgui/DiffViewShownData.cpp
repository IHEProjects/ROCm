
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include "DiffViewShownData.h"

#define DV_DEBUG 0

DiffViewShownData::DiffViewShownData()
{
	m_viewCount 		= 0;	
}

DiffViewShownData::~DiffViewShownData()
{

}

void DiffViewShownData::addViewShownData(ViewShownData *vs)
{
	m_viewShownVec.push_back(vs);
	m_viewCount++;
}

void DiffViewShownData::rearrangeViewDelta(int *nextCol, bool isSeparateCpu)
{
	for(int i = 0 ; i < m_viewCount ; i++)
	{
		// Insert Address
		QString tmp = QString("[") + QString::number(i) + "] - Address";	
		m_columnMap.insert(DiffCpuEventType(-1,0,0,i),	
			DiffViewColumnInfo(true,*nextCol,ADDR_COL,tmp));
		(*nextCol)++;
	}

	for(int i = 0 ; i < m_viewCount ; i++)
	{
		// Insert Data from ViewShown
		CpuEventViewIndexMap::iterator i_it = m_viewShownVec[i]->indexes.begin(); 
		CpuEventViewIndexMap::iterator i_end = m_viewShownVec[i]->indexes.end(); 
		for(; i_it != i_end ; i_it++)
		{
				//----------------------------------
				// Check if event should be shown
				bool isColShown = false;
				IndexVector::iterator s_it = m_viewShownVec[i]->shown.begin();
				IndexVector::iterator s_end = m_viewShownVec[i]->shown.end();
				for(; s_it != s_end ; s_it++)
				{
					if((*s_it) == i_it.data())
					{
						isColShown = true;
						break;
					}
				}
			
				//----------------------------------
				// Prepare key
				DiffCpuEventType key;
				if(isSeparateCpu)
				{
					key = DiffCpuEventType(i_it.key().cpu,
							i_it.key().event,
							i_it.key().umask,
							-1);
				}else{
					key = DiffCpuEventType (-1,		// All CPU
							i_it.key().event,
							i_it.key().umask,
							-1);
				}
				if(m_columnMap.find(key) == m_columnMap.end())
				{
					// Prepare data
					QString tmp = QString("Delta ") + m_viewShownVec[i]->available[i_it.data()];
					DiffViewColumnInfo data = DiffViewColumnInfo(isColShown,(*nextCol),DATA_COL,tmp);
					m_columnMap.insert(key, data);	

					// Generate ConverterKey
					ConvertKey cKey(-1,i_it.data());
					if( m_indexConverter.find(cKey) == m_indexConverter.end())
					{
						m_indexConverter.insert(cKey, *nextCol);
					}
					(*nextCol)++;
				}
		}
/*
TODO: We do not show delta complex value at this point. So, we do not need complex columns
		// Insert Complex data from ViewShown
		ComplexDependentMap::iterator c_it = m_viewShownVec[i]->calculated.begin();
		ComplexDependentMap::iterator c_end = m_viewShownVec[i]->calculated.end();
		for(; c_it != c_end ; c_it++)
		{
			fprintf(stderr,"calculated key = %d\n",c_it.key());
			ListOfComplex::iterator it = c_it.data().begin();
			ListOfComplex::iterator end = c_it.data().end();
			for(; it != end ; it++)
			{
				fprintf(stderr,"complex list: columnIndex =  %d, op1Index= %d, op2Index = %d\n",
					(*it).columnIndex, 
					(*it).op1Index,
					(*it).op2Index); 
		
				// Generate Diff Complex Key
				ConvertKey lKey(-1,(*it).op1Index);
				int newL = m_indexConverter[lKey];
				ConvertKey rKey(-1,(*it).op2Index);
				int newR = m_indexConverter[rKey];
				ComplexKey key(-1, newL, newR, (*it).complexType);
				if(m_complexColumnMap.find(key) == m_complexColumnMap.end())
				{
					QString colName = m_viewShownVec[i]->available[(*it).columnIndex];
					QString tmp = QString("Delta") + ":" + colName;
					DiffViewColumnInfo data(true,*nextCol,COMPLEX_COL,tmp);
					m_complexColumnMap.insert(key,data);
					(*nextCol)++;
				}

			}
		}
*/
	}

} //DiffViewShownData::rearrangeViewDelta

void DiffViewShownData::rearrangeViewSideBySide(int *nextCol, bool isSeparateCpu)
{
	for(int i = 0 ; i < m_viewCount ; i++)
	{
		// Insert Address
		QString tmp = QString("[") + QString::number(i) + "] - Address";	
		m_columnMap.insert(DiffCpuEventType(-1,0,0,i),	
			DiffViewColumnInfo(true,*nextCol,ADDR_COL,tmp));
		(*nextCol)++;
	}

	for(int i = 0 ; i < m_viewCount ; i++)
	{
		// Insert Data from ViewShown
		CpuEventViewIndexMap::iterator i_it = m_viewShownVec[i]->indexes.begin(); 
		CpuEventViewIndexMap::iterator i_end = m_viewShownVec[i]->indexes.end(); 
		for(; i_it != i_end ; i_it++)
		{
			// For each Session Diff
			for(int j = 0 ; j < m_viewCount ; j++)
			{
				//----------------------------------
				// Check if event should be shown
				bool isColShown = false;
				IndexVector::iterator s_it = m_viewShownVec[i]->shown.begin();
				IndexVector::iterator s_end = m_viewShownVec[i]->shown.end();
				for(; s_it != s_end ; s_it++)
				{
					if((*s_it) == i_it.data())
					{
						isColShown = true;
						break;
					}
				}
			
				//----------------------------------
				// Prepare key
				DiffCpuEventType key;
				if(isSeparateCpu)
				{
					key = DiffCpuEventType(i_it.key().cpu,	// Separate CPU
							i_it.key().event,
							i_it.key().umask,
							j);
				}else{
					key = DiffCpuEventType(-1,		// All CPU
							i_it.key().event,
							i_it.key().umask,
							j);
				}

				if(m_columnMap.find(key) == m_columnMap.end())
				{
					// Prepare data
					QString tmp = QString("[") + QString::number(j) + "] - " 
							+ m_viewShownVec[i]->available[i_it.data()];
					DiffViewColumnInfo data = DiffViewColumnInfo(isColShown,*nextCol,DATA_COL,tmp);
					m_columnMap.insert(key, data);	
#if DV_DEBUG
fprintf(stderr,"DV_DEBUG : rearrangeViewSideBySide: Column Name= %s, Index = %d\n",tmp.data(),*nextCol);
#endif

					// Generate ConverterKey
					ConvertKey cKey(j,i_it.data());
					if( m_indexConverter.find(cKey) == m_indexConverter.end())
					{
						m_indexConverter.insert(cKey, *nextCol);
					}

					(*nextCol)++;
				}
			}
		}

		// Insert Complex data from ViewShown
		ComplexDependentMap::iterator c_it = m_viewShownVec[i]->calculated.begin();
		ComplexDependentMap::iterator c_end = m_viewShownVec[i]->calculated.end();
		for(; c_it != c_end ; c_it++)
		{
			ListOfComplex::iterator it = c_it.data().begin();
			ListOfComplex::iterator end = c_it.data().end();
			for(; it != end ; it++)
			{
#if DV_DEBUG
fprintf(stderr,"complex list: calculated key %d, columnIndex =  %d, op1Index= %d, op2Index = %d\n",
		c_it.key(),
		(*it).columnIndex, 
		(*it).op1Index,
		(*it).op2Index); 
#endif
		
				//----------------------------------
				// Check if event should be shown
				bool isColShown = false;
				IndexVector::iterator s_it = m_viewShownVec[i]->shown.begin();
				IndexVector::iterator s_end = m_viewShownVec[i]->shown.end();
				for(; s_it != s_end ; s_it++)
				{
					if( (*s_it) == (*it).columnIndex)
					{
						isColShown = true;
						break;
					}
				}
			
				//----------------------------------
				for(int j = 0 ; j < m_viewCount ; j++)
				{
					// Generate Diff Complex Key
					ConvertKey lKey(j,(*it).op1Index);
					int newL = m_indexConverter[lKey];
					ConvertKey rKey(j,(*it).op2Index);
					int newR = m_indexConverter[rKey];
					ComplexKey key(j, newL, newR, (*it).complexType);
					if(m_complexColumnMap.find(key) == m_complexColumnMap.end())
					{
						QString colName = m_viewShownVec[j]->available[(*it).columnIndex];
						QString tmp = QString("[") + QString::number(j) + "] - " + colName;
						DiffViewColumnInfo data(isColShown,*nextCol,COMPLEX_COL,tmp);
						m_complexColumnMap.insert(key,data);
						(*nextCol)++;
					}

				}
			}
		}

	}
}// DiffViewShownData::rearrangeViewSideBySide

void DiffViewShownData::rearrangeViewLeftRight(int *nextCol, bool isSeparateCpu)
{
	for(int i = 0 ; i < m_viewCount ; i++)
	{
		// Insert Address
		QString tmp = QString("[") + QString::number(i) + "] - Address";	
		m_columnMap.insert(DiffCpuEventType(-1,0,0,i),	
			DiffViewColumnInfo(true,*nextCol,ADDR_COL,tmp));
		(*nextCol)++;

		// Insert Data from ViewShown
		CpuEventViewIndexMap::iterator i_it = m_viewShownVec[i]->indexes.begin(); 
		CpuEventViewIndexMap::iterator i_end = m_viewShownVec[i]->indexes.end(); 
		for(; i_it != i_end ; i_it++)
		{
			//----------------------------------
			// Check if event should be shown
			bool isColShown = false;
			IndexVector::iterator s_it = m_viewShownVec[i]->shown.begin();
			IndexVector::iterator s_end = m_viewShownVec[i]->shown.end();
			for(; s_it != s_end ; s_it++)
			{
				if((*s_it) == i_it.data())
				{
					isColShown = true;
					break;
				}
			}
		
			//----------------------------------
			// Prepare key
			DiffCpuEventType key;
			if(isSeparateCpu)
			{
				key = DiffCpuEventType(i_it.key().cpu,
						i_it.key().event,
						i_it.key().umask,
						i);
			}else{
				key = DiffCpuEventType(-1,		// All CPU
						i_it.key().event,
						i_it.key().umask,
						i);
			}
			
			if(m_columnMap.find(key) == m_columnMap.end())
			{
				// Prepare data
				QString tmp = QString("[") + QString::number(i) + "] - " + m_viewShownVec[i]->available[i_it.data()];
				DiffViewColumnInfo data = DiffViewColumnInfo(isColShown,*nextCol,DATA_COL,tmp);
				m_columnMap.insert(key, data);	

				// Generate ConverterKey
				ConvertKey cKey(i,i_it.data());
				if( m_indexConverter.find(cKey) == m_indexConverter.end())
				{
					m_indexConverter.insert(cKey, *nextCol);
				}

				(*nextCol)++;
				
#if DV_DEBUG 
fprintf(stderr,"DV_DEBUG: rearrangeViewLeftRight: Column Name= %s, event = %llx, umask = %llx, Index = %d\n",
						tmp.data(), i_it.key().event, i_it.key().umask, *nextCol);
#endif
			}
		}

		// Insert Complex data from ViewShown
		ComplexDependentMap::iterator c_it = m_viewShownVec[i]->calculated.begin();
		ComplexDependentMap::iterator c_end = m_viewShownVec[i]->calculated.end();
		for(; c_it != c_end ; c_it++)
		{
			ListOfComplex::iterator it = c_it.data().begin();
			ListOfComplex::iterator end = c_it.data().end();
			for(; it != end ; it++)
			{
#if DV_DEBUG 
fprintf(stderr,"complex list: calculated key = %d, columnIndex =  %d, op1Index= %d, op2Index = %d\n",
		c_it.key(),
		(*it).columnIndex, 
		(*it).op1Index,
		(*it).op2Index); 
#endif
				//----------------------------------
				// Check if event should be shown
				bool isColShown = false;
				IndexVector::iterator s_it = m_viewShownVec[i]->shown.begin();
				IndexVector::iterator s_end = m_viewShownVec[i]->shown.end();
				for(; s_it != s_end ; s_it++)
				{
					if( (*s_it) == (*it).columnIndex)
					{
						isColShown = true;
						break;
					}
				}
			
				//----------------------------------
		
				// Generate Diff Complex Key
				ConvertKey lKey(i,(*it).op1Index);
				int newL = m_indexConverter[lKey];
				ConvertKey rKey(i,(*it).op2Index);
				int newR = m_indexConverter[rKey];
				ComplexKey key(i, newL, newR, (*it).complexType);
				if(m_complexColumnMap.find(key) == m_complexColumnMap.end())
				{
					QString colName = m_viewShownVec[i]->available[(*it).columnIndex];
					QString tmp = QString("[") + QString::number(i) + "] - " + colName;
					DiffViewColumnInfo data(isColShown,*nextCol,COMPLEX_COL,tmp);
					m_complexColumnMap.insert(key,data);
					(*nextCol)++;
				}
			}
		}
	}	
} // DiffViewShownData::rearrangeViewLeftRight

void DiffViewShownData::rearrangeView(bool isSeparateCpu)
{
	m_columnMap.clear();
	int  nextCol = 0;
	
	// Insert Symbol
	m_columnMap.insert( DiffCpuEventType(-1,0,0,-1),	
		DiffViewColumnInfo(true,0,SYMBOL_COL,QString("Symbol")));
	nextCol++;


	if(m_diffViewOptions.showSideBySide) 
	{
		rearrangeViewSideBySide(&nextCol,isSeparateCpu);
	} else if(m_diffViewOptions.showDelta) {
		rearrangeViewDelta(&nextCol,isSeparateCpu);
	} else {
		rearrangeViewLeftRight(&nextCol,isSeparateCpu);
	}


#if DV_DEBUG // BEGIN DEBUG: 
{
	fprintf(stderr,"DV_DEBUG: rearrangeView: \n"); 
	DiffViewColumnInfoMap::iterator it = m_columnMap.begin();
	DiffViewColumnInfoMap::iterator end = m_columnMap.end();
	for(; it != end ; it++)
	{
		fprintf(stderr,
		"DataCol : diffIndex = %d, cpu = %d, event = %llx, umask = %llx | name = %s, index = %d, type = %d\n",
				(it.key()).diffIndex,
				(it.key()).cpu,
				(it.key()).event,
				(it.key()).umask,
				(it.data()).colName.data(),
				(it.data()).colIndex,
				(it.data()).colType);
	}
}
{
	ComplexColumnInfoMap::iterator it = m_complexColumnMap.begin();
	ComplexColumnInfoMap::iterator end = m_complexColumnMap.end();
	for(; it != end; it++)
	{
		fprintf(stderr,
		"ComplexCol : diffIndex = %d, left = %d, right = %d, op = %d, colName = %s, colIndex = %d, colType = %d\n",
				(it.key()).diffIndex,
				(it.key()).LopIndex,
				(it.key()).RopIndex,
				(it.key()).opType,
				(it.data().colName.data()),
				(it.data().colIndex),
				(it.data().colType));
			
	}
}
#endif // END DV_DEBUG: 

				
}

unsigned int DiffViewShownData::getSampleColumnMap(DiffViewColumnInfoMap** pMap )
{
	*pMap = &m_columnMap;
	return m_columnMap.size();
}

unsigned int DiffViewShownData::getComplexColumnMap(ComplexColumnInfoMap** pMap )
{
	*pMap = &m_complexColumnMap;
	return m_complexColumnMap.size();
}

int DiffViewShownData::getDiffIndex(int col, bool *isAddr)
{
	int ret = -1;
	DiffViewColumnInfoMap::iterator it = m_columnMap.begin();
	DiffViewColumnInfoMap::iterator end = m_columnMap.end();
	for(; it != end ; it++)
	{
		if(col == it.data().colIndex)
		{
			ret = it.key().diffIndex;
			if(isAddr != NULL)
			{
				if(it.data().colType == ADDR_COL)
				{
					*isAddr = true;
				}else{
					*isAddr = false;
				}
			}	
			return ret;
		}
	}

	///////////////////////////
	ComplexColumnInfoMap::iterator cit = m_complexColumnMap.begin();
	ComplexColumnInfoMap::iterator cend = m_complexColumnMap.end();
	for(;cit != cend ; cit++)
	{
		if(col == cit.data().colIndex)
		{
			ret = cit.key().diffIndex;
			if(isAddr != NULL)
			{
				if(cit.data().colType == ADDR_COL)
				{
					*isAddr = true;
				}else{
					*isAddr = false;
				}
			}	
			return ret;
		}

	}
	return ret;
}

