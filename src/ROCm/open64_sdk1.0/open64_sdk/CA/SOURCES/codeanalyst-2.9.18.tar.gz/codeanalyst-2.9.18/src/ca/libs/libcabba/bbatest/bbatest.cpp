
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bbanalysis.h"

#include <map>

#define DEBUG 

using namespace std;

char *binaryfile = NULL;
char *bba_output = NULL;
char *bba_input = NULL;


bool g_dumpblock = false;
bool g_dumpjump = false;
bool g_dumpcall = false;
bool g_dumpreturn = false;
bool g_dumpmemory = false;
bool g_dumpdest = false;
 
BBAnalysis g_bba;

//	printf("Usage: %s -[bjcrmd] -o output.bba -i input.bba binaryfile\n",
char *usage_strings[] = {
	" -b	: dump basic block info",
	" -j	: dump jump instruction info",
	" -c	: dump call instruction info",
	" -r	: dump return intruction info",
	" -m	: dump memory access info",
	" -d	: dump branch destination info",
	" -o fn	: specify output file name",
	" -i fn	: specify input file name",
	NULL	
};


bool 
parseArgs(int argc, char **argv)
{
	bool bret = true;
	int arglen = 0;

	for (int cnt = 1; cnt < argc; cnt++) {
		if (argv[cnt][0] == '-') {
			arglen = strlen(argv[cnt]);
		
			if (arglen < 2) {
				bret = false;
				break;
			}

			for (int i = 1; i < arglen; i++) {
				switch(argv[cnt][i]) {
				case 'b':	
					g_dumpblock = true;
					break;
				case 'j':
					g_dumpjump = true;
					break;
				case 'c':
					g_dumpcall = true;
					break;
				case 'r': 
					g_dumpreturn = true;
					break;
				case 'm':
					g_dumpmemory = true;
					break;
				case 'd':
					g_dumpdest = true;
					break;
				case 'o':
					if (i == 1) {
						if (++cnt < argc) {
							bba_output = argv[cnt];	
						} else {
							bret = false;
						}
					}	
					break;
				case 'i':
					if (i == 1) {
						if (++cnt < argc)
							bba_input = argv[cnt];
						else
							bret = false;
					}
					break;
					
				default:
#ifdef DEBUG
					printf("Unknown argument ('%s') is ignored\n", argv[cnt]);
#endif
				}
			}
		}
		else if (cnt + 1 == argc) {
			binaryfile = argv[cnt];
		}
		else {
#ifdef DEBUG
			printf("Unknown argument ('%s') is ignored\n", argv[cnt]);
#endif
		}
	}

	if (binaryfile) {
		if(bba_input) {
#ifdef DEBUG
			printf("Both bianry file and input are specified. "
					"The input file is ignored\n");
#endif
			bba_input = NULL;
		}
	} else {
		if (!bba_input) {
#ifdef DEBUG
			printf("Need to specify bianry file or input file.\n");
#endif
			bret = false;
		}

		if (bba_output) {
#ifdef DEBUG
			printf("Need to specify a bianry file to analyze to generate\n"
					"output file. The bianry is not specified. The output\n" 
					"file will be ignored\n\n");
#endif
		}
	}
	return bret;
}


void 
summarizeArgs()
{
	printf("********* Argument Summary **********\n");

	printf("Target file : %s\n", (binaryfile) ? binaryfile : " ");
	printf("Input file  : %s\n", (bba_input) ? bba_input: " ");
	printf("Output file : %s\n", (bba_output) ? bba_output: " ");

	printf("dump block  : %s\n", (g_dumpblock) ? "On" : "Off");
	printf("dump jump   : %s\n", (g_dumpjump) ? "On" : "Off");
	printf("dump call   : %s\n", (g_dumpcall) ? "On" : "Off");
	printf("dump return : %s\n", (g_dumpreturn) ? "On" : "Off");
	printf("dump memory : %s\n", (g_dumpmemory) ? "On" : "Off");
	printf("dump br dest: %s\n", (g_dumpdest) ? "On" : "Off");

	printf("*************************************\n");
}



void 
print_usage(char *app)
{
	char **msg;

	printf("Usage: %s -[bjcrmd] -o output.bba -i input.bba binaryfile\n",
					app);
	
	for (msg = usage_strings; *msg != NULL; msg++)
		printf("%s\n", *msg);
}

void 
printInstrType(unsigned int type)
{
	switch(type) {
		case INSTR_OTHER_TYPE:       // the type we don't care
			printf("Other   ");
			break;

		case BR_COND_JUMP:
			printf("CONDJUMP");
			break;


		case BR_RELATIVE_JUMP:
			printf("REL_JUMP");
			break;

		case BR_ABS_JUMP:
			printf("ABS_JUMP");
			break;

		case BR_ABS_INDIRECT_JUMP:   // don't care jump near or far
			printf("IND_JUMP");
			break;

		case BR_RELATIVE_CALL:
			printf("REL_CALL");
			break;

		case BR_ABS_CALL:
			printf("ABS_CALL");
			break;

		case BR_ABS_INDIRECT_CALL:
			printf("IND_CALL");
			break;

		case BR_SYSCALL:
			printf("SYS_CALL");
			break;

		case BR_SYSRET:
			printf("SYS_RET");
			break;

			    // BR_ENTER, INT, IRET/IRETD
		case BR_RET:
			printf("RET     ");
			break;

		default:
		case INSTR_UNKNOWN:
			printf("Unknown ");
			break;
	}
}
bool 
dump_block_info()
{
	bool bret = OK;
	BASIC_BLOCK_INFO bb;
	int rc = OK;
	unsigned int reads;
	unsigned int writes;

	int blocknum = g_bba.bba_get_block_num();

	unsigned int imagebase = (unsigned int) g_bba.bba_get_image_base();	
	printf("\n\n");
	printf("***************************************************************\n");
	printf("************************* Basic Blocks ************************\n");
	printf("Image base = %08x\n", imagebase);
	printf("Number of block: %d\n", blocknum);
	
	printf("|  Num  |  Start |   End  |EndInstr|  Read  |  Write |InstType|\n");
	printf("---------------------------------------------------------------\n");
	for (int i = 0; i < blocknum; i++) {
		if (i == 0)
			rc = g_bba.bba_get_first_basicblock(&bb);
		else
			rc = g_bba.bba_get_next_basicblock(&bb);

		if (rc != OK) {
			bret = false;
			break;
		}
	
		rc = g_bba.bba_get_memory_accesses(bb.bb_start_offset,&reads, &writes);
		if (rc != OK) {
			bret = false;
			break;
		}

		printf("%8d %8x %8x %8x %8d %8d ", i,
					imagebase + bb.bb_start_offset,
					imagebase + bb.bb_start_offset + bb.bb_size,
					imagebase + bb.bb_start_offset + bb.bb_size - 
					bb.bb_end_instr_length,
					reads, writes);

		printInstrType(bb.bb_end_instr_type);
		printf("\n");


	}

	printf("********************* End of Basic Blocks *********************\n");
	printf("***************************************************************\n");

	return bret;
}

bool
dump_br_info(BRANCHINSTRMAP *pmap, const char* str)
{
	bool bret = OK;
	BRANCHINSTRMAP::iterator iter;
	if (!pmap)
		return false;


	unsigned int imagebase = (unsigned int) g_bba.bba_get_image_base();
	printf("\n\n");
	printf("***************************************************************\n");
	printf("*************************** %s Instr ************************\n",
					str);

	printf("Image base = %08x\n", imagebase);
	printf("Number of block: %d\n", (unsigned int) pmap->size());
	printf("|  Num  |InstrOff| InstLen|DestOff|JumpType|\n");
	printf("---------------------------------------------\n");

	int i = 0;	
	for (iter = pmap->begin(); iter != pmap->end(); iter++) {
		printf("%8d %8x %8d %8x ",
				++i,
				imagebase + iter->second.instr_offset, 
				iter->second.instr_length,
				imagebase + iter->second.destination_offset);

		printInstrType(iter->second.instr_type);
		printf("\n");
	}
	printf("*********************** End of %s Instr *********************\n", 
					str);
	printf("***************************************************************\n");
	return bret;
}


bool 
dump_memory_info()
{
	bool bret = OK;
	MEMACCESSMAP* pmap = NULL;

	pmap = g_bba.bba_get_mem_map();
	if (!pmap)
		return false;

	MEMACCESSMAP::iterator iter;

	printf("\n\n");
	printf("***************************************************************\n");
	printf("************************** Memory Access **********************\n");
	printf("Memory access: %d\n", pmap->size());
	unsigned int imagebase = (unsigned int) g_bba.bba_get_image_base();
	
	printf("|  instr Addr   |   access type  |\n");
	printf("---------------------------------------------\n");

	for (iter = pmap->begin(); iter != pmap->end(); iter++) {
		printf("   %8x         ", iter->first + imagebase);

		switch(iter->second) {
			case 0x01:
				printf("Read\n");
				break;
			case 0x02:
				printf("Write\n");
				break;
			case 0x03:
				printf("Read/Write\n");
				break;
			default:
			case 0: 
				printf("NA\n");
				break;
		}

	}

	printf("***************************************************************\n");
	return bret;
}


bool 
dump_br_dest_info()
{
	bool bret = OK;
	MULTIMAP::iterator iter;
	MULTIMAP* pmap = NULL;
	pmap = g_bba.bba_get_br_dest_map();
	if (!pmap)
		return false;

	unsigned int imagebase = (unsigned int) g_bba.bba_get_image_base();
	printf("\n\n");
	printf("***************************************************************\n");
	printf("************************ Branch Destination *******************\n");
	printf("Memory access: %d\n", pmap->size());

	printf("|   destination  |   branch instr |\n");
	printf("---------------------------------------------\n");

	for (iter = pmap->begin(); iter != pmap->end(); iter++) {
		printf("   %8x         %8x \n",
					imagebase + iter->first,
					imagebase + iter->second);
	}
	printf("***************************************************************\n");
	return bret;
}




int main(int argc, char **argv)
{

	BRANCHINSTRMAP *pmap = NULL;

	if (argc < 2) {
		print_usage(argv[0]);	
		exit (EXIT_FAILURE);
	}

	if (!parseArgs(argc, argv)) {
		print_usage(argv[0]);
		exit(EXIT_FAILURE);
	}

#ifdef DEBUG
	summarizeArgs();
#endif	

	if (binaryfile)	 {
		if (g_bba.bba_init(binaryfile) != OK) {
			printf("Failed to intialize '%s' \n", binaryfile);
			exit(EXIT_FAILURE);
		}

		if (g_bba.bba_analyze_all() != OK) {
			printf("Failed to analyze '%s' \n", binaryfile);
			exit(EXIT_FAILURE);
		}

		if ((bba_output) && g_bba.bba_write_output(bba_output) != OK) {
			printf("Failed to write basic block analysis into "
						"'%s' \n", bba_output);
			exit(EXIT_FAILURE);
		}


	} else { 
		if (g_bba.bba_read_datafile(bba_input) != OK) {
			printf("Failed to read bba input file %s\n", bba_input);
			exit(EXIT_FAILURE);
		}
	}

	if (g_dumpblock) {
		dump_block_info();	
	}

	if (g_dumpjump) {
		pmap = g_bba.bba_get_jump_map();
		dump_br_info(pmap, "Jump");
	}

	if (g_dumpcall) {
		pmap = g_bba.bba_get_call_map();
		dump_br_info(pmap, "Call");
	}

	if (g_dumpreturn) {
		pmap = g_bba.bba_get_ret_map();
		dump_br_info(pmap, "Ret ");
	}

	if (g_dumpmemory)
		dump_memory_info();

	if(g_dumpdest)
		dump_br_dest_info();

	return 0;

}


/*
int test()
{
	BBAnalysis bba;
	char binaryfile[200];
	int bb_cnt;
	strcpy(binaryfile, "/home/lei/temp/null/example");
	int rc = bba.bba_init(binaryfile);
	if (rc != OK) { 
		printf("Failed to open\n");
		exit(0);
	}

	long long base = bba.bba_get_image_base();
	if((rc = bba.bba_analyze_all()) == OK) {
		bb_cnt = bba.bba_get_block_num();
		BASIC_BLOCK_INFO bbinfo;
		for (int i = 0; i < bb_cnt; i++) {
			if (i == 0) 
				rc = bba.bba_get_first_basicblock(&bbinfo);
			else
				rc = bba.bba_get_next_basicblock(&bbinfo);

			if (rc == OK) {
				printf("[%llx - %llx) : ", base + bbinfo.bb_start_offset,
							base + bbinfo.bb_start_offset + bbinfo.bb_size);
				unsigned int reads, writes;
				rc = bba.bba_get_memory_accesses(bbinfo.bb_start_offset,
							&reads, &writes);
				if (rc == OK) {
					printf("r-%d, w-%d\n", reads, writes);
				} else {
					printf("failed to get read/write\n");
				}	
			} else {
				printf("failed to get block info\n");
			}
			
		}


		MULTIMAP::iterator dest_iter;
		MULTIMAP::iterator dest_iter_end = bba.bba_get_dest_map_end();
			
		dest_iter = bba.bba_get_dest_map_begin();
		while (dest_iter != dest_iter_end) {
			printf("dest addr: %llx <- from %llx\n",
						base + dest_iter->first,
						base + dest_iter->second);

			dest_iter++;
		};

		if (bba.bba_write_output("example.bba") == OK)
			printf("write output file OK\n");
		else 
			printf("Failed to write output file\n");


	} else {
		printf("error in bba_analyze_all(), er = %d\n", rc);
	}
	
}
*/
