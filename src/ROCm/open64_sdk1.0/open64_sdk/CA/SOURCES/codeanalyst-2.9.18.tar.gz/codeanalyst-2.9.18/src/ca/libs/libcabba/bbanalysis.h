
/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef _LIBCABBA_H
#define _LIBCABBA_H

#include <stdio.h>
#include <stdlib.h>
#include <elf.h>

#include "datatype.h"

#include <list>
#include <map>
#include <set>
#include <string>

#ifdef HAVE_LIBELF_GELF_H
#include <libelf/gelf.h>
#include <libelf/libelf.h>
#else
#include <libelf.h>
#include <gelf.h>
#endif

using namespace std;
	
typedef list<unsigned int> OFFSETLIST;

// this set is used to hold the valid instruction offsets
typedef set<unsigned int> DATASET;


// this map is used to hold branch instruction and destination
// key is instruction offset 
typedef map<unsigned int, BR_INSTR_INFO> BRANCHINSTRMAP;



// this map to hold instructions that access memory.
// key is instruction offset
typedef map<unsigned int, MEMORYTYPE> MEMACCESSMAP;

struct BASIC_BLOCK_KEY
{
	unsigned int bb_start; // basic block start offset;

	bool operator < (const BASIC_BLOCK_KEY & other) const 
	{
		return bb_start > other.bb_start;
	};
};

typedef map<BASIC_BLOCK_KEY, BASIC_BLOCK_INFO> BLOCKMAP;

// key is section start offset, data is section end offset;
typedef map<BASIC_BLOCK_KEY, unsigned int> SECTIONMAP;

// key is destination offset, data is branch instr offset
typedef multimap<unsigned int, unsigned int>MULTIMAP;

class BBAnalysis 
{
public:
	BBAnalysis();
	~BBAnalysis();

	int bba_init(const char* filename);
        
	void bba_attach_info(OFFSETLIST samplesList);

	int bba_analyze_all();

	int bba_analyze_range(unsigned int startoffset, 
					unsigned int endoffset, bool );

	// void bba_add_loadstore_info();
	int bba_write_output(const char* filename);

	int bba_read_datafile(const char* filename);

	long long bba_get_image_base();

	int bba_get_block_num();

	int bba_get_basicblock_info(unsigned int offset, BASIC_BLOCK_INFO *pbbinfo);

	int bba_get_first_basicblock(BASIC_BLOCK_INFO *pbbinfo);
	int bba_get_next_basicblock(BASIC_BLOCK_INFO *pbbinfo);

	int bba_get_memory_accesses(unsigned int block_offset,
					unsigned int *pNumReads, unsigned int *pNumWrites);
	void bba_cleanup();

	// fast access
	BRANCHINSTRMAP* bba_get_jump_map() { return &m_jmp_map; };
	BRANCHINSTRMAP* bba_get_call_map() { return &m_call_map; };
	BRANCHINSTRMAP* bba_get_ret_map() { return &m_ret_map; };

	MEMACCESSMAP* bba_get_mem_map() { return &m_memacc_map;	};
	MULTIMAP* bba_get_br_dest_map() { return &m_br_dest_map; };
	
	BLOCKMAP* bba_get_block_map() { return &m_block_map;};

	BRANCHINSTRMAP::iterator bba_get_jump_map_end() { return m_jmp_map.end();};
	BRANCHINSTRMAP::iterator bba_get_jump_map_begin() { 
			return m_jmp_map.begin();};

	MULTIMAP::iterator bba_get_dest_map_end() {return m_br_dest_map.end();};
	MULTIMAP::iterator bba_get_dest_map_begin() {return m_br_dest_map.begin();};

	unsigned int bba_get_first_section_offset();

private:
	int initialize_elf(const char *filename);
	void cleanup_maps();

	int enumerate_symbols(const char *filename);

	int analyze_range(unsigned int start, unsigned int end);

	void updateMaps(BLOCKMAP blockMap, BRANCHINSTRMAP jmpMap,
					BRANCHINSTRMAP callMap, BRANCHINSTRMAP retMap,
					MEMACCESSMAP memAccMap);
	
	unsigned int addUnknownBlock(unsigned int start, unsigned int end, 
					unsigned int current);

	DATASET::iterator get_next_valid(unsigned int offset);	

	
	void validate_blocks();

	int				m_fd;
	Elf				*m_elf;
	long long		m_image_base;
	bool			m_32bit;

	BRANCHINSTRMAP	m_jmp_map;
	BRANCHINSTRMAP	m_call_map;
	BRANCHINSTRMAP	m_ret_map;
	MEMACCESSMAP	m_memacc_map;	
	SECTIONMAP		m_section_map;
	DATASET			m_valid_addr_set;
	
	BLOCKMAP		m_block_map;
	BLOCKMAP::iterator m_block_iter;

	// the key of m_br_src_map is branch instruction offset, 
	// the data of the map is destionation offset to file base
	//MULTIMAP		m_br_src_map;

	// the key of m_br_dest_map is destination of branch instruction, 
	// the data of the map is branch instruction offset to file base
	MULTIMAP		m_br_dest_map;

	string			m_modname;

};

#endif
