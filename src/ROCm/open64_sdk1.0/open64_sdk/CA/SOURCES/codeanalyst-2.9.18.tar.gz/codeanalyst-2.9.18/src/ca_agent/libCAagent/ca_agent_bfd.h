/**
 * @file ca_agent_bfd.h
 * Class header to write JIT code to elf file
 *
 * @remark Read the file COPYING
 *
 * @author Jason Yeh
 */


#ifndef CA_AGENT_BFD_H_
#define CA_AGENT_BFD_H_

#include <bfd.h>
#include <map>

class ca_agent_bfd
{
public:	
	ca_agent_bfd() {};
	
	~ca_agent_bfd() {};
	
	int write_symbol_content(const char * symbol_name, const void* code_addr, unsigned int size);

private:
	bfd *abfd;
	std::map<bfd_vma, unsigned int> regit_map;
		
};




#endif /*CA_AGENT_BFD_H_*/
