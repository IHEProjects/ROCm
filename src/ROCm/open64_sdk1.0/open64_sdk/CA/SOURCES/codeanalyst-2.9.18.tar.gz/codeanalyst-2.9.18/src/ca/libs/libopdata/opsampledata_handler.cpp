//$Id: opsampledata_handler.cpp $
// Interface for processing profile data using Oprofile interfaces.

/*
// CodeAnalyst for Open Source
// Copyright 2002 . 2009 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <vector>
#include <string>
#include <list>
#include <iomanip>

#include <sys/time.h>

// headers from Oprofile libop
#include "op_sample_file.h"

// headers from Oprofile libutil++
#include "op_bfd.h"
#include "string_filter.h"

// headers from Oprofile libpp
#include "profile.h"			// For class profile_t
#include "parse_filename.h"		// For struct parsed_filename
#include "arrange_profiles.h"		// For struct profile_classes 

// headers from Oprofile libregex
#include "demangle_symbol.h"		// For enum demangle_type 

// CodeAnalyst headers
#include "opsampledata_handler.h"
#include "proctree.h"
#include "tbswriter.h"
#include "dataagg.h"


using namespace std;


namespace options {
// NOTE: [Suravee] This is needed to uses libregex as 
// it is defined as extern in libregex/demangle_symbol.cpp
	demangle_type demangle;

// NOTE: [Suravee] This is needed as we uses it in function 
//       opsampledata_handler::read_op_module_data
       string_filter symbol_filter;
}

// NOTE: [Suravee] This is needed to uses libpp as 
// it is defined as extern in libpp/format_output.h
profile_classes classes;


//////////////////////

typedef list<string> stringList;


opsampledata_handler::opsampledata_handler()
: opdata_handler()
{
}


opsampledata_handler::~opsampledata_handler()
{
	reset_data();

	m_java_name_map.clear();
}


void opsampledata_handler::init(const char * op_data_dir, EventMaskEncodeMap evt_map)
{
	m_op_data_dir 		= op_data_dir;
	m_event_encode_map 	= evt_map;
}


void opsampledata_handler::enumeratefiles(QString dir, stringList & flist)
{
	QDir search_dir(dir);
	const QFileInfoList* itemlist = search_dir.entryInfoList(
						QDir::Dirs|QDir::Files, 
						QDir::DirsFirst | 
						QDir::Name);
	if (!itemlist)
		return;

	QFileInfoListIterator it(*itemlist);

	QFileInfo *fi = NULL;
	while ((fi = it.current()) != NULL) {
		++it;
		QString itemname = fi->fileName();
		if (itemname == "." || itemname == "..")
			continue;

		QString fullpath = fi->absFilePath();

		if (fi->isFile()) {
			flist.push_back(fullpath.data());
		} 

		if (fi->isDir()) {
			enumeratefiles(fullpath, flist);
		}

	}
}


bool opsampledata_handler::read_op_module_data(QStringList task_filter )
{	
	bool ret = false;
	string cur_taskname;
	unsigned int cur_taskid = 0;
	string cur_modname; 
	SampleDataMap taskSampMap;

	MODULE_SUMMARY_TYPE mod_data;
	string binarypath;
	string converted;
	SampleDetail *pDetailedMap = NULL;

	op_bfd *p_bfd = NULL;
	unsigned long long jitAddr = 0;
	int jitId = -1;
	unsigned int filesize = 0;

#ifdef __x86_64__	
	unsigned int bitness = ev64bit;
#else
	unsigned int bitness = ev32bit;
#endif
	stringList flist;
	enumeratefiles(m_op_data_dir, flist);
	if(flist.size() > 0)
		ret = true;

	/* For each sample file */
	stringList::iterator f_it = flist.begin();
	stringList::iterator f_it_end = flist.end();
	for (;f_it != f_it_end; f_it++) {

		parsed_filename parsed;
		try {
#if OP_VERSION_BASE > 0x00903
			extra_images extra;
			parsed = parse_filename(f_it->c_str(),extra);
//			fprintf(stderr,"DEBUG: image = %s\n",parsed.image.c_str());
//			fprintf(stderr,"DEBUG: lib_image= %s\n",parsed.lib_image.c_str());
//			fprintf(stderr,"DEBUG: filename = %s\n",parsed.filename.c_str());
//			fprintf(stderr,"DEBUG: jit_dumpfile_exists= %s\n",(parsed.jit_dumpfile_exists)?"yes":"no");
#else
			parsed = parse_filename(f_it->c_str());
//			fprintf(stderr,"DEBUG: image = %s\n",parsed.image.c_str());
//			fprintf(stderr,"DEBUG: lib_image= %s\n",parsed.lib_image.c_str());
//			fprintf(stderr,"DEBUG: filename = %s\n",parsed.filename.c_str());
#endif
		} catch (invalid_argument const & e) {
			// This is not oprofile data file;
			continue;
		}

		// filter call graph file
		if (!parsed.cg_image.empty())
			continue;

		// filter tasks
		if (task_filter.size()) {
			bool found = false;
			QStringList::iterator f_it= task_filter.begin();
			QStringList::iterator  f_it_end = task_filter.end();
			for (;f_it!= f_it_end; f_it++) {
				if (!(*f_it).compare(parsed.image.c_str())) {
					found = true;
					break;
				}
			}
			if (!found)
				continue;
		}

		if (parsed.lib_image.empty())
			parsed.lib_image = parsed.image;

		// task level 
		if (cur_taskname != parsed.image) {
			// update task id;
			if (cur_taskid != 0) {
				//update previous task summary;
				addTaskData(cur_taskname, cur_taskid, bitness, taskSampMap);
			}
			
			// clear previous task sample data
			taskSampMap.clear();
			cur_taskid++;
			cur_taskname = parsed.image;
			binarypath = "";
			bitness = getTaskBitness(cur_taskname);

			// update GUI for data processing
			if (m_ca_display) {
				m_ca_display->update_display(
					"\n============================\n");
				string t_str = "Processing Task: " + cur_taskname;
				m_ca_display->update_display((t_str.c_str()));
			}
		}

		// Checking for Java modules
		bool bJava = false;	
		bJava = isJavaApp(parsed.lib_image, converted);

		// Getting new module summary if module/task changed;
		if ( cur_modname != converted
		||   cur_taskid  != mod_data.taskid) {
			if (!cur_modname.empty()) {
				SampleDataMap::iterator it = mod_data.sampMap.begin();
				SampleDataMap::iterator it_end = mod_data.sampMap.end();
				for(; it != it_end; it++) 
					mod_data.total += it->second;
				m_mod_summary.push_back(mod_data);
			}
			
			mod_data.taskid  = cur_taskid;
			mod_data.total   = 0;
			mod_data.bitness = bitness;
			mod_data.name    = converted;
			mod_data.modtype = (bJava)? JAVAMODULE : UNMANAGEDPE;
			mod_data.sampMap.clear();

			// update GUI progress	
			cur_modname = converted;
			if (m_ca_display)
				m_ca_display->update_display((cur_modname.c_str()));

			// Adding to m_mod_detail
			pDetailedMap = getDetailMap(cur_modname);
		}
		
		// Check if the bianry changes
		if (binarypath != parsed.lib_image) {
			if (p_bfd) {
				delete p_bfd;
				p_bfd = NULL;
			}

			bool ok = true;
			binarypath = parsed.lib_image;
#if OP_VERSION_BASE > 0x00903
			extra_images extra;
			p_bfd = new op_bfd(parsed.lib_image, 
						options::symbol_filter,
						extra,
						ok);
#else // OPROFILE_0_9_3
			p_bfd = new op_bfd("", parsed.lib_image, 
						options::symbol_filter, ok);
#endif

			// TODO: [Suravee] Handling error here??
			if (!ok) {
				if(p_bfd) {
					delete p_bfd;
					p_bfd = NULL;
				}
			}

			string jitSym;
			jitAddr = 0;
			filesize = 0;
			if (bJava) {
				// Update jitDetailVec ;
				getJitInfo(p_bfd, parsed.lib_image, 
					&jitSym, &jitAddr, &filesize);
				
				jitDetail jDetail(jitAddr, filesize, jitSym, parsed.lib_image); 
				m_jitDetailVec.push_back(jDetail);
				jitId++;
			} else {
				QFile binfile(parsed.lib_image);
				if (binfile.open(IO_ReadOnly)) {
					filesize = binfile.size();
					binfile.close();
				}
			}
		}

		// detailed module sample aggregation;
		SampleDataMap oneFileTotal;
		oneFileTotal.clear();
	   	if (!processOneOpDataFile(parsed, 
					p_bfd, 
					cur_taskid, 
					bJava, 
					jitId, 
					jitAddr, 
					filesize,
					pDetailedMap, 
					oneFileTotal)) {
		//	string t_str = "Failed to process " + parsed.lib_image;
		//	if (m_ca_display)
		//		m_ca_display->update_display(t_str.c_str());
		
			continue;
		}

		// Aggregate total	
		if (oneFileTotal.size()) {	
			AggregateSamples(mod_data.sampMap, oneFileTotal);	
			AggregateSamples(taskSampMap, oneFileTotal);	
		}
	}

	//update last task summary;
	if (cur_taskid != 0) {
		addTaskData(cur_taskname, cur_taskid, bitness, taskSampMap);
	}
	
	//update last module summary;
	if (!cur_modname.empty()) {
		SampleDataMap::iterator it = mod_data.sampMap.begin();
		SampleDataMap::iterator it_end = mod_data.sampMap.end();
		for(; it != it_end; it++) 
			mod_data.total += it->second;

		m_mod_summary.push_back(mod_data);
	}	

	if (m_ca_display)
		m_ca_display->display_oprofile_log();

	if (p_bfd) {
		delete p_bfd;
		p_bfd = NULL;
	}

	//dumpresult();
	return ret;
} //opsampledata_handler::read_op_module_data


bool opsampledata_handler::isJoFile(parsed_filename parsed)
{
	unsigned long loc = parsed.lib_image.rfind(".jo",parsed.lib_image.length(),3);	
	return (loc != string::npos);
}


bool opsampledata_handler::processOneOpDataFile( parsed_filename parsed, 
						op_bfd *p_bfd, 
						unsigned int pid, 
						bool bJava, 
						int jitId, 
						unsigned long long jitAddr, 
						unsigned int filesize, 
						SampleDetail *pDetailMap, 
						SampleDataMap &totalData)
{	
	if (parsed.filename.empty())
		return false;

	// convert event string into index and CPU string into number
	SampleKey sampKey;
	if (!convertSampKey(parsed, sampKey)) {
		return false;
	}

	unsigned int total = 0;

	bool bJo = isJoFile(parsed);

	profile_t samplefile;
	samplefile.add_sample_file(parsed.filename);
	if (p_bfd)
		samplefile.set_offset(*p_bfd);
		
	profile_t::iterator_pair p_it = samplefile.samples_range();
	for (;p_it.first != p_it.second; ++p_it.first) {
		
		unsigned int cnt = p_it.first.count();
	
		/* no-vmlinux */	
		if (parsed.lib_image == "/no-vmlinux") {
			total += cnt;
			continue;
		}
	
		unsigned int offset = p_it.first.vma();

		/* Handling error when offset is larger than filesize */
		if (filesize != 0 
		&& !bJava
		&& !bJo
		&& offset > filesize) {
			m_missed++;
			continue;
		}

		/* Sometimes samples fall into the memeory area where 
		 * anon:[vdso] is being map. These files does not exist.
		 * Therefore, we ignore them.
		 */
		if(filesize == 0) {
			total += cnt;
			continue;
		}

		SampleDataMap t_data;
		t_data.insert(SampleDataMap::value_type(sampKey, cnt));

		Detail_Key d_key;
		d_key.taskId = pid;

		if (p_bfd && !bJo) {
			// aggregate module detail sample 
			d_key.rip = p_bfd->offset_to_pc(p_it.first.vma());
		} else {
			// the module binary does not exist;
			// no need to aggregate module detail samples
			d_key.rip = p_it.first.vma();
		}

		if (bJava && p_bfd) {
			// Jnc file
			
			// TODO: [Suravee] I don't think we need this but check with Lei.
			// This must be consistent with the daemon side (opd_trans.c and opd_caagent.cpp).

			// get the offset of first section which is .text 
//			unsigned int header_offset = 0;
//			header_offset = p_bfd->get_start_offset(0);

			// when daemon write data into oprofile data file. The offset
			// is relative to image base.
			// we will take the jnc file header off. 
			d_key.jitId = jitId; 
			d_key.rip   = jitAddr + p_it.first.vma();
//			d_key.rip   = jitAddr + p_it.first.vma() - header_offset;
			if (d_key.rip < jitAddr ||  d_key.rip >= jitAddr + filesize) {
#ifdef CA_ENABLE_DEBUG
				fprintf(stderr,
					"WARNING: rip:%llx is out of range (%llx - %llx), vma:%llx ,filename %s\n",
					d_key.rip, jitAddr, jitAddr + filesize, p_it.first.vma(), parsed.filename.c_str());
#endif //CA_ENABLE_DEBUG
				continue;
			}
		}

		SampleDetail::iterator sd_it = pDetailMap->find(d_key);
		if (sd_it != pDetailMap->end()) {
			AggregateSamples(sd_it->second, t_data); 
			total += cnt;
		} else {
			pDetailMap->insert(SampleDetail::value_type(d_key, t_data));
			total += cnt;
		}	
	}
	
	totalData.insert(SampleDataMap::value_type(sampKey, total));
	return true;
} //opsampledata_handler::processOneOpDataFile


bool opsampledata_handler::isJavaApp(string modname, string &converted)
{
	QString name = modname; 

	if (!name.startsWith("/var/lib/oprofile/jit/")) {
		// this is non-java module
		converted = modname;
		return false;
	} else {
		// this is java module;
		unsigned int java_id = name.section("/", 5, 5).toUInt();

		// find java app argument;
		java_app_name_map::iterator it = m_java_name_map.find(java_id);
		if (it == m_java_name_map.end()) {
			// new java app
			QString logname;
			logname.sprintf("/var/lib/oprofile/Java/%d", java_id);
			QFile logfile (logname);
			if (logfile.open(IO_ReadOnly)) {
				QString launch_arg;
				logfile.readLine(launch_arg, Q_ULONG(1024));
				logfile.close();
				launch_arg = launch_arg.stripWhiteSpace() + "(" +
					QString::number(java_id) + ")";	

				converted = launch_arg.data();

			} else {
				name = "Unknow Java App pid(" + 
					QString::number(java_id) + ")";
				converted = name.data();
			}
			m_java_name_map.insert(java_app_name_map::value_type(
						java_id, converted));
		} else {
			converted = it->second;
		}
	}

	return true;
}


bool opsampledata_handler::convertSampKey(parsed_filename parsed, SampleKey &key)
{
	bool bRet = false;

	string str = "event:" + parsed.event + 
				" count:" + parsed.count + 
				" unit-mask:" + parsed.unitmask;
	EventMaskEncodeMap::iterator it = m_event_encode_map.find(str);
	if (it == m_event_encode_map.end()) {
		return false;
	}
	key.event = it->second.sortedIndex;

	//i.e cpu1
	QString cpu_str = parsed.cpu;
	key.cpu = cpu_str.toInt();
	bRet = true;

	return bRet;
}


bool opsampledata_handler::getJitInfo(op_bfd *p_bfd, string jitfile, 
			string *p_str, unsigned long long *p_addr, 
			unsigned int *p_size)
{
	bool bRet = false;

	string str;	
	unsigned long long addr = 0;
	unsigned int size = 0;
	*p_size = 0;

	if (!p_bfd) 
		return bRet;

	if(p_bfd->syms.size()) {
#if OP_VERSION_BASE > 0x00903
		unsigned long long start = 0;
		unsigned long long end = 0;
#else // OPROFILE_O_9_3
		unsigned long start = 0;
		unsigned long end = 0;
#endif
		str  = p_bfd->syms[0].name();
		addr = p_bfd->offset_to_pc(start);

		p_bfd->get_symbol_range((symbol_index_t) 0, start, end);
		if (end > start) {
			size = end - start;
		}
	}

	if ( addr == 0 || str.empty()) {
		// if previous action failed, try to parse the file
		QString t = jitfile.c_str();

		// i.e. /var/lib/oprofile/jit/1776/2aaaab8eb760-0
		// will be truncate into 2aaaab8eb760-0
		t = t.section('/', -1);
		if (str.empty())
			str = t.ascii();

		// into 2aaaab8eb760 
		t = t.section('-', 0,0);
		addr = (unsigned long long) t.toULongLong(NULL, 16);
	}

	*p_str  = str;
	*p_addr = addr;
	*p_size = size;

#if OP_VERSION_BASE > 0x00903
		//fprintf(stderr, "getJitInfo: %s, sym:%s, addr:%llx, size = %x\n", 
		//		jitfile.c_str(), str.c_str(), addr, size);
#else // OPROFILE_O_9_3
		//fprintf(stderr, "getJitInfo: %s, sym:%s, addr:%lx, size = %x\n", 
		//		jitfile.c_str(), str.c_str(), addr, size);
#endif

	return true;
}


void opsampledata_handler::dumpDataMap(SampleDataMap &data)
{
	SampleDataMap::iterator it = data.begin();
	SampleDataMap::iterator it_end = data.end();
	for(; it != it_end; it++) {
		printf("[%d %llu] %u, ", 	it->first.cpu, 
			(unsigned long long) it->first.event, it->second);
	}
	printf("\n");
}


void opsampledata_handler::dumpresult()
{
	//dump process info
	printf("Task section\n");
	task_summary_map::iterator t_it = m_task_summary.begin();	
	task_summary_map::iterator t_it_end = m_task_summary.end();	
	for (; t_it != t_it_end; t_it++) {
		printf("%d, %s, %llu\n", t_it->second.taskid, 
				t_it->first.c_str(), t_it->second.total);
	}


	printf("Module section\n");
	mod_summary_list::iterator m_it = m_mod_summary.begin();
	mod_summary_list::iterator m_it_end = m_mod_summary.end();
	for (; m_it != m_it_end; m_it++) {
		printf("tid = %d, type=%d, total=%llu, %s\n",
			m_it->taskid, m_it->modtype, m_it->total, m_it->name.c_str());
	}


	printf("Module Detail\n");
	MOD_DETAIL_MAP::iterator md_it = m_mod_detail.begin();
	MOD_DETAIL_MAP::iterator md_it_end = m_mod_detail.end();
	for(; md_it != md_it_end; md_it++) {
		printf("modname = %s\n", md_it->first.c_str());
		SampleDetail::iterator sd_it = md_it->second.begin();
		SampleDetail::iterator sd_end = md_it->second.end();
		for (; sd_it != sd_end; sd_it++) {
			printf("addr = %llx, tid=%u", 
					sd_it->first.rip, sd_it->first.taskId);
			
			dumpDataMap(sd_it->second);
		}
	}


	printf("jit Detail Vector\n");
	jitDetailVec::iterator j_it = m_jitDetailVec.begin();
	jitDetailVec::iterator j_it_end = m_jitDetailVec.end();
	for(; j_it != j_it_end; j_it++) {
	printf("JitBlk: %s: %s: %llx: %u\n",
		(*j_it).jncFile.c_str(),
		(*j_it).jitSym.c_str(),
		(*j_it).jitAddr,
		(*j_it).jitSize);
	}
}
