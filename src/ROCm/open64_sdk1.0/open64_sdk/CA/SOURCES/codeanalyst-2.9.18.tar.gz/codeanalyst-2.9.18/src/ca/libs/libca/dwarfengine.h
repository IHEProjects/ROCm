// $Id: dwarfengine.h 12095 2007-05-02 18:18:09Z jyeh $

/*
// CodeAnalyst for Open Source
// Copyright 2008 Advanced Micro Devices, Inc.
// You may redistribute this program and/or modify this program under the terms
// of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later 
// version.
//
// This program is distributed WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
// Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#ifndef __DWARFENGINE_H__
#define __DWARFENGINE_H__

#include <string>
#include <vector>
#include <map>
#include <list>

#include "dwarf.h"
#include "libdwarf.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////
/*
 * INTERNAL STRUCTURES
 */

/*
 * Structure to hold Dwarf key
 */
typedef struct _ADDRESSKEY
{
	Dwarf_Addr startAddr;
	Dwarf_Addr stopAddr;

	_ADDRESSKEY()
	{
		startAddr = 0;
		stopAddr = 0;
	};	

	// Note: address key is sorted in descending order;
	// to make easy search in the map
	bool operator < (const struct _ADDRESSKEY & other) const 
	{
		if(startAddr < other.startAddr)
		{
			return true;	
		}
		else if (startAddr == other.startAddr)
		{
			// If stopAddr == other.stopAddr,
			// we say that its less than because???
			//if(stopAddr <= other.stopAddr)
			if(stopAddr < other.stopAddr)
				return true;
			else
				return false;
		}
		else
		{
			return false;
		}
	};

} ADDRESSKEY;

/*
 * Structure to hold function's inline information
 */
typedef struct _SUBROUTINE
{
	string		symName;
	unsigned int	numInline; 
	Dwarf_Off 	gOff;
	_SUBROUTINE()
	{
		numInline = 0;	
		gOff = 0;
	};
} SUBROUTINE;

typedef map<ADDRESSKEY, SUBROUTINE> SUBROUTINEMAP;


/*
 * Structure to hold inline instance information
 */
typedef struct _INLINEROUTINE
{
	string		symName;
	Dwarf_Addr 	parentAddr;
	Dwarf_Off 	gOff;
	unsigned int	callLineNo;
	unsigned int	callFileNo;
	_INLINEROUTINE()
	{
		parentAddr = 0;
		gOff = 0;
		callLineNo = 0;
		callFileNo = 0;
	};
} INLINEROUTINE;

typedef map<ADDRESSKEY, INLINEROUTINE> INLINEROUTINEMAP;


/*
 * Structure to hold file / line number information
 */
typedef struct _FILELINE
{
	string		fileName;
	unsigned int	lineNo;
	_FILELINE()
	{
		fileName = "";
		lineNo = 0;	
	};
} FILELINE;

typedef map<Dwarf_Addr , FILELINE> 	ADDRLINEMAP; 
typedef map<Dwarf_Off  , ADDRLINEMAP> 	CULINEINFOMAP;
typedef std::vector<string> 		FILENAMEVEC;	
typedef map<Dwarf_Off  , FILENAMEVEC> 	CUFILENAMEVECMAP; 

////////////////////////////////////////////////////////////////////////////
/*
 * EXTERNAL STRUCTURES
 */
typedef struct _DW_sym_info
{
	unsigned long	startAddr;
	unsigned long	stopAddr;
	string		symName;
	Dwarf_Off	symId;	

	_DW_sym_info()
	{
		startAddr = 0;
		stopAddr  = 0;
		symId     = 0;
	};
} DW_sym_info;

typedef std::vector<DW_sym_info*> DW_SYM_INFO_VEC;

extern void delete_DW_SYM_INFO_VEC(DW_SYM_INFO_VEC &vec);

////////////////////////////////////////////////////////////////////////////

/*
 * Class CDwarfEngine Declaration
 */
class CDwarfEngine
{
public:
	CDwarfEngine();
	
	~CDwarfEngine();	

	int readDwarfFile(const char* fileName, bool inlineFlag = false);
	
	int dumpSymbolMap(FILE* file);

	int getSymbolForId(Dwarf_Off id, DW_sym_info *symbolInfo);

	int getInlineForId(Dwarf_Off id, DW_sym_info *inlineInfo);	

	int getSymbolForAddr(Dwarf_Addr addr,
				DW_sym_info *symbolInfo,
				DW_sym_info *inlineInfo);	

	int getNumInline(Dwarf_Addr startAddr);

	int getInlinesForFunction(Dwarf_Addr startAddr, DW_SYM_INFO_VEC &inlines);

	int getLineInfoForAddr(Dwarf_Addr addr, 
				string *fileName, 
				unsigned int *linenum,
				bool isCaller);

	int getFileForId(Dwarf_Off id, string *fileName);

	int getStartLineForId(Dwarf_Off id, unsigned int *linenum);

//	int getFileForAddr(Dwarf_Addr addr, string *fileName);

//	int getLineForAddr(Dwarf_Addr addr, unsigned int *linenum);

private:
	unsigned long int _getCuOff(Dwarf_Off id);

	int _populateFileNameVecForCu(Dwarf_Off cuOff);

	int _populateLineInfoMapForCu(Dwarf_Off cuOff);

	void Cleanup();

	int process_one_die( Dwarf_Die oneDie);

	int get_DW_sym_info( Dwarf_Die symDIE,
					ADDRESSKEY *addrKey,
					string *symName,
					Dwarf_Off *gOff);

	int get_DW_symbol_name_attr( Dwarf_Die die, string* pstr );

	int get_DW_mangled_name( Dwarf_Die die, string* mangledName);
	
	int get_DW_inline_sym_info( Dwarf_Die funcDIE,
					Dwarf_Addr parentAddr);

	int get_DW_inline_call_line_file(Dwarf_Die die, 
					unsigned int *callFileNo, 
					unsigned int *callLineNo);

	int get_DW_sym_from_abstract_origin( Dwarf_Die subDIE, 
					string *symstring,
					Dwarf_Off *gOff);

	int get_DW_sym_from_specification( Dwarf_Die subDIE, 
					string *symstring,
					Dwarf_Off *gOff);

	int get_DW_decl_file_attr( Dwarf_Die die,
					Dwarf_Unsigned *fileNo);

	int get_DW_decl_line_attr( Dwarf_Die die,
					Dwarf_Unsigned *lineNo);

	int get_DW_call_file_attr( Dwarf_Die die,
					Dwarf_Unsigned *fileNo);

	int get_DW_call_line_attr( Dwarf_Die die,
					Dwarf_Unsigned *lineNo);

	int get_DW_symbol_low_high_pc( Dwarf_Die die, 
					Dwarf_Addr *low,
					Dwarf_Addr *high);

	int get_DW_inline_low_high_in_sibling_lexical(Dwarf_Die die,
							Dwarf_Addr *low,
							Dwarf_Addr *high);

	int get_DW_inline_low_high_in_child_lexical(Dwarf_Die die,
							Dwarf_Addr *low,
							Dwarf_Addr *high);


	int find_level1_die( ADDRESSKEY addrKey, 
					Dwarf_Die *die1 );

	int find_level2plus_die( ADDRESSKEY inlineKey, 
					Dwarf_Die *die2 );

	int find_abstract_origin_die( Dwarf_Die die, 
					Dwarf_Die *aboDIE);

	int find_specification_die( Dwarf_Die subDIE, 
					Dwarf_Die *spcDIE);

	SUBROUTINEMAP::iterator find_func_from_id(Dwarf_Off id);

	INLINEROUTINEMAP::iterator find_inline_from_id(Dwarf_Off gOff);

	SUBROUTINEMAP::iterator find_func_from_addr(Dwarf_Addr addr);

	int getLineInfo(ADDRESSKEY symAddr, 
				ADDRESSKEY inlineAddr, 
				string *fileName, 
				unsigned int *lineNum);
private:
	int 		m_fd;		// to hold file descriptor;	
	Dwarf_Debug	m_dbg;
	bool		m_inlineFlag;	// indicate if query inline function
	SUBROUTINEMAP	m_routineMap;	// this is to hold level 1 functions
	INLINEROUTINEMAP m_inlineMap;	// this is to hold inline instances
	CULINEINFOMAP	m_cuLineInfoMap;
	CUFILENAMEVECMAP m_cuFileNameVecMap;		
};

#endif /*__DWARFENGINE_H__ */

