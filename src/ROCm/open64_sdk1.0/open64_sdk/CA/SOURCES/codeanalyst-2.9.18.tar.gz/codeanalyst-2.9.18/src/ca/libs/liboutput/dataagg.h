#ifndef _DATA_AGG_H_
#define _DATA_AGG_H_
#include "stdafx.h"

unsigned long AggregateSamples(SampleDataMap &destMap,
				                SampleDataMap &sourceMap);

#endif

